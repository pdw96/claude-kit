<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.1230679 -->

`/pr-review-toolkit:review-pr`를 불러 관점을 지정했지만 리뷰 에이전트는 따로 돌리지 않았습니다. 저장소가 파일 11개로 작아서 전부 직접 읽었습니다. Bash가 막혀 있어 코드를 실행하거나 DB에 붙여 보지는 못했고, 아래는 모두 코드를 읽고 내린 판단입니다. 코드는 수정하지 않았습니다.

## 중대

1. **직렬화 실패를 재시도하지 않습니다.**
   - 자리: `app/db.py:9`, `app/main.py:16-29`
   - 까닭: 엔진 전체가 `SERIALIZABLE`인데, 동시 대출이 충돌해 Postgres가 SQLSTATE 40001(`SerializationFailure`)을 내면 재시도하는 곳이 없습니다.
   - 충돌한 요청은 그대로 500이 됩니다. `RefusedLoan`(422)과도 구분되지 않습니다.
   - docs 원칙 3("하나만 선다")은 "나머지는 오류가 된다"는 뜻이 되고, 인기 도서에서는 자주 일어납니다.
   - 재시도 루프나 40001 → 409/503 변환이 필요합니다.

2. **커밋 실패가 클라이언트에게 성공으로 보일 수 있습니다.** (확인 필요)
   - 자리: `app/main.py:21-24`, 그리고 `requirements.txt`의 FastAPI 0.141.1
   - 까닭: `session.commit()`이 `yield` 뒤 의존성 종료 코드에 있습니다. SERIALIZABLE에서는 충돌이 커밋 시점에도 드러납니다.
   - 최근 FastAPI에서는 yield 의존성의 종료 코드가 응답을 보낸 뒤에 실행될 수 있습니다. 그러면 201을 이미 보낸 뒤 커밋이 실패해, 클라이언트는 대출이 성공했다고 믿지만 DB에는 없습니다.
   - 이 버전의 실제 동작은 실행해서 확인하지 못했습니다.
   - 안전하게 하려면 커밋을 엔드포인트 안(응답 전)에서 하거나, 서비스 호출 쪽에서 `with session.begin()`으로 트랜잭션 경계를 잡아야 합니다.

3. **반납 경로가 없어 `available_copies`가 줄기만 합니다.**
   - 자리: `app/services/loans.py`(`lend`만 있음), `app/main.py`(POST /loans만 있음), `docs/schema.md:7-8`
   - 까닭: docs는 "반납하면 `returned_on`이 찬다"고 하지만, `returned_on`을 채우고 `available_copies`를 되올리는 코드가 없습니다.
   - 반납을 나중에 손으로 구현하면 원칙 1(대출 줄과 권수가 함께 움직임)이 반납 쪽에서는 보장되지 않습니다.
   - 지금 상태로는 책이 한 번 나가면 영영 돌아오지 않습니다.

## 중요

4. **`available_copies`는 파생값인데 정합성 장치가 없습니다.**
   - 자리: `app/models.py:26`, `migrations/0001_initial.py:24`
   - 까닭: 총 소장 권수 컬럼이 없습니다. CHECK는 `>= 0`만 막고 상한이 없어서, 값이 소장 수보다 커져도 아무것도 잡지 못합니다.
   - 미반납 대출 수(`returned_on IS NULL`)와 대조해 검증하거나 복구할 기준도 없습니다.

5. **대출일을 클라이언트가 정합니다.**
   - 자리: `app/schemas.py:9`, `app/services/loans.py:44-45`
   - 까닭: `loaned_on`을 요청 본문에서 받고 `due_on`도 그 값에서 계산합니다. 과거나 미래 날짜로 연체를 피하거나 만들 수 있습니다.
   - 서버 날짜로 정하는 편이 맞습니다.

6. **`loan_days`에 검증이 없습니다.**
   - 자리: `app/models.py:25`, `migrations/0001_initial.py:23`
   - 까닭: `loan_days <= 0`이나 음수면 `due_on < loaned_on`이 되어 `loans_due_after_loan` 제약을 위반합니다.
   - `lend`는 이를 `RefusedLoan`이 아니라 `IntegrityError`(500)로 맞습니다. 그 책은 영영 빌릴 수 없고, 원인이 로그에만 남습니다.
   - `CHECK (loan_days > 0)`가 필요합니다.

7. **`downgrade`가 대출 기록만 보호합니다.**
   - 자리: `migrations/0001_initial.py:39-46`
   - 까닭: 주석은 "지우면 되살릴 길이 없다"고 하는데, `loans`가 비어 있기만 하면 `members`와 `books`는 데이터가 있어도 그대로 `drop_table`합니다. 회원과 도서 목록이 소리 없이 사라집니다.
   - 같은 이유로 세 테이블 중 어느 하나라도 행이 있으면 거부해야 앞뒤가 맞습니다.
   - 검사와 삭제 사이에 잠금이 없는 문제도 있습니다. 작은 위험이지만 대출이 그 틈에 들어올 수 있습니다.

8. **Alembic 실행 환경이 저장소에 없습니다.**
   - 자리: `migrations/`
   - 까닭: `env.py`, `script.py.mako`, `alembic.ini`가 없어 `alembic upgrade`를 그대로는 돌릴 수 없습니다.
   - `Base.metadata`와 마이그레이션이 어긋나는지 잡는 장치(autogenerate 비교)도 없습니다. 지금은 `models.py`와 `0001`이 손으로 이중 관리되고 있습니다.

## 보통

9. **같은 회원이 같은 책을 중복 대출할 수 있습니다.**
   - 자리: `app/models.py:29-38`
   - 까닭: 미반납 대출에 대한 부분 유니크 인덱스(`member_id, book_id WHERE returned_on IS NULL`)나 회원당 대출 한도가 없습니다.
   - 같은 요청을 재전송하면 권수가 두 번 줄고 대출 줄도 두 개 생깁니다. 멱등 키도 없습니다.

10. **외래키와 조회 컬럼에 인덱스가 없습니다.**
    - 자리: `loans.book_id`, `loans.member_id`, `loans.returned_on` (`models.py:34-38`, `0001:30-34`)
    - 까닭: Postgres는 FK에 자동으로 인덱스를 만들지 않습니다.
    - 반납이나 연체 조회가 풀스캔이 되고, SERIALIZABLE에서는 읽기 범위가 넓어져 서로 충돌하는 직렬화 실패가 늘어납니다.

11. **`returned_on`에 제약이 없습니다.**
    - 자리: `app/models.py:31, 38`
    - 까닭: `returned_on >= loaned_on` CHECK가 없습니다.

12. **ISBN 형식 검증이 없습니다.**
    - 자리: `app/schemas.py:7`, `app/models.py:23`
    - 까닭: 길이 10~13만 보고, 같은 책의 ISBN-10과 ISBN-13이 서로 다른 행으로 들어갈 수 있습니다. 유니크가 문자열 기준이기 때문입니다.

13. **DB 오류가 422/409로 매핑되지 않습니다.**
    - 자리: `app/main.py:35-42`
    - 까닭: `RefusedLoan`만 잡습니다. `IntegrityError`(CHECK/FK 위반)와 `OperationalError`(연결 끊김)는 모두 일반 500으로 나갑니다.
    - 롤백은 `session_scope`에서 되지만, 호출자는 원인을 알 수 없습니다.

## 참고

- 테스트가 하나도 없습니다. 동시 대출, 롤백, 마이그레이션 up/down 모두 검증되지 않습니다.
- 잘 된 점:
  - 요청 하나가 트랜잭션 하나이고 예외 시 롤백합니다.
  - CHECK가 앱 로직 뒤의 마지막 방어선으로 있습니다.
  - 회원을 지우지 않고 `is_active`로 끕니다.
  - `downgrade`가 최소한 대출 기록은 보호합니다.
