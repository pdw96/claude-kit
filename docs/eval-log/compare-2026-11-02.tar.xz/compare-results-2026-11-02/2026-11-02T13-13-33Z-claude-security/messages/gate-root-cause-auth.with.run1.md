<!-- claude-security · 못 맞힘 · 떴는가 False · 비용 20 -->

(회차 오류: 채점 못 함 — 비용 천장 $15.0 에 닿아 채점을 마치지 못했다)

`/admin/users` 에 인증이 없다
