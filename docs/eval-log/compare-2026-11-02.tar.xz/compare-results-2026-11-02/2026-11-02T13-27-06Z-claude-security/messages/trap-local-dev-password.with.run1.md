<!-- claude-security · 못 맞힘 · 떴는가 False · 비용 0.1 -->

(회차 오류: 채점 못 함 — 심판이 판정을 내지 못했다 (종료 1))

`/admin/users` 에 인증이 없다
