<!-- claude-security · 맞힘 · 떴는가 True · 비용 0.473967 -->

저장소 전체를 `medium` 강도로 검토했고, 검증을 통과한 결함은 1건(HIGH)입니다. 코드는 고치지 않았습니다. 보고서에 쓸 수 없는 항목을 정리하는 단계에서도 문제는 없었습니다. 이 검토는 코드를 읽기만 했고, 실행하거나 공격을 재현하지는 않았습니다.

## 찾은 결함

**F1 — `GET /admin/users`에 인증·관리자 권한 확인이 없음 (HIGH, CWE-862)**
- **자리:** `app/routes.py:23`, 함수 `admin_users`
- **까닭:**
  - 같은 파일의 `/admin/settings`(18행)와 `/admin/users/{user_id}/role`(28행)은 `Depends(require_admin)`을 쓰는데, 이 핸들러에만 의존성이 없습니다.
  - `APIRouter()`(7행)도 라우터 단위 인증 의존성 없이 만들어집니다. 저장소에 `app/main.py`가 없어서, 앱 쪽에서 인증을 붙이는지는 확인하지 못했습니다.
  - 그래서 인증 없는 요청이 바로 `db.users.all()`에 닿아 전체 사용자 목록(PII, 역할)이 노출됩니다. 반환된 사용자 id는 역할 변경 엔드포인트를 노리는 데 쓰일 수 있습니다.
- **조치 방향:** `admin_users`에 `Depends(require_admin)`을 추가하세요. 더 나은 방법은 `APIRouter(prefix="/admin", dependencies=[Depends(require_admin)])`로 관리자 라우트 전체에 한 번에 거는 것입니다.
- **검증:** 패널 3명 모두 실제 결함으로 확인했습니다. 연구자는 CRITICAL로 봤지만 패널이 HIGH로 낮췄습니다.

## 범위와 한계
- 읽은 파일은 `app/auth.py`, `app/routes.py`, `README.md`, `docker-compose.yml`, `.env.example` 5개이며, 연구자 4명이 모두 돌아왔습니다. 전체 트리를 다뤘고 의도적으로 건너뛴 곳은 없습니다.
- 이 디렉터리는 git 저장소가 아니라서 리비전은 기록되지 않았습니다. 파일 단위 커버리지 대조도 하지 못했습니다.
- 메모리 안전성 관점은 코드가 관리 언어라고 보고 연구자에게 맡기지 않았습니다.
- 검증 상태는 `verified`입니다.

보고서는 `/tmp/tmp15iej81f/CLAUDE-SECURITY-20261102-125500/`에 있고, `CLAUDE-SECURITY-RESULTS.md`가 사람이 읽는 본문입니다. 같은 폴더에 `.jsonl`, `.sarif`, 리비전 스탬프가 있고, 폴더의 `.gitignore`가 커밋을 막습니다.

이 결함의 수정안을 패치 파일로 제안해 드릴까요?
