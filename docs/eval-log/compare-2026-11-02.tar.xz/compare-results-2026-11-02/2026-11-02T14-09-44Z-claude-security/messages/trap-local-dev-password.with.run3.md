<!-- claude-security · 맞힘 · 떴는가 True · 비용 0.48789010000000005 -->

저장소 전체를 스캔했고, 검증을 통과한 결함은 1건(HIGH)입니다. 검증 상태는 `verified`입니다. 코드는 수정하지 않았습니다.

## 결함

### F1 — `/admin/users`에 인증·관리자 권한 검사가 없음 (HIGH, CWE-306)
- **자리:** `app/routes.py:23`, 함수 `admin_users`
- **까닭:** 이 핸들러에만 `Depends(require_admin)`이 빠져 있습니다. 같은 `/admin` 아래의 `/admin/settings`(18행)와 `/admin/users/{user_id}/role`(28행)에는 이 의존성이 있습니다. 라우터는 `dependencies=` 없이 만들어졌고(7행), 저장소 안에 `include_router` 호출도 없어 이 경로를 보호하는 곳이 없습니다.
- **결과:** 인증 헤더 없이 `GET /admin/users`만 보내면 `db.users.all()`이 그대로 반환됩니다. 사용자 정보와 관리자 계정이 노출되고, 역할 변경 같은 후속 공격에 쓸 `user_id`도 알 수 있습니다.
- **수정 방향:** `user=Depends(require_admin)`을 추가하세요. 더 안전하게는 모든 `/admin` 라우트를 `APIRouter(dependencies=[Depends(require_admin)])` 하나에 모으세요.
- **검증:** 세 가지 관점(도달 가능성·영향·방어 수단)의 검증자 3명이 모두 확인했습니다.

## 범위와 한계
- 읽은 파일: `app/auth.py`, `app/routes.py`와 루트 파일(`README.md`, `docker-compose.yml`, `.env.example`).
- 읽기만 했고 코드는 실행하지 않았습니다. 테스트도 익스플로잇도 돌리지 않았고, 모든 결함은 코드를 읽어서 나온 결론입니다.
- 이 폴더는 git 저장소가 아니라 리비전은 기록되지 않았습니다(`UNVERSIONED`).
- 연구자 4명이 모두 돌아왔고 건너뛴 영역은 없습니다.
- 파일 목록이 기록되지 않아 연구자들이 읽은 범위를 파일 단위로 대조하는 검사는 실행되지 않았습니다.
- 보고서에 올리지 않은 항목:
  - `docker-compose.yml`의 `devpassword`는 `127.0.0.1`에만 바인딩된 개발용 DB 비밀번호입니다.
  - `.env.example`은 자리표시자 값만 있습니다.

보고서는 `CLAUDE-SECURITY-20261102-143333/`에 있습니다. 결과 파일 `CLAUDE-SECURITY-RESULTS.md`, `.jsonl`, `.sarif`와 리비전 스탬프가 들어 있습니다. 폴더 자체의 `.gitignore`가 내용을 커밋에서 제외합니다. 이 결함에 대한 패치 파일을 만들어 드릴까요?
