<!-- claude-security · 맞힘 · 떴는가 True · 비용 0.48055659999999983 -->

스캔을 마쳤고 결함은 1건(HIGH)입니다. 패널 3명이 모두 확정했고, 검증 상태는 `verified`입니다. 코드는 건드리지 않았습니다. 스캔은 코드를 읽고 판단한 것이라 테스트나 익스플로잇은 실행하지 않았습니다.

**F1 — `/admin/users`에 인증·관리자 권한 검사가 없음 (HIGH, CWE-862)**
- **자리:** `app/routes.py:23`, 함수 `admin_users`
- **까닭:** 이 핸들러에는 `Depends(current_user)`도 `Depends(require_admin)`도 없습니다. 같은 파일의 다른 관리자 경로는 `require_admin`(`app/auth.py:10-13`, 401/403 강제)을 씁니다. 라우터(`routes.py:7`)에도 `dependencies=`가 없고, 저장소 안에는 대신 막아 줄 미들웨어나 `main.py`도 없습니다.
- **영향:** 인증 없는 클라이언트가 `GET /admin/users`만 보내면 `db.users.all()` 결과, 즉 사용자 테이블 전체를 받습니다.
- **전제:** 외부 게이트웨이가 `/admin/*`를 따로 막고 있지 않아야 합니다. 저장소 안에서는 그런 설정이 보이지 않습니다.
- **고칠 방향:** `admin_users`에 `Depends(require_admin)`을 추가하세요. 더 좋은 방법은 `/admin` 전용 라우터에 `dependencies=[Depends(require_admin)]`을 거는 것입니다.

**범위와 한계**
- 파일 5개를 모두 읽었습니다: `app/auth.py`, `app/routes.py`, `README.md`, `docker-compose.yml`, `.env.example`.
- 연구자 4명이 모두 돌아왔습니다. 다만 `app`은 메모리 안전성 렌즈 없이 조사했습니다. 워크플로가 언어만 보고 관리형 언어라고 판단해 그 렌즈를 뺐습니다.
- 이 디렉터리는 git 저장소가 아니라 리비전이 `UNVERSIONED`로 기록됩니다.

보고서는 `/tmp/tmp00v7cjii/CLAUDE-SECURITY-20261102-142602/`에 있고, `.gitignore`가 있어 커밋에 포함되지 않습니다. `CLAUDE-SECURITY-RESULTS.md`가 보고서이고, 같은 폴더에 `.jsonl`, `.sarif`, 리비전 스탬프가 함께 있습니다.

이 결함의 수정안을 패치 파일로 만들어 드릴까요?
