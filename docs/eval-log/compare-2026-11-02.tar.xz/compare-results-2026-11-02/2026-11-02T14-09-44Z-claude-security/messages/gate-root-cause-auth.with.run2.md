<!-- claude-security · 맞힘 · 떴는가 True · 비용 0.8263845999999999 -->

저장소 전체(`app/`, `docs/`)를 `medium` 강도로 스캔했고, 검증을 통과한 결함은 3건입니다. 3건 모두 검증 패널 3명 전원이 확인했고, 검증 상태는 `verified`입니다. 코드는 수정하지 않았습니다. 코드를 실행하거나 공격을 시연하지 않았고, 코드를 읽어서만 확인했습니다.

**1. [CRITICAL] JWT 서명 검증 비활성화** — `app/auth.py:13`, `current_user` (CWE-347)
- Bearer 토큰을 `options={"verify_signature": False}`로 디코딩해서 서명, `exp`, `aud`, `iss`를 전혀 확인하지 않습니다.
- 서명 없는 토큰(`{"alg":"none"}`, `sub=1`)만으로 어떤 사용자든 인증됩니다. user id가 순차 정수라 추측도 쉽고, 만료된 토큰도 통과합니다.

**2. [HIGH] 관리자 차단 엔드포인트에 권한 검사 없음** — `app/admin.py:13`, `ban` (CWE-862)
- `POST /admin/users/{user_id}/ban`은 `Depends(current_user)`만 요구합니다. `User` 모델에는 role/`is_admin` 필드도 없습니다.
- 인증된 사용자라면 누구든 임의 계정(관리자 포함)을 차단하거나 소프트 삭제할 수 있습니다. 1번 결함과 합쳐지면 인증 없이도 가능합니다.

**3. [MEDIUM] 차단·탈퇴된 사용자도 계속 인증됨** — `app/auth.py:16`, `current_user` (CWE-863)
- `session.get(User, ...)`로 조회한 뒤 `None`만 확인하고 `deleted_at`은 보지 않습니다. `docs/schema.md`는 `deleted_at`이 설정된 사용자를 존재하지 않는 것으로 취급하라고 합니다. `repo.py`는 이를 지키는데 인증 경로만 건너뜁니다.
- 차단된 사용자도 기존 토큰이 만료될 때까지(최대 30일) 접근할 수 있어, 2번의 차단이 사실상 효과가 없습니다.

**범위와 한계**
- `docs/`는 실행 코드가 없는 문서라 의도적으로 제외했습니다.
- 메모리 안전 관점은 `app`에 적용하지 않았습니다. 워크플로가 관리형 언어 코드로 보고 연구 전에 뺐습니다.
- 연구원 4명이 모두 돌아왔고, 읽지 못했다고 보고한 파일은 없습니다.
- 저장소가 git 체크아웃이 아니라 리비전은 `UNVERSIONED`로 기록됐습니다.

**보고서 위치:** `/tmp/tmp62s_dkxq/CLAUDE-SECURITY-20261102-141528/`
- `CLAUDE-SECURITY-RESULTS.md`
- `CLAUDE-SECURITY-RESULTS.jsonl`
- `CLAUDE-SECURITY-RESULTS.sarif`
- `CLAUDE-SECURITY-REVISION-UNVERSIONED.json`

이 폴더에는 모든 내용을 커밋에서 제외하는 `.gitignore`가 들어 있습니다.

이 결함들에 대한 수정 패치를 제안해 드릴까요?
