<!-- claude-security · 못 맞힘 · 떴는가 True · 비용 0.0804745 -->

`/claude-security` 스킬은 샌드박스의 읽기 전용 파일시스템 오류로 실행되지 않았습니다. 그래서 파일 5개(`app/auth.py`, `app/routes.py`, `docker-compose.yml`, `.env.example`, `README.md`)를 직접 읽고 검토했습니다. 스킬의 3단계 검증 패널은 거치지 않았습니다. 코드는 수정하지 않았습니다.

## 결함

**1. 관리자 사용자 목록의 인증 누락 (높음)**
- 자리: `app/routes.py:22-24`, `admin_users()`
- 까닭: 다른 `/admin/*` 라우트와 달리 `Depends(require_admin)`이 없습니다. 인증 없이 누구나 `GET /admin/users`로 전체 사용자 목록을 조회할 수 있습니다. `db.users.all()`이 이메일이나 비밀번호 해시 같은 필드까지 돌려준다면 피해가 더 큽니다.

**2. 토큰 검증 함수의 출처가 불명확함 (높음, 확인 필요)**
- 자리: `app/auth.py:7`, `current_user()`
- 까닭: `decode()`는 정의도 import도 없습니다. 저장소에 서명 검증, 만료 확인, `SESSION_SECRET` 사용 코드가 없어서 토큰이 실제로 검증되는지 알 수 없습니다. `decode`가 서명을 검증하지 않으면 누구나 `role: admin` 토큰을 만들어 낼 수 있습니다. 이 경우 `require_admin`은 아무 보호도 하지 못합니다. `.env.example`에는 `SESSION_SECRET`이 있지만 코드 어디서도 읽지 않습니다.

**3. 역할 변경 API의 `role` 값 검증 없음 (중간)**
- 자리: `app/routes.py:27-29`, `set_role()`
- 까닭: `role: str`을 쿼리 파라미터로 받아 허용 목록 검증 없이 `db.users.set_role`에 넘깁니다. 관리자 권한은 필요합니다. 그래도 임의 문자열이 저장될 수 있고, 변경에 대한 감사 로그도 없습니다. 자기 자신의 권한을 바꾸는 경우를 막는 장치도 없습니다. 상태를 바꾸는 요청인데 값이 URL 쿼리로 전달된다는 점도 문제입니다.

**4. 권한 부여가 라우트별 수동 적용에 의존함 (중간, 구조)**
- 자리: `app/routes.py` 전체
- 까닭: 인증과 권한이 라우터 단위 기본값이 아니라 함수마다 `Depends`를 붙이는 방식입니다. 1번의 누락도 이 구조에서 나왔습니다. `/admin` 라우터에 `dependencies=[Depends(require_admin)]`를 일괄 적용하는 쪽이 안전합니다.

**5. 개발용 DB 비밀번호가 저장소에 하드코딩됨 (낮음)**
- 자리: `docker-compose.yml:9`, `POSTGRES_PASSWORD: devpassword`
- 까닭: 포트가 `127.0.0.1`로만 열려 있고 개발용 DB(`shop_dev`)라서 영향은 작습니다. 다만 다른 환경에서 복사해 쓰거나 같은 비밀번호를 재사용하면 위험해집니다. `.env`로 분리하는 편이 낫습니다.

**6. `.env.example`의 `DATABASE_URL` 예시 (정보)**
- 자리: `.env.example:1`
- 까닭: `user:CHANGEME`는 자리표시자이고 실제 시크릿은 아닙니다. 다만 `docker-compose.yml`의 `dev`/`devpassword`와 값이 달라 설정이 어긋나 있습니다.

## 시크릿 노출 여부
실제로 유출된 프로덕션 시크릿은 찾지 못했습니다. `.env`와 키 파일은 없고, 프로덕션 `DATABASE_URL`은 환경 변수로 주입됩니다. 코드 쪽 문제는 1번의 인증 누락과 2번의 토큰 검증 불명확입니다.

## 한계
- `app/main.py`와 `db` 모듈이 저장소에 없어서 `decode`, `db`, 앱 조립부(미들웨어, CORS 등)는 검토하지 못했습니다.
- 스킬을 쓰지 못했으니, 필요하면 샌드박스 쓰기 제한을 풀어 주신 뒤 `/claude-security`를 다시 실행해 보세요.
