<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.09967820000000001 -->

데이터 쪽 결함을 아래에 정리했습니다. 코드를 읽어서 찾은 것이고, 실행해서 확인하지는 않았습니다. 저장소는 파일 7개 규모라 서브에이전트나 별도 감사 도구는 쓰지 않았습니다. 코드는 고치지 않았습니다.

## 핵심 결함

1. **만료일을 잘못된 날짜에서 계산합니다.**
   - 자리: `app/services/memberships.py`의 `approve` 29~35줄.
   - `starts_on`을 승인 시각의 날짜(`approved_at.date()`)로 잡고 `valid_until`을 거기에 기간을 더해 정합니다. `seed/plans.sql`의 안내 문구는 "신청일 + 기간"이라고 했고, `docs/schema.md`는 승인이 신청 다음 날이나 그 뒤에, 주말 신청이면 월요일에 이뤄진다고 적었습니다.
   - 그래서 승인이 늦어진 만큼 회원이 날짜를 얻거나 잃습니다. 출입 단말은 `valid_until`로 막으니 실제 출입에 영향이 갑니다.
   - `applications.applied_on`은 읽지도 않습니다.

2. **날짜 기준이 UTC입니다.**
   - 자리: `approve` 29~30줄.
   - `datetime.now(timezone.utc).date()`는 UTC 날짜입니다. 체육관 현지 시각으로 00:00~09:00(KST 기준)에 승인하면 시작일이 하루 앞서고, 만료일도 하루 앞서 계산됩니다.

3. **동시 승인에서 확인과 처리가 한 덩어리가 아닙니다.**
   - 자리: `approve` 22~26행과 39~41행.
   - `session.get`으로 상태를 읽고 나중에 바꾸는데, 행을 잠그지 않습니다(`FOR UPDATE`나 상태 조건부 UPDATE가 없습니다).
   - 두 요청이 동시에 오면 둘 다 `pending`을 보고 통과합니다.
   - 그러면 `memberships.application_id`의 unique 제약이 `flush` 때 `IntegrityError`를 냅니다. `RefusedApproval`이 아니라서 `app/main.py`의 `post_approval`이 잡지 못하고, 이미 처리했다는 422 대신 500이 나갑니다.

4. **제약 위반이 500으로 새고, `approved_by` 값의 정당성도 확인하지 않습니다.**
   - 자리: `approve`와 `post_approval`.
   - `duration_days`가 0 이하이면 `memberships_period` 체크 제약에 걸려 `IntegrityError`가 납니다. `plans`에 `duration_days > 0`이나 `price >= 0` 같은 CHECK가 없어 잘못된 기준 데이터가 승인 시점에야 터집니다.
   - `approved_by`는 길이만 확인하는 자유 문자열이라, 누가 승인했는지 감사 기록으로 쓰기 어렵습니다.

## 데이터 모델·무결성

5. **`status`에 값 제한이 없습니다.**
   - 자리: `Application.status`와 `migrations/0001_memberships.py` 25행.
   - `String(10)` 자유 문자열이라 CHECK나 enum이 없습니다. 오타나 임의 값이 들어갈 수 있고, `!= "pending"` 검사로는 걸러지지 않습니다.
   - 거절 경로도 없어서, 상태 전이가 모델에 정의되어 있지 않습니다.

6. **`member_id`가 어디에도 연결되어 있지 않습니다.**
   - 자리: `applications.member_id`와 `memberships.member_id`.
   - 회원 테이블이나 FK가 없습니다. `memberships.member_id`는 `applications.member_id`를 복사한 값이라, 두 값이 어긋나도 막을 장치가 없습니다.
   - 같은 회원의 회원권 기간이 겹치는 것도 막지 못합니다. 제약도 서비스 검사도 없습니다.

7. **`applications.plan_code`와 `member_id`에 인덱스가 없습니다.** 회원별·종류별 조회가 전체 스캔이 됩니다. FK에 이름도 붙어 있지 않습니다(두 곳 모두).

8. **`applied_on`에 기본값이 없고 미래 날짜 검사도 없습니다.** 신청일이 만료일 계산의 기준이 되어야 하는 값인데(1번), 입력 검증이 없습니다.

## 마이그레이션·되돌림

9. **`downgrade`의 보호가 불완전합니다.**
   - 자리: `migrations/0001_memberships.py` `downgrade` 40~46줄.
   - `memberships`가 비었는지만 확인하고 `applications`와 `plans`는 확인하지 않습니다. 신청 이력과 기준 데이터가 있어도 조용히 삭제되어 복구할 수 없습니다.
   - 조건도 안내 메시지(회원권이 있어 되돌리지 않는다)와 같은 범위만 막습니다.

10. **기준 데이터 시드가 마이그레이션 밖에 있습니다.**
    - 자리: `seed/plans.sql`.
    - 마이그레이션은 `plans`를 비워 두고, 시드는 `ON CONFLICT` 없이 `INSERT`만 합니다. 두 번 실행하면 PK 충돌로 실패하고, 새 환경에서 시드를 빼먹으면 `approve`에서 `plan`이 `None`이 되어 `AttributeError`(500)가 납니다.
    - 시드의 `description` 문구가 코드가 지키지 않는 규칙(1번)을 화면 안내로 내보냅니다. 이 안내와 실제 동작이 갈라져 있습니다.

11. **Alembic 구성이 저장소에 없습니다.** `alembic.ini`와 `env.py`가 없고 `Base.metadata`와의 연결도 없습니다. 마이그레이션을 실제로 돌릴 수 없고, 모델과 마이그레이션이 어긋나는지 확인할 수도 없습니다. 제약 이름 규칙(naming convention)도 없습니다.

## 트랜잭션 경계

12. **트랜잭션 소유가 분산되어 있습니다.**
    - 자리: `app/main.py`의 `post_approval`과 `session`.
    - 서비스는 `flush`만 하고, 커밋은 핸들러가, 롤백은 `s.close()`에 암묵적으로 맡깁니다. 예외 경로(3·4번의 `IntegrityError`)에서는 명시적 `rollback`이 없습니다.
    - `s.commit()` 자체가 실패해도 잡는 곳이 없습니다.
    - 엔진은 접속 정보를 코드에 박아 두었고(12행), `pool_pre_ping` 같은 설정이 없어 끊어진 연결에 취약합니다.

13. **응답이 커밋 뒤의 상태가 아니라 `flush` 시점 값입니다.** `Approved`에는 `membership.id`와 `valid_until`이 `flush` 직후 값으로 들어갑니다. 커밋이 실패하면 호출자에게는 이미 만든 것처럼 보이는 값이 서비스 쪽에 남습니다. 다만 현재는 핸들러가 커밋 뒤에야 응답하므로 영향은 작습니다.

가장 먼저 볼 것은 1번(만료일 기준)과 3번(동시 승인 처리)입니다. 둘 다 사용자에게 바로 영향을 줍니다.
