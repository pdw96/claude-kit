<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.1069743 -->

저장소는 작았습니다(파일 9개). 도구를 쓰지 않고 전부 직접 읽고 검토했습니다. 코드는 고치지 않았습니다.

## 결함 목록

### 높음

1. **비활성 코드로도 환불이 세워집니다.**
   - 자리: `app/services/refunds.py`의 `_must_be_a_code`(22–24행), `refund`(31–32행)
   - 까닭: `session.get(CommonCode, (group, code))`는 행이 있는지만 봅니다. `is_active`를 보지 않습니다. `app/models.py`의 `CommonCode` 독스트링은 "새 기록에서는 못 고르고"라고 약속합니다. 하지만 `seed/codes.sql`에서 꺼 둔 `POINT`와 `PROMO`도 지금은 통과합니다.
   - DB의 복합 FK(`app/models.py` 36–37행, `migrations/0001_refunds.py` 33–34행)는 행의 존재만 보장합니다. 활성 여부는 어디서도 강제되지 않습니다.

2. **같은 요청을 다시 보내면 환불이 이중으로 세워집니다.**
   - 자리: `app/main.py`의 `post_refund`, `app/models.py`의 `Refund`
   - 까닭: `POST /orders/{id}/refunds`에 멱등 키가 없고, `refunds`에도 유일 제약이 없습니다. 타임아웃 뒤 재시도하거나 더블클릭하면 한도 안에서 환불이 두 번 나갑니다.
   - 돈이 움직이는 쓰기라서 가장 위험한 경로입니다.

3. **`downgrade`가 환불 기록만 검사하고 주문과 공통코드는 그냥 지웁니다.**
   - 자리: `migrations/0001_refunds.py`의 `downgrade`(41–47행)
   - 까닭: 가드는 `refunds`가 비어 있는지만 봅니다. 환불이 없어도 `orders`와 `common_codes`에는 실데이터가 있습니다. 이 데이터는 `drop_table`로 되돌릴 수 없게 사라집니다.
   - `common_codes`를 지우지 않는다는 원칙(`docs/schema.md` 12행)도 어깁니다.
   - 가드 검사와 drop 사이에 잠금이 없어서, 그 틈에 들어온 환불도 막지 못합니다.

4. **되돌림 경로가 없어서 문서의 원칙이 실현되지 않습니다.**
   - 자리: `docs/schema.md` 11행, `app/services/refunds.py`의 `refund`, `app/main.py`의 `RefundIn`
   - 까닭: 문서는 "환불은 고치지 않고 되돌리는 환불을 새로 세운다"고 합니다. 그런데 `amount > 0`이 세 곳에서 강제됩니다: `RefundIn.amount`(`gt=0`), `refund`의 검사, CHECK 제약 `refunds_amount_positive`. 그래서 음수 환불이나 취소 환불을 표현할 수 없습니다.
   - 환불을 취소·정정하는 코드가 없고, `orders.refunded`를 줄이는 코드도 없습니다. 이것은 구현이 빠졌거나, 문서가 구현보다 앞서 나간 것입니다.

### 중간

5. **`orders.refunded`는 파생 값인데 DB가 무결성을 보장하지 않습니다.**
   - 자리: `app/models.py`의 `Order`(25–30행), `migrations/0001_refunds.py` 18–23행
   - 까닭: `refunded`는 `SUM(refunds.amount)`의 중복 저장입니다. 이를 맞추는 것은 애플리케이션 코드뿐이라, 다른 경로로 쓰거나 수동으로 고치면 어긋납니다.
   - `CHECK (refunded >= 0 AND refunded <= amount)`와 `CHECK (amount >= 0)`가 없습니다. 상한 검사는 `refund()` 안에만 있습니다.
   - 일치를 확인하는 트리거도 점검도 없습니다.

6. **"일어난 일은 지우지 않는다"는 원칙을 DB가 강제하지 않습니다.**
   - 자리: `docs/schema.md`, `app/models.py`의 `CommonCode`와 `Refund`
   - 까닭: `refunds`와 `common_codes`에 UPDATE·DELETE를 막는 트리거나 권한 제한이 없습니다. 어떤 환불에도 참조되지 않는 공통코드는 DELETE가 그냥 통과합니다.
   - FK에 `ondelete`가 없어서(기본값 NO ACTION) 참조된 코드만 우연히 보호됩니다. 의도를 명시한 것이 아닙니다.

7. **환불 기록에 시각과 행위자가 없습니다.**
   - 자리: `app/models.py`의 `Refund`, `migrations/0001_refunds.py`의 `refunds`
   - 까닭: `created_at`, 요청자, 상태 칸이 없습니다. 환불은 되돌릴 수 있는 사건인데 언제 누가 했는지 남지 않아서, 감사와 정정이 불가능합니다.

8. **코드 검증이 주문 잠금 뒤에 있지만 코드 행은 잠그지 않습니다.**
   - 자리: `app/services/refunds.py`의 `refund`(28–32행)
   - 까닭: 코드 조회는 잠금 없이 읽습니다. 검증과 INSERT 사이에 코드가 꺼지면 어긋날 수 있습니다. 항목 1을 고치면 이 틈도 함께 따져야 합니다.
   - 1번보다 작은 문제입니다.

### 낮음 · 운영

9. **마이그레이션 환경이 갖춰져 있지 않습니다.**
   - 자리: 저장소 전체 (`migrations/`)
   - 까닭: `alembic.ini`와 `migrations/env.py`가 없어서 `alembic upgrade`를 실행할 수 없습니다. 리비전 파일도 `script.py.mako` 구조 밖에 있습니다.
   - 모델(`models.py`)과 마이그레이션이 손으로 이중 관리되고 있어서, 어긋남을 잡는 `alembic check` 같은 검증도 없습니다.

10. **시드가 마이그레이션 밖에 있고, 다시 실행하면 실패합니다.**
    - 자리: `seed/codes.sql`
    - 까닭: `ON CONFLICT`가 없어서 두 번 실행하면 PK 위반이 납니다. 마이그레이션이 시드를 넣지 않으므로, 시드를 빠뜨린 환경에서는 모든 환불이 "그런 코드가 없다"로 거절됩니다.
    - 코드를 켜고 끄는 일이 변경 이력 없이 SQL 파일 수정으로만 이뤄집니다.

11. **`refunds.order_id`에 인덱스가 없습니다.**
    - 자리: `migrations/0001_refunds.py` 27행, `app/models.py` 44행
    - 까닭: 주문별 환불 조회와 FK 검사에 전체 스캔이 생깁니다.

12. **트랜잭션 경계가 라우터에 흩어져 있습니다.**
    - 자리: `app/main.py`의 `post_refund`(31–35행)
    - 까닭: `commit`이 서비스 밖 HTTP 계층에 있습니다. 예외 경로는 `s.close()`의 암묵 롤백에 기댑니다. 동작은 맞지만, 서비스를 다른 진입점(배치, 관리 도구)에서 부르면 commit 책임이 불분명합니다.
    - `commit()` 자체가 실패하면 처리되지 않은 500이 됩니다.

13. **DB 접속 정보가 하드코딩되어 있습니다.**
    - 자리: `app/main.py` 12행
    - 까닭: `postgresql+psycopg://shop@localhost/shop`이 모듈 import 시점에 고정됩니다. 환경별 설정이나 비밀번호 주입이 불가능하고, import만으로 엔진이 만들어집니다.

## 확인한 범위와 한계
- 실행하지는 않았습니다. 동시성(항목 2, 8)은 코드를 읽고 추론한 것이고 재현하지 않았습니다.
- 주문 잠금(`with_for_update`)과 `refunded` 증가는 같은 트랜잭션에서 순서대로 일어나므로, 단일 주문의 한도 초과 경쟁은 막혀 있다고 판단했습니다.
