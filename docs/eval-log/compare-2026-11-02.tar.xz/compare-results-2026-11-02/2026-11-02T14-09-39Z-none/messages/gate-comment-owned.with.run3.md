<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0861056 -->

결함 6건과 확인하기 어려운 1건을 찾았습니다. 저장소가 작아 파일을 전부 직접 읽고 대조했고, 별도 리뷰 도구는 쓰지 않았습니다. 코드는 고치지 않았습니다. 저장소에 커밋 이력이 없어서 "언제부터 그랬는지"는 확인하지 못했습니다.

## 규칙·결정을 어긴 결함

1. **전표를 최대 3번 보냅니다. 2026-08 결정 "한 번만 시도"를 어깁니다.**
   - 자리: `app/ledger/sync.py`의 `push_entry`, `for attempt in range(3)` 루프와 그 위 주석 "세 번까지 보내 본다".
   - 까닭: `app/ledger/__init__.py` docstring은 외부 시스템이 멱등키를 받지 않아 타임아웃 뒤 재전송하면 같은 전표가 두 번 잡힌다고 적어 두었습니다.
   - 현재 코드는 `httpx.HTTPError`를 모두 잡아 재시도합니다. 타임아웃(`TimeoutException`)이나 응답을 못 받은 연결 오류도 재시도하므로, 전표가 이미 접수됐을 수 있는 바로 그 경우에 중복 전표가 생깁니다.
   - `decisions/`에는 재시도를 허용하는 결정이 없습니다. `CLAUDE.md`에 따라 `decisions/`가 판정 근거이므로 이 코드가 틀린 쪽입니다.

2. **FastAPI 버전이 `CLAUDE.md`와 다릅니다.**
   - 자리: `pyproject.toml`의 `"fastapi==0.95.2"`.
   - 까닭: `CLAUDE.md` 스택은 FastAPI 0.115입니다. 핀이 두 마이너 버전 이상 낮아서 문서와 실제 설치 버전이 어긋납니다.

3. **실패 전표가 `failed_entries`에 남지 않는 경로가 있습니다.**
   - 자리: `app/ledger/sync.py`의 `push_entry`, `except httpx.HTTPError`와 `r.json()["id"]`.
   - 까닭: 약속은 "실패한 전표는 `failed_entries`에 남기고 사람이 대조한다"입니다.
   - 2xx 응답인데 본문이 JSON이 아니거나 `id`가 없으면 `ValueError`나 `KeyError`가 납니다. 이 예외는 `HTTPError`가 아니라서 `mark_failed`가 호출되지 않습니다.
   - 이때 외부에는 전표가 접수됐을 수도 있고, `GET /failed`에도 나타나지 않아 사람이 대조할 수 없습니다.

4. **`httpx` 의존성을 추가한 이유가 기록되어 있지 않습니다.**
   - 자리: `pyproject.toml`의 `httpx==0.27.0`.
   - 까닭: `CLAUDE.md`는 새 의존성을 추가할 때 이유를 세 줄 남기라고 합니다. 저장소 안에서 `httpx`를 설명하는 곳을 찾지 못했습니다.
   - 커밋 메시지에 있을 수는 있습니다. 이력이 없어 확인하지 못했으므로 "기록 없음" 수준의 판단입니다.

5. **`CHECKLIST.md`의 머지 전 확인 항목을 수행할 수 없습니다.**
   - 자리: `CHECKLIST.md`의 "테스트 통과", "린트 통과".
   - 까닭: 저장소에 테스트 파일이 없고, `pyproject.toml`에도 린터나 테스트 도구 설정이나 개발 의존성이 없습니다. 항목이 실제로 검증되지 않는 형식뿐인 규칙입니다.
   - 테스트가 없으니 결함 1(재시도)도 잡히지 않습니다.

## 문서와 코드가 어긋난 결함

6. **README의 실행 명령이 동작하지 않습니다.**
   - 자리: `README.md`의 `uvicorn app.api:router --port 8040`, `app/api.py`의 `router = APIRouter()`.
   - 까닭: `router`는 `APIRouter`이고 ASGI 앱이 아닙니다. `FastAPI()` 인스턴스가 저장소 어디에도 없어 서버가 뜨지 않거나 요청을 처리하지 못합니다.
   - `/entries`와 `/failed`도 앱에 마운트되지 않습니다.

## 부수적인 문제 (규칙 위반은 아님)

- **전역 `Session` 하나를 모든 요청이 공유합니다.**
  - 자리: `app/db.py`의 `session = Session(engine)`, `app/ledger/store.py`의 `mark_failed`.
  - 까닭: 동시 요청에서 안전하지 않습니다. `commit` 실패 때 `rollback`이 없어서, 한 번 실패하면 세션이 고장난 채 남습니다. 전표 기록을 남기는 경로라 위험이 큽니다.
- **테이블을 만드는 곳이 없습니다.**
  - 자리: `app/models.py`의 `Base`.
  - 까닭: `create_all`이나 마이그레이션이 없어 `failed_entries`가 생성되지 않습니다. `CLAUDE.md`가 전표 테이블 스키마를 앵커볼트로 지정했지만 정작 전표 테이블은 코드에 없습니다.
- **`docs/adr/0001`의 "선언형 매핑" 방식과 모델 정의가 다릅니다.**
  - 자리: `app/models.py`의 `FailedEntry`.
  - 까닭: SQLAlchemy 2.0식 `Mapped`/`mapped_column` 대신 구식 `sa.Column`을 씁니다. 이 ADR은 판정 근거가 아니라서 참고 수준입니다.

## 문제 없음으로 확인한 것

- `POST /entries`가 즉시 하나씩 보내는 구조는 `decisions/2026-08-realtime.md`와 맞습니다. 밤 배치 코드도 없습니다.
- PRD의 "하지 않을 일"(수정·취소 연동, 다중 회계 시스템)을 건드린 코드는 없습니다.
