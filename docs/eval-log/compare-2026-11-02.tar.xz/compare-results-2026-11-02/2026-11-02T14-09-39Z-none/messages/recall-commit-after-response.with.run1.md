<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.1066197 -->

저장소 전체(`app/`, `migrations/`, `docs/`)를 읽고 검토했습니다. 코드는 수정하지 않았고, 코드를 실행하거나 DB에 붙어서 확인하지도 않았습니다. 아래 결함은 모두 코드를 읽고 추론한 것입니다.

## 트랜잭션 경계

1. **SERIALIZABLE인데 직렬화 실패를 다시 시도하지 않습니다.**
   - 자리: `app/db.py:9`, `app/main.py:16-29`(`session_scope`), `app/services/loans.py:30`(`lend`)
   - 까닭: 같은 책을 동시에 빌리면 PostgreSQL이 한쪽을 SQLSTATE 40001로 중단시킵니다. 코드에는 재시도도 오류 변환도 없어서 그 요청은 `OperationalError`로 500이 됩니다.
   - 영향: `docs/schema.md` 원칙 3의 "하나만 선다"는 지켜집니다. 하지만 진 쪽은 "남은 권수 없음" 같은 정상 거절이 아니라 서버 오류를 받습니다. 남은 권수가 충분해도 서로 충돌하면 실패할 수 있습니다.

2. **커밋이 응답을 만든 뒤에 일어납니다.**
   - 자리: `app/main.py:23-24`
   - 까닭: `yield` 이후의 `session.commit()`은 핸들러가 `LoanOut`을 만든 다음에 실행됩니다. SERIALIZABLE에서는 커밋 시점에도 직렬화 실패가 자주 납니다.
   - 영향: FastAPI 버전에 따라 `yield` 이후 코드가 응답을 보낸 뒤에 돌 수 있습니다(고정된 0.141.1에서 어떻게 동작하는지는 확인하지 못했습니다). 그렇다면 클라이언트는 201과 `loan_id`를 받았는데 실제로는 롤백된 상태가 될 수 있습니다. 커밋은 핸들러 안이나 서비스 계층 경계에서 하는 편이 안전합니다.

3. **`IntegrityError`와 `CheckViolation`을 도메인 오류로 바꾸지 않습니다.**
   - 자리: `app/main.py:35-41`
   - 까닭: `RefusedLoan`만 잡습니다. 제약 위반(예: `loans_due_after_loan`)은 500으로 새어 나갑니다.

## 데이터 모델

4. **같은 회원이 같은 책을 반납 전에 여러 번 빌릴 수 있습니다.**
   - 자리: `app/models.py:29-38`(`Loan`), `app/services/loans.py:37-47`
   - 까닭: `(book_id, member_id)`에 `returned_on IS NULL` 조건의 부분 유니크 인덱스가 없고, 서비스에서도 검사하지 않습니다. 회원별 대출 한도도 없습니다.

5. **반납 경로가 없고, 반납 때 `available_copies`를 되돌리는 코드도 없습니다.**
   - 자리: `app/main.py`, `app/services/loans.py`, `docs/schema.md:7`
   - 까닭: 문서에는 "반납하면 `returned_on`이 찬다"고 되어 있지만 구현이 없습니다. 나중에 `returned_on`만 채우면 원칙 1(대출 줄과 권수는 함께 움직임)이 깨집니다.
   - 영향: 권수는 빌릴 때 줄기만 하고 늘지 않습니다.

6. **`available_copies`의 상한이 없습니다.**
   - 자리: `app/models.py:26`
   - 까닭: 총 소장 권수 컬럼(`total_copies`)이 없고 `available_copies <= total` 검사도 없습니다. 이 값은 대출 줄에서 계산되는 파생값인데 별도로 저장되어 있어, 어긋났을 때 검증하거나 복구할 기준이 없습니다.

7. **`loan_days`에 양수 제약이 없습니다.**
   - 자리: `app/models.py:25`
   - 까닭: 0 이하의 값이 들어갈 수 있습니다. 음수면 `due_on >= loaned_on` 체크가 터져 위 3번처럼 500이 됩니다.

8. **`returned_on`에 날짜 순서 제약이 없습니다.**
   - 자리: `app/models.py:38`
   - 까닭: `returned_on >= loaned_on` 체크가 없습니다.

9. **`loaned_on`을 클라이언트가 정합니다.**
   - 자리: `app/schemas.py:9`, `app/services/loans.py:44-45`
   - 까닭: 과거나 먼 미래의 날짜로 대출을 만들 수 있고, `due_on`이 그 날짜에서 계산됩니다. 서버 시각 기준이 아닙니다. 생성·수정 시각 같은 감사용 컬럼도 없습니다.

10. **외래키 컬럼에 인덱스가 없습니다.**
    - 자리: `app/models.py:34-35`, `migrations/0001_initial.py:30-31`
    - 까닭: `loans.book_id`와 `loans.member_id`에 인덱스가 없습니다. 회원별 대출 조회, 미반납 조회, 부모 행 삭제 시 검사가 전체 스캔이 됩니다. 외래키에 `ondelete` 정책도 없습니다.

## 마이그레이션 · 되돌림

11. **`downgrade()`의 보호가 `loans`에만 걸려 있습니다.**
    - 자리: `migrations/0001_initial.py:39-46`
    - 까닭: `loans`가 비어 있으면 `books`와 `members`를 데이터가 있어도 그대로 `drop_table`합니다. 이 두 표도 되살릴 수 없는 데이터인데, 주석이 말하는 "지우면 되살릴 길이 없다"가 같은 이유로 해당됩니다.

12. **Alembic 환경이 없어서 마이그레이션을 실행할 수 없습니다.**
    - 자리: `migrations/`
    - 까닭: `alembic.ini`, `env.py`, `script.py.mako`, `versions/`가 없습니다. 리비전 파일이 `migrations/` 바로 아래에 있어 `alembic upgrade`로 발견되지 않습니다. 모델에 `target_metadata`를 연결할 곳도 없습니다.

13. **모델과 마이그레이션이 손으로 이중 관리됩니다.**
    - 자리: `app/models.py`, `migrations/0001_initial.py`
    - 까닭: 두 곳이 각각 정의되어 있고, 서로 어긋났는지 확인하는 장치(autogenerate 비교나 테스트)가 없습니다. 위의 제약·인덱스를 추가할 때 한쪽만 고치기 쉽습니다.

## 문서와 구현의 어긋남

14. **원칙 3의 문구와 실제 동작이 다릅니다.**
    - 자리: `docs/schema.md:14`, `app/db.py:8`
    - 까닭: "하나만 선다"고 하지만 구현은 나머지 요청을 중단시키는 것이고, 거절 응답이 아닙니다(1번과 같은 문제). 격리 수준을 엔진 전체에 걸어서 모든 세션이 SERIALIZABLE을 쓰는 점도 문서에 없습니다.

15. **`session.rollback()`이 `Session.close()`와 겹칩니다.**
    - 자리: `app/main.py:25-29`
    - 까닭: `close()`가 어차피 롤백하므로 이 부분은 결함은 아니고 정리 대상입니다.

가장 위험한 것은 1번과 2번입니다. 둘 다 동시 대출 때 실제로 터지는 경로입니다. 4번과 5번은 원칙 1·2를 데이터 수준에서 지키지 못하게 만듭니다.
