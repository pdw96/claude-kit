<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0973927 -->

저장소는 작아서(파일 9개) 전부 읽었습니다. 코드는 고치지 않았고, 아래 목록은 읽고 따져 본 결과입니다. 실제 DB를 띄워 재현하지는 않았습니다.

## 결함 목록 (심각한 순)

1. **만료일 기준일이 틀림 (데이터 정확성)**
   - 자리: `app/services/memberships.py` `approve()` 29–35행.
   - `starts_on`을 승인 시각(`datetime.now`)의 날짜로 잡고, `applications.applied_on`은 쓰지 않습니다.
   - `seed/plans.sql`은 "신청일로부터 N일, 신청일 + 기간"이라고 안내합니다. `docs/schema.md`는 승인이 신청 다음 날이나 그 뒤에 이뤄진다고 적습니다(주말 신청은 월요일 승인).
   - 그래서 승인이 늦은 만큼 회원이 안내받은 기간보다 적게 이용하게 됩니다. 금요일 신청이 월요일에 승인되면 3일을 잃습니다.
   - 만료일 때문에 출입 단말이 막히므로, 회원이 실제로 불이익을 받습니다.

2. **날짜 기준이 UTC임 (시간대)**
   - 자리: `memberships.py` 29–30행. `datetime.now(timezone.utc).date()`를 씁니다.
   - 한국 지점 기준으로 KST 00:00–09:00에 승인하면 `starts_on`이 전날로 찍힙니다. 날짜 단위 비즈니스 값이 UTC 달력으로 계산됩니다.

3. **동시 승인 경합 (트랜잭션 경계)**
   - 자리: `memberships.py` 22–26행 `session.get(Application, …)`, `status` 확인 후 갱신(39행).
   - 행 잠금(`with_for_update`)이나 조건부 `UPDATE … WHERE status='pending'` 없이 "읽고 확인한 뒤 쓰기"를 합니다. 두 요청이 동시에 오면 둘 다 `pending`을 보고 통과합니다.
   - 이때 `memberships.application_id`의 unique 제약이 마지막 방어선인데, 지는 쪽은 `main.py` 33행 `s.commit()`에서 `IntegrityError`가 납니다. 이 오류는 처리하지 않아 422가 아니라 500으로 나갑니다.
   - 같은 이유로, 이미 처리된 신청에 대한 중복 승인 방지가 애플리케이션 수준에서는 성립하지 않습니다.

4. **커밋 위치와 실패 처리**
   - 자리: `app/main.py` `post_approval` 30–33행.
   - 커밋은 엔드포인트가, 쓰기는 서비스가 맡아 경계가 둘로 갈립니다. `commit()` 실패(`IntegrityError` 등)는 잡히지 않고, 명시적 `rollback`도 없습니다. 지금은 `close()`가 암묵적으로 롤백해 줘서 버틸 뿐입니다.
   - 서비스를 다른 곳(배치, 일괄 승인)에서 재사용하면 커밋 책임이 불분명해집니다.

5. **다운그레이드 보호가 불완전함 (되돌림)**
   - 자리: `migrations/0001_memberships.py` `downgrade()` 40–46행.
   - `memberships`가 비어 있는지만 확인하고 `applications`와 `plans`를 통째로 DROP합니다. 승인 전 신청(`pending`)이 있어도 막지 않고 지워 버립니다.
   - `plans`는 시드로 다시 심을 수 있어도, `applications`는 되살릴 수 없는 원천 데이터입니다. 보호 조건이 지우는 범위보다 좁습니다.
   - 이 가드는 두 번째 방어선이 되지 못하고, 데이터가 거의 없는 환경에서만 의미가 있습니다.

6. **상태·값 제약이 DB에 없음 (데이터 모델)**
   - 자리: `models.py`와 마이그레이션의 `applications.status`, `plans.duration_days`, `plans.price`.
   - `status`는 자유 문자열이라 `pending`/`approved` 외 값이 들어가도 막지 못합니다. `CHECK`나 enum이 없습니다.
   - `duration_days > 0`, `price >= 0` 제약도 없습니다. `duration_days`가 0이거나 음수면 `memberships_period` 제약에 걸려 승인이 500으로 실패합니다.
   - 상태와 회원권의 일관성(approved이면 membership이 있음)도 DB가 보장하지 않고 코드에만 의존합니다.

7. **중복되는 회원 식별자와 기간 겹침 (데이터 모델)**
   - 자리: `applications.member_id`와 `memberships.member_id`.
   - `member_id`가 두 표에 따로 있고 서로 일치한다는 제약이 없습니다. `members` 표나 FK도 없고, 인덱스도 없어 회원별 조회가 전체 스캔이 됩니다.
   - 같은 회원의 회원권 기간이 겹치는 것도 막지 않습니다. 중복 신청 후 각각 승인되면 이중 회원권이 생깁니다.

8. **시드의 위치와 중복 (마이그레이션)**
   - 자리: `seed/plans.sql`과 `plans.duration_days`.
   - 마이그레이션 밖에 있고, `ON CONFLICT` 없는 단순 `INSERT`라 두 번 실행하면 PK 충돌이 납니다. 어떤 리비전에 대응하는지도 정해져 있지 않습니다.
   - `description` 문구에 기간(30/90/365)을 하드코딩해 `duration_days` 컬럼과 이중으로 관리합니다. 한쪽만 바꾸면 화면 안내와 실제 계산이 어긋납니다. 이 안내문은 결함 1과 반대되는 내용이기도 합니다.

9. **Alembic 구성이 빠짐 (마이그레이션)**
   - 자리: 저장소 전체. `alembic.ini`와 `env.py`가 없어 마이그레이션을 실제로 실행할 수 없습니다.
   - 리비전 파일만 있어서 `target_metadata` 기반 드리프트 검사(autogenerate)도 안 됩니다.
   - 모델과 마이그레이션이 손으로 따로 복제되어 있고 제약 이름 규칙(naming convention)이 없습니다. FK와 unique 제약 이름이 DB 기본값이라 이후 마이그레이션에서 제약을 지우기 어렵습니다.

10. **승인자 값의 신뢰 (감사 기록)**
    - 자리: `main.py` `ApprovalIn.approved_by`.
    - 승인자를 요청 본문의 자유 문자열로 받아 `memberships.approved_by`에 그대로 저장합니다. 인증과 연결되지 않아 감사 기록으로서 신뢰할 수 없습니다.

11. **사소한 점**
    - `main.py` 12행: 접속 문자열이 하드코딩되어 있습니다(환경 설정 분리 없음).
    - `main.py` 31–32행: 없는 신청은 404, 이미 처리된 신청은 409가 맞는데 둘 다 422로 응답합니다.
    - `memberships.py` 27행: `plan`이 `None`일 때 방어가 없습니다. FK가 있어 현실적으로는 드뭅니다.

핵심은 1·3·5입니다. 1은 고객 불이익으로 이어지는 로직 결함이고, 3은 동시성 때문에 500이 나는 경로입니다. 5는 되돌림 보호가 지우는 범위와 맞지 않는 문제입니다.
