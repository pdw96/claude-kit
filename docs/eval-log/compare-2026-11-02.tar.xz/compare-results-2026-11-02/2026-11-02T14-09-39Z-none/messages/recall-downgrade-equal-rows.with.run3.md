<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0966388 -->

저장소는 파일 5개(`app/models.py`, 마이그레이션 0006·0007, `docs/schema.md`)뿐이라 직접 읽고 검토했습니다. 코드는 고치지 않았고, 실행하거나 테스트하지도 않았습니다. 아래 결함은 모두 코드를 읽어서 찾았습니다.

## 결함 목록 (심각도 순)

**1. 되돌리기가 운영자가 먼저 만든 코드 줄을 지웁니다. 원칙 1 위반입니다.**
- 자리: `migrations/versions/0007_shipping_zone.py`의 `upgrade()` 20~30행과 `downgrade()` 50~63행
- 까닭:
  - `upgrade()`는 `WHERE NOT EXISTS`로 이미 있는 줄을 건너뜁니다. 그래서 운영자가 `SHIPPING_ZONE/METRO` 같은 줄을 먼저 만들어 두었다면, 그 줄은 리비전이 심은 것이 아닙니다.
  - 그런데 `downgrade()`는 "심은 값 그대로인가"만 비교합니다. 이름·순서·활성이 우연히 같으면 통과해서 `DELETE FROM common_codes WHERE group_code = ...`가 그 줄을 지웁니다.
  - 리비전이 심은 줄인지 운영자의 줄인지 구분하는 표시(출처 컬럼이나 기록 표)가 없습니다. `docs/schema.md`가 말하는 "리비전이 만든 것만 거둔다"를 지킬 수 없는 구조입니다.

**2. 그룹 줄은 변경 검사 없이 지워집니다.**
- 자리: `downgrade()` 62~63행의 `DELETE FROM code_groups ...`
- 까닭:
  - 코드 줄은 `extra`와 `changed` 두 검사를 거치지만, `code_groups` 줄에는 검사가 없습니다.
  - 운영자가 그룹의 `name`이나 `description`을 고쳤거나, 그룹을 먼저 만들어 두었어도 그냥 삭제됩니다.
  - 결함 1과 같은 원칙 위반입니다. 주석 61행의 "위의 멈춤 검사가 지킨다"는 그룹에는 해당하지 않습니다.

**3. 검사와 삭제 사이에 잠금이 없어서(TOCTOU) 주문 데이터가 사라질 수 있습니다.**
- 자리: `downgrade()` 36~64행
- 까닭:
  - `orders`에 `shipping_zone`이 있는지 센 뒤 `drop_column`까지 사이에, 다른 트랜잭션이 권역이 적힌 주문을 넣거나 고칠 수 있습니다. 기본 격리 수준(READ COMMITTED)에서는 막히지 않습니다.
  - 그러면 사라지지 않아야 할 값이 조용히 사라집니다.
  - `common_codes`에서도 마찬가지로, 검사 뒤에 운영자가 코드를 더하거나 고칠 수 있습니다.
  - 해결하려면 `LOCK TABLE orders, common_codes, code_groups` 같은 명시적 잠금이 필요합니다.

**4. `orders.shipping_zone`에 참조 무결성이 없습니다.**
- 자리: `app/models.py` 31행, `0007` 19행
- 까닭:
  - `docs/schema.md`는 이 컬럼이 `SHIPPING_ZONE` 그룹의 코드를 "가리킨다"고 하지만, FK도 제약도 없는 자유 문자열입니다.
  - `common_codes`는 `(group_code, code)` 복합키라서 단일 컬럼 FK로는 걸 수 없고, 그룹 조건을 강제하는 장치도 없습니다.
  - 운영자가 코드를 지우거나 이름을 바꾸면, 주문이 존재하지 않는 코드를 가리키는 상태가 생깁니다.
  - 검사나 인덱스도 없어서 `downgrade()`의 `count(*) ... WHERE shipping_zone IS NOT NULL`은 전체 스캔입니다.

**5. 마이그레이션이 PostgreSQL 전용 문법에 묶여 있습니다.**
- 자리: `0007` 28행과 53~55행
- 까닭:
  - `(VALUES ...) AS v(code, name, sort_order)`의 컬럼 별칭 목록과 `ROW IS DISTINCT FROM ROW`는 PostgreSQL 방언입니다.
  - 다른 DB, 예를 들어 SQLite 테스트 환경에서는 실패합니다.
  - 이 제약이 코드나 문서 어디에도 적혀 있지 않습니다.

**6. SQL을 문자열 보간으로 조립합니다.**
- 자리: `_values()` 15행, `downgrade()` 44행의 `repr(c)`
- 까닭:
  - 지금은 상수라 안전하지만, `ZONES`에 `'`가 든 이름이 들어가면 깨집니다.
  - 44행은 SQL 인용에 Python의 `repr()`을 씁니다. 두 인용 규칙이 다릅니다. 바인드 파라미터나 `sa.text(...).bindparams`를 써야 합니다.

**7. 리비전 0006은 되돌릴 수 없고, 0006의 `orders`는 `id` 컬럼만 있습니다.**
- 자리: `migrations/versions/0006_orders.py` 31~32행, 25~28행
- 까닭:
  - `downgrade()`가 무조건 `RuntimeError`를 던집니다. 그래서 `alembic downgrade base`는 항상 중간에 실패하고, 빈 DB에서도 처음으로 돌아갈 수 없습니다.
  - 이렇게 막은 것이 의도라면 `docs/schema.md`에 적혀 있어야 하는데 없습니다.
  - `orders`에 생성 시각·상태·금액 같은 컬럼이 전혀 없고, `common_codes`에도 `created_at`이나 `updated_by` 같은 감사 컬럼이 없습니다. 운영자가 만든 줄과 리비전이 심은 줄을 나중에 구분할 근거도 남지 않습니다. 결함 1의 뿌리와 같은 문제입니다.

**8. 동시 실행 시 `upgrade()`가 키 충돌로 실패할 수 있습니다.**
- 자리: `0007` 21~30행
- 까닭:
  - `NOT EXISTS` 뒤 `INSERT`는 원자적이지 않습니다. 운영자가 같은 순간에 같은 키를 만들면 PK 위반이 납니다.
  - `ON CONFLICT DO NOTHING`을 쓰거나 잠금을 걸어야 합니다.
  - 가능성은 낮습니다.

## 참고
- `app/models.py`와 `0006`의 컬럼 정의는 서로 일치합니다. 모델과 마이그레이션 사이의 드리프트는 `orders.shipping_zone`이 0007에서만 추가된다는 점 외에는 찾지 못했습니다. 이 컬럼은 모델에도 선언되어 있어 문제가 없습니다.
- 결함 1과 2는 문서화된 원칙을 직접 어기므로 우선순위가 가장 높습니다.
