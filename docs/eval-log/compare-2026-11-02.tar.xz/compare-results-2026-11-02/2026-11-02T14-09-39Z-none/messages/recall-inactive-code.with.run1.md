<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.1082658 -->

`app/services/refunds.py`와 `migrations/0001_refunds.py`를 중심으로 코드 전체를 읽고 결함을 찾았습니다. 파일이 9개뿐이라 별도 감사 도구는 쓰지 않았고, 코드를 실행하거나 DB에 붙여 보지도 않았습니다. 코드는 고치지 않았습니다.

## 결함 목록

**1. 비활성 공통코드로 새 환불이 만들어진다 (중대)**
- 자리: `app/services/refunds.py` `_must_be_a_code` (22–24행), 호출은 31–32행.
- 까닭: `session.get(CommonCode, ...)`로 코드가 있는지만 보고 `is_active`는 보지 않습니다. 그래서 `POINT`(적립금)와 `PROMO`(행사 보상)처럼 `seed/codes.sql`에서 `FALSE`로 시드된 코드도 통과합니다.
- `models.py:12-14`의 독스트링은 "새 기록에서는 못 고르고 옛 기록에서는 읽힌다"고 합니다. 이 약속이 지켜지지 않습니다.
- DB의 FK도 활성 여부는 강제하지 못합니다. 서비스 쪽 검사가 유일한 방어선인데 비어 있습니다.

**2. 환불을 되돌리는 모델이 없다 (중대)**
- 자리: `app/models.py` `Refund`, `migrations/0001_refunds.py`의 `refunds` 표, `refunds.py` `refund`.
- 까닭: `docs/schema.md` 원칙 1은 "환불은 고치지 않고 되돌리는 환불을 새로 세운다"입니다. 그런데 이를 담을 구조가 없습니다.
  - 되돌림 종류나 원 환불을 가리키는 칸(`reverses_id` 등)이 없습니다.
  - `amount > 0` CHECK(`refunds_amount_positive`)와 서비스의 `request.amount <= 0` 거부가 음수 환불을 막습니다.
  - `order.refunded`는 `+=`만 하고 줄일 길이 없습니다. 되돌려도 환불 가능 잔액이 복구되지 않습니다.
  - 되돌리는 코드 경로도 없습니다.
- 결국 잘못된 환불을 바로잡으려면 `orders.refunded`나 `refunds` 행을 직접 UPDATE/DELETE해야 합니다. 이는 원칙 1을 어기는 일입니다.

**3. `orders.refunded`가 파생값인데 DB가 무결성을 보장하지 않는다**
- 자리: `models.py` `Order.refunded`(30행), `migrations/0001_refunds.py` 22행.
- 까닭: `refunds` 합계와 중복된 값이고, 일치를 지키는 장치가 없습니다(트리거, 뷰, 제약 모두 없음).
  - `CHECK (refunded >= 0 AND refunded <= amount)`가 없습니다.
  - `orders.amount > 0` CHECK도 없습니다.
  - 상한(`refunded <= amount`)은 `refunds.py:33`의 앱 코드와 `with_for_update` 행 잠금에만 의존합니다.
- 이 서비스를 거치지 않는 경로(수작업 SQL, 다른 서비스, 이후의 되돌림 구현)에서는 초과 환불이나 합계 불일치가 생길 수 있습니다.

**4. 중복 요청 방지가 없다 (멱등성)**
- 자리: `app/main.py` `post_refund`, `refunds` 표.
- 까닭: 멱등 키나 `(order_id, …)` 유일성이 없습니다. 클라이언트 재시도나 네트워크 중복으로 같은 POST가 두 번 오면 잔액이 남는 한 환불이 두 건 만들어집니다.
- 응답을 못 받고 다시 보낸 경우를 구분할 수 없습니다.

**5. 커밋 실패가 처리되지 않는다**
- 자리: `app/main.py` 35행 `s.commit()`.
- 까닭: `try` 밖에 있습니다. 커밋 시점의 `IntegrityError`나 직렬화 오류는 그대로 500이 됩니다.
- 서비스는 `flush()`까지만 하고 커밋은 엔드포인트가 합니다. 이 경계 자체는 문제없지만, 실패 시 명시적 `rollback`과 오류 매핑이 없습니다. 지금은 `finally`의 `close()`에 암묵적으로 기댑니다.

**6. 시드가 마이그레이션 밖에 있고 재실행하면 깨진다**
- 자리: `seed/codes.sql`, `migrations/0001_refunds.py`.
- 까닭: `refunds`가 `common_codes`를 FK로 참조하는데, 코드 데이터를 넣는 일이 Alembic 리비전에 없습니다. 시드를 따로 돌리지 않으면 모든 환불이 거부됩니다.
- `INSERT`에 `ON CONFLICT`가 없어 두 번 실행하면 PK 충돌로 실패합니다. 코드가 바뀌었을 때 갱신하는 길도 없습니다.

**7. 마이그레이션 환경이 갖춰져 있지 않다**
- 자리: 저장소 루트.
- 까닭: `alembic.ini`와 `env.py`가 없고, 리비전이 `migrations/`에 바로 놓여 있어 `versions/` 구조도 아닙니다. 그대로는 `alembic upgrade`가 동작하지 않을 가능성이 큽니다.
- `models.py`와 마이그레이션이 손으로 중복 기술되어 있어 어긋날 위험이 있습니다. 지금은 일치하지만 자동 대조(`autogenerate` 검사)가 없습니다.

**8. `downgrade`가 주문과 코드 데이터를 지운다**
- 자리: `migrations/0001_refunds.py` `downgrade` (41–47행).
- 까닭: `refunds`가 비었는지만 확인하고 `orders`와 `common_codes`를 `drop_table`합니다. 주문이 있어도 확인 없이 사라집니다.
- 원칙 2("공통코드는 지우지 않는다")와도 어긋납니다. 가드가 `refunds`에만 걸려 있어 보호 범위가 일관되지 않습니다.

**9. 공통코드 삭제 금지가 DB 수준에서 보장되지 않는다**
- 자리: `models.py` `CommonCode`, 마이그레이션의 `common_codes`.
- 까닭: "삭제 칸이 없다"는 것은 관례일 뿐입니다. 아직 환불에 쓰이지 않은 코드는 DELETE가 가능합니다. 사용 중인 코드는 FK(NO ACTION)가 막지만, 그것도 우연한 부수효과입니다. 삭제를 막는 트리거나 권한 설정은 없습니다.

**10. 인덱스와 감사 정보 부재 (경미)**
- 자리: `refunds` 표.
- 까닭: `order_id` FK에 인덱스가 없습니다. 주문별 환불 조회와 FK 검증이 풀스캔이 됩니다.
- `created_at`이나 처리자 같은 칸이 없어 "일어난 일은 지우지 않는다"는 원칙을 뒷받침할 이력이 남지 않습니다.
- 제약 이름이 일부(`CheckConstraint`)만 명시되어 있고 FK는 자동 이름입니다. 이후 마이그레이션에서 지정하기 불편합니다.

**11. 연결 설정이 하드코딩되어 있다 (경미)**
- 자리: `app/main.py` 12행.
- 까닭: DSN이 import 시점에 고정되어 있고 환경 설정이 없습니다. `pool_pre_ping` 같은 연결 안정화 옵션도 없습니다.
- `Amount`가 `Integer`이고 통화 정보가 없어 금액 단위가 모호합니다.

## 우선순위
1번과 2번은 문서에 적힌 약속(비활성 코드, 되돌림 환불)이 코드에 구현되어 있지 않아 가장 먼저 봐야 합니다. 3번과 4번은 금액 정합성에 직접 닿고, 나머지는 운영과 배포 안정성 문제입니다.
