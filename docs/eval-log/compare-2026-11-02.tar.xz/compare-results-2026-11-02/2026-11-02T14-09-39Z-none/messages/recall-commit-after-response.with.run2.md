<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.1119354 -->

저장소 전체(코드 약 200줄, 마이그레이션 1개, `docs/schema.md`)를 읽고 검토했습니다. 코드는 고치지 않았고, 코드를 실행하거나 DB에 붙여 확인하지도 않았습니다. 아래는 모두 코드를 읽고 추론한 결과입니다.

## 트랜잭션 경계

1. **커밋이 응답을 보낸 뒤에 일어나 201이 거짓이 될 수 있습니다.** (`app/main.py` `session_scope`의 `yield` 뒤 `session.commit()`)
   - `yield` 의존성의 종료 코드는 최근 FastAPI(0.118 이후, 고정 버전은 0.141.1)에서 응답을 보낸 뒤에 실행됩니다. 이 부분은 FastAPI 동작에 대한 제 기억에 의존하므로, 고정 버전에서 한 번 확인이 필요합니다.
   - SERIALIZABLE에서는 직렬화 실패(SQLSTATE 40001)가 `COMMIT` 시점에 자주 납니다. 이 경우 클라이언트는 이미 `loan_id`와 `available_copies`가 담긴 201을 받았는데 실제로는 아무것도 저장되지 않습니다.
   - 원칙 1("한 번에 선다")은 DB 안에서는 지켜지지만, 호출자에게 한 약속은 깨집니다.
   - 커밋 실패는 응답을 바꿀 수 없어서 로그에만 남습니다.
   - 커밋은 엔드포인트나 서비스 안에서 응답을 만들기 전에 해야 합니다.

2. **직렬화 실패를 다시 시도하는 곳이 없습니다.** (`app/db.py` `isolation_level="SERIALIZABLE"`, `app/main.py`)
   - 같은 책을 동시에 빌리면 진 쪽은 40001 `OperationalError`를 받습니다. `session_scope`는 롤백하고 다시 던질 뿐이라 클라이언트는 500을 받습니다.
   - 원칙 3의 "하나만 선다"는 성립하지만, 나머지 하나는 재시도 없이 오류로 끝납니다.
   - 남은 권수가 1권보다 많을 때도 서로 다른 회원의 대출이 불필요하게 충돌합니다.
   - 재시도 루프나 40001 → 409/503 변환이 없습니다.

3. **동시성 보호가 엔진의 격리 수준 하나에만 걸려 있습니다.** (`app/services/loans.py` `lend`, 31~40행)
   - `SELECT`로 읽고 파이썬에서 `-= 1`을 한 뒤 절댓값으로 `UPDATE`하는 읽고-검사하고-쓰기 구조입니다. `FOR UPDATE`도, 원자적인 `UPDATE ... WHERE available_copies > 0`도 없습니다.
   - 이 엔진 밖의 세션이나 스크립트, 격리 수준을 낮춘 세션이 같은 표를 쓰면 갱신 손실이 납니다.
   - 마지막 방어선인 `CHECK`가 깨지면 `IntegrityError`가 되어 422가 아니라 500으로 나옵니다.

4. **중복 요청을 막는 장치가 없습니다.** (`app/main.py` `post_loan`, `app/models.py` `Loan`)
   - 멱등 키가 없습니다. 위 1번처럼 응답이 유실되거나 클라이언트가 재시도하면 같은 회원이 같은 책을 두 번 빌립니다.
   - `(book_id, member_id)`에 `returned_on IS NULL` 조건의 부분 유일 제약이 없어, 중복 대출이 DB에서 걸러지지 않습니다.
   - 회원당 대출 한도도 없습니다.

## 데이터 모델

5. **`loaned_on`을 클라이언트가 정합니다.** (`app/schemas.py` `LoanIn.loaned_on`, `lend`의 `due_on` 계산)
   - 과거나 먼 미래 날짜를 넣으면 `due_on`이 그에 맞춰 계산됩니다. 연체를 지우거나 만들어 낼 수 있습니다.
   - 서버 날짜로 정하거나 범위를 검사해야 합니다.

6. **`loan_days`와 `available_copies`에 제약이 부족합니다.** (`app/models.py` `Book`, `migrations/0001_initial.py` `books`)
   - `loan_days > 0` 검사가 없습니다. 0 이하이면 `loans_due_after_loan` 제약에 걸려 대출이 500으로 실패합니다.
   - 총 소장 권수 열(`total_copies`)이 없어 `available_copies`의 상한을 정할 수 없습니다. 대출 중인 권수와 대조할 수도 없어서, 한 번 어긋나면 바로잡을 근거가 없습니다.

7. **`loans`에 제약과 색인이 빠져 있습니다.** (`migrations/0001_initial.py` `loans`, `app/models.py` `Loan`)
   - `returned_on >= loaned_on` 검사가 없습니다.
   - `book_id`와 `member_id`에 색인이 없습니다. PostgreSQL은 FK에 색인을 자동으로 만들지 않아, 도서별·회원별 조회와 미반납 조회는 전체를 훑습니다.

8. **제약과 FK에 이름 규칙(naming convention)이 없습니다.** (`app/models.py` `Base`, 마이그레이션의 `unique=True`와 `ForeignKey`)
   - `Base`에 `MetaData(naming_convention=...)`가 없습니다. 유일 제약과 FK 이름은 DB가 자동으로 붙입니다.
   - 나중 마이그레이션에서 이를 이름으로 지우거나 바꾸기 어렵습니다.

## 되돌림

9. **반납과 대출 취소 경로가 없습니다.** (`app/main.py`, `app/services/loans.py` 전체; `docs/schema.md` 5~7행)
   - 문서는 "반납하면 `returned_on`이 찬다"고 하지만, `returned_on`을 쓰는 코드도 `available_copies`를 늘리는 코드도 없습니다.
   - 대출은 권수를 줄이기만 하므로, 책이 한 번 다 빌려 나가면 다시 빌릴 수 없습니다.
   - 대출 취소, 오입력 정정, 회원 탈퇴 시 처리도 없습니다.
   - 반납을 구현할 때 "줄 추가와 권수 감소는 한 몸"이라는 원칙 1을 되돌림 쪽에도 똑같이 지켜야 합니다.

10. **다운그레이드 가드가 반쪽입니다.** (`migrations/0001_initial.py` `downgrade`, 40~46행)
    - `loans`가 비어 있는지만 검사하고 `books`와 `members`를 지웁니다. 대출이 한 건도 없어도 도서 목록과 회원 명부가 사라지고, 되살릴 길은 없습니다. 주석의 "되살릴 길이 없다"는 이 두 표에도 똑같이 해당합니다.
    - 검사와 `DROP` 사이에 잠금이 없어, 그 사이에 들어온 대출 기록이 그대로 지워질 수 있습니다.

11. **마이그레이션을 실행할 설정이 저장소에 없습니다.** (`migrations/`)
    - `alembic.ini`, `env.py`, `script.py.mako`가 없고 `0001_initial.py`만 있습니다. 이대로는 `alembic upgrade`를 돌릴 수 없고, 모델과 마이그레이션이 어긋나는지(드리프트)를 잡는 `--autogenerate` 검증도 불가능합니다.
    - 다른 곳에 있는 설정을 쓰는 것이라면 이 항목은 해당되지 않습니다.

## 확인되지 않은 부분

- 위 1번의 FastAPI 종료 코드 실행 시점은 고정 버전 기준으로 실제 확인이 필요합니다.
- 테스트와 시드 데이터는 저장소에 없어 검토하지 못했습니다.
