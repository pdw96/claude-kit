<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0900145 -->

`app/`, `migrations/`, `seed/` and `docs/schema.md` are all reviewed, but I only read the code and ran nothing. I didn't use the installed review tools, because the repo is small enough to read in full. I changed no code. Items 1 to 4 are the ones most likely to hurt real data.

## Data and transaction defects

1. **Wrong membership start date** (`app/services/memberships.py:29-35`, `approve`)
   - `starts_on` is set to the approval date, and `valid_until` is that date plus `duration_days`.
   - `seed/plans.sql` says "신청일로부터 N일", and `docs/schema.md` says approval happens the next day or later, with weekend applications approved on Monday. `applied_on` is never used.
   - A member who applies on Saturday and is approved on Monday loses two days of a paid membership.
   - The wrong date goes into `starts_on` and `valid_until`, which the entry terminal uses to block access.

2. **Date taken in UTC** (`memberships.py:29-30`)
   - `starts_on = datetime.now(timezone.utc).date()` is a UTC date. `applied_on` is a date from the gym's local counter.
   - Between 00:00 and 09:00 local time (assuming KST), the start date is one day earlier than the local date.
   - The business timezone is defined nowhere.

3. **Concurrent approval is not guarded** (`memberships.py:22-26`, `app/main.py:30-33`)
   - `session.get` takes no lock (no `with_for_update`), and the `status != "pending"` check is a read-then-write.
   - Two simultaneous requests can both pass it. The `unique` constraint on `memberships.application_id` catches the second one, but only as an `IntegrityError` at flush or commit.
   - `post_approval` catches only `RefusedApproval`, so the client gets a 500 instead of a 422.
   - `s.commit()` is also outside the `try`, so a commit failure is not translated either.

4. **Missing plan crashes with `AttributeError`** (`memberships.py:27, 35`)
   - `session.get(Plan, ...)` can return `None`. The code then reads `plan.duration_days`, which gives a 500 and no clear message.
   - The foreign key makes this unlikely, but nothing handles it.

5. **`downgrade` can silently destroy data** (`migrations/0001_memberships.py:40-46`)
   - It only checks that `memberships` is empty. It then drops `applications` (pending and rejected rows) and `plans` without any check.
   - The existence check and the drop are separate statements, so a row inserted between them is not protected.

6. **Seed is not part of the migration and cannot be rerun** (`seed/plans.sql`)
   - The reference data is outside Alembic, so there is no guarantee of a deploy order. `approve` fails if `plans` is empty.
   - The plain `INSERT` has no `ON CONFLICT`. Running it twice fails on the primary key.
   - Price and duration changes have no upgrade path.

7. **No Alembic environment** (repo root)
   - `alembic` is in `requirements.txt`, but there is no `alembic.ini`, `env.py` or `script.py.mako`, and `migrations/` has no `versions/` layout.
   - `Base.metadata` is not wired up, so `alembic upgrade` and autogenerate cannot run.

## Model and constraint defects

8. **No constraint on `applications.status`** (`models.py:26`, migration line 25)
   - It is a free-form `String(10)` with no `CHECK` or enum. Values other than "pending" and "approved" can be stored, and nothing else defines the allowed values or transitions.

9. **Nothing prevents overlapping or duplicate memberships**
   - There is no exclusion constraint or uniqueness rule on `member_id` and the period.
   - The same member can hold several pending applications. Approving each one creates overlapping memberships.

10. **`member_id` references nothing** (`models.py:23, 35`, migration lines 22, 31)
    - There is no `members` table or foreign key. `memberships.member_id` is copied from the application without any consistency check.

11. **Price and duration are not recorded on the application or membership**
    - The membership stores no price paid and no plan code.
    - If `plans.price` or `duration_days` is edited later, the amount paid and the basis for the dates cannot be reconstructed.

12. **Missing value constraints**
    - `plans.duration_days` and `price` have no `CHECK > 0`.
    - No `CHECK` ties the stored period to `duration_days`.
    - `applied_on` has no default.
    - There is no index on `applications.member_id` or `plan_code`.

13. **`approved_by` is a client-supplied string** (`main.py:23-25, 30`)
    - There is no authentication, and the value is stored as the audit identity, so anyone can claim any name.
    - There is no foreign key to a staff table.

14. **Unclear session and engine setup** (`main.py:12-20`)
    - The DB URL (with no password) is hard-coded, and the engine is created at import time with no pool configuration.
    - Commit belongs to the endpoint, but `session()` has no explicit `rollback`. It relies on `close()` to roll back.
    - `approve` only flushes, so its callers must remember to commit.

15. **Model and migration are maintained separately**
    - `models.py` and the migration declare the same schema twice, with nothing to detect drift.
    - This is why item 7 matters. Without autogenerate or a check, the two copies can diverge.
