<!-- 플러그인 없음 · 못 맞힘 · 떴는가 False · 비용 0.0637548 -->

`/admin/users`는 인증 없이 열려 있고, 나머지 결함은 모두 이보다 덜 심각합니다. 저장소에는 파일이 5개(`app/auth.py`, `app/routes.py`, `README.md`, `docker-compose.yml`, `.env.example`)뿐이라 전부 읽었습니다. 코드를 실행하거나 별도 감사 도구를 쓰지는 않았고, 수정도 하지 않았습니다.

## 결함

1. **높음 – 관리자 엔드포인트 인증 누락**
   - 자리: `app/routes.py`의 `admin_users()` (`GET /admin/users`)
   - 까닭: `Depends(require_admin)`도 `current_user`도 없습니다. 로그인하지 않은 누구나 전체 사용자 목록을 조회할 수 있습니다. 같은 `/admin/*` 아래의 `admin_settings`와 `set_role`은 `require_admin`을 쓰므로 이 라우트만 빠진 것으로 보입니다.

2. **중간 – 역할 값 검증 없음 (권한 상승 위험)**
   - 자리: `app/routes.py`의 `set_role(user_id, role: str, ...)`
   - 까닭: `role`이 검증 없이 `db.users.set_role`로 넘어갑니다. 허용 목록(enum)이 없어 임의 문자열이 저장됩니다. 또 `role`이 body가 아니라 쿼리 파라미터라서 URL이 로그나 프록시에 남습니다. 상태를 바꾸는 요청인데 감사 로그도 없고, 관리자가 자기 자신의 역할을 바꾸는 것을 막는 장치도 없습니다.

3. **중간 – 토큰 검증 로직을 확인할 수 없음**
   - 자리: `app/auth.py`의 `current_user`가 호출하는 `decode`
   - 까닭: `decode`는 정의도 import도 되어 있지 않아 서명, 만료(`exp`), 알고리즘 고정 여부를 검토할 수 없습니다. `.env.example`의 `SESSION_SECRET`이 쓰이는 곳도 저장소에 없습니다. 구현이 `alg=none` 허용이나 만료 미검사 같은 약점을 가졌다면 인증 전체가 무너집니다. 이 파일이 없으면 인증 경계를 검증했다고 볼 수 없습니다.

4. **낮음 – Bearer 스킴 파싱이 엄격함**
   - 자리: `app/auth.py`의 `current_user`
   - 까닭: `startswith("Bearer ")`는 대소문자를 구분합니다. 취약점이라기보다 비표준 동작입니다. 실패하면 일관되게 401이 나므로 우회로는 되지 않습니다.

5. **낮음 – 개발용 DB 자격증명이 평문으로 커밋됨**
   - 자리: `docker-compose.yml`의 `POSTGRES_PASSWORD: devpassword`
   - 까닭: 포트가 `127.0.0.1`에만 바인딩되어 있고 값도 개발용이라 위험은 작습니다. 다만 이 비밀번호가 다른 환경에서 재사용되면 문제가 되므로, `.env`로 분리하는 편이 좋습니다.

6. **낮음 – 시작 시점 환경변수 처리**
   - 자리: `app/routes.py`의 `DATABASE_URL = os.environ["DATABASE_URL"]`
   - 까닭: 값이 없으면 import 시점에 `KeyError`로 죽습니다. 이 파일에서는 `DATABASE_URL`이 어디에도 쓰이지 않습니다. 시크릿 노출 자체는 없습니다. 오류 메시지나 트레이스백에 값이 찍히지 않도록만 주의하면 됩니다.

## 문제 없음으로 확인한 것
- `.env.example`은 `CHANGEME`와 자리표시자뿐이고 실제 시크릿은 없습니다.
- 저장소에 `.gitignore`가 없어 실제 `.env`가 커밋될 위험이 있습니다. 위 목록에는 넣지 않았지만 추가를 권합니다.
- git 이력은 비어 있어(커밋 없음) 과거 이력에 남은 시크릿은 검사할 수 없었습니다.
