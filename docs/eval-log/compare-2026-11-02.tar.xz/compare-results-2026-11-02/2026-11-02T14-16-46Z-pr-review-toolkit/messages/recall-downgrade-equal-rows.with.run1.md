<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.36074039999999996 -->

`pr-review-toolkit`의 `code-reviewer`와 `silent-failure-hunter`를 돌렸고, 제가 직접 읽은 내용과 합쳤습니다. 코드는 고치지 않았습니다. 이 검토는 읽기만 했고 마이그레이션을 실제 DB에서 실행해 보지는 않았습니다.

## 높음

**1. `0007_shipping_zone.py` · `downgrade()`: 심은 줄과 운영자 줄을 구분하지 못해 운영자 데이터를 지웁니다.**
- 이는 `docs/schema.md` 원칙 1(사람이 만든 데이터는 리비전이 지우지 않는다)을 어깁니다.
- `upgrade()`는 `WHERE NOT EXISTS`로 이미 있는 줄을 건너뛰고, 자기가 넣은 줄이 무엇인지 어디에도 기록하지 않습니다.
- 운영자가 0007 전에 `METRO`/`REGION`/`ISLAND`를 시드와 같은 값으로 만들어 두면, `upgrade`는 그 줄을 건너뜁니다.
- 하지만 `downgrade`의 `extra`와 `changed` 검사는 둘 다 통과하고, `DELETE`가 운영자의 줄을 지웁니다. "값이 같으니 내가 심은 줄"이라는 가정이 틀렸습니다.

**2. `0007_shipping_zone.py` · `downgrade()`: `code_groups` 줄은 아무 검사도 받지 않고 지워집니다.**
- 마지막 `DELETE FROM code_groups WHERE group_code = 'SHIPPING_ZONE'` 앞에는 `orders`와 `common_codes`만 보는 검사 세 개가 있습니다.
- 운영자가 미리 만든 `SHIPPING_ZONE` 그룹, 또는 리비전이 만든 뒤 이름·설명을 고친 그룹도 그대로 지워집니다.
- 코드 줄에 있는 "심은 셋인지는 위의 멈춤 검사가 지킨다"는 주석은 그룹 줄에는 해당하지 않습니다.

**3. `0007_shipping_zone.py` · `downgrade()`: 검사와 삭제 사이에 잠금이 없어 경합이 생깁니다.**
- 검사 세 개는 READ COMMITTED의 일반 SELECT이고, 이어지는 `DELETE`와 `drop_column`과 같은 락 아래에 있지 않습니다.
- 검사 통과 뒤 운영자가 `SHIPPING_ZONE/JEJU` 같은 코드를 추가하면, `code` 조건이 없는 `DELETE`가 그 코드까지 지웁니다.
- `used` 검사 뒤 앱이 `orders.shipping_zone`에 값을 쓰고 커밋하면, `drop_column`이 그 값을 오류 없이 날립니다.
- `docs/schema.md`는 운영자가 관리 화면에서 이 표를 라이브로 고친다고 적고 있어, 현실적인 시나리오입니다.

**4. `app/models.py` `Order.shipping_zone`, `0007` · `upgrade()`: `orders.shipping_zone`에 제약이 전혀 없습니다.**
- 문서는 이 칸이 `SHIPPING_ZONE` 그룹의 코드를 "가리킨다"고 하지만, FK도 CHECK도 없습니다.
- 그래서 `'MARS'`나 `'metro'` 같은 값이 그대로 들어갑니다.
- 운영자가 `ISLAND` 코드를 지우거나 비활성화해도 막는 것이 없어, 그 코드를 쓰던 주문은 매달린 값이 됩니다.
- `common_codes`의 PK가 `(group_code, code)` 복합키라 `code` 단일 컬럼 FK는 걸 수 없습니다. 고정 그룹 컬럼과 복합 FK, 트리거, 전용 표 중 하나가 필요합니다.
- 이 때문에 `downgrade`의 `used` 검사가 사실상 유일한 무결성 장치가 됩니다.

## 중간

**5. `0007_shipping_zone.py` · `upgrade()`: 충돌하는 기존 줄을 알리지 않고 건너뜁니다.**
- 운영자가 `METRO`를 다른 뜻(예: 이름 "서울만", 순서 9)으로 만들어 뒀다면, 두 `INSERT`는 아무 경고 없이 건너뜁니다.
- 시드의 의미("수도권")를 가정하는 코드는 조용히 틀어지고, 나중에 `downgrade`가 `changed`로 멈추는 것은 올바르지만 원인이 어디에도 남지 않습니다.
- 같은 키인데 값이 다르면 건너뛰지 말고 멈추거나 기록해야 합니다.

**6. `0007_shipping_zone.py` · `upgrade()`: `NOT EXISTS` 뒤 `INSERT` 사이에 동시 삽입 경합이 있습니다.**
- 같은 PK가 그 사이에 들어오면 건너뛰는 대신 `IntegrityError`가 납니다.
- 이는 `ON CONFLICT DO NOTHING`으로 막을 수 있습니다.
- 같은 파일은 `(VALUES …) AS v(…)`와 `IS DISTINCT FROM` 같은 PostgreSQL 전용 문법을 씁니다. DDL이 트랜잭션에 묶이지 않는 DB에서는 `downgrade`가 `DELETE`까지 하고 `drop_column`에서 실패해 반쯤 되돌려진 채 남을 수 있습니다. PostgreSQL 전용이라는 전제를 코드나 문서에 밝혀야 합니다.

**7. `0007_shipping_zone.py` · `upgrade()`와 `app/models.py`: 기존 주문의 `shipping_zone`이 NULL인 채 남고 영구히 nullable입니다.**
- 기존 주문은 권역이 없는 상태가 되고, 배송비를 가르는 축인데도 새 주문도 값을 생략할 수 있습니다.
- NULL을 "미분류"로 정한 것인지 문서에도 없습니다.
- 이 항목은 설계 판단이 필요한 쪽에 가깝습니다.

## 낮음

**8. `0007_shipping_zone.py` · `_values()`, `downgrade()`의 `NOT IN (...)`: SQL을 f-string과 `repr()`로 만듭니다.**
- 지금은 입력이 모듈 상수라 안전합니다.
- 이름에 `'`가 들어가면 깨지고, `repr()`은 Python 인용이지 SQL 인용이 아닙니다. 바인드 파라미터를 써야 합니다.

**9. `0006_orders.py` · `downgrade()`: 항상 예외를 냅니다.**
- 첫 리비전이라 의도된 것이지만, `alembic downgrade base`는 0007을 되돌린 뒤 반드시 여기서 실패합니다.
- 이 사실을 문서에 적어 두는 편이 낫습니다.

## 확인했고 문제없는 것

- 모델과 마이그레이션의 컬럼·타입·nullable·`server_default`·복합 PK·FK는 0007 적용 후 일치합니다.
- PostgreSQL에서는 DDL이 트랜잭션 안에서 돌아, 동시 쓰기가 없다면 검사 하나가 실패할 때 `downgrade` 전체가 롤백됩니다.
- `used`와 `extra` 검사는 경합을 빼면 의도대로 동작합니다.

## 한 줄 요약

1~3번은 같은 뿌리입니다. 마이그레이션이 자기가 넣은 줄을 기록하지 않고, 삭제 범위가 검사한 범위와 일치하지 않으며, 잠금도 없습니다. 이 셋이 원칙 1을 실제로 깨뜨립니다.
