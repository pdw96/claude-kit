<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.38633049999999997 -->

저장소 전체를 검토했습니다. 코드는 고치지 않았고, 실행도 하지 않고 읽어서 판단했습니다. 제가 직접 읽은 내용과 pr-review-toolkit의 code-reviewer, silent-failure-hunter 결과를 합쳤습니다. 모델과 마이그레이션의 컬럼·제약 정의는 서로 같습니다.

## 높음

1. **만료일을 신청일이 아니라 승인일 기준으로 계산합니다.**
   - 자리: `app/services/memberships.py` `approve()` 29–35줄, `seed/plans.sql` 3–5줄, `docs/schema.md` 6·9줄
   - 까닭: seed 문구(화면 안내로도 나감)는 "신청일 + 기간"이라고 하고, `applied_on`은 회원이 창구에 온 날입니다. 코드는 `starts_on = approved_at.date()`를 쓰고 `applied_on`은 읽지 않습니다.
   - 문서상 승인은 신청 다음 날이나 그 뒤에 이뤄지고, 주말 신청은 월요일에 승인됩니다. 그래서 만료일이 안내보다 1~3일 늦게 잡힙니다. 출입 단말이 이 `valid_until`로 회원을 막으므로 안내와 실제 동작이 어긋납니다.
   - 어느 쪽이 정책인지는 정해야 합니다. 신청일이 맞다면 코드를, 승인일이 맞다면 seed 문구를 고쳐야 합니다.

2. **시작일이 UTC 날짜입니다.**
   - 자리: `app/services/memberships.py` 29–30줄
   - 까닭: `datetime.now(timezone.utc).date()`는 한국 시간 00:00~08:59에 승인하면 전날 날짜가 됩니다. 시작일과 만료일이 하루 당겨집니다. 1번을 신청일 기준으로 고치면 함께 사라집니다.

3. **동시 승인에 락이 없어서, 늦은 쪽 요청이 500으로 끝납니다.**
   - 자리: `app/services/memberships.py` 22–26줄·39–41줄, `app/main.py` `post_approval` 29–33줄
   - 까닭: `session.get(Application, id)`에 `FOR UPDATE`나 조건부 UPDATE가 없어서, 두 요청이 모두 `pending`을 통과합니다. 회원권이 두 장 생기는 것은 `memberships.application_id`의 UNIQUE가 막습니다.
   - 늦은 쪽은 `flush()`나 `commit()`에서 `IntegrityError`를 맞습니다. `main.py`는 `RefusedApproval`만 잡으므로 "이미 처리한 신청"(422) 대신 처리되지 않은 500이 나갑니다.

4. **`downgrade()` 가드가 `memberships`만 확인합니다.**
   - 자리: `migrations/0001_memberships.py` `downgrade()` 40–46줄
   - 까닭: 승인 전 `applications`가 있어도 경고 없이 `drop_table`해서 접수 데이터가 영구히 사라집니다.
   - `plans`도 함께 지워지는데 `upgrade()`는 plans를 다시 심지 않습니다. downgrade 뒤 upgrade를 하면 plans가 비어서 새 신청이 모두 FK에 막힙니다.
   - 확인(`SELECT EXISTS`)과 삭제 사이에 `LOCK TABLE`이 없어서, 그 사이에 들어온 승인이 그대로 지워질 수 있습니다.

## 중간

5. **`commit()`이 `try` 밖에 있습니다.**
   - 자리: `app/main.py` 33줄
   - 까닭: 연결 끊김이나 직렬화 실패 같은 커밋 단계 실패가 가공 없이 500이 됩니다. 클라이언트는 승인됐는지 알 수 없고, 롤백도 `finally`의 `close()`에 암묵적으로 맡겨져 있습니다.

6. **seed가 마이그레이션과 따로 놀고 다시 돌릴 수 없습니다.**
   - 자리: `seed/plans.sql` 2–5줄, `docs/schema.md` 5줄
   - 까닭: 일반 `INSERT`라서 두 번째 실행은 PK 충돌로 실패합니다. alembic revision에 묶여 있지 않아서, 마이그레이션만 돌린 DB는 plans가 비어 있습니다. 기간이나 문구를 고쳐도 기존 행에 반영할 경로가 없습니다.

7. **plan이 없을 때 `AttributeError`가 납니다.**
   - 자리: `app/services/memberships.py` 27줄, 35줄
   - 까닭: `session.get(Plan, ...)`가 `None`이면 `plan.duration_days`에서 터집니다. FK가 있어 평상시엔 안 나지만, seed가 안 심긴 환경에서는 이 경로로 갑니다.

8. **`plans`에 CHECK 제약이 없습니다.**
   - 자리: `app/models.py` 14–15줄, `migrations/0001_memberships.py` 15–16줄
   - 까닭: `duration_days <= 0`이나 음수 `price`가 들어갈 수 있습니다. `duration_days`가 0 이하인 plan이 들어가면 승인 시 `memberships_period` CHECK에 걸려 500이 납니다. 기준 데이터가 틀렸다는 사실이 운영자에게 전달되지 않습니다.

## 낮음

9. **`applications.status` 값을 DB가 강제하지 않습니다.**
   - 자리: `app/models.py` 26줄, `migrations/0001_memberships.py` 25줄
   - 까닭: 자유 문자열이라 CHECK나 enum이 없습니다. 상태 전이의 방어선이 서비스 코드의 문자열 비교 하나뿐입니다.

10. **신청 시점의 plan 조건을 고정해 두지 않습니다.**
    - 자리: `app/models.py` `Application`, `Membership`
    - 까닭: 두 표 모두 `plan_code`, 가격, 기간의 스냅샷이 없습니다. 승인 전에 plan이 바뀌면 신청 때와 다른 기간이 적용됩니다. 승인 뒤에도 `memberships`만으로는 무엇을 샀는지 알 수 없습니다.

11. **`valid_until`이 마지막 유효일인지 첫 무효일인지 정의돼 있지 않습니다.**
    - 자리: `docs/schema.md` 7줄, `app/services/memberships.py` 35줄
    - 까닭: 마지막 유효일로 읽으면 "30일" 회원권이 31일이 됩니다. 출입 단말과 기준을 맞춰야 합니다.

12. **마이그레이션 환경 파일이 저장소에 없습니다.**
    - 자리: `migrations/`
    - 까닭: `env.py`와 `alembic.ini`가 없어서 트랜잭션 DDL 설정과 실제 적용 방법을 확인할 수 없습니다. 부분 실패 시 전체 롤백되는지도 알 수 없습니다.

13. **`downgrade()`가 던지는 오류가 거칩니다.**
    - 자리: `migrations/0001_memberships.py` 43줄
    - 까닭: 일반 `RuntimeError`에 건수나 대처 안내가 없습니다.

가장 먼저 볼 것은 1번(정책 확정)과 3번(동시 승인 처리)입니다.
