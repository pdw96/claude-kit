<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.782135 -->

`pr-review-toolkit`의 에이전트 4개(code-reviewer, silent-failure-hunter, type-design-analyzer, comment-analyzer)로 저장소 전체를 검토했습니다. 코드는 고치지 않았습니다. 이 환경에는 FastAPI, SQLAlchemy, Alembic이 설치돼 있지 않고 DB도 없어서 실행 검증은 못 했습니다. 아래 내용은 모두 코드를 읽고 판단한 것입니다. 1번은 FastAPI 0.118 이후 동작에 대한 에이전트들의 기억에 기대고 있어서 재현 테스트로 확인하길 권합니다.

## 치명 · 높음

1. **커밋이 응답을 보낸 뒤에 실행됩니다.**
   - 자리: `app/main.py` `session_scope()`의 `session.commit()`(24줄), `post_loan()`의 `Depends(session_scope)`(33줄).
   - 까닭: 고정 버전 FastAPI 0.141.1에서는 `yield` 의존성의 종료 코드가 응답 뒤에 돕니다. SERIALIZABLE에서는 커밋 시점에 직렬화 실패(40001)가 날 수 있습니다. 그러면 DB에는 롤백됐는데 클라이언트는 이미 `201`과 `loan_id`를 받습니다.
   - 같은 자리에서 `session_scope`의 "한 번에 들어가거나 하나도 들어가지 않는다" 주석은 DB 안에서만 맞습니다. 호출자가 받은 결과와는 어긋납니다.

2. **직렬화 실패(40001)와 교착(40P01)을 처리하지 않고 재시도도 없습니다.**
   - 자리: `app/db.py:9`, `app/services/loans.py` `lend()`의 `available_copies -= 1`(40줄)과 `flush()`(48줄), `app/main.py:35-41`.
   - 까닭: 같은 책을 동시에 빌리면 한쪽이 `OperationalError`로 500을 받습니다. 남은 권수가 2권 이상이어도 마찬가지입니다. `docs/schema.md` 원칙 3의 "하나만 선다"는 재시도 루프 없이는 "정당한 요청이 500으로 떨어진다"가 됩니다.
   - 재시도는 커밋이 의존성 종료 단계에 있으면 붙일 수 없어서 1번과 함께 손봐야 합니다.

3. **같은 회원이 같은 책을 중복 대출하는 것을 막지 못합니다.**
   - 자리: `app/models.py:29-38`, `migrations/0001_initial.py:27-36`, `app/services/loans.py:30-49`.
   - 까닭: `loans`에 `returned_on IS NULL` 조건의 부분 UNIQUE 인덱스가 없습니다. `lend()`도 기존 미반납 대출을 조회하지 않습니다. 같은 요청을 두 번 보내면 대출 줄이 둘 생기고 권수가 두 번 줄어듭니다. SERIALIZABLE로도 이 중복은 막히지 않습니다.

4. **`returned_on`과 반납 상태가 DB 제약으로 강제되지 않습니다.**
   - 자리: `app/models.py:31,38`, `migrations/0001_initial.py:34-35`.
   - 까닭: CHECK가 `due_on >= loaned_on` 하나뿐이라 `returned_on`이 `loaned_on`보다 앞서는 행이 들어갑니다.
   - 반납 코드가 저장소에 없고, `available_copies`와 미반납 대출 수가 따로 놀 수 있는 구조입니다.

5. **`IntegrityError`가 번역되지 않고 전부 500이 됩니다.**
   - 자리: `app/services/loans.py:41-48`, `app/main.py:40`.
   - 까닭: `books_available_not_negative`, `loans_due_after_loan`, FK 위반은 모두 `IntegrityError`가 됩니다. `post_loan`은 `RefusedLoan`만 잡습니다. 제약 이름도 로그에 남지 않아 데이터 오류와 서버 버그를 구분할 수 없습니다.

## 마이그레이션 · 되돌림

6. **downgrade 가드가 `loans`만 보호합니다.**
   - 자리: `migrations/0001_initial.py:39-46`.
   - 까닭: `loans`가 비면 `books`와 `members`에 데이터가 있어도 그대로 `drop_table`합니다. "지우면 되살릴 길이 없다"는 주석은 이 두 표에도 똑같이 해당합니다. `docs/schema.md:5`는 members를 "지우지 않는" 데이터로 설명하는데 이와 어긋납니다.

7. **downgrade 가드의 검사와 삭제 사이에 경쟁 조건이 있습니다.**
   - 자리: `migrations/0001_initial.py:42-44`.
   - 까닭: `SELECT EXISTS`는 약한 잠금만 잡습니다. 검사 뒤 `DROP` 전에 대출이 커밋되면 가드가 막으려던 손실이 그대로 일어납니다. 먼저 `LOCK TABLE ... ACCESS EXCLUSIVE`가 필요합니다. 틈은 좁다는 평가도 있었습니다.

8. **오프라인(`--sql`) 모드에서 downgrade 가드가 무력화됩니다.**
   - 자리: `migrations/0001_initial.py:41-43`.
   - 까닭: `bind.execute`가 실제 쿼리를 돌리지 않아 검사를 조용히 통과하고 DROP SQL이 생성됩니다. 오류 메시지도 건수나 우회 방법을 알려 주지 않습니다.

9. **Alembic 실행 구조가 없습니다.**
   - 자리: `migrations/` 디렉터리.
   - 까닭: `env.py`, `script.py.mako`, `versions/`, `alembic.ini`가 없습니다. 이대로면 `alembic upgrade`와 `downgrade`가 이 파일을 찾지 못해 두 경로 모두 검증되지 않았습니다. 이 저장소가 일부만 발췌한 것이라면 해당하지 않습니다.
   - `target_metadata`가 없어서 모델과 마이그레이션 일치를 `alembic check`로 자동 검증할 수도 없습니다.

10. **(확신 낮음) FK 컬럼에 타입이 없습니다.**
    - 자리: `migrations/0001_initial.py:30-31`.
    - 까닭: `sa.Column("book_id", sa.ForeignKey(...))`처럼 타입 없이 쓰면 DDL 컴파일 때 `NullType` 오류가 날 수 있습니다. 확인하지 못했습니다. `sa.Integer`를 명시하면 어느 쪽이든 안전합니다.

## 데이터 모델 (중간)

11. **재고 상한과 소장 권수가 없습니다.**
    - 자리: `app/models.py:20,26`.
    - 까닭: CHECK가 `>= 0`뿐이고 `total_copies`가 없어서 `available_copies <= total_copies`를 표현할 수 없습니다. 반납이 생기면 권수가 소장 수를 넘을 수 있습니다.

12. **`loan_days`에 CHECK가 없습니다.**
    - 자리: `app/models.py:25`, `migrations/0001_initial.py:23`.
    - 까닭: 0이나 음수가 들어갈 수 있습니다. 음수면 `lend()`가 계산한 `due_on`(`loans.py:45`)이 `loaned_on`보다 앞서고, 한참 뒤 `loans_due_after_loan`에서 500으로 터집니다.

13. **FK 삭제 동작이 명시돼 있지 않고 FK 컬럼에 인덱스가 없습니다.**
    - 자리: `app/models.py:34-35`, `migrations/0001_initial.py:30-31`.
    - 까닭: `ondelete`가 없어 기본값(NO ACTION)입니다. 의도와 도서 삭제 정책이 문서에 없습니다. PostgreSQL은 FK에 인덱스를 자동으로 만들지 않아서, `loans.member_id`와 `book_id` 조회는 전체 스캔입니다.

14. **ISBN 규칙이 schema, 모델, DB 사이에서 어긋납니다.**
    - 자리: `app/schemas.py:7`, `app/models.py:23`, `migrations/0001_initial.py:21`.
    - 까닭: 스키마는 길이 10~13을 받아 11, 12자도 통과합니다. DB에는 길이 CHECK가 없습니다. 정규화 규칙(ISBN-10/13 통일)이 없어서 같은 책이 두 행으로 들어갈 수 있고 UNIQUE가 막지 못합니다.

15. **원칙 1과 3이 DB가 아니라 코드와 설정에만 의존합니다.**
    - 자리: `docs/schema.md:11-14`, `app/db.py:9`.
    - 까닭: `Loan`을 직접 INSERT하는 다른 경로가 있으면 재고가 어긋납니다. SERIALIZABLE은 이 엔진 설정에서만 켜지고 스키마가 보장하지 않습니다. 엔진 전체에 걸려 읽기 세션에도 적용됩니다.

16. **빈 문자열을 막지 않습니다.**
    - 자리: `app/models.py:13,15`와 `title`, `app/schemas.py:8`.
    - 까닭: 스키마의 `card_number`는 `min_length=1`인데 DB는 `card_number`, `name`, `title`의 빈 문자열을 모두 허용합니다.

## 트랜잭션 · 오류 처리 (낮음~중간)

17. **거절 사유가 전부 같은 `RefusedLoan`이고 422로 나갑니다.**
    - 자리: `app/services/loans.py:12,33,36,38`, `app/main.py:41`.
    - 까닭: 없는 도서, 비활성 회원, 재고 없음을 한국어 문장 파싱으로만 구분합니다. 의미상 404와 409에 가깝습니다. 카드번호와 ISBN이 응답에 그대로 되돌아갑니다.

18. **`except Exception`이 `BaseException`을 놓치고, `rollback()` 실패가 원래 예외를 가립니다.**
    - 자리: `app/main.py:25-29`.
    - 까닭: 취소 계열 예외는 롤백을 건너뜁니다. `close()`가 암묵적으로 롤백하므로 데이터가 깨지지는 않습니다. `rollback()` 자체가 실패하면 원래 예외가 사라지고 로깅도 없습니다.

19. **`loaned_on + timedelta`가 오버플로하면 500이 됩니다.**
    - 자리: `app/services/loans.py:45`, `app/schemas.py` `LoanIn.loaned_on`.
    - 까닭: `9999-12-31` 근처에서 `OverflowError`가 납니다. 날짜 범위 검증이 없습니다.

20. **로깅이 없고 DB 타임아웃이 없습니다.**
    - 자리: `app/main.py`, `app/services/loans.py` 전체, `app/db.py:9`.
    - 까닭: 거절, 롤백, 직렬화 실패에 로그가 없어 충돌률을 알 수 없습니다. `connect_timeout`, `pool_timeout`, `statement_timeout`이 없어 풀이 고갈되면 요청이 오래 매달리다 500이 됩니다. 503이 맞습니다.

## 문서와 코드의 어긋남

- `app/main.py:16-19`의 "한 번에 들어가거나 하나도 들어가지 않는다"는 1번 때문에 오해하기 쉽습니다. "201 = 확정"이 아닙니다.
- `docs/schema.md:14`의 "하나만 선다"는 지는 쪽이 직렬화 실패로 중단되고 호출자가 재시도해야 한다는 점을 말하지 않습니다. 2번과 이어집니다.
- `docs/schema.md:5,7`은 탈퇴 처리와 반납 처리를 설명하는데 구현된 코드는 `lend()`뿐입니다. 계획이라면 그렇게 표시해야 합니다.

## 잘 된 점

- 모델과 마이그레이션의 컬럼, 타입, NULL 허용, unique, `server_default`, CHECK 이름(`books_available_not_negative`, `loans_due_after_loan`)이 서로 일치합니다.
- 원칙 2(재고 음수 금지)는 CHECK와 서비스 사전 검사 양쪽에서 지켜집니다.
- 원칙 1은 DB 안에서는 같은 트랜잭션으로 묶입니다. 어긋나는 곳은 호출자에게 알린 결과입니다(1번).
- `RefusedLoan` 경로의 롤백과 재발생은 정상입니다.

## 우선순위

1, 2번(커밋 시점과 직렬화 실패 재시도)은 서로 얽혀 있어서 함께 고쳐야 합니다. 다음은 3, 4번(제약 보강)과 6, 7번(마이그레이션 데이터 손실)입니다. 3, 4, 11, 12, 14번은 새 마이그레이션 `0002`에서 CHECK와 부분 UNIQUE 인덱스로 대부분 처리됩니다. 기존 데이터가 새 제약을 어기는지는 DB를 읽지 않아 확인하지 못했습니다.
