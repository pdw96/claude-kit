<!-- pr-review-toolkit · 못 맞힘 · 떴는가 True · 비용 0.5650774999999999 -->

# 결함 목록 (코드는 고치지 않았습니다)

`pr-review-toolkit`의 `code-reviewer`, `silent-failure-hunter`, `comment-analyzer` 세 에이전트를 돌렸고, 제가 직접 읽은 결과와 합쳤습니다. 테스트는 실행하지 않았고 전부 코드를 읽고 판단한 것입니다. git 이력이 없어서 "요구사항·설계를 한 PR로 낸 뒤 구현" 규칙(CLAUDE.md)은 확인하지 못했습니다.

## A. 문서화된 규칙을 직접 어기는 결함

1. **SMS 발송이 구현돼 있습니다.**
   - 자리: `app/reminder/sms.py`의 `send_sms`, `app/reminder/run.py`의 `remind` 12줄
   - 까닭: `docs/slices/2-dues-reminder/requirements.md` "하지 않을 일 1"이 SMS를 금지했습니다. 건당 비용이 들고, 전화번호를 알림에 쓰는 동의를 받지 않았기 때문입니다. 그런데 코드는 모든 미납자의 `phone`으로 유료 API를 부릅니다.
   - 설계 ①(`design.md`)의 변경 범위에도 SMS가 없습니다. `sms.py:11` 주석은 금지 사유에 대한 반박이 못 되고, 범위 변경 기록도 없습니다.

2. **"미납자 한 명에 달마다 이메일 한 통" 보장(`design.md` ②)이 깨집니다.** 요구사항 "미납자 전원에게 이메일"도 같이 깨집니다.
   - **첫 오류에서 전체가 중단됩니다.**
     - 자리: `app/reminder/run.py`의 `remind` 10~12줄, `sms.py`의 `os.environ["SMS_TOKEN"]`
     - 까닭: `deploy/crontab`은 `SMS_TOKEN`을 설정하지 않습니다. 첫 미납자에게 이메일을 보낸 직후 `KeyError`가 나고 루프가 멈춥니다. 나머지 미납자는 한 통도 받지 못합니다.
     - SMTP 예외나 SMS API 오류도 같은 방식으로 전체를 멈춥니다. 회원별 try/except나 로그가 없습니다.
   - **재실행하면 중복 발송됩니다.**
     - 자리: `run.py`의 `main`, `remind`
     - 까닭: 발송 기록이 없습니다. 같은 달에 다시 돌리면 이미 받은 사람이 또 받습니다. 이 항목은 "한 통"이 재실행해도 한 통이라는 뜻인지 문서만으로는 확정할 수 없습니다.
     - 발송 기록을 두려면 스키마를 바꿔야 합니다. CLAUDE.md는 스키마 변경을 먼저 물어보라고 했으니 사용자 확인이 필요합니다.
   - **반환값이 실제 발송 수가 아닙니다.** `remind`는 `len(targets)`를 돌려줘서, 부분 실패가 있어도 성공처럼 보입니다.

3. **스택 선언에 없는 의존성이 있습니다.**
   - 자리: `pyproject.toml` 7줄 `httpx==0.27.0`
   - 까닭: CLAUDE.md 스택은 Python 3.12 · FastAPI 0.115 · SQLAlchemy 2.0뿐입니다. httpx는 금지된 `sms.py`에서만 씁니다.
   - 덧붙여 `requires-python = ">=3.12"`는 선언("3.12")보다 넓습니다.

4. **테스트가 위 결함을 가립니다.**
   - 자리: `tests/test_remind.py` 8줄 `monkeypatch.setattr(run, "send_sms", lambda ...: None)`
   - 까닭: SMS 경로를 무력화한 채 통과해서, 1번 위반도 2번 중단 버그도 드러나지 않습니다.
   - 설계 ⑤의 "알림 수를 센다"는 대상 수를 세는 것이지 "한 통"을 검증하는 것이 아닙니다. 발송 실패, 부분 실패 뒤 재실행, 이중 실행을 다루는 테스트도 없습니다.

## B. 문서끼리 모순되거나 기록이 사실과 다른 곳

5. **`PRD.md`가 낡았습니다.**
   - 자리: `PRD.md` 7줄(성공 기준), 10줄(하지 않을 일)
   - 까닭: "미납자가 화면 배너로 보인다", "이메일 발송 — 알림은 화면 배너로만"이라고 적혀 있습니다. `docs/master-plan.md` 22줄은 2026-08-03에 배너에서 이메일로 바꿨다고 기록했고, 조각 2 문서와 `email.py`도 이메일입니다.
   - PRD 기준으로 보면 이메일 발송 자체가 위반입니다. `CLAUDE.md`와 master-plan의 문서 표에도 PRD가 없어서, 범위를 바꿀 때 고칠 대상에서 빠졌습니다.

6. **"INTENT.md What 을 고쳤다"는 기록을 확인할 수 없습니다.**
   - 자리: `docs/master-plan.md` 22줄, `INTENT.md` 8줄
   - 까닭: INTENT의 What은 "미납자 알림"뿐이라 채널(배너·이메일)이 드러나지 않습니다. 고친 흔적이 없거나, 채널과 무관한 문구라 고칠 필요가 없었거나 둘 중 하나인데 기록으로는 구분할 수 없습니다. 원래 문구는 git 이력이 없어 확인하지 못했습니다.
   - INTENT의 Not에는 SMS가 없어서, SMS 금지가 조각 문서에만 있고 의도 수준에서는 보호되지 않습니다.

7. **미납자 CSV가 조각 1 "하지 않을 일 1"과 충돌할 수 있습니다. (판단이 필요합니다.)**
   - 자리: `app/main.py`의 `download_unpaid`, `app/reminder/export.py`의 `unpaid_csv`
   - 까닭: `docs/slices/1-members/requirements.md`는 "CSV 내보내기를 만들지 않는다 — 명부는 화면에서만 본다"고 했습니다. 조각 2가 이 CSV를 요구하므로 의도한 변경으로 읽을 수도 있습니다. 그렇다면 master-plan "범위 변경" 표에 기록이 없고, 조각 2 `design.md` ④가 "결정 없음"이라고 적은 것이 빠진 부분입니다.

8. **`phone` 수집 목적이 문서에 없습니다. (확인 사항입니다.)**
   - 자리: `app/db.py` `members.phone`(nullable=False)
   - 까닭: SMS를 걷어내면 전화번호를 필수로 받을 이유가 어느 문서에도 남지 않습니다. 스키마는 앵커볼트라 제가 바꾸자고 제안하지 않고, 물어볼 사항으로만 남깁니다.

## C. 입력 검증과 접근 통제 (규칙 위반으로 보기엔 약하지만 보장을 흔드는 곳)

9. **`month` 형식을 검증하지 않습니다.**
   - 자리: `app/main.py`의 `record_payment` 31줄, `download_unpaid` 38줄
   - 까닭: `design.md` ③은 `YYYY-MM`을 말합니다. `2026-8`처럼 저장된 납부는 `run.main`의 `%Y-%m` 조회와 맞지 않아, 납부자가 미납 알림을 받습니다.
   - 잘못된 `month`는 `unpaid.csv`에서 오류 대신 빈 CSV로 나오고, `Content-Disposition` 헤더에 그대로 들어갑니다.
   - 같은 달을 두 번 기록하면 PK 충돌로 500 오류가 납니다. SQLite는 기본으로 FK를 검사하지 않아 없는 `member_id`도 저장됩니다.

10. **`/admin/*`에 인증이 없습니다. (저장소만으로는 확정할 수 없습니다.)**
    - 자리: `app/main.py`의 `register`, `roster`, `download_unpaid`
    - 까닭: 누구나 `POST /admin/members`로 스스로를 등록할 수 있어, `INTENT.md` Not 2(회원 셀프 가입 화면 금지)의 취지가 유명무실해집니다. `/admin/unpaid.csv`로 회원 이메일도 노출됩니다. 배포 앞단에서 막는지는 저장소에 없습니다.

11. **`email.py`의 `smtplib.SMTP("localhost")`에 timeout이 없습니다.**
    - 자리: `app/reminder/email.py`의 `send_email`
    - 까닭: 메일 서버가 멈추면 cron 작업이 무기한 매달립니다. 호스트도 코드에 고정돼 있고, 실패 시 어떤 회원·달인지 남기는 맥락이 없습니다.

## 위반이 없음을 확인한 것
- `app/db.py`는 조각 1 설계와 일치합니다. PK가 (member_id, month)이고 금액 컬럼이 없습니다.
- PG 연동 코드는 없어서 INTENT Not 1을 지킵니다.
- 이메일 본문에 계좌 번호가 없습니다.
- 자동 납부 확인 로직이 없습니다.
- `deploy/crontab`(매달 5일 09:00)과 `README.md`는 코드와 맞습니다.
- `CLAUDE.md`의 스택 버전은 `pyproject.toml`의 FastAPI·SQLAlchemy 핀과 일치합니다.

## 요약
가장 중요한 것은 1~4번입니다. 모두 "SMS가 금지인데 구현됐다"는 한 뿌리에서 나옵니다. 우선순위는 2번(중단·중복), 1번(SMS 금지 위반), 5번(PRD 모순) 순으로 보시길 권합니다.
