<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.36112009999999994 -->

`pr-review-toolkit`의 `code-reviewer`와 `silent-failure-hunter`를 저장소 전체에 돌렸고, 두 결과를 제가 코드와 대조해 확인했습니다. 저장소에 커밋이 없어 `/pr-review-toolkit:review-pr`은 쓰지 않았습니다. 코드는 고치지 않았고 실행도 하지 않아, 아래는 모두 코드를 읽고 추론한 것입니다.

## 결함

**1. 만료일 기준이 시드 안내와 다름 (확실)**
- 자리: `app/services/memberships.py`의 `approve()` 29–35줄, `seed/plans.sql` 3–5줄.
- 까닭: 시드 description은 "신청일 + 기간"이라고 적고, 이 문구가 화면 안내로도 나갑니다. 코드는 `starts_on = 승인일`, `valid_until = 승인일 + duration_days`로 계산하고 `application.applied_on`은 쓰지 않습니다.
- 예: `docs/schema.md` 9줄대로 주말 신청이 월요일에 승인되면, 토요일에 신청한 M1은 안내보다 최소 이틀 늦게 만료됩니다. 출입 단말은 `valid_until`로 막으므로 실제 이용 기간이 바뀝니다.
- 승인일 기준이 정책이라면 틀린 쪽은 시드 문구입니다.

**2. 날짜를 UTC로 잘라 하루가 어긋남 (시간대가 KST라고 가정)**
- 자리: `app/services/memberships.py` 29–30줄, `datetime.now(timezone.utc).date()`.
- 까닭: KST 00:00–08:59에 승인하면 UTC 날짜는 전날입니다. `starts_on`과 `valid_until`이 하루 일찍 저장되고, 단말이 하루 일찍 막습니다.

**3. 동시·중복 승인이 500이 되고 재시도는 멱등하지 않음**
- 자리: `app/services/memberships.py`의 `approve()` 22–26줄(`session.get`에 잠금 없음), 41줄 `flush()`, `app/main.py` 30–33줄.
- 까닭: 같은 신청에 요청이 동시에 오면 둘 다 `pending`을 읽고 통과합니다. `memberships.application_id`의 UNIQUE 제약이 중복 회원권은 막습니다. 하지만 늦은 쪽의 `IntegrityError`는 `RefusedApproval`이 아니라 잡히지 않아 500이 됩니다.
- 응답이 유실돼 클라이언트가 재시도하면 "이미 처리한 신청" 422만 받고, 만들어진 `membership_id`와 `valid_until`은 돌려받지 못합니다.

**4. `downgrade()`가 데이터를 말없이 지움**
- 자리: `migrations/0001_memberships.py`의 `downgrade()` 40–46줄.
- 까닭: `memberships`가 비었는지만 확인하고 `applications`와 `plans`를 drop합니다. 회원권이 0건이어도 `pending` 신청이 있으면 사라지고, 시드로 넣은 `plans`도 사라집니다.
- 검사와 drop 사이에 잠금이 없어 그 틈에 들어온 승인도 막지 못합니다.
- `memberships` 표가 없는 부분 적용 상태에서는 검사 `SELECT` 자체가 `ProgrammingError`로 실패합니다.

**5. `duration_days` 검증이 없어 승인 시점에 500**
- 자리: `app/models.py` 14줄, `migrations/0001_memberships.py` 15줄.
- 까닭: `CHECK (duration_days > 0)`가 없습니다. 0 이하인 플랜이 들어가면 그 플랜의 승인이 모두 `memberships_period` 위반으로 `IntegrityError`가 나 500이 됩니다. 잘못된 값이 플랜 입력 때가 아니라 승인 때 드러납니다.

**6. `plan`의 `None` 검사가 없음 (낮음)**
- 자리: `app/services/memberships.py` 27줄과 35줄.
- 까닭: `application`은 `None`을 검사하는데 `plan`은 검사 없이 `plan.duration_days`를 씁니다. FK가 있어 평소엔 막히지만, 제약이 빠진 환경에서는 `AttributeError`로 500이 됩니다.

**7. 트랜잭션 경계가 나뉘고 rollback이 암묵적임**
- 자리: `app/main.py`의 `session()` 15–20줄과 `post_approval()` 33줄, `app/services/memberships.py`의 `approve()`.
- 까닭: `approve()`는 `flush`만 하고 commit은 엔드포인트가 합니다. `commit()` 실패는 변환·로깅되지 않고, 정리는 `close()`의 암묵적 rollback에 기댑니다.
- 지금은 데이터가 오염되지 않습니다. 다만 `approve()`를 다른 곳에서 호출하면 commit·rollback 책임이 모호해집니다.

**8. `applications.status`에 값 제약이 없음 (낮음)**
- 자리: `app/models.py` 26줄, `migrations/0001_memberships.py` 25줄.
- 까닭: 자유 문자열이라 오타나 정의되지 않은 값이 들어가도 DB가 막지 못합니다. 상태 전이 규칙이 `"pending"` 리터럴 비교에만 있습니다.

**9. 만료일 경계가 정해져 있지 않음 (확인 필요)**
- 자리: `docs/schema.md` 7줄, `app/services/memberships.py` 35줄.
- 까닭: `valid_until = starts_on + N일`인데 문서는 "`valid_until`이 지나면 막는다"고만 합니다. 당일까지 출입이 되면 시작일을 포함해 N+1일이 됩니다. 코드·문서·시드 어디에도 포함 여부가 없습니다.

**10. 시드를 다시 실행하면 실패**
- 자리: `seed/plans.sql`.
- 까닭: `ON CONFLICT` 처리가 없어 두 번째 실행은 PK 충돌로 실패합니다. 마이그레이션 밖에 있어 downgrade 후 재적용하면 따로 다시 넣어야 합니다.

## 데이터 쪽이 아니라 참고만 (에이전트 지적)
- `approved_by`를 인증 없이 요청 본문에서 받아 감사 기록을 위조할 수 있습니다 (`app/main.py` 23–25줄).
- "없는 신청"과 "이미 처리됨"이 모두 422입니다. 각각 404와 409가 의미에 맞습니다 (`app/main.py` 32줄).
- DSN이 하드코딩돼 있고 `create_engine`에 `pool_pre_ping`이 없습니다 (`app/main.py` 12줄).

## 문제없음으로 확인한 것
- `models.py`와 `0001` 마이그레이션은 컬럼, 타입, nullable, FK, UNIQUE, CHECK, `server_default`가 일치합니다.
- 실패 경로에서 `session.close()`가 롤백하므로 세션 누수나 부분 커밋은 없습니다.

가장 먼저 정할 것은 1번입니다. 만료일을 신청일 기준으로 할지 승인일 기준으로 할지에 따라 코드나 시드 문구 중 하나를 고쳐야 하고, 2번과 9번도 같은 결정에 걸려 있습니다.
