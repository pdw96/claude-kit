<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.6465774 -->

# 데이터 쪽 검토 결과

`pr-review-toolkit`의 에이전트 4개(code-reviewer, silent-failure-hunter, type-design-analyzer, comment-analyzer)를 병렬로 돌렸고, 코드는 고치지 않았습니다. 테스트 파일이 없어 test-analyzer는 건너뛰었습니다. 에이전트들의 지적은 제가 읽은 코드와 대조해 확인했습니다. 모델과 마이그레이션의 칼럼·제약은 1:1로 일치했고, 지금 드리프트는 없습니다.

## 치명적

1. **비활성 공통코드로도 새 환불이 만들어집니다.**
   - 자리: `app/services/refunds.py:22-24` `_must_be_a_code`, 호출은 31-32행.
   - 까닭: `session.get(...) is None`으로 존재만 보고 `is_active`는 보지 않습니다. 시드의 `POINT`와 `PROMO`(`seed/codes.sql:4,8`, FALSE)가 그대로 통과합니다. 복합 FK(`models.py:36-37`)도 존재만 확인하므로 DB도 막지 못합니다. `models.py:12-13` 독스트링의 "새 기록에서는 못 고르고"라는 약속을 어깁니다.

2. **문서 원칙 1("되돌리는 환불을 새로 세운다")을 구현할 길이 없습니다.**
   - 자리: `docs/schema.md:11`, `models.py:40`과 `migrations/0001_refunds.py:37`의 `CHECK amount > 0`, `main.py:24`의 `Field(gt=0)`, `refunds.py:33`.
   - 까닭: 음수 금액을 세 겹으로 막고 있고, 원 환불을 가리키는 칸(`reverses_refund_id`)이나 종류 칸도 없습니다. `orders.refunded`는 `+=`로만 늘어나고(`refunds.py:36`) 줄이는 경로가 없습니다. 환불을 취소하려면 UPDATE나 DELETE밖에 없는데, 이는 원칙 1을 어깁니다.

3. **`downgrade`가 주문과 공통코드를 지웁니다.**
   - 자리: `migrations/0001_refunds.py:41-47`.
   - 까닭: 가드는 `refunds`가 비었는지만 봅니다(43행). 비어 있으면 `orders`와 `common_codes`를 무조건 `drop_table`합니다. 주문 데이터가 사라지고, 원칙 2("공통코드는 지우지 않는다")도 어깁니다. 시드는 마이그레이션 밖(`seed/codes.sql`)이라 다시 upgrade해도 코드가 돌아오지 않습니다.
   - 추정(신뢰도 약 60%)으로, 43행 검사와 DROP 사이에 다른 트랜잭션이 환불을 commit하면 그 기록도 함께 지워질 수 있습니다.

## 중요

4. **`orders`에 금액 불변식 제약이 없습니다.**
   - 자리: `models.py:28-30`, `migrations/0001_refunds.py:20-23`.
   - 까닭: `amount > 0`과 `0 <= refunded <= amount`가 `refunds.py:33`의 앱 검사에만 있습니다. 직접 SQL이나 배치 같은 다른 쓰기 경로는 초과 환불을 그대로 넣을 수 있습니다.

5. **`orders.refunded == SUM(refunds.amount)`를 보증하는 장치가 없습니다.**
   - 자리: `models.py:30`, `refunds.py:36-38`.
   - 까닭: 파생값을 중복 저장한 칼럼입니다. `refund()` 경로에서만 같은 트랜잭션으로 갱신되고, `refunds`를 직접 건드리면 어긋납니다. 트리거도 점검 쿼리도 없습니다. `with_for_update`(`refunds.py:28`)의 직렬화는 이 경로 안에서만 유효합니다.

6. **DB 예외가 처리되지 않아 500이 되고, 롤백이 암묵적입니다.**
   - 자리: `app/main.py:31-36`.
   - 까닭: `RefusedRefund`만 잡습니다. `flush`나 `commit`에서 나는 `IntegrityError`, `DataError`, `OperationalError`(데드락·직렬화 실패)는 그대로 500이 됩니다. 롤백은 `finally`의 `s.close()`가 암묵적으로 해 주고 명시적 `rollback()`은 없습니다. 오류 맥락(order_id, 금액)도 로그에 남지 않습니다.

7. **금액에 상한이 없어, 32비트 정수를 넘으면 500이 됩니다.**
   - 자리: `main.py:24`, `models.py`의 `sa.Integer`.
   - 까닭: 2,147,483,647을 넘는 `amount`나 `refunded + amount`는 flush에서 `DataError`가 나고, 6번 때문에 422가 아니라 500이 됩니다. 롤백으로 데이터 손상은 없습니다.

8. **중복 환불을 막는 멱등 장치가 없습니다.**
   - 자리: `main.py:29-36`, `refunds.py:27-40`.
   - 까닭: 같은 요청을 다시 보내면 한도 안에서는 행이 하나 더 생깁니다. `commit()`이 실패하거나 타임아웃이 나면 클라이언트는 결과를 모른 채 재시도할 텐데, 그러면 이중 환불이 됩니다.

9. **공통코드 검사와 INSERT 사이에 경쟁이 있습니다.**
   - 자리: `refunds.py:31-32`.
   - 까닭: `common_codes` 행을 잠그지 않습니다(`FOR SHARE` 없음). 검사 직후 코드가 비활성화되거나 삭제될 수 있습니다. 1번을 고쳐도 이 틈은 남습니다.

10. **"기록은 지우지 않는다"를 DB가 강제하지 않습니다.**
    - 자리: `docs/schema.md:11-12`, `models.py:12`.
    - 까닭: `refunds`의 UPDATE/DELETE를 막는 트리거나 권한 제한이 없습니다. `common_codes`도 FK가 막는 것은 이미 환불에 쓰인 코드뿐이고, 쓰이지 않은 코드는 DELETE할 수 있습니다. `models.py:12`의 "삭제 칸이 없다"는 말은 "삭제 플래그 칸이 없다"로도 읽혀 모호합니다. 원칙 2의 근거를 독스트링으로 가리키는 `docs/schema.md:12`는 순환 참조이고, 그 독스트링 자체가 1번 때문에 지금은 사실과 다릅니다.

## 낮음

11. **시드가 마이그레이션 밖에 있고 멱등하지 않습니다.**
    - 자리: `seed/codes.sql:1-8`.
    - 까닭: 마이그레이션만 돌린 새 DB는 코드가 비어서 환불이 항상 거부됩니다. `ON CONFLICT`가 없어 재실행하면 PK 충돌이 납니다. FALSE 행이 "과거 기록용 비활성 코드"라는 설명도 없습니다.

12. **`refunds`에 시각 칸과 FK 인덱스가 없습니다.**
    - 자리: `models.py:33-49`.
    - 까닭: `created_at`이 없어 "일어난 일"의 순서를 알 수 없습니다. 원칙 1이 "일어난 일은 지우지 않는다"인 점을 생각하면 아쉽습니다. `order_id`와 코드 FK 칼럼에 인덱스가 없어 조회가 풀스캔이 됩니다. 인덱스 건은 성능 문제입니다.

13. **없는 주문도 404가 아니라 422로 응답합니다.**
    - 자리: `refunds.py:29-30`, `main.py:33-34`.
    - 까닭: 응답 코드 선택이 문서나 주석에 없습니다.

14. **마이그레이션 관리가 부실합니다.**
    - 자리: `models.py`의 `Base`, `migrations/0001_refunds.py`.
    - 까닭: 모델과 마이그레이션이 수작업 복제본이고, 이를 비교하는 `alembic check` 같은 검사가 없습니다. `naming_convention`이 없고 FK와 인덱스가 무명이라 이후 마이그레이션에서 제약을 참조하기 어렵습니다. Alembic 자동 생성은 CHECK 변경을 감지하지 못합니다. `alembic.ini`와 `env.py`도 저장소에 없어 마이그레이션 실행 환경은 확인하지 못했습니다.

15. **문서와 주석이 부실합니다.**
    - 자리: `docs/schema.md`, `models.py:21`, `refunds.py:1,27`.
    - 까닭: `docs/schema.md`에는 `is_active`, 제약 목록, `refunded`가 비정규화 값이라는 점, 총액 한도 규칙이 없습니다. `models.py:21`의 주석은 독스트링과 중복입니다. `refund()`에는 독스트링이 없어 락의 이유, 커밋이 호출자 책임이라는 점, `RefusedRefund` 발생 조건이 문서화돼 있지 않습니다.
    - 확인이 필요한 건으로, `main.py:34`의 `HTTP_422_UNPROCESSABLE_CONTENT`는 고정한 FastAPI 버전(`requirements.txt:1`)에 포함된 Starlette에 따라 없을 수 있습니다. 설치 환경에서 확인하지 않았습니다.

## 잘 된 점
- `refund()`가 주문 행을 `FOR UPDATE`로 잠근 뒤 검사하고 갱신하므로, 같은 주문의 동시 환불에서 lost update가 없습니다.
- 커밋을 엔드포인트에서 한 번만 하고, 세션은 `finally`에서 정리합니다.
- `method_group`/`reason_group`을 CHECK와 복합 FK로 고정해 그룹이 섞이지 않습니다.

## 권장 순서
1번(동작 버그, 바로 재현됨), 2번과 3번(문서 원칙과 코드의 충돌), 4번과 5번(DB 제약 보강), 6번과 8번(오류·재시도 안전성) 순으로 보시길 권합니다.
