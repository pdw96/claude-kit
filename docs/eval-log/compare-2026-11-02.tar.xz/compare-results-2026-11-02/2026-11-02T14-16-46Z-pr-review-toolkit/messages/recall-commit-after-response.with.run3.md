<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.5308807999999999 -->

두 리뷰 에이전트(`code-reviewer`, `silent-failure-hunter`)와 제가 직접 읽은 결과를 합쳤습니다. 코드는 고치지 않았습니다. 이 환경에는 FastAPI와 alembic이 설치돼 있지 않아 아무것도 실행하지 못했습니다. 아래 결함은 모두 코드를 읽어서 찾았고, 1번은 FastAPI 버전별 동작을 기억에 의존해 추정한 부분이 있습니다.

## 높음

1. **201 응답이 나간 뒤에 commit 이 실행됩니다.**
   - 자리: `app/main.py` `session_scope()` 24행 `session.commit()`, `post_loan()` 33행 `Depends(session_scope)`.
   - 까닭: commit 이 `yield` 뒤에 있습니다. 고정 버전 FastAPI 0.141.1 은 `scope` 를 주지 않으면 `yield` 의존성의 종료 코드를 응답 전송 뒤에 실행하는 것으로 알고 있습니다. 설치된 소스로 확인하지 못했습니다.
   - 그러면 commit 이 실패해도(SERIALIZABLE 직렬화 실패, 연결 끊김) 클라이언트는 이미 201 과 존재하지 않는 `loan_id` 를 받은 뒤입니다. 상태 코드를 바꿀 수 없고 예외는 서버 로그에만 남습니다.
   - 이는 `docs/schema.md` 원칙 1과 3을 응답 쪽에서 깨뜨립니다.
   - 응답의 `available_copies` 도 commit 전 값입니다(`app/services/loans.py` 49행).

2. **직렬화 실패를 재시도하지 않고, 오류도 구분하지 않습니다.**
   - 자리: `app/db.py` 9행 `isolation_level="SERIALIZABLE"`, `app/services/loans.py` `lend()` 31~48행, `app/main.py` `post_loan()`.
   - 까닭: SERIALIZABLE 은 충돌을 오류(40001)로 알리고 애플리케이션이 재시도하는 것을 전제합니다. 그런데 `post_loan()` 은 `RefusedLoan` 만 잡습니다.
   - 같은 책에 요청이 겹치면 권수가 넉넉해도 한쪽은 `flush`(48행)나 commit 에서 실패해 500 이 됩니다.
   - `IntegrityError`(CHECK, FK), `DataError`, 연결 오류도 모두 같은 500 입니다. 클라이언트는 "다시 시도하면 되는 오류"와 "고칠 수 없는 오류"를 구분하지 못합니다.

3. **alembic 구성이 없어 마이그레이션을 실행할 수 없습니다.**
   - 자리: 저장소 루트(`alembic.ini` 없음), `migrations/`(`env.py`, `script.py.mako`, `versions/` 없음).
   - 까닭: `alembic upgrade` 나 `downgrade` 가 동작하지 않습니다. `env.py` 가 없어 `Base.metadata` 가 연결되지 않으므로 모델과 마이그레이션의 차이를 검증할 수도 없습니다. 접속 URL 과 격리 수준도 정해져 있지 않습니다.

## 중간

4. **`downgrade()` 의 가드가 `loans` 에만 걸려 있습니다.**
   - 자리: `migrations/0001_initial.py` `downgrade()` 42~46행.
   - 까닭: `members` 와 `books` 는 행이 있어도 그대로 `drop_table` 됩니다. 주석이 말하는 "지우면 되살릴 길이 없다"는 두 표에도 똑같이 해당합니다. `docs/schema.md` 는 회원을 지우지 않는다고 명시합니다.

5. **`downgrade()` 의 확인과 삭제 사이에 잠금이 없습니다.**
   - 자리: 같은 함수, 42행 `SELECT EXISTS` 와 44행 `drop_table("loans")`.
   - 까닭: 앱이 떠 있으면 확인을 통과한 직후 들어온 대출이 함께 사라질 수 있습니다. `LOCK TABLE loans` 가 없습니다. 운영 절차에서 앱을 먼저 내린다면 위험은 줄어듭니다.

6. **반납 경로가 없어 `available_copies` 가 줄기만 합니다.**
   - 자리: `app/` 전체(엔드포인트가 `POST /loans` 하나뿐), `app/models.py` `Loan.returned_on`, `docs/schema.md`.
   - 까닭: 문서는 반납하면 `returned_on` 이 찬다고 하지만, 이를 채우거나 `available_copies` 를 되돌리는 코드가 없습니다. 총 권수 열(`total_copies`)도 없어 불변식(`available_copies` ≤ 총 권수, 미반납 대출 수와 일치)을 검증하거나 복구할 수 없습니다.

7. **같은 회원이 같은 책을 중복 대출할 수 있고, 재시도하면 대출이 중복됩니다.**
   - 자리: `app/models.py` `Loan`, `app/services/loans.py` `lend()`.
   - 까닭: `(book_id, member_id)` 에 미반납 대출 유일성(부분 유일 인덱스)이 없습니다. 멱등 키도 없어서, 응답을 못 받은 클라이언트가 재시도하면 대출과 재고 차감이 두 번 일어납니다.

8. **값 범위를 막는 CHECK 가 부족합니다.**
   - 자리: `app/models.py` 25행과 `migrations/0001_initial.py` 23행(`books.loan_days`), `loans.returned_on`.
   - 까닭: `loan_days > 0` 과 `returned_on >= loaned_on` 이 없습니다. `loan_days` 가 음수인 도서는 대출 시 `loans_due_after_loan` 위반으로 500 이 됩니다. 데이터 문제가 요청 오류처럼 보입니다.

9. **`loaned_on` 을 클라이언트가 정합니다.**
   - 자리: `app/schemas.py` `LoanIn.loaned_on`, `app/services/loans.py` 41~46행.
   - 까닭: 과거나 미래 날짜를 그대로 받아 `due_on` 을 계산합니다. 연체 판정 기준이 되는 날짜를 요청자가 조작할 수 있습니다.

## 낮음

10. **재고 확인과 차감이 읽고-고치고-쓰는 방식입니다.**
    - 자리: `app/services/loans.py` 37~40행.
    - 까닭: 정합성이 SERIALIZABLE 설정 하나에 전부 기댑니다. 격리 수준이 바뀌면 마지막 방어선이 CHECK 제약이 되고, 그때는 2번의 500 으로 나타납니다. `UPDATE ... SET available_copies = available_copies - 1 WHERE available_copies > 0` 같은 조건부 갱신이 더 견고합니다.

11. **rollback 이나 close 가 실패하면 원래 오류를 가립니다.**
    - 자리: `app/main.py` 25~29행.
    - 까닭: 연결이 끊긴 상태에서 `session.rollback()` 이 예외를 던지면 그 예외가 대신 올라가고, 원래 오류는 `__context__` 로만 남습니다.

12. **로깅이 전혀 없습니다.**
    - 자리: `app/` 전체.
    - 까닭: 1번처럼 응답 뒤에 commit 이 실패해도 isbn, 카드 번호, `loan_id` 같은 맥락이 남지 않아 "저장된 줄 알았던 대출"을 추적할 수 없습니다.

13. **외래키 열에 인덱스가 없습니다.**
    - 자리: `loans.book_id`, `loans.member_id` (`app/models.py` 34~35행, 마이그레이션 29~30행).
    - 까닭: 회원별·도서별 대출 조회가 전체 훑기가 됩니다. 정합성이 아니라 성능 문제입니다.

14. **ISBN 과 카드 번호를 정규화하지 않습니다.**
    - 자리: `app/schemas.py` 7~8행, `app/models.py` 23행.
    - 까닭: 하이픈이 든 ISBN(13자 초과)이나 ISBN-10 과 ISBN-13 표기 차이는 "없는 도서"로 거절됩니다. 공백이나 대소문자 차이도 마찬가지입니다.

## 문제없음

- `app/models.py` 와 `migrations/0001_initial.py` 는 열, 타입, NULL 허용, 기본값, CHECK 이름, unique 가 서로 일치합니다.
- `RefusedLoan` → 422 경로는 의존성 안에서 rollback 되고, 그 전에 쓴 것이 없어 안전합니다.

## 확인이 필요한 것

1번의 실행 시점은 FastAPI 0.141.1 을 설치해 `fastapi/routing.py` 와 `fastapi/dependencies/utils.py` 의 종료 스택 처리를 읽거나, 충돌 테스트로 재현해서 확인해야 합니다.
