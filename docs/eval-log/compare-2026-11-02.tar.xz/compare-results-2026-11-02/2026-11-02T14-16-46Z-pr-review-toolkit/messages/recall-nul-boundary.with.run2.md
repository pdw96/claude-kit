<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.5567132 -->

# 검토 결과: 참가 신청 API (`POST /registrations`)

`pr-review-toolkit`의 code-reviewer, silent-failure-hunter, comment-analyzer 세 에이전트로 저장소 전체를 검토했습니다. 코드는 고치지 않았습니다. 테스트 파일이 없어서 pr-test-analyzer는 돌리지 않았고, 새 타입이 없어서 type-design-analyzer도 생략했습니다.

DB는 띄우지 못했습니다. code-reviewer는 pydantic 검증만 실행해 재현했습니다. fastapi와 psycopg는 그 환경에 없었습니다. 그래서 DB 단계 동작(결함 1, 2, 3)은 코드와 PostgreSQL/psycopg의 알려진 동작에서 추론한 것입니다.

## 핵심 결함

**1. NUL(`\x00`)이 검증을 통과해 DB에서 실패하고, 응답은 422가 아니라 500이 됩니다.**
- 자리: `app/schemas.py:22-25` (네 필드 모두), `app/main.py:27-29`
- 까닭:
  - `_present`는 공백만 있는지 보고, 길이 제한은 글자 수만 셉니다. `\x00`을 막는 규칙이 없습니다.
  - `note`(25행)는 `Present`도 아니라서 어떤 문자열이든 통과합니다.
  - PostgreSQL `text`는 NUL을 담지 못해서 `s.commit()`에서 psycopg `DataError`가 납니다. 처리하는 곳이 없어 `detail` 없는 500이 나갑니다.
  - 이 때문에 `docs/api.md:10`의 "받을 수 없는 요청은 경계에서 422"와 "경계를 지난 요청은 저장된다"가 둘 다 깨집니다.
- 재현 입력(검증 통과 확인): `attendee_name="Kim\u0000"`, `attendee_name="\u0000"`, `organization="a\u0000b"`, `note="\u0000"`

**2. `add`/`commit`에 DB 오류 처리가 없습니다.**
- 자리: `app/main.py:27-30`
- 까닭: `DataError`, `IntegrityError`, `OperationalError`(연결 실패·타임아웃)가 구분 없이 500이 되고 로그도 없습니다. 클라이언트는 입력 문제인지 일시 장애인지 알 수 없습니다.

**3. 문서가 응답 규약을 다 말하지 않습니다.**
- 자리: `docs/api.md:5-10`
- 까닭: 표에 201과 422만 있는데, 실제로는 500(DB 오류)이 나갈 수 있습니다. 중복 신청을 어떻게 다루는지도 정의가 없습니다.

## 중요 결함

**4. 공백 검증이 "눈에는 비어 보이는 값"이라는 의도보다 좁습니다.**
- 자리: `app/schemas.py:7-8`, `app/schemas.py:13`
- 까닭:
  - `_BLANK`는 주석의 여섯 문자(스페이스, 탭, 개행, 복귀, U+3000, U+00A0)와 정확히 일치합니다. 주석과 코드가 어긋난 것은 아닙니다.
  - 하지만 이 여섯 개만 막아서, 그 밖의 빈 문자만으로 된 이름은 201로 저장됩니다. 기본 `str.strip()`보다도 좁습니다.
  - 재현 입력(통과 확인): `"\u2003"`(EM SPACE), `"\u2028"`, `"\u0085"`, `"\u000b\u000c"`, `"\u200b"`(폭 없는 공백), `"\ufeff"`(BOM), `"ㅤ"`(U+3164, 한글 채움 문자)

**5. `organization`의 길이 초과 오류 메시지가 다른 필드와 다릅니다.**
- 자리: `app/schemas.py:24`
- 까닭:
  - `Present | None`에 붙은 `max_length`가 문자열 제약이 아닌 일반 길이 제약으로 적용됩니다. 그래서 `"a"*101`을 넣으면 type이 `too_long`이고 메시지가 "at most 100 items"로 나옵니다.
  - 다른 필드는 `string_too_long`에 "characters"라고 나옵니다.
  - 422 자체는 맞지만, `detail`이 까닭을 말한다는 규약에는 덜 맞습니다.
  - code-reviewer가 신뢰도 약 70으로 매긴 항목이라 확정은 아닙니다.

**6. 커밋 뒤 `row.id`를 읽을 때 한 번 더 SELECT가 나가서, 저장됐는데 500이 나갈 수 있습니다.**
- 자리: `app/main.py:14`, `app/main.py:29-30`
- 까닭:
  - `sessionmaker` 기본값이 `expire_on_commit=True`라서 커밋 뒤 `row.id` 접근 시 SELECT가 나갑니다.
  - 그 시점에 연결이 끊기면 행은 이미 커밋됐는데 클라이언트는 500을 받습니다.
  - 재시도하면 중복 신청이 생기는데, 유니크 제약이나 멱등성 키도 없습니다.
  - silent-failure-hunter가 코드를 읽고 추론한 항목으로, 실행해 확인하지는 못했습니다.

## 부수 결함

**7. `_present` 독스트링이 원인을 잘못 짚습니다.**
- 자리: `app/schemas.py:12`
- 까닭:
  - "공백만인 값은 DB까지 가면 이름 없는 실패가 된다"고 하지만, `app/models.py:13-16`과 `migrations/0001_registrations.py:14-17`에는 CHECK 제약이 없고 컬럼도 `Text`라서 공백 문자열은 그냥 저장됩니다.
  - 실제로 이름 없는 실패가 되는 값은 NUL인데, 이 함수는 그것을 거르지 않습니다.

**8. 스키마의 제약이 pydantic에만 있고 DB에는 없습니다.**
- 자리: `app/models.py`, `migrations/0001_registrations.py:11-18`
- 까닭: 길이 20/50/100/500과 "공백만 금지"가 DB에 없고, 유니크 제약도 없습니다. 경계를 거치지 않는 쓰기는 DB가 막지 못합니다. 모델과 마이그레이션의 컬럼 이름·타입·nullable은 서로 일치합니다.

**9. 마이그레이션 실행 구성이 저장소에 없습니다.**
- 자리: 저장소 루트
- 까닭: `alembic.ini`와 `env.py`가 없어서 `migrations/0001_registrations.py`만으로는 `alembic upgrade`를 돌릴 수 없습니다. 모델과 마이그레이션이 일치하는지 autogenerate로 비교하는 것도 못 합니다.

**10. 엔진 설정이 코드에 박혀 있고 장애 대비가 없습니다.**
- 자리: `app/main.py:14`
- 까닭:
  - DSN이 하드코딩돼 있습니다(`postgresql+psycopg://events@localhost/events`).
  - `connect_timeout`과 `pool_pre_ping`이 없어서, 끊어진 연결을 재사용하면 첫 요청이 실패할 수 있습니다.
  - 연결 실패가 시작 시점이 아니라 첫 `commit()`에서야 드러납니다.

**11. `downgrade()`가 일반 `RuntimeError`를 냅니다.**
- 자리: `migrations/0001_registrations.py:22-24`
- 까닭: 데이터가 있으면 롤백을 막는 것은 의도된 보호입니다. 다만 메시지가 짧고 예외 종류가 일반적이라 운영 중에는 원인 파악이 어렵습니다.

**12. `app/__init__.py`가 비어 있습니다.**
- 자리: `app/__init__.py`
- 까닭: 내용이 없습니다. 패키지 표식이면 문제는 아니지만 확인용으로 적습니다.

## 결함이 아닌 것으로 확인된 것
- 단독 서로게이트(`"\ud800"`)는 pydantic이 이미 422로 거부합니다.
- `note`가 `Present`가 아닌 것은 선택 필드라 의도일 수 있어 결함으로 보지 않았습니다. NUL 문제(1번)만 해당됩니다.
- 앞뒤 공백을 정규화하지 않는 것은 계약 위반이 아닙니다.
- `docs/api.md`의 201 행과 `app/main.py:25`의 `status_code=201`은 일치합니다.

우선순위는 1번과 2번이 가장 높고, 그다음 3번, 4번, 6번 순입니다.
