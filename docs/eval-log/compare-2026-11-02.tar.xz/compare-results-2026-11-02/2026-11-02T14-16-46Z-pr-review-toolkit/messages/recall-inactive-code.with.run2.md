<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.11907480000000001 -->

저장소가 작아서(파일 9개) 전부 직접 읽었습니다. 리뷰 에이전트는 따로 띄우지 않았고, 코드는 고치지 않았습니다.

## 결함 목록

### 중요도 높음

1. **비활성 공통코드로 새 환불이 만들어진다.**
   - 자리: `app/services/refunds.py` 의 `_must_be_a_code` (줄 20–22).
   - 까닭: `session.get(CommonCode, ...)` 가 행이 있는지만 보고 `is_active` 는 보지 않습니다. 그래서 `POINT`, `PROMO` 처럼 꺼 둔 코드로도 환불이 들어갑니다.
   - 이것은 `app/models.py` `CommonCode` 독스트링의 약속("새 기록에서는 못 고른다")을 깹니다.
   - DB의 FK 는 행이 있는지만 검사하므로 DB도 이것을 막지 못합니다.

2. **"되돌리는 환불을 새로 세운다"는 원칙을 구현할 수단이 없다.**
   - 자리: `docs/schema.md` 원칙 1, `app/models.py` `Refund`, `migrations/0001_refunds.py`.
   - 까닭:
     - `refunds` 에 되돌림 표시(`reverses_id`, 종류, 상태)가 없습니다.
     - `refunds_amount_positive` (`amount > 0`) 때문에 음수 행으로 되돌릴 수도 없습니다.
     - `orders.refunded` 는 서비스에서 더하기만 하고 줄이는 경로가 없습니다.
     - 환불을 취소해야 하면 행을 지우거나 고치는 수밖에 없고, 그러면 원칙이 깨집니다.

3. **다운그레이드가 지우지 않는 기록을 지운다.**
   - 자리: `migrations/0001_refunds.py` `downgrade` (줄 40–46).
   - 까닭: 환불 행이 있는지만 검사하고 `orders` 와 `common_codes` 는 확인 없이 `drop_table` 합니다.
   - 환불이 없어도 주문 데이터가 통째로 사라지고, 꺼 둔 코드까지 사라집니다. 이는 "공통코드는 지우지 않는다"에도 어긋납니다.

4. **환불 요청이 멱등하지 않다.**
   - 자리: `app/main.py` `post_refund`, `app/services/refunds.py` `refund`.
   - 까닭: 멱등 키나 유일 제약이 없습니다.
   - 클라이언트가 재시도하거나 응답이 끊겨서 같은 요청이 두 번 오면, 한도 안에서는 환불이 두 번 만들어집니다.

### 중간

5. **환불 합계 불변식을 DB 가 지키지 않는다.**
   - 자리: `app/models.py` `Order`, `migrations/0001_refunds.py` 의 `orders`.
   - 까닭:
     - `orders.refunded` 는 `refunds` 합계를 복제한 값입니다.
     - `CHECK (refunded >= 0 AND refunded <= amount)` 도, `CHECK (amount > 0)` 도 없습니다.
     - `refunds` 행과 이 값이 어긋나도 잡을 장치가 없습니다.
     - 한도 검사는 `with_for_update` 로 잠근 서비스 코드에만 의존하므로, 다른 경로(SQL 직접 수정, 다른 서비스)는 우회할 수 있습니다.

6. **씨앗 데이터가 마이그레이션과 이어져 있지 않고 다시 실행할 수도 없다.**
   - 자리: `seed/codes.sql`, `migrations/0001_refunds.py`.
   - 까닭:
     - 마이그레이션이 코드를 넣지 않습니다. 새 DB 에서 시드를 따로 돌리기 전에는 모든 환불이 "그런 코드가 없다"로 거절됩니다.
     - 시드는 `ON CONFLICT` 가 없는 순수 `INSERT` 라서 두 번 돌리면 PK 충돌로 실패합니다.
     - 같은 파일에서 `is_active` 를 다시 맞추는 경로도 없습니다.

7. **코드 검사와 삽입 사이에 잠금이 없다.**
   - 자리: `app/services/refunds.py` `refund`.
   - 까닭: 주문 행만 `FOR UPDATE` 로 잠그고 `common_codes` 는 잠그지 않습니다.
   - 검사 직후 코드가 꺼져도 환불은 그대로 삽입됩니다. 1번을 고치더라도 이 틈은 남습니다.

### 낮음

8. **트랜잭션 경계가 라우트에 흩어져 있다.**
   - 자리: `app/main.py` `post_refund` (줄 31–36).
   - 까닭:
     - `s.commit()` 은 라우트에서 하고 `flush` 는 서비스에서 합니다.
     - `RefusedRefund` 외의 예외(`IntegrityError` 등)와 커밋 실패는 명시적 롤백이나 변환 없이 500 이 됩니다.
     - 롤백은 `finally` 의 `close()` 에 암묵적으로 맡겨져 있습니다.

9. **`refunds.order_id` 에 인덱스가 없다.**
   - 자리: `app/models.py` `Refund`, 마이그레이션의 `refunds`.
   - 까닭: PostgreSQL 은 FK 열에 인덱스를 자동으로 만들지 않아서, 주문별 환불 조회나 합계 대조가 전체 스캔이 됩니다.

10. **`refunds` 에 시각과 처리자 열이 없다.**
    - 자리: `app/models.py` `Refund`.
    - 까닭: 생성 시각, 처리자, 상태가 없어서 "일어난 일을 지우지 않는다"는 원칙을 감사 기록으로 뒷받침하지 못합니다.

11. **Alembic 환경이 없고, 제약 이름 규칙도 없다.**
    - 자리: 저장소 루트, `app/models.py` `Base`.
    - 까닭:
      - `alembic.ini` 와 `env.py` 가 없어서 `requirements.txt` 에 alembic 이 있어도 마이그레이션을 실행할 방법이 저장소에 없습니다.
      - `Base` 에 `naming_convention` 이 없어서 FK 이름이 자동 생성되고, 뒤 마이그레이션에서 제약을 이름으로 다루기 어렵습니다.
      - 모델과 마이그레이션이 같은 정의를 따로 적어 두어, 어긋남을 잡는 검사가 없습니다.

## 참고
- 테스트가 없어서 위 항목 중 코드로 확인한 것은 없고, 모두 코드 읽기로 찾은 것입니다. 1번과 3번은 코드만 봐도 분명합니다.
- 잘 된 점은 두 가지입니다. 금액·그룹 CHECK 와 복합 FK 로 코드 그룹을 DB 에서 고정했고, 주문 행 `FOR UPDATE` 로 동시 환불의 한도 초과를 막았습니다.
