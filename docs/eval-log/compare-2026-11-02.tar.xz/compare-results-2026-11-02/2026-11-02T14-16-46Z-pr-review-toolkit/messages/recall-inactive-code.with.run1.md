<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.39812200000000003 -->

`pr-review-toolkit`의 `code-reviewer`와 `silent-failure-hunter`를 돌렸고, 제가 직접 읽은 내용과 맞춰 봤습니다. 코드는 고치지 않았고, 정적으로 읽기만 했습니다. 실행이나 테스트는 하지 않았습니다.

## 확실한 결함

1. **꺼 둔 공통코드로도 새 환불이 만들어집니다.**
   - 자리: `app/services/refunds.py`의 `_must_be_a_code`(22–24줄). `refund`가 31–32줄에서 부릅니다.
   - 까닭: `session.get(...) is None`으로 행이 있는지만 보고 `is_active`는 보지 않습니다. 복합 FK도 행이 있는지만 따집니다. 그래서 `seed/codes.sql`에서 꺼 둔 `REFUND_METHOD.POINT`와 `REFUND_REASON.PROMO`를 API로 바로 고를 수 있습니다. `app/models.py` 12–13줄 독스트링의 "새 기록에서는 못 고른다"와 어긋납니다.

2. **"되돌리는 환불을 새로 세운다"(docs/schema.md 원칙 1)를 지금 스키마로는 할 수 없습니다.**
   - 자리: `app/models.py` 40줄과 `migrations/0001_refunds.py` 37줄의 `CHECK (amount > 0)`, `refunds.py` 33줄, `main.py` 24줄의 `Field(gt=0)`.
   - 까닭: 금액이 DB, 서비스, API 세 곳에서 모두 양수만 허용됩니다. `refunds`에는 되돌리는 대상을 가리키는 칸이나 종류 칸도 없습니다. `orders.refunded`를 줄이는 경로도 없습니다. 취소하려면 `refunds`를 UPDATE나 DELETE로 고치고 `refunded`를 손으로 맞추는 수밖에 없습니다.

3. **`downgrade`가 환불 기록 말고는 확인 없이 데이터를 지웁니다.**
   - 자리: `migrations/0001_refunds.py` `downgrade`의 46–47줄.
   - 까닭: `refunds`가 비어 있으면 `orders`와 `common_codes`를 그대로 드롭합니다. 환불 없는 주문도 일어난 일이고, 공통코드는 원칙 2("지우지 않는다")가 정한 대상입니다.

4. **`downgrade`에서 검사하고 지우는 사이에 경쟁이 있습니다.**
   - 자리: `migrations/0001_refunds.py` 43–45줄.
   - 까닭: `SELECT EXISTS` 뒤에 `drop_table("refunds")`를 하는데 락이 없습니다. 그 사이에 커밋된 환불이 함께 지워집니다. 두 에이전트 모두 이 경쟁을 지적했습니다. 점검 시간에만 돌린다면 실제 위험은 작습니다.

5. **환불 한도 불변식이 DB에 없습니다.**
   - 자리: `app/models.py`의 `Order`(25–30줄)와 마이그레이션 18–23줄.
   - 까닭: `orders`에 `refunded >= 0`, `refunded <= amount`, `amount > 0` CHECK가 없습니다. `orders.refunded`는 `SUM(refunds.amount)`를 따로 저장한 값인데 둘이 같다는 보장도 없습니다. `refund()`는 행 락 안에서만 지키므로, 수작업 SQL이나 앞으로 만들 되돌림 경로가 값을 깨도 DB는 막지 못합니다.

6. **`s.commit()`이 `try` 밖에 있어 커밋 실패가 처리되지 않습니다.**
   - 자리: `app/main.py` `post_refund` 35줄.
   - 까닭: 커밋 시점의 `IntegrityError`, 직렬화 실패, 연결 끊김이 그대로 500이 됩니다. 명시적 `rollback()`도 없어서 `session()`의 `close()`에 암묵적으로 기댑니다.
   - 같은 이유로 `refunds.py` 39줄 `flush()`의 DB 오류도 번역되지 않습니다.

7. **재시도하면 환불이 중복 집행될 수 있습니다.**
   - 자리: `app/main.py` `post_refund`와 `refunds` 표.
   - 까닭: 멱등 키가 없습니다. 커밋 중 연결이 끊겨 클라이언트가 500을 받고 다시 보내면, 한도 안에서 같은 환불이 한 번 더 만들어집니다.

## 약한 결함

- **락 대기에 상한이 없습니다.** `refunds.py` 28줄의 `with_for_update=True`에 `nowait`나 `lock_timeout`이 없습니다. 거부 경로에서도 락은 `close()`까지 유지됩니다.
- **거부 사유가 모두 422로 뭉칩니다.** `main.py` 33–34줄에서 없는 주문, 없는 코드, 한도 초과가 같은 422가 됩니다. 클라이언트가 사유별로 분기하지 못합니다.
- **`refunds.order_id`에 인덱스가 없습니다.** PostgreSQL은 FK 칸에 인덱스를 자동으로 만들지 않아서, 주문별 환불 조회와 합계가 전체 스캔이 됩니다. 이 항목은 제가 보탰습니다.
- **`refunds`에 `created_at`이 없습니다.** "일어난 일"의 기록인데 시각이 없어서, 되돌림을 넣으면 순서를 따지기 어렵습니다.
- **`seed/codes.sql`을 두 번 돌리면 PK 충돌이 납니다.** `ON CONFLICT`가 없습니다. 시드가 마이그레이션 밖에 있어서 어느 환경에 적용됐는지도 추적되지 않습니다.
- **공통코드 DELETE를 DB가 막지 않습니다.** 환불이 가리키는 코드는 FK 때문에 지워지지 않지만, 아직 쓰이지 않은 코드는 일반 DELETE로 지워집니다.
- **스키마가 두 곳에 손으로 복제돼 있습니다.** `models.py`와 `migrations/0001_refunds.py`가 지금은 일치하지만 따로 바뀌면 어긋납니다. 저장소에 `alembic.ini`와 `env.py`도 보이지 않습니다.
- **엔진 설정이 약합니다.** `main.py` 12줄은 import 시점에 DSN을 하드코딩해 엔진을 만들고, `pool_pre_ping`과 문장 타임아웃이 없습니다.

## 문제없다고 본 것

- 환불 한도 확인과 `order.refunded` 갱신은 같은 주문 행 락 안에서 이뤄집니다. 동시 요청으로 한도를 넘길 수 없습니다.
- 요청 하나가 트랜잭션 하나이고, 서비스는 `flush`만 하며 `commit`은 성공했을 때만 합니다. 예외가 나면 `close()`가 롤백합니다.
- `method_group`과 `reason_group`은 CHECK로 고정돼 있어, 다른 그룹의 코드를 가리킬 수 없습니다.
