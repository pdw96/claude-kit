<!-- pr-review-toolkit · 못 맞힘 · 떴는가 True · 비용 0.7919434000000001 -->

`pr-review-toolkit`의 `code-reviewer`와 `comment-analyzer`를 돌렸고, 둘이 보고한 결함을 취합했습니다. 아래 항목 중 직접 다시 확인한 것은 D1뿐입니다. 나머지는 두 에이전트가 파일 내용을 인용해 보고한 대로 적었습니다. 코드는 수정하지 않았습니다.

이 저장소는 코드 없이 마크다운과 JSON 설정만으로 된 Claude Code 플러그인입니다. 그래서 테스트, 타입, 에러 처리를 보는 나머지 세 에이전트(`pr-test-analyzer`, `type-design-analyzer`, `silent-failure-hunter`)와 `code-simplifier`는 돌리지 않았습니다. `compare/` 디렉터리는 샌드박스 읽기 제한으로 읽지 못했습니다. 이 저장소는 git 저장소가 아니라서 diff 없이 파일을 직접 읽었습니다.

## 메타데이터 (README ↔ 설정)
1. **라이선스 불일치**: `README.md:303-305`는 "MIT"라고 적었지만 `LICENSE:1-2`는 Apache 2.0입니다. `LICENSE:190`의 저작권자 `[yyyy] [name of copyright owner]` 칸도 비어 있습니다.
2. **저자 불일치**: `README.md:307-309`는 "Daisy (daisy@anthropic.com)"이고, `.claude-plugin/plugin.json:5-8`은 "Anthropic / support@anthropic.com"입니다.
3. **다른 프로젝트 경로를 가리키는 Contributing**: `README.md:299-301`은 에이전트가 `~/.claude/agents/`나 `claude-cli-internal`의 `.claude/agents/`에서 관리된다고 합니다. 이 플러그인의 에이전트는 `agents/`에 있습니다.
4. **없는 구성요소 언급**: `README.md:286`의 `build-validator`는 저장소 어디에도 정의가 없습니다.
5. **설치 안내가 실제 절차가 아님**: `README.md:183-191`은 "Or add manually to settings if needed" 정도만 적고 있습니다. (`comment-analyzer`의 지적이고, 앞의 `code-reviewer` 보고에는 없습니다.)

## 점수 체계가 서로 어긋남
6. **`code-reviewer` 안에서 충돌**: `agents/code-reviewer.md:38-39`는 76-90을 Important, 91-100을 Critical로 정의합니다. 같은 파일 `:52`는 "Critical: 90-100, Important: 80-89"로 묶습니다. 그래서 90점은 정의상 Important인데 출력에서는 Critical이 됩니다. 보고 하한(`:41`, ≥80)도 76-90 구간 한가운데에 있습니다.
7. **README의 임계값도 한쪽만 따름**: `README.md:207`의 "91-100 = critical"은 `code-reviewer.md:39`와만 맞고 `:52`와는 어긋납니다.
8. **`pr-test-analyzer` 안에서 충돌**: `agents/pr-test-analyzer.md:52-53`은 9-10을 Critical, 7-8을 Important로 정의합니다. `:63-64`는 "Critical Gaps: 8-10", "Important: 5-7"로 출력합니다. 8점은 정의상 Important인데 출력에서는 Critical이 되고, 1-4점은 담을 출력 구간이 없습니다.
9. **README의 `pr-test-analyzer` 설명도 어긋남**: `README.md:201`은 "10 = critical, must add"라고 하는데, 에이전트는 8-10을 반드시 추가하고 9-10을 critical이라 합니다.
10. **"모든 에이전트가 신뢰도 점수를 낸다"는 주장이 사실과 다름**: `README.md:195-199`가 그렇게 적었지만 점수를 내는 에이전트는 `code-reviewer`뿐입니다.
    - `comment-analyzer`에는 점수 체계가 없어서 `README.md:199`의 "high confidence"는 근거가 없습니다.
    - `silent-failure-hunter`는 CRITICAL/HIGH/MEDIUM 라벨만 씁니다.
    - `pr-test-analyzer`와 `type-design-analyzer`는 신뢰도 점수가 아니라 중요도·품질 점수를 냅니다.
    - `code-simplifier`는 점수가 없습니다.
11. **"모든 에이전트가 구조화된 출력과 file:line을 낸다"는 주장도 사실과 다름**: `README.md:213-218`이 그렇게 적었습니다.
    - `code-simplifier.md`에는 출력 형식이 없습니다(`:86`은 "Document only significant changes"뿐).
    - `type-design-analyzer.md:60-87`은 타입별 점수 형식이라 file:line도 심각도도 없습니다.
    - `pr-test-analyzer.md:60-66`도 file:line을 요구하지 않습니다.

## 에이전트 설명 ↔ 본문
12. **`type-design-analyzer`의 시나리오 수 불일치**: `agents/type-design-analyzer.md:3`은 세 가지 용도, 즉 새 타입 도입, PR 생성, 리팩터링을 말하고 "When to invoke"를 참조하라고 합니다. 실제 `:12-15`는 "Two representative scenarios"이고 리팩터링 시나리오가 없습니다. `README.md:86`은 리팩터링을 광고합니다. 이건 직접 확인했습니다. 두 에이전트 보고가 서로 달랐는데(`comment-analyzer`는 "세 개"라고 했습니다), 파일을 보니 `code-reviewer` 쪽이 맞았습니다. 따라서 `comment-analyzer`의 "시나리오 수가 일치한다"는 문장은 이 에이전트에 한해 틀렸습니다.
13. **`code-simplifier` 실행 시점 모순**: `agents/code-simplifier.md:4`와 `:88`은 작성 직후 자동·선제적으로 실행한다고 합니다. 반면 `README.md:128-129`, `:234-235`, `:294`와 `commands/review-pr.md:43`은 리뷰 통과 후에 실행한다고 합니다. `README.md:174-179`의 "Proactive Review" 목록에도 빠져 있습니다.
14. **`code-simplifier`의 성격을 잘못 설명함**: `README.md:119`와 `:209`는 분석하고 제안한다고 하는데, 실제로는 코드를 직접 고칩니다(`code-simplifier.md:45`). `comment-analyzer.md:79`의 "Do not modify code"와 대조됩니다. `commands/review-pr.md:105-106`도 이를 리뷰로 취급합니다.
15. **`silent-failure-hunter`에 다른 프로젝트의 규약이 박혀 있음**:
    - `agents/silent-failure-hunter.md:39,41,94,124-125`가 `logError`, Sentry, `constants/errorIds.ts`, `logForDebugging`, Statsig를 사실처럼 적습니다.
    - `:123`은 "CLAUDE.md의 패턴을 따르라"고 하지만, 바로 아래에서 특정 코드베이스의 규칙을 단정합니다.
16. **`code-simplifier`에도 같은 문제**: `agents/code-simplifier.md:49-55`가 "CLAUDE.md의 표준"이라며 ES 모듈, `function` 키워드 선호, React Props 타입 같은 고정 규칙을 나열합니다.
17. **`code-simplifier`와 `silent-failure-hunter`의 규칙이 충돌**: `code-simplifier.md:55`의 "avoid try/catch when possible"는 `silent-failure-hunter`가 요구하는 명시적 에러 처리와 반대 방향입니다. 단순화 과정에서 필요한 에러 처리가 지워질 수 있습니다.
18. **`silent-failure-hunter`의 예시에 개인 이름 사용**: `agents/silent-failure-hunter.md:3`에 "Daisy"가 여러 번 나옵니다. 다른 에이전트는 일반적인 "user"를 씁니다.
19. **`code-reviewer`의 기본 범위가 내부에서 어긋남**: `agents/code-reviewer.md:21`의 기본값은 unstaged diff인데, `:16`의 PR 전 점검은 "full diff"를 말합니다.
20. **설명 형식 불일치**: `code-simplifier`와 `silent-failure-hunter`는 설명에 `<example>` 블록을 직접 넣고, 나머지 네 개는 "When to invoke" 절을 씁니다. `code-simplifier`에는 `color`도 없고(`:1-41`), `code-reviewer.md:5`와 `comment-analyzer.md:5`는 둘 다 `color: green`입니다. 이 둘은 문서에 명시된 규칙을 어긴 것은 아니고 일관성 문제입니다.
21. **README와 에이전트의 라벨 표기 차이**: `README.md:80`은 "Type usefulness"인데 `type-design-analyzer.md:44,73`은 "Invariant Usefulness"입니다.

## `commands/review-pr.md`
22. **스테이지 후 리뷰하면 볼 변경이 없음**: `:166-172`는 "Stage all changes → review-pr all"을 안내합니다. `:31`의 `git diff --name-only`는 unstaged만 보여 줍니다(`code-reviewer.md:21`도 같습니다). 스테이징하고 나면 목록이 비어 버립니다.
23. **`pr-test-analyzer` 실행 조건이 목적과 반대**: `:39`는 테스트 파일이 바뀐 경우에만 실행하라고 합니다. 이 에이전트는 새 로직에 테스트가 없는 공백을 찾는 용도라서(`pr-test-analyzer.md:3,14-15`) 테스트가 안 바뀐 PR에서 가장 필요한데, 그때 건너뜁니다. `README.md:228-229`는 PR 전 표준 단계로 둡니다.
24. **`parallel`이 정의되지 않음**: `:109-112`의 예시에는 나오지만 유효 aspect 목록(`:20-28`)과 인자 파싱(`:17`)에는 없습니다. `errors`, `types`, `code`가 각각 어느 에이전트인지 매핑도 없습니다.
25. **`all`과 `code-simplifier`의 순서 모순**: `:18,28,111`의 `all`과 병렬 실행은 simplifier를 포함합니다. `:43`은 "리뷰 통과 후"라고 합니다. 병렬이면 리뷰어들이 읽는 동안 simplifier가 코드를 수정하게 됩니다.
26. **"에이전트는 기본적으로 git diff를 분석한다"는 주장이 사실과 다름**: `:151`이 그렇게 적었지만 명시한 에이전트는 `code-reviewer`뿐입니다.
    - `code-simplifier.md:77`은 "현재 세션에서 수정된 코드"를 대상으로 합니다.
    - `pr-test-analyzer.md:44`는 PR의 변경을, `silent-failure-hunter.md:22`는 PR을 말합니다.
    - `comment-analyzer`와 `type-design-analyzer`는 기본 범위를 적지 않았습니다.
    - 이 저장소처럼 git이 아닌 디렉터리에서는 `:31-32`의 git 단계가 동작하지 않고, 저장소 전체를 리뷰하는 방법도 안내가 없습니다.
27. **집계 기준이 없음**: `:57-87`은 Critical/Important/Suggestions로 모으라고 하지만, 에이전트마다 0-100, 1-10, CRITICAL/HIGH/MEDIUM으로 척도가 달라 변환 규칙이 없습니다.
28. **트리거 조건 표현 불일치**: `:25`는 "if new types added"이고 `:42`는 "added/modified"입니다. `:40`의 "comments/docs added"도 README(`:230`)의 "added/modified"와 다릅니다.
29. **쓰이지 않는 단계**: `:32`의 `gh pr view`는 그 결과를 어디에도 쓰지 않습니다.
30. **모델 설명이 부정확**: `:188`의 "appropriate models"는 실제로 `code-reviewer`와 `code-simplifier`가 `opus`로 고정이고 나머지는 `inherit`인 것을 가립니다. 문서의 약속을 어긴 결함이라기보다 설명이 모호한 것입니다.

## 정확하다고 확인된 것
에이전트 수 6개와 이름, 슬래시 명령 네임스페이스는 README, `plugin.json`, 명령 문서에서 일치합니다. 각 에이전트의 `name`은 파일명과 같습니다. 그리고 `code-reviewer`, `comment-analyzer`, `pr-test-analyzer`의 "When to invoke" 참조는 실제 절로 이어집니다.

가장 영향이 큰 것은 6-9번(점수 체계 충돌), 13번(`code-simplifier` 실행 시점 모순), 22-23번(명령 문서의 실행 흐름 오류)입니다. 1-2번은 사실 확인이 쉬운 불일치입니다.
