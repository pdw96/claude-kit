<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.6610455 -->

# 데이터 쪽 결함 목록

`pr-review-toolkit` 에이전트 4개(code-reviewer, silent-failure-hunter, type-design-analyzer, comment-analyzer)로 검토했습니다. 테스트 파일이 없어서 pr-test-analyzer는 돌리지 않았습니다. 코드는 고치지 않았습니다. SQLAlchemy와 Alembic이 설치돼 있지 않아 실행으로 확인한 것은 없고, 전부 코드를 읽어서 내린 판단입니다.

## 높음

**1. 0007 downgrade가 운영자가 먼저 만든 코드와 그룹을 지웁니다.**
- 자리: `migrations/versions/0007_shipping_zone.py`의 `upgrade()` 21–30행(`WHERE NOT EXISTS`), `downgrade()` 50–63행.
- 까닭: 운영자가 `SHIPPING_ZONE` 그룹이나 `METRO` 같은 코드를 미리 만들어 뒀다면 upgrade는 그 줄을 건너뜁니다. 그런데 리비전이 실제로 넣은 줄이 어느 것인지는 어디에도 기록되지 않습니다.
- 시드와 값이 같은 줄은 `changed` 검사(51–59행)를 통과합니다. 그래서 62행의 `DELETE`가 운영자의 줄을 지웁니다.
- 이는 `docs/schema.md` 11–12행의 원칙 "되돌리기는 그 리비전이 만든 것만 거둔다"를 어깁니다.

**2. `code_groups` 줄은 어떤 검사도 없이 지워집니다.**
- 자리: `0007_shipping_zone.py:63`.
- 까닭: 코드 행에는 이름·순서·활성 여부를 비교하는 검사가 있지만, 그룹 행에는 `name`과 `description` 검사가 없습니다. 운영자가 그룹의 이름이나 설명을 고쳤어도 지워집니다. 61행 주석 "위의 멈춤 검사가 지킨다"는 그룹 행에 대해서는 사실이 아닙니다.

**3. downgrade의 검사와 삭제 사이에 경쟁이 있습니다(TOCTOU).**
- 자리: `0007_shipping_zone.py`의 `downgrade()` 36–64행.
- 까닭: 검사 세 개는 잠금 없는 `SELECT count(*)`입니다. PostgreSQL 기본 격리 수준(READ COMMITTED)에서는 검사 뒤에 들어온 쓰기를 막지 못합니다.
- 경로 A: 검사 직후 운영자가 코드를 추가하면 62행의 `DELETE`가 그 코드를 지웁니다.
- 경로 B: 검사 직후 `shipping_zone`이 채워진 주문이 들어오면 64행의 `drop_column`이 그 값을 잃게 합니다.
- 삭제 조건이 "검사로 확인한 줄"이 아니라 "그룹 전체"라서 위험이 커집니다. 테이블 잠금이 없고, 삭제 건수도 확인하지 않습니다.

## 중간

**4. `orders.shipping_zone`에 참조 무결성이 없는데 문서는 "가리킨다"고 씁니다.**
- 자리: `app/models.py:31`, `0007_shipping_zone.py:19`, `docs/schema.md:7`.
- 까닭: 컬럼이 FK 없는 `String(30)`이라 없는 코드, 다른 그룹의 코드, 비활성 코드도 들어갑니다.
- `common_codes`의 기본키가 `(group_code, code)` 복합키라서 `code`만으로는 FK를 걸 수 없습니다. 고치려면 고정 그룹 컬럼을 둔 복합 FK, 전용 테이블, 문서에서 "규약상 참조(FK 없음)"로 낮추는 방법 중 하나를 골라야 합니다.

**5. 다운그레이드의 사용 중 검사가 `orders`만 봅니다.**
- 자리: `0007_shipping_zone.py:36`.
- 까닭: 참조 컬럼이 하드코딩돼 있고 FK도 없습니다. 이후 리비전에서 `SHIPPING_ZONE` 코드를 쓰는 다른 컬럼이 생기면, 이 검사는 그것을 모른 채 코드를 지웁니다. FK가 있었다면 `DELETE`가 실패해 오히려 안전했을 겁니다.

**6. 제약이 전혀 없습니다.**
- 자리: `app/models.py` 9–31행 전체와 `0006_orders.py` (`__table_args__` 없음).
- 까닭: 같은 그룹 안에서 코드 이름이나 `sort_order`가 중복돼도 막지 못합니다. 음수 `sort_order`와 빈 문자열 `name`도 막지 못합니다. `code`와 `group_code`의 대소문자·공백 형식을 정하는 체크도 없습니다.

**7. 코드 비교가 정렬 규칙(collation)에 기대고 있습니다.**
- 자리: `0007_shipping_zone.py:43–44, 54, 62`.
- 까닭: 대소문자나 끝 공백을 무시하는 정렬 규칙에서는 `metro`가 `METRO`와 같게 취급됩니다. 그러면 운영자의 줄이 `NOT IN` 검사를 통과해 삭제될 수 있습니다. PostgreSQL 기본 설정에서는 오히려 멈추므로 안전한 쪽입니다.

**8. 제약에 이름 규칙이 없습니다.**
- 자리: `app/models.py:5–6`(`Base`에 `naming_convention` 없음), `0006_orders.py:19`.
- 까닭: FK와 PK 이름이 DB 기본값에 맡겨져 있어서, 나중에 제약을 떼거나 바꿀 때 `drop_constraint`가 이름을 지정할 수 없습니다. 4번을 고치려면 먼저 필요합니다.

## 문서·주석 어긋남

**9. 20행 주석이 선재하는 줄을 건너뛰는 것만 안전하다고 읽히게 합니다.**
- 자리: `0007_shipping_zone.py:20`.
- 까닭: 건너뛴 줄이 downgrade에서 지워질 수 있다는 점이 어디에도 없습니다. 1번과 이어지는 문제입니다.

**10. `docs/schema.md` 원칙 1이 코드 동작과 다릅니다.**
- 자리: `docs/schema.md:11–12`.
- 까닭: 1~3번의 경로에서는 남의 것을 지우고도 멈추지 않습니다.

## 낮음 · 확인 필요

**11. (확신 낮음, 실행 확인 못 함) 0006의 FK 컬럼 타입이 정해지지 않을 수 있습니다.**
- 자리: `0006_orders.py:19`.
- 까닭: `common_codes.group_code`에 타입 없이 `ForeignKey`만 줬습니다. 모델은 같은 MetaData 안에서 타입을 추론하지만, Alembic의 `op.create_table`은 임시 MetaData를 씁니다. 에이전트는 이 경우 컬럼이 `NullType`이 돼 DDL 생성이 실패할 수 있다고 봤습니다. 이 부분은 제 기억과도 일치하지만 실행해 보지는 못했습니다. `alembic upgrade --sql`로 확인해 보세요.

**12. 0007이 PostgreSQL 전용 SQL을 씁니다.**
- 자리: `0007_shipping_zone.py:28, 53–55`.
- 까닭: `(VALUES …) AS v(code, name, sort_order)`와 행 값 `IS DISTINCT FROM`은 PostgreSQL 문법입니다. 대상 DB가 PostgreSQL로 고정이라는 사실이 문서에 없습니다.
- DDL이 암묵적으로 커밋되는 DB에서는 검사나 삭제 중간에 실패하면 반쯤 적용된 상태가 남을 수 있습니다.

**13. 트랜잭션 경계를 확인할 수 없습니다.**
- 자리: 저장소에 `env.py`가 없습니다.
- 까닭: `transactional_ddl`과 `transaction_per_migration` 설정을 알 수 없어서, 실패 시 전부 롤백되는지 확인하지 못했습니다.

**14. SQL을 문자열로 이어 붙입니다.**
- 자리: `0007_shipping_zone.py:15, 21–29, 43–44, 53`.
- 까닭: `repr()`로 SQL 리터럴을 만들고 있습니다(44행). 지금은 상수라 안전하지만, `ZONES`나 `GROUP`에 따옴표나 비ASCII 문자가 들어가면 깨집니다. 바인드 파라미터가 안전합니다.

**15. upgrade의 `INSERT … WHERE NOT EXISTS`가 동시 삽입에 안전하지 않습니다.**
- 자리: `0007_shipping_zone.py:21–30`.
- 까닭: 같은 순간 운영자가 같은 키를 넣으면 PK 위반으로 마이그레이션이 실패합니다. 데이터는 망가지지 않고, 다시 실행하면 됩니다.

**16. 다운그레이드 오류 메시지가 건수만 알려 줍니다.**
- 자리: `0007_shipping_zone.py:38, 48, 59`.
- 까닭: 어떤 코드나 주문이 막았는지, 어떻게 정리하라는지 안내가 없습니다. 검사가 첫 실패에서 중단돼서 하나씩 고쳐 가며 반복해야 합니다.

**17. `orders`가 뼈대 수준이고 백필·기본값 정책이 없습니다.**
- 자리: `app/models.py:27–31`, `0007_shipping_zone.py:19`.
- 까닭: `shipping_zone`이 nullable이라 "배송비를 가르는 축"(23행)이 비어 있는 주문이 가능합니다. 의도인지 문서에 없고, 기존 주문을 채우는 정책도 없습니다.

## 문제 없음으로 확인된 것

- `models.py`와 0006+0007을 합친 결과가 컬럼, 타입, nullable, `server_default`, 복합 PK, 그룹 FK까지 일치합니다. 11번의 `NullType` 우려만 예외입니다.
- downgrade가 막는 경우: `shipping_zone`이 채워진 주문(빈 문자열 포함), 시드 외의 코드, 시드 코드의 이름·순서·활성 여부 변경.
- 0006의 downgrade가 항상 예외를 던지는 것은 첫 리비전이라 의도된 동작입니다.

## 우선순위

1~3번은 같은 뿌리입니다. 리비전이 심은 줄을 구별할 장치가 없고, 삭제 범위가 검사 범위보다 넓습니다. 이 셋이 검사를 통과한 뒤에도 남의 데이터가 조용히 지워지는 경로입니다. 다음은 4번(FK를 어떻게 걸지)과 8번(제약 이름 규칙)입니다.
