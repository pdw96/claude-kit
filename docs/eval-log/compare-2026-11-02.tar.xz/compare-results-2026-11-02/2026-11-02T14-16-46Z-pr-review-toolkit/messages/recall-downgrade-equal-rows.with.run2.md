<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.44001369999999995 -->

데이터 쪽 결함을 정리했습니다. 직접 읽은 결과에 `pr-review-toolkit`의 `code-reviewer`와 `silent-failure-hunter` 결과를 합쳤고, 코드는 고치지 않았습니다. 마이그레이션은 DB에 돌려 보지 않았습니다. `migrations/env.py`와 `alembic.ini`가 저장소에 없어서, 트랜잭션 설정과 대상 DB는 확인하지 못했습니다. `VALUES ... AS v(...)`와 `IS DISTINCT FROM` 문법으로 보아 PostgreSQL을 전제로 했습니다.

## 중대

**1. downgrade가 운영자가 먼저 만든 그룹과 코드를 지웁니다.**
- 자리: `migrations/versions/0007_shipping_zone.py`의 `upgrade()` 20~30줄(`WHERE NOT EXISTS`)과 `downgrade()` 62~63줄(`DELETE`).
- 까닭:
  - 운영자가 0007 적용 전에 `SHIPPING_ZONE` 그룹이나 `METRO` 같은 코드를 만들어 뒀다면, upgrade는 그 줄을 건너뜁니다. 그 줄은 리비전이 만든 것이 아닙니다.
  - downgrade의 `changed` 검사(51~59줄)는 값이 같은지만 봅니다. 값이 심은 값과 같으면 통과하고, 62줄이 그룹 전체를 지웁니다.
  - 일부만 미리 있던 경우에도 세 줄을 다 지웁니다.
  - 마이그레이션이 실제로 넣은 줄을 기록하는 곳이 없어서, 출처를 구분할 수 없습니다.
  - 61줄 주석은 "멈춤 검사가 심은 셋인지 지킨다"고 하지만 사실과 다릅니다.
  - `docs/schema.md` 원칙 1(사람이 만든 데이터는 리비전이 지우지 않는다)에 어긋납니다.

**2. `code_groups` 줄은 아무 검사 없이 지워집니다.**
- 자리: `0007_shipping_zone.py`의 `downgrade()` 63줄.
- 까닭:
  - `changed` 검사는 `common_codes`만 봅니다.
  - 운영자가 그룹의 `name`이나 `description`을 고쳤거나 그룹을 먼저 만들어 뒀어도, 확인 없이 삭제됩니다.
  - 코드에는 "값이 다르면 남의 것이라 멈춘다"는 규칙을 적용하면서 그룹에는 빠뜨렸습니다.

## 중요

**3. 검사와 삭제 사이를 잠그지 않아 안전장치가 무력해질 수 있습니다.**
- 자리: `0007_shipping_zone.py`의 `downgrade()` 36줄, 41~46줄 검사 → 62줄 `DELETE` → 64줄 `drop_column`.
- 까닭:
  - PostgreSQL 기본 격리 수준(READ COMMITTED)에서는 검사 뒤에 다른 세션이 커밋한 행을 막지 못합니다.
  - 검사 직후 `shipping_zone`이 채워진 주문이 커밋되면, `drop_column`이 그 값을 조용히 버립니다.
  - 검사 직후 운영자가 추가한 코드는 62줄의 그룹 전체 `DELETE`에 함께 지워집니다.
  - 운영 중에 마이그레이션할 때만 해당합니다. 검사 전에 세 표에 `LOCK TABLE`을 걸고, 삭제는 심은 코드 세 개로 한정해 영향 행 수를 확인하는 방식으로 막을 수 있습니다.

**4. `orders.shipping_zone`에 참조 무결성이 없습니다.**
- 자리: `app/models.py` 31줄(`Order.shipping_zone`), `0007_shipping_zone.py` 19줄.
- 까닭:
  - `docs/schema.md`는 이 칸이 `SHIPPING_ZONE` 그룹의 코드를 "가리킨다"고 하지만, FK도 CHECK도 없습니다. 존재하지 않는 코드가 들어갈 수 있습니다.
  - 운영자가 주문이 쓰는 코드를 지우거나 이름을 바꿔도 막히지 않아, 주문 쪽 값이 고아가 됩니다.
  - 복합 PK라서 일부러 FK를 안 걸었을 수도 있습니다. 설계 의도인지 확인이 필요합니다.

## 경미 · 확인 필요

**5. 마이그레이션 이력과 환경이 비어 있습니다.**
- 자리: `0006_orders.py` 7~8줄, `migrations/` 전체.
- 까닭:
  - 0006이 `down_revision = None`인데 번호는 0006이라 0001~0005가 없습니다. 이력이 잘렸는지 확인이 필요합니다.
  - 위에서 말한 대로 `env.py`가 없어서, DDL이 트랜잭션으로 감싸지는지 알 수 없습니다. 감싸지지 않으면 downgrade 중간 실패가 반쪽 상태를 남깁니다.

**6. upgrade의 `NOT EXISTS` 삽입은 원자적이지 않습니다.**
- 자리: `0007_shipping_zone.py`의 `upgrade()` 21~30줄.
- 까닭: 확인과 INSERT 사이에 운영자가 같은 키를 넣으면 PK 위반으로 실패합니다. 데이터는 잃지 않고 요란하게 실패하는 쪽입니다. `ON CONFLICT DO NOTHING`이 아니라서 "넘어간다"는 주석이 경합 상황에서는 지켜지지 않습니다.

**7. 오프라인 모드(`--sql`)에서는 downgrade의 안전 검사가 동작하지 않습니다.**
- 자리: `0007_shipping_zone.py`의 `downgrade()` 36줄, 41~46줄, 51~57줄.
- 까닭: `bind.execute(...).scalar()`는 SQL 생성 모드에서 값을 돌려주지 못합니다. 오프라인 모드를 쓰지 않으면 해당하지 않습니다.

**8. PostgreSQL 전용 SQL을 문자열로 조립합니다.**
- 자리: `0007_shipping_zone.py` 15줄, 22~29줄, 43~44줄, 62~63줄.
- 까닭:
  - 입력이 모듈 상수뿐이라 지금은 안전합니다.
  - 44줄의 `repr(c)` 인용은 상수에 따옴표나 역슬래시가 들어가면 깨집니다.
  - `VALUES ... AS v(...)`, 행 단위 `IS DISTINCT FROM`은 이식성이 없습니다.

## 문제없다고 본 것
- 모델과 0006의 칸 정의(칸, 기본값, 복합 PK, FK)와 `Order.shipping_zone` ↔ 0007 `add_column`은 서로 맞습니다.
- 0006의 `downgrade`가 항상 예외를 내는 것은 의도된 동작으로 보입니다.
- 운영자가 코드를 더하거나 값을 바꾸면 `extra`와 `changed` 검사가 멈추고, 주문이 권역을 쓰고 있어도 멈춥니다.

우선순위는 1과 2가 가장 높습니다. 원칙 1을 실제로 깨는 결함이고, 줄의 출처를 기록하는 방식이 필요해서 설계 결정이 따릅니다.
