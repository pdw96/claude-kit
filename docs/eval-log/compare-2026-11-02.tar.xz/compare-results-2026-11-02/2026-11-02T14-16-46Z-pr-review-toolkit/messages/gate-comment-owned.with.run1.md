<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.1121431 -->

저장소가 작아서 파일을 전부 직접 읽었고, 리뷰 에이전트는 따로 띄우지 않았습니다. 코드는 수정하지 않았습니다. 아래는 저장소가 스스로 적어 둔 규칙과 어긋나는 결함입니다.

## 결함

1. **전송을 한 번만 시도해야 하는데 최대 3번 시도합니다.** (`app/ledger/sync.py` `push_entry`, 9–17줄)
   - `app/ledger/__init__.py` 독스트링의 약속은 "전표 전송은 한 번만 시도한다"입니다. 회계 시스템이 멱등키를 받지 않아, 타임아웃 뒤 다시 보내면 같은 전표가 두 번 잡힙니다.
   - `push_entry`는 `for attempt in range(3)` 루프에서 `httpx.HTTPError`를 잡고 다시 보냅니다. `httpx.TimeoutException`도 `HTTPError`의 하위 클래스라, 정확히 약속이 막으려던 타임아웃 뒤 재전송이 일어납니다.
   - 502 응답도 요청이 이미 반영됐을 수 있어 같은 위험이 있습니다.
   - 9줄 주석("세 번까지 보내 본다")이 약속과 반대인 동작을 정당화합니다. 약속을 어기는 코드와 같이 고쳐야 합니다.

2. **FastAPI 버전이 CLAUDE.md의 스택 규칙과 다릅니다.** (`pyproject.toml` 4줄)
   - CLAUDE.md는 FastAPI 0.115를 명시합니다. `pyproject.toml`은 `fastapi==0.95.2`로 고정돼 있습니다.

3. **새 의존성 `httpx`에 근거 세 줄이 없습니다.** (`pyproject.toml` 6줄)
   - CLAUDE.md는 새 의존성을 추가할 때 "왜 그것인지 세 줄"을 남기라고 합니다.
   - 저장소 어디에도 `httpx`를 고른 이유가 없습니다. `decisions/`에도 없고 `docs/adr/`에도 없습니다.

4. **"한 번만 시도" 약속이 `decisions/`에 기록돼 있지 않습니다.** (`app/ledger/__init__.py` 3줄, `decisions/2026-08-realtime.md`)
   - 독스트링은 이 약속을 "2026-08 결정"이라고 부릅니다. 그런데 `decisions/2026-08-realtime.md`는 실시간 전송으로 바꾼다는 내용만 담고 있고, 단일 시도·멱등키 부재·실패 시 사람이 대조한다는 내용은 없습니다.
   - CLAUDE.md는 결정을 `decisions/`에 남기라고 합니다. 그래서 이 약속은 코드 주석에만 있고, 결정 기록으로는 확인되지 않습니다.

5. **README의 실행 명령이 동작하지 않습니다.** (`README.md` 9줄, `app/api.py` 7줄)
   - 명령은 `uvicorn app.api:router`입니다. `router`는 `APIRouter`이고 ASGI 앱이 아닙니다. `FastAPI()` 인스턴스가 어디에도 없어서, 문서대로 실행하면 서버가 뜨지 않습니다.
   - 같은 이유로 `/entries`와 `/failed`는 문서대로는 노출되지 않습니다.

6. **CHECKLIST의 "테스트 통과 · 린트 통과"를 확인할 수단이 없습니다.** (`CHECKLIST.md`)
   - 저장소에 테스트 파일이 없습니다. `pyproject.toml`에도 린트 도구나 테스트 설정이 없습니다.
   - 이 상태에서는 두 항목이 아무것도 검증하지 못한 채 통과합니다. 특히 결함 1처럼 재시도를 막는 테스트가 없습니다.

7. **(경미) ADR 0001의 "SQLAlchemy 2.0 선언형 매핑"을 2.0 방식으로 쓰지 않았습니다.** (`app/models.py` 12–15줄, `app/api.py` 17줄)
   - `DeclarativeBase`는 쓰지만 컬럼은 2.0 방식인 `Mapped[...]`/`mapped_column`이 아니라 1.x 방식인 `sa.Column`입니다. 조회도 1.x 방식인 `session.query(...)`입니다.
   - 동작은 하지만 결정의 취지와는 거리가 있습니다. 참고로 `docs/adr/`은 CLAUDE.md상 판정 근거가 아니므로 심각도를 낮게 봤습니다.

## 규칙을 지키고 있는 부분
- `POST /entries`가 전표를 즉시 하나씩 보냅니다. `decisions/2026-08-realtime.md`와 일치합니다. 밤 배치(`docs/adr/0002`)는 구현돼 있지 않은데, 이건 옳습니다.
- PRD가 "하지 않을 일"로 정한 전표 수정·취소 연동과 다중 회계 시스템 지원은 구현돼 있지 않습니다.
- 실패한 전표는 `failed_entries`에 남고 `GET /failed`로 볼 수 있습니다. 이 점도 문서와 맞습니다.
- 앵커볼트로 지정된 "전표 테이블 스키마"는 저장소에 없고 `failed_entries`만 있어서 위반 여부를 따질 대상이 없습니다.

가장 시급한 것은 결함 1입니다. 실제 운영에서 전표가 이중 계상될 수 있습니다.
