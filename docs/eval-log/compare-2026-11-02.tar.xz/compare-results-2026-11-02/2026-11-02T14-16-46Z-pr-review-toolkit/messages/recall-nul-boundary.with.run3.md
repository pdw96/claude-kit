<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.3828975 -->

# 결함 목록: 참가 신청 API (`POST /registrations`)

`pr-review-toolkit`의 code-reviewer와 silent-failure-hunter로 저장소 전체(`app/`, `migrations/`, `docs/api.md`)를 검토했고, 코드는 고치지 않았습니다. 이 환경에서는 FastAPI, PostgreSQL, psycopg를 설치하거나 실행하지 못했습니다. 그래서 DB와 pydantic 동작은 코드를 읽고 추론한 것이고, JSON 파싱과 공백 문자 판정만 `python3`로 확인했습니다.

## 치명 (Critical)

**1. NUL 문자(`\u0000`)가 검증을 통과해 500이 난다**
- **자리:** `app/schemas.py:21-25`의 `RegistrationIn` 네 필드 전부. 실패는 `app/main.py:29`의 `post_registration`에서 `s.commit()` 때 터진다.
- **까닭:**
  - JSON의 `"\u0000"`은 실제 NUL 문자로 파싱되고, pydantic `str`은 이를 받는다.
  - `_present`(`app/schemas.py:11-15`)는 `_BLANK`만 거르므로 `"x\u0000"` 같은 값도 통과한다.
  - `note`는 검증기가 아예 없다.
  - PostgreSQL `TEXT` 컬럼은 NUL을 저장할 수 없다. 그래서 psycopg가 `DataError`를 내고, 아무도 잡지 않아 필드 이름 없는 500이 나간다.
- **계약 위반:** `docs/api.md:10`의 "받을 수 없는 요청은 경계에서 422", "경계를 지난 요청은 저장된다"를 어긴다. 문서의 응답 표(`docs/api.md:5-8`)에는 500이 없다. `_present`의 독스트링(`app/schemas.py:12`)이 이 위험을 이미 알고 있는데, 공백만 막는다.

## 중요 (Important)

**2. 빈 값 판정 `_BLANK`가 불완전해서 눈에 안 보이는 이름이 저장된다**
- **자리:** `app/schemas.py:8`의 `_BLANK`, `app/schemas.py:13`의 `value.strip(_BLANK)`.
- **까닭:** 목록에 6자(스페이스, 탭, 개행, 복귀, U+3000, U+00A0)뿐이다. 다음 문자들은 걸러지지 않아 `attendee_name: "\u2003"` 같은 값이 201로 저장된다.
  - `\x0b`, `\x0c`, `\x1c`, `\x85`, U+2000–U+200A, U+2028, U+2029, U+202F, U+205F
  - 제로폭 문자 U+200B, U+FEFF (이 둘은 `str.strip()`으로도 안 지워진다)
- **참고:** 500은 아니지만 `_present`가 약속한 "눈에 비어 보이는 값 거르기"에 구멍이 있는 것이다.

**3. DB 오류를 번역하거나 기록하는 곳이 없다**
- **자리:** `app/main.py:26-30`의 `post_registration`, 특히 `s.commit()`(29행).
- **까닭:** `DataError`, `IntegrityError`, DB 다운 때의 `OperationalError`가 모두 이름 없는 500으로 나간다. 명시적 `rollback()`도 없다. 세션 `close()`(`app/main.py:17-22`)가 트랜잭션을 버려 주기는 하지만 암묵적이다. 1번을 입력 경계에서 막는 것이 근본 해결이고, 이 항목은 그 뒤의 안전망이다.

**4. 문서의 응답 표가 실제 동작을 다 담지 못한다**
- **자리:** `docs/api.md:5-8`.
- **까닭:** 201과 422만 적혀 있지만 실제로는 500도 나온다(1번, 3번). 오류 본문 형식이나 DB 불가 시의 응답도 정의되어 있지 않다.

## 낮음 / 확인 필요

**5. `note`와 `organization`의 빈 값 처리가 다르다**
- **자리:** `app/schemas.py:24-25`.
- **까닭:** `organization=""`이나 공백만 있으면 422인데, `note=""`나 공백만 있는 값은 그대로 저장된다. 의도한 차이인지 문서에 없고, 빈 값을 `None`으로 정규화하지도 않는다.

**6. DB가 경계 규칙을 강제하지 않는다**
- **자리:** `migrations/0001_registrations.py:11-18`, `app/models.py:12-16`.
- **까닭:** 컬럼이 길이 제한 없는 `Text`이고 `CHECK` 제약이 없다. 길이(20, 50, 100, 500)와 비공백 규칙이 pydantic에만 있어서, 이 엔드포인트가 아닌 다른 쓰기 경로는 우회할 수 있다.

**7. 중복 신청과 `event_code` 유효성이 정해져 있지 않다**
- **자리:** `migrations/0001_registrations.py`(유니크 제약 없음), `app/schemas.py:22`.
- **까닭:**
  - 같은 사람이 같은 행사에 여러 번 신청해도 전부 201이다.
  - `event_code`는 길이만 보고 어떤 행사인지는 확인하지 않는다.
  - 문서에는 중복 응답(예: 409)이 없어서 이것이 의도인지 알 수 없다.

**8. (미확인) 짝 없는 서로게이트(`"\ud800"`)**
- **자리:** `app/schemas.py`의 문자열 필드.
- **까닭:** 두 에이전트의 판단이 달랐습니다. 하나는 psycopg 인코딩에서 500이 날 수 있다고 봤고, 다른 하나는 pydantic-core가 먼저 422로 거를 것이라고 봤습니다. 실행해 보지 못했으니 테스트로 확인이 필요합니다.

## 참고
- 저장소에 테스트가 없어서 위 경계 사례들이 어떤 것도 고정되어 있지 않습니다.
- 잘 된 부분: 세션을 `finally`에서 항상 닫고(`app/main.py:17-22`), `downgrade`가 데이터가 있으면 이유를 말하고 거부하며(`migrations/0001_registrations.py:21-25`), 응답의 `row.id`는 commit 후 다시 읽혀 정확합니다.
