<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.7666458000000002 -->

`pr-review-toolkit`의 리뷰 에이전트 네 개(code-reviewer, silent-failure-hunter, type-design-analyzer, comment-analyzer)를 병렬로 돌렸습니다. 테스트 파일이 없어서 pr-test-analyzer는 제외했고, 코드는 고치지 않았습니다. 아래는 에이전트 보고를 중복 없이 합치고, 제가 읽은 코드와 대조해 정리한 결과입니다.

실행으로 확인한 것은 없습니다. 이 환경에는 FastAPI, SQLAlchemy, PostgreSQL이 없어서 모든 항목이 코드를 읽고 내린 판단입니다.

## 높음

**1. 커밋이 응답보다 늦게 일어나, 실패한 대출이 201로 나갈 수 있습니다.**
- 자리: `app/main.py` `session_scope` 24행 `session.commit()`, `post_loan` 42행
- 까닭:
  - 커밋이 `yield` 뒤의 종료 코드에 있습니다. `Depends(session_scope)`에 `scope="function"`도 없습니다.
  - 고정 버전 FastAPI 0.141.1에서는 이 종료 코드가 응답을 보낸 뒤 실행될 가능성이 큽니다. 이 부분은 설치본으로 확인하지 못했습니다. 에이전트 세 개가 같은 판단을 냈지만 모두 문서 기준 추론입니다.
  - 그렇다면 클라이언트는 `loan_id`가 붙은 201을 받고, 그 뒤 커밋이 실패하면 그 대출은 DB에 없습니다.
  - SERIALIZABLE에서는 SSI 충돌(40001)이 커밋 시점에 드러나는 일이 흔해서 현실적인 경로입니다.
  - 그 시점의 예외는 HTTP 상태를 바꿀 수 없어 로그에만 남습니다.
- 원칙 1(`docs/schema.md:11-12`)은 DB 안에서는 지켜집니다. `lend`가 `flush`만 하고 같은 세션에서 처리하기 때문입니다. 다만 응답과 DB 상태가 갈라집니다.

**2. 직렬화 실패와 IntegrityError가 번역되지 않고 500으로 샙니다.**
- 자리: `app/main.py` 40~41행(`RefusedLoan`만 잡음)과 25~27행(`except Exception`은 rollback 후 재던짐), `app/services/loans.py` `lend` 48행 `session.flush()`
- 까닭:
  - 같은 책을 동시에 빌리면 진 쪽은 `OperationalError`(SQLSTATE 40001)로 실패합니다. 이 예외는 `flush`나 `commit`에서 올라옵니다.
  - CHECK 위반이나 FK 위반 같은 `IntegrityError`도 같은 경로로 새어 나옵니다.
  - "남은 권수 없음"(422)과 "경합으로 짐"(재시도하면 됨)이 구분되지 않습니다. 정상 경합이 서버 오류 알람으로 보입니다.
  - 어떤 대출이 왜 졌는지 남기는 로그도 없습니다.
- 원칙 3(`docs/schema.md:14`)의 "하나만 선다"는 DB에서는 맞지만, 진 쪽의 결과가 내부 오류가 됩니다.

**3. 직렬화 실패 재시도가 없습니다.**
- 자리: `app/db.py:9`(SERIALIZABLE 설정), `app/main.py`의 세션·트랜잭션 구조 전체
- 까닭:
  - PostgreSQL SERIALIZABLE은 실패한 트랜잭션 전체를 다시 시도하는 것을 전제로 합니다.
  - 지금은 트랜잭션 경계가 `Depends`에 묶여 있어 재시도 루프를 끼울 자리가 없습니다.
  - 남은 권수가 여러 권이어도 SSI의 거짓 양성으로 불필요하게 실패할 수 있습니다.
  - 재시도는 커밋까지 포함해야 하므로 1번과 같은 자리에서 고쳐야 합니다.

**4. 같은 책·회원의 미반납 중복 대출을 막는 제약이 없습니다.**
- 자리: `app/models.py:29-38` `Loan`, `migrations/0001_initial.py:27-36`
- 까닭:
  - `(book_id, member_id)` 유니크나 `WHERE returned_on IS NULL` 부분 유니크 인덱스가 없습니다.
  - 같은 요청이 두 번 들어오면 대출 행이 두 개 생기고 `available_copies`도 두 번 줄어듭니다.

**5. 이 마이그레이션을 실행할 수 없습니다.**
- 자리: `migrations/` 디렉터리 전체, 저장소 루트
- 까닭:
  - `alembic.ini`, `env.py`, `script.py.mako`가 없고 `versions/` 디렉터리도 없습니다.
  - 스키마를 만들 방법도 되돌릴 방법도 저장소 안에 없습니다.
  - `target_metadata`가 연결되지 않아 autogenerate도 쓸 수 없습니다.

## 중간

**6. `downgrade`의 되돌림이 안전하지 않습니다.**
- 자리: `migrations/0001_initial.py` `downgrade` 39~46행
- 까닭:
  - (a) 가드가 `loans`에만 걸려 있습니다. `loans`가 비어 있으면 `books`와 `members`는 데이터가 있어도 경고 없이 DROP됩니다.
    - 주석("지우면 되살릴 길이 없다", 40행)의 논리는 그 두 표에도 똑같이 적용됩니다.
    - `docs/schema.md:5`도 회원은 지우지 않는다고 합니다.
  - (b) `SELECT EXISTS` 검사와 `DROP TABLE` 사이에 잠금이 없습니다. READ COMMITTED에서는 그 틈에 커밋된 대출이 함께 사라질 수 있습니다. `LOCK TABLE ... ACCESS EXCLUSIVE`를 먼저 잡아야 합니다.
  - (c) `op.get_bind()`로 조회하는 가드는 오프라인 모드(`--sql`)에서 의미 있게 동작하지 않아, 생성되는 SQL에 무조건 DROP이 들어갈 수 있습니다.
  - (d) 거부 메시지가 일반 `RuntimeError`이고 건수나 대처 방법이 없습니다.

**7. `loans.returned_on`에 날짜 순서 CHECK가 없습니다.**
- 자리: `app/models.py:31`, `migrations/0001_initial.py:35`
- 까닭: CHECK가 `due_on >= loaned_on` 하나뿐이라 `returned_on < loaned_on`인 행이 들어갈 수 있습니다.

**8. `loan_days`에 양수 검사가 없습니다.**
- 자리: `app/models.py:25`, `migrations/0001_initial.py:23`
- 까닭: 0이나 음수가 들어갈 수 있습니다. 음수면 대출 자체가 `loans_due_after_loan` 위반으로 터져서, 원인과 증상이 멀리 떨어집니다. 이 경우 위 2번의 500으로 나옵니다.

**9. FK에 `ondelete`가 없고 FK 컬럼에 인덱스가 없습니다.**
- 자리: `app/models.py:34-35`, `migrations/0001_initial.py:30-31`
- 까닭:
  - 기본값 `NO ACTION`은 "지우지 않는다"는 정책과는 맞지만, `RESTRICT`로 명시하지 않아 나중에 CASCADE가 들어와도 막을 근거가 없습니다.
  - `loans.book_id`와 `loans.member_id`는 PostgreSQL이 자동으로 인덱스하지 않아 회원별·책별 조회가 전체 스캔이 됩니다.
  - 미반납 행만 대상으로 하는 부분 인덱스도 없습니다. 4번의 부분 유니크 인덱스와 함께 해결됩니다.

**10. 비활성 회원 거절이 애플리케이션 계층에만 있습니다.**
- 자리: `app/services/loans.py:35`(검사), `app/models.py:15`
- 까닭: DB에는 `is_active=false`인 회원의 대출을 막는 장치가 없어, 다른 경로로 들어오는 쓰기는 통과합니다.

**11. 재고 감소가 읽고-수정-쓰는 방식입니다.**
- 자리: `app/services/loans.py:37-40`
- 까닭:
  - 파이썬에서 값을 읽어 줄인 뒤 절대값으로 씁니다. SERIALIZABLE이라 지금은 갱신이 사라지지 않습니다.
  - 격리 수준이 바뀌면 갱신 손실이 생기고, CHECK도 이를 막지 못합니다.
  - 원자적 `UPDATE ... SET available_copies = available_copies - 1 WHERE ... AND available_copies > 0`이나 `with_for_update()`가 더 안전합니다.

## 낮음

**12. `available_copies`가 파생값이고 상한이 없습니다.**
- 자리: `app/models.py:26`
- 까닭:
  - 미반납 대출 수와 어긋날 수 있습니다.
  - `total_copies` 컬럼이 없어 상한 검사가 불가능합니다.
  - 반납 쪽 코드가 생기면 값이 끝없이 커질 수 있습니다.

**13. 모델과 마이그레이션을 손으로 이중 정의했고 `naming_convention`이 없습니다.**
- 자리: `app/models.py:5-6`(`Base`에 `MetaData` 지정 없음), `migrations/0001_initial.py:11-36`
- 까닭:
  - 지금은 열 이름, 타입, 길이, `server_default`, CHECK 이름이 일치합니다.
  - 일치를 지켜 줄 `alembic check` 같은 검사가 없습니다.
  - CHECK만 이름이 있고 PK, FK, UNIQUE는 DB 자동 이름이라, 나중에 제약을 지우거나 바꿀 때 DB마다 이름이 달라 `drop_constraint`를 쓰기 어렵습니다.

**14. 입력 스키마와 컬럼의 불일치입니다.**
- 자리: `app/schemas.py:7`(ISBN), `app/schemas.py:8-9`, `app/models.py:14`, `app/models.py:24`
- 까닭:
  - ISBN은 길이 10~13이면 통과해 11, 12자리도 들어옵니다. DB에도 형식 CHECK가 없습니다.
  - `loaned_on`을 클라이언트가 임의로 정해서 미래나 먼 과거 날짜가 `due_on` 계산에 그대로 쓰입니다.
  - 빈 문자열 `name`/`title`과 공백만 있는 `card_number`가 통과합니다.

**15. 문서와 코드의 어긋남입니다.**
- 자리: `docs/schema.md:5-7`, `docs/schema.md:11-14`, `app/db.py:8`, `app/main.py:17-20`, `app/main.py:34`
- 까닭:
  - 반납(`returned_on`을 채움)과 탈퇴(`is_active`를 끔)를 수행하는 코드가 저장소에 없는데 문서는 이미 있는 동작처럼 적었습니다.
  - `session_scope` docstring(17~20행)과 원칙 1은 "응답이 곧 확정"으로 읽히지만 1번 때문에 보장되지 않습니다.
  - `db.py:8` 주석과 원칙 3은 직렬화 실패 시 진 쪽이 500이 된다는 점과 PostgreSQL 전제를 적지 않았습니다. `settings.py:5`의 `database_url`은 바꿀 수 있습니다.
  - `post_loan` docstring(34행)은 거절을 422로 말한다고 하지만 직렬화 실패는 500입니다.

**16. 기타 구조 문제입니다.**
- 자리: `app/models.py:12-38`, `app/main.py:25-27`
- 까닭:
  - `DeclarativeBase`를 쓰면서 컬럼은 구식 `sa.Column`이라 `returned_on`의 `None` 가능성이 타입에 드러나지 않습니다. `relationship()`도 없습니다.
  - `session.rollback()` 자체가 실패하면 원래 예외를 가릴 수 있습니다.

## 정정과 한계
- 데이터 모델 에이전트는 `app/db.py`를 받지 못해 "엔진 격리 수준 설정을 못 찾았다"고 보고했습니다(항목 6). 이 지적은 틀렸습니다. `app/db.py:9`에 `isolation_level="SERIALIZABLE"`이 있습니다. 위 목록에서는 그 지적을 뺐습니다.
- 코드 리뷰어의 "Alembic 구성 파일 없음"과 "읽고-수정-쓰는 방식"은 단독 지적이었고, 나머지는 둘 이상의 에이전트가 겹쳐 지적했습니다.
- 에이전트들이 확인한 정상 항목은 다음과 같습니다.
  - 모델과 마이그레이션이 일치합니다.
  - 원칙 2의 CHECK가 양쪽에 있습니다.
  - `lend`가 커밋 없이 `flush`만 하므로 대출 행 INSERT와 재고 UPDATE가 한 트랜잭션에 묶입니다.
