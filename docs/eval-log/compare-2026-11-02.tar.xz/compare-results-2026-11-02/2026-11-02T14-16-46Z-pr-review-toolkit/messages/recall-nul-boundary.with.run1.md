<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.4369816 -->

`POST /registrations`가 `docs/api.md`에서 약속한 것과 다르게 동작하는 곳을 찾았습니다. 코드는 고치지 않았습니다. 이 점검은 `pr-review-toolkit`의 code-reviewer와 silent-failure-hunter, 그리고 제가 직접 읽은 내용을 합친 것입니다.

확인 정도는 둘로 나뉩니다. pydantic 검증을 직접 돌려 확인한 것은 NUL과 공백류 통과 두 가지입니다. DB 단계(500 응답, `commit()` 오류 경로)는 이 환경에 FastAPI와 psycopg가 없어 실행하지 못했고, psycopg3의 알려진 동작을 근거로 한 추론입니다.

## 높음

1. **NUL(`\x00`)이 검증을 통과해 500이 됩니다.**
   - 자리: `app/schemas.py`의 `RegistrationIn` 네 필드 모두(`note` 포함), 실패 지점은 `app/main.py`의 `post_registration`(`s.commit()`).
   - 까닭: 검증기는 공백만 검사하고 `note`에는 검증기가 없어서, `"홍\x00길동"` 같은 값이 길이와 공백 검사를 통과합니다. PostgreSQL `text`는 NUL을 저장할 수 없으므로 psycopg가 `DataError`를 내고, 처리하는 곳이 없어 500이 됩니다. 문서의 "받을 수 없는 요청은 422"와 "경계를 지난 요청은 저장된다"(`docs/api.md` 10행)가 함께 깨집니다.

2. **500 응답이 문서에 없고, 응답 형식도 정해져 있지 않습니다.**
   - 자리: `app/main.py`의 `post_registration`(27~30행), `docs/api.md` 응답 표(5~8행).
   - 까닭: `commit()`의 DB 예외(`DataError`, `IntegrityError`, `OperationalError`)를 처리하지 않습니다. 그래서 칸과 까닭이 없는 평문 `Internal Server Error`가 나가고, 로그나 오류 ID도 없습니다. 문서에는 201과 422뿐이라 클라이언트가 이 응답을 예측할 수 없습니다.

3. **DB가 내려가거나 연결에 실패해도 같은 이름 없는 500이 나갑니다.**
   - 자리: `app/main.py` 14행(모듈 수준 `create_engine`)과 `session()`.
   - 까닭: 일시적 장애를 뜻하는 503이 아니라 500이라, 클라이언트가 재시도해도 되는지 알 수 없습니다. 연결 문자열도 코드에 고정돼 있어 설정 오류도 같은 500으로 보입니다.

## 중간

4. **공백 목록이 짧아서 "비어 보이는 값"이 저장됩니다.**
   - 자리: `app/schemas.py`의 `_BLANK`(8행)와 `_present`.
   - 까닭: 목록에 없는 `\v`, `\f`, U+0085, U+2000~U+200A, U+2028/2029, U+202F, U+205F와 폭 없는 문자(U+200B, U+2060, U+FEFF)만으로 된 `event_code`, `attendee_name`, `organization`이 422가 아니라 그대로 저장됩니다.

5. **`note`에는 어떤 검증도 없습니다.**
   - 자리: `app/schemas.py` 25행.
   - 까닭: 공백만인 `note`를 허용하는 것은 설계일 수 있습니다. 하지만 1번의 NUL 문제는 `note`에도 그대로 적용되므로, `Present`에만 검사를 붙이면 `note`가 빠집니다.

6. **중복 신청을 막지 못하고, DB는 길이를 강제하지 않습니다.**
   - 자리: `migrations/0001_registrations.py`의 `upgrade`, `app/models.py`.
   - 까닭: `(event_code, attendee_name)`에 유일 제약이 없어서 같은 신청이 오류 없이 여러 번 저장됩니다. 멱등성 키도 없습니다. 열은 모두 길이 제한 없는 `Text`이고 `max_length`는 스키마에만 있어서 DB가 두 번째 방어선이 되지 못합니다.

7. **`commit()` 뒤 응답 단계의 실패가 중복 신청으로 이어질 수 있습니다.**
   - 자리: `app/main.py` 30행(`row.id`).
   - 까닭: 커밋 뒤 `row.id` 접근은 속성이 만료돼 다시 조회합니다. 이 조회가 실패하면 저장은 끝났는데 응답은 500이 되고, 재시도하면 중복이 생깁니다(6번과 이어짐).

## 낮음

8. **계약 문서가 불완전합니다.**
   - 자리: `docs/api.md`.
   - 까닭: 201 본문(`{"registration_id": int}`), 422 `detail`의 실제 형식(FastAPI 기본 배열이고 `msg`가 `"Value error, 비어 있다"`처럼 나옴), 필드별 길이 제한(20/50/100/500), 필수·선택 여부가 적혀 있지 않습니다.

9. **`commit()` 실패 시 롤백을 명시하지 않습니다.**
   - 자리: `app/main.py`의 `session()`.
   - 까닭: `finally`의 `close()`가 암묵적으로 되돌리긴 합니다. 하지만 오류 처리를 추가할 때 롤백 위치가 정해져 있지 않습니다.

10. **앞뒤 공백이 그대로 저장됩니다.**
    - 자리: `app/schemas.py`의 `_present`.
    - 까닭: 검사만 하고 원래 값을 돌려줘서 `" 홍길동 "`이 정리되지 않습니다.

11. **`downgrade()`의 예외가 너무 일반적입니다.**
    - 자리: `migrations/0001_registrations.py` 22~25행.
    - 까닭: 신청이 남아 있으면 막는 의도는 좋습니다. 다만 `RuntimeError`라 다른 오류와 구분이 안 되고, 메시지에 건수나 해결 방법이 없습니다.

## 결함이 아닌 것

- 짝 없는 서로게이트(`"\ud800"`)는 pydantic이 경계에서 거부하는 것을 code-reviewer가 확인했습니다. silent-failure-hunter는 이것도 500이 될 수 있다고 적었지만, 이 확인에 따라 제외했습니다.
- `app/__init__.py`는 비어 있고 문제가 없습니다.
