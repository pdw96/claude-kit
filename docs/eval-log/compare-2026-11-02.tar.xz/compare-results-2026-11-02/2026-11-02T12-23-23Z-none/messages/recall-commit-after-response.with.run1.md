<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.1043488 -->

저장소 전체(파일 10개)를 읽고 검토했습니다. 코드는 고치지 않았고 실행이나 테스트도 하지 않았습니다. 아래 결함은 모두 코드를 읽고 추론한 것입니다.

## 트랜잭션 경계 · 동시성

1. **직렬화 실패를 재시도하거나 번역하지 않습니다.**
   - 자리: `app/db.py:9`, `app/main.py:16-29` (`session_scope`), `app/services/loans.py:lend`
   - 까닭: 엔진 전체가 `SERIALIZABLE`입니다. PostgreSQL은 동시에 같은 책을 빌리는 요청 중 하나를 `40001`(`SerializationFailure`)로 중단시킵니다. 코드에는 재시도도 409/503 변환도 없어서, 지는 쪽은 500이 됩니다. `docs/schema.md` 원칙 3의 "하나만 선다"는 나머지 요청이 에러로 끝난다는 뜻이 됩니다.
2. **`commit()`이 엔드포인트 밖, 의존성 종료 단계에서 일어납니다.**
   - 자리: `app/main.py:24`
   - 까닭: SERIALIZABLE에서는 충돌이 `flush` 시점이 아니라 `COMMIT` 시점에 터질 수 있습니다. 그 에러가 `post_loan`의 `try` 바깥에서 나므로 `RefusedLoan`처럼 처리할 수 없습니다. FastAPI 버전에 따라 이미 보낸 201 응답과 실제 저장 결과가 어긋날 수도 있습니다. 커밋 결과가 응답을 결정하지 못하는 구조입니다.
3. **읽고 나서 쓰는 방식으로 재고를 줄입니다.**
   - 자리: `app/services/loans.py:37-40`
   - 까닭: 권수를 읽고, 파이썬에서 `-= 1`을 한 뒤 씁니다. 원자적 `UPDATE … SET available_copies = available_copies - 1 WHERE id=… AND available_copies > 0`이나 `SELECT … FOR UPDATE`가 아닙니다. 정합성이 격리 수준 설정 하나에만 걸려 있습니다. 누가 격리 수준을 낮추거나 다른 DB로 바꾸면 갱신 손실이 납니다. 이때 안전망은 `CHECK >= 0`뿐이고, 그것도 권수가 0일 때만 잡습니다.
4. **격리 수준이 엔진 전역에 걸려 있습니다.**
   - 자리: `app/db.py:9`
   - 까닭: 읽기만 하는 요청과 앞으로 생길 다른 쓰기 경로도 모두 SERIALIZABLE을 씁니다. 충돌과 중단이 불필요하게 늘고, 1번의 재시도 문제가 쓰기 경로마다 반복됩니다.
5. **제약 위반이 500으로 새어 나갑니다.**
   - 자리: `app/services/loans.py:48` (`flush`), `app/main.py:40`
   - 까닭: `IntegrityError`(CHECK 위반, 그리고 `Loan`에 `returned_on >= loaned_on` 제약이 없는 점)를 `RefusedLoan`으로 바꾸지 않습니다. 예를 들어 `loan_days`가 음수인 책은 `loans_due_after_loan` 위반으로 500이 됩니다.

## 데이터 모델

6. **되돌림(반납) 경로가 없습니다.**
   - 자리: `app/services/loans.py` 전체, `app/main.py`
   - 까닭: `lend`만 있고 반납 코드가 없습니다. `returned_on`을 채우는 곳도, `available_copies`를 되돌리는 곳도 없습니다. `docs/schema.md`의 "반납하면 `returned_on`이 찬다"를 구현한 코드가 없습니다. 반납을 나중에 추가하면 대출 줄 갱신과 재고 증가를 한 트랜잭션에 묶어야 하는데, 지금 구조에는 그 틀이 없습니다.
7. **총 보유 권수 컬럼이 없어서 재고 상한을 지킬 수 없습니다.**
   - 자리: `app/models.py:Book`, `migrations/0001_initial.py:19-26`
   - 까닭: `available_copies`에는 `>= 0` 하한만 있습니다. `total_copies`가 없어서 반납이나 수동 보정이 중복되면 보유 권수보다 많아져도 막을 수 없습니다. 재고 수가 `loans`의 미반납 건수와 일치하는지 검증할 수단도 없습니다. 같은 사실이 두 곳에 있고 서로를 묶는 제약이 없습니다.
8. **같은 회원이 같은 책을 중복으로 빌릴 수 있습니다.**
   - 자리: `app/models.py:Loan`
   - 까닭: `(book_id, member_id) WHERE returned_on IS NULL` 같은 부분 유니크 제약이 없습니다. 중복을 막는 것이 정책이라면 빠진 제약입니다. 정책이 아니라면 문서에 명시되어 있지 않습니다.
9. **외래키 열에 인덱스가 없습니다.**
   - 자리: `app/models.py:Loan.book_id`, `Loan.member_id`, `migrations/0001_initial.py:30-31`
   - 까닭: PostgreSQL은 FK에 인덱스를 자동으로 만들지 않습니다. 회원별 대출과 책별 미반납 조회가 전체 스캔이 됩니다. `returned_on IS NULL` 조회용 인덱스도 없습니다.
10. **값 검증이 약합니다.**
    - 자리: `app/models.py:Book.loan_days`, `app/schemas.py:LoanIn.loaned_on`
    - 까닭: `loan_days > 0` 제약이 없습니다. `loaned_on`은 클라이언트가 보내는 값이어서 과거나 미래 날짜를 넣을 수 있고, 서버 날짜와 대조하지 않습니다. 이 값이 `due_on`을 결정합니다.
11. **FK에 삭제 정책이 없고, 도서를 비활성화하는 방법도 없습니다.**
    - 자리: `app/models.py:Loan.book_id`, `Loan.member_id`
    - 까닭: `ondelete`가 지정되어 있지 않아 기본값인 `NO ACTION`입니다. 회원은 `is_active`로 보호하지만 `books`에는 같은 장치가 없습니다. 책을 지우려면 대출 이력이 막거나, 이력을 지우게 됩니다.

## 마이그레이션

12. **`downgrade`가 `loans`만 확인하고 `books`와 `members`는 그대로 지웁니다.**
    - 자리: `migrations/0001_initial.py:39-46`
    - 까닭: 주석의 취지는 "지우면 되살릴 길이 없다"입니다. 그런데 소장 도서와 회원 데이터는 같은 이유로 되살릴 수 없는데도 검사하지 않습니다. 대출이 없고 도서와 회원만 있는 DB에서는 데이터가 조용히 사라집니다. 검사도 `loans` 행 존재 여부뿐이라 기준이 일관되지 않습니다.
13. **Alembic 실행 환경이 저장소에 없습니다.**
    - 자리: 저장소 루트 (`alembic.ini`, `migrations/env.py`, `script.py.mako` 없음)
    - 까닭: `requirements.txt`에는 `alembic==1.14.0`이 있지만 마이그레이션을 실제로 돌릴 설정이 없습니다. 스키마가 어떻게 배포되는지 재현할 수 없습니다. `models.py`와 마이그레이션이 손으로 중복 정의되어 있어서, 어긋나는지 확인하는 `alembic check`나 autogenerate 검증도 불가능합니다.
14. **제약 이름 규칙이 없습니다.**
    - 자리: `app/models.py:Base`, `migrations/0001_initial.py`
    - 까닭: `Base`에 `naming_convention`이 없고, `unique=True`와 FK 이름은 DB가 자동 생성합니다. 나중에 마이그레이션에서 이 제약을 이름으로 지우거나 바꾸기 어렵습니다. 반면 CHECK 두 개만 이름이 붙어 있어 일관성이 없습니다.

## 문서와 구현의 어긋남

15. **`docs/schema.md` 원칙 1은 코드 구조만으로 보장되지 않습니다.**
    - 자리: `docs/schema.md:11-12`, `app/main.py:17-19`
    - 까닭: 원칙 1("둘 중 하나만 선 상태는 없다")은 `session_scope`의 요청당 트랜잭션에 기대고 있습니다. 서비스 함수 `lend` 자체는 세션을 받아 `flush`만 하므로, 다른 곳(스크립트나 배치)에서 호출하면 경계가 없습니다. 2번의 커밋 위치 문제와 겹쳐서, 보장이 DB 제약이 아닌 호출 규약에만 있습니다.

## 우선순위

가장 먼저 볼 것은 1·2·3번(동시 대출 시 실패 처리와 재고 갱신 방식)과 6·7번(반납 경로와 재고 정합성)입니다. 운영 중 데이터 손실로 이어질 수 있는 것은 12번입니다.
