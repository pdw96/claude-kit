<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.19239249999999997 -->

`vibe-audit:audit-data` 감사자를 저장소 전체에 돌렸습니다. 결함은 4건이고, 확인하지 못한 항목이 3건 있습니다. 코드는 고치지 않았습니다.

## 결함

**1. 만료일이 문서와 다른 기준일로 계산돼 틀린 값이 조용히 저장됨 (높음)**
- 자리: `app/services/memberships.py:29-35`, `seed/plans.sql:3-5`, `docs/schema.md:6,9`
- 까닭:
  - 시드 안내와 스키마 문서는 "신청일 + 기간"이라고 합니다. 코드는 승인 시각의 UTC 날짜를 `starts_on`으로 쓰고 `applied_on`은 읽지 않습니다.
  - 승인이 신청보다 늦으면 `valid_until`이 약정보다 1~3일 늦게 잡힙니다. 이 값이 출입 단말의 차단 기준입니다.
  - 체크 제약 `valid_until > starts_on`으로는 이 오류를 잡을 수 없습니다.
  - 이미 승인된 행을 바로잡으려면 백필이 필요합니다.
  - 신청일 기준과 승인일 기준 중 어느 쪽이 의도인지는 저장소로는 정할 수 없습니다.

**2. downgrade가 `applications`와 `plans`를 가드 없이 삭제함 (높음)**
- 자리: `migrations/0001_memberships.py:40-46`
- 까닭:
  - 가드는 `memberships`에 행이 있는지만 봅니다.
  - `pending`이나 거절된 신청은 `memberships`에 행이 없어도 `applications`에 있습니다. `memberships`가 비어 있기만 하면 downgrade가 통과해 그 신청들이 지워지고, 복구할 수 없습니다.
  - 이 리비전이 첫 리비전이라 downgrade가 곧 전체 삭제인데, 파일에 그 표시가 없습니다.

**3. 같은 신청을 동시에 두 번 승인하면 진 쪽이 500을 받음 (보통)**
- 자리: `app/services/memberships.py:22-26`, `app/main.py:28-34`
- 까닭:
  - `session.get`으로 읽고 `status != "pending"`을 확인한 뒤 쓰는 구조인데, 행 잠금(`with_for_update`)이나 조건부 `UPDATE`가 없습니다.
  - `memberships.application_id`의 유니크 제약(`models.py:34`)이 중복 생성은 막습니다. 데이터는 틀어지지 않습니다.
  - 진 쪽은 `commit()`에서 `IntegrityError`가 나는데 `main.py`가 이를 잡지 않아 500이 됩니다. 정상 거절(422)과 다른 응답이 나갑니다.

**4. 참조와 상태 값의 제약이 DB에 없음 (보통)**
- 자리: `app/models.py:23,26,35`, `migrations/0001_memberships.py:22,25,31`, `models.py:14`
- 까닭:
  - `applications.member_id`와 `memberships.member_id`는 어느 표도 가리키지 않는 맨 정수입니다. `members` 표가 없고, 같은 신청의 두 `member_id`가 같다는 보장도 없습니다.
  - `applications.status`는 `String(10)`에 CHECK가 없어서, 오타가 난 값이 "이미 처리한 신청"으로 오분류됩니다.
  - `plans.duration_days`와 `price`에 양수 CHECK가 없습니다. `duration_days`가 0 이하이면 승인 시점에 CHECK가 터져 500이 납니다.
  - 제약을 나중에 추가하려면 기존 행 검증과 백필이 필요합니다.

## 확인하지 못한 것
- **마이그레이션 환경과 시드 적용 경로**: `alembic.ini`, `env.py`가 없고 `seed/plans.sql`을 실행하는 절차도 없습니다. 그래서 마이그레이션과 모델이 같은 상태인지 판정하지 못했습니다. 시드의 `INSERT`에는 `ON CONFLICT`가 없어서, 재실행하면 PK 충돌로 실패합니다.
- **날짜 계산의 시간대**: 운영 시간대와 출입 단말의 날짜 기준을 알아야 합니다. KST라면 UTC로 자른 승인일이 하루 어긋날 수 있습니다.
- **운영 데이터 존재 여부**: 저장소 밖 정보라 알 수 없습니다. 있다고 가정해 1번과 2번의 심각도를 올렸습니다.

## 참고 관찰 (결함은 아님)
- `price`가 신청이나 회원권에 스냅샷되지 않습니다. 결제를 붙이기 전에 정해야 합니다.
- 승인 응답이 자동 증가 `membership_id`를 그대로 노출합니다.

감사자가 결과를 `.claude/audits/` 아래 파일로 저장해 달라고 했지만, 고치지 말라는 요청이라 저장하지 않았습니다. 필요하면 말씀해 주세요.
