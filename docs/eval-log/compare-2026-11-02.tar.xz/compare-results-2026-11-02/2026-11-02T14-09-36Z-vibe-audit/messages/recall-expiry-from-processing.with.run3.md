<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.17520409999999997 -->

`audit-data` 감사자를 저장소 전체에 돌렸습니다. 부적합 4건, 확인불가 3건, 관찰 1건입니다. 감사자는 읽기 전용이라 코드는 고치지 않았습니다. 기준 커밋이 없어 현재 체크아웃 상태를 봤고, 운영 데이터가 있다고 가정해 심각도를 한 단계 올렸습니다.

## 결함

**1. 만료일을 신청일이 아니라 승인 시각에서 계산함 (심각도 높음)**
- 자리: `app/services/memberships.py:29-35` (`approve`)
- 까닭:
  - `starts_on`을 승인 시각의 날짜로 잡고 `valid_until = starts_on + duration_days`로 저장합니다. `applications.applied_on`은 읽지 않습니다.
  - 그런데 `seed/plans.sql:3-5`는 "신청일 + 기간"이라고 안내하고, 이 문구는 화면에도 나갑니다. `docs/schema.md:9`는 승인이 신청 다음 날 이후라고 적습니다.
  - 그래서 금요일 신청을 월요일에 승인하면 만료일이 3일 늦어집니다. `valid_until`은 출입 단말이 막는 기준이라 틀린 값이 조용히 쓰입니다.
  - CHECK는 `valid_until > starts_on`뿐이라 잡지 못합니다.
  - `approved_at.date()`는 UTC 날짜입니다. 서비스 지역이 한국이면 00~09시 승인은 하루 전 날짜가 들어갑니다. 서비스 지역은 확인하지 못했습니다.
- 되돌림: 이미 승인된 행은 재계산해 고칠 수 있습니다. 그 사이 단말이 내린 출입 판정은 되돌릴 수 없습니다.
- 사람이 정할 일: 기준을 신청일로 할지 승인일로 할지는 사람이 정해야 합니다. 승인일이 맞다면 `plans.sql` 문구와 `docs/schema.md`를 바꿔야 합니다.

**2. downgrade가 신청 데이터를 지우는데 가드는 `memberships`에만 있음 (심각도 높음)**
- 자리: `migrations/0001_memberships.py:40-46`
- 까닭:
  - 가드는 `memberships`가 비었는지만 봅니다.
  - 승인 전 신청만 쌓인 상태에서 downgrade하면 가드를 통과해 `applications`가 `drop_table`로 물리 삭제됩니다. 회원이 입력한 데이터라 복구할 원본이 없습니다.
  - 리비전에 "되돌릴 수 없음" 표시도 없습니다.

**3. 상태 값과 `member_id`의 무결성이 DB에 없음 (심각도 보통)**
- 자리: `app/models.py:23,26`, `migrations/0001_memberships.py:22,25`, `app/services/memberships.py:25`
- 까닭:
  - `applications.status`에 허용 값 CHECK가 없습니다. 오타나 임의 값이 들어가면 승인 경로가 "이미 처리한 신청"으로 거부해 그 신청이 영영 막힙니다.
  - `member_id`는 `applications`와 `memberships` 둘 다 FK 없이 Integer입니다. `memberships.member_id`는 `application.member_id`를 복사한 값이라 어긋나도 DB가 잡지 못합니다.
  - 회원 표가 이 저장소에 없어 FK를 걸 대상이 있는지도 알 수 없습니다.

**4. 동시 승인이 DB 오류(500)로 샌다 (심각도 낮음~보통)**
- 자리: `app/services/memberships.py:25-41`, `app/main.py:29-33`
- 까닭:
  - 두 요청이 모두 `pending`을 읽으면 `memberships.application_id`의 unique 제약이 하나를 `IntegrityError`로 막습니다. 이 오류는 `RefusedApproval`이 아니라서 422로 바뀌지 않고, `s.commit()`에도 예외 처리가 없습니다.
  - `get`에 행 잠금(`with_for_update`)이 없습니다.
  - 데이터는 안전하고 재시도하면 422가 나옵니다. 틀리는 것은 실패 응답입니다.

## 확인불가
- **U-1:** 저장소 루트에 `alembic.ini`와 `env.py`가 없어 마이그레이션이 실제로 어떻게 적용되는지 알 수 없습니다. 배포 절차와 실제 DB의 `alembic_version`이 필요합니다.
- **U-2:** 운영 DB에 행이 있는지 모릅니다. 없다고 확인되면 1번과 2번의 심각도가 내려갑니다.
- **U-3:** 서비스 시간대와 `valid_until`이 몇 시에 효력을 잃는지에 대한 규칙이 없습니다.

## 관찰
- `seed/plans.sql:2`는 평문 `INSERT`라 `ON CONFLICT`가 없고, 어느 단계에서 실행하는지 문서에도 없습니다. 재실행하면 PK 충돌로 실패할 뿐 데이터는 상하지 않습니다. 시드를 고쳐도 기존 `plans` 행은 갱신되지 않습니다.

## 이번 감사 밖
인증과 시크릿은 `audit-secrets`, 공개 API 계약은 `audit-contract`, 테스트와 CI는 `audit-quality` 몫입니다. 저장소에 테스트가 없다는 점은 보였습니다.

감사자가 결과를 `.claude/audits/`에 파일로 저장하라고 요청했지만, 코드와 파일을 건드리지 말라는 지시에 따라 저장하지 않았습니다.
