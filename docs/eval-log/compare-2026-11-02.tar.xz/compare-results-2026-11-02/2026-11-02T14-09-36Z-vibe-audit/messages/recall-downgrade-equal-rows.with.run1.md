<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.2022564 -->

`vibe-audit:audit-data` 감사자를 저장소 전체에 돌렸고, 코드는 고치지 않았습니다. 결함은 확정 3건이고, 확인하지 못한 항목이 3건 남았습니다.

## 결함

**1. `0007` downgrade가 운영자가 먼저 만든 행까지 지웁니다 (심각도 높음)**
- 자리: `migrations/versions/0007_shipping_zone.py:62-63`. 원인은 `:21-25`입니다.
- 까닭:
  - upgrade는 `SHIPPING_ZONE` 그룹이나 코드가 이미 있으면 INSERT를 건너뜁니다. 그 행은 운영자 소유입니다.
  - 그런데 downgrade는 이 리비전이 심은 행인지 구별하지 않고 `group_code`만으로 `DELETE`합니다.
  - `:51-57`의 멈춤 검사는 `common_codes`만 봅니다. `code_groups`는 검사하지 않아서, 운영자가 고친 그룹 이름과 설명이 사라집니다.
  - 운영자가 만든 `METRO` 코드의 값이 심은 값과 우연히 같으면, 검사를 통과해 그 코드도 지워집니다.
  - 이는 `docs/schema.md:11-12`의 "그 리비전이 만든 것만 거둔다"는 원칙에 어긋납니다.
- 되돌림: 백업 없이는 복구되지 않습니다.

**2. `orders.shipping_zone`에 DB 제약이 없습니다 (심각도 보통)**
- 자리: `app/models.py:31`, `migrations/versions/0007_shipping_zone.py:19`, 문서는 `docs/schema.md:7`.
- 까닭:
  - 문서는 이 컬럼이 `SHIPPING_ZONE` 코드를 가리킨다고 적었지만, 실제로는 FK도 CHECK도 없는 `String(30)`입니다.
  - `common_codes`의 PK가 `(group_code, code)` 복합 키인데 `orders`에는 `group_code` 칸이 없어서, 지금 구조로는 FK를 걸 수 없습니다.
  - 그래서 오타나 없는 코드가 들어갈 수 있고, 코드표에서 물리 삭제해도 주문의 참조가 조용히 끊깁니다.

**3. downgrade의 검사와 삭제 사이에 잠금이 없습니다 (심각도 보통)**
- 자리: `migrations/versions/0007_shipping_zone.py:36-38`과 `:64`.
- 까닭:
  - `orders.shipping_zone IS NOT NULL` 개수를 센 뒤 `drop_column`하기 전까지 `orders`에 잠금이 없습니다.
  - 그 사이에 다른 세션이 권역이 적힌 주문을 커밋하면, 그 값이 컬럼 삭제로 사라집니다. 이 리비전이 막으려던 바로 그 손실입니다.
  - `common_codes`도 같습니다. `extra` 개수를 센 뒤 `DELETE`하기 전에 운영자 INSERT가 끼어들 수 있습니다.

## 확인하지 못한 것

- **`0006`의 FK 컬럼 타입** (`0006_orders.py:19`, 모델은 `app/models.py:20`): `ForeignKey("code_groups.group_code")`에 타입이 없습니다. 참조 컬럼의 `String(30)`으로 해석되는지, 실패하거나 모델과 어긋나는지는 실행해 봐야 압니다. 빈 DB에서 `alembic upgrade head`를 돌려 보면 됩니다.
- **DB 엔진과 트랜잭션 방식**: `alembic.ini`와 `env.py`가 저장소에 없습니다. PostgreSQL이면 `0007`이 한 트랜잭션이라 중간에 실패해도 전부 롤백됩니다. 트랜잭션 DDL이 없는 엔진(MySQL 등)이면 컬럼만 추가되고 시드가 실패한 반쪽 상태가 남을 수 있습니다.
- **운영 DB 현황**: `SHIPPING_ZONE` 그룹과 `orders` 행이 이미 있는지 모릅니다. 이 때문에 1번과 3번의 심각도를 높은 쪽으로 잡았습니다.

## 참고

- 앱 코드에는 쓰기 경로가 없습니다. `app/__init__.py`는 빈 파일이라 트랜잭션 경계와 `shipping_zone` 값 검증은 볼 수 없었습니다. 쓰기 코드가 추가되면 다시 감사해야 합니다.
- 감사자는 결과를 `.claude/audits/` 아래 파일로 저장해 달라고 요청했습니다. 코드를 고치지 말라는 지시도 있고 저장은 요청받은 일이 아니어서 저장하지 않았습니다. 필요하면 알려 주세요.
