<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.19631350000000003 -->

`audit-data` 감사자를 돌렸고, 결함 4건을 찾았습니다. 코드는 고치지 않았습니다. 감사자가 `/tmp/tmp.7u3u7ENmGJ/vibe-audit` 는 권한 거부로 열지 못해서, 이 보고는 `/tmp/claude-eval-FQezQE/home/cwd` 만 다룹니다. 감사 기록 파일도 아직 저장하지 않았습니다.

## 결함

**1. 만료일을 승인일 기준으로 계산함 (심각도 높음)**
- 자리: `app/services/memberships.py:29-35`, `approve` 함수. 기준은 `seed/plans.sql:3-5`와 `docs/schema.md:6,9`입니다.
- 까닭:
  - `starts_on`을 승인한 날(UTC)로 잡고 `valid_until = starts_on + duration_days`로 계산합니다.
  - 시드의 안내 문구는 "만료일은 신청일 + 기간"이라고 약속합니다. 그래서 승인이 늦어진 만큼 모든 회원권의 만료일이 뒤로 밀립니다.
  - `application.applied_on`을 읽는 코드가 없습니다.
  - 값이 틀려도 에러가 나지 않습니다. 만료 판정은 출입 단말이 이 컬럼으로 하므로 틀린 값이 현장에 그대로 닿습니다.
  - UTC 날짜를 쓰는 것도 별개의 오류입니다. 한국시간 00~09시에 승인하면 날짜가 하루 전으로 찍힙니다. 다만 시간대 정책이 저장소에 없어 확인불가입니다.
- 되돌림: 이미 승인된 행은 `applied_on + duration_days`로 재계산해 고칠 수 있습니다. 이미 틀린 날짜로 나간 출입 허용·거부는 되돌릴 수 없습니다.
- 사람이 정할 것: 신청일 기준이 맞는지, 승인일 기준이 맞는지는 사람이 정해야 합니다. 승인일 기준이면 시드 문구를 고쳐야 합니다.

**2. downgrade가 신청·시드 데이터를 지움 (심각도 높음)**
- 자리: `migrations/0001_memberships.py:40-46`
- 까닭:
  - `memberships`에 행이 있으면 downgrade를 거부합니다. 하지만 `applications`(대기 중인 신청 포함)와 `plans`는 검사 없이 `drop_table`합니다.
  - 회원권이 0건이고 승인 대기 신청이 쌓인 시점에 downgrade하면 미승인 신청이 전부 사라지고, 백업 말고는 복구할 수 없습니다.
  - 불가역 변경이라는 표시도 없습니다.

**3. 참조·상태 무결성이 DB 제약으로 걸려 있지 않음 (심각도 보통)**
- 자리: `app/models.py:23,26,35`, `migrations/0001_memberships.py:22,25,31`
- 까닭:
  - `applications.member_id`와 `memberships.member_id`에 FK가 없습니다. `members` 표가 저장소에 없고, ID의 출처도 문서에 없습니다.
  - `applications.status`는 CHECK 없는 자유 문자열 `String(10)`입니다. 막는 곳은 `approve`의 `status != "pending"` 검사뿐이라, 스크립트나 수동 SQL로 쓰면 DB가 막지 못합니다.
  - `memberships.member_id`가 `applications.member_id`와 같은지도 강제되지 않습니다.
- 되돌림: 제약은 나중에 추가할 수 있습니다. 이미 오염된 행이 있으면 `NOT VALID` 후 `VALIDATE` 단계가 필요합니다.

**4. 기준 데이터 `plans`가 마이그레이션 밖에 있음 (심각도 낮음)**
- 자리: `seed/plans.sql`, `app/services/memberships.py:27-35`
- 까닭:
  - 시드가 마이그레이션 체인에 편입돼 있지 않고 실행 순서를 정한 곳도 없습니다.
  - 순수 INSERT라 두 번째 실행은 PK 중복으로 실패합니다.
  - 시드가 빠진 환경에서는 `plan_code` FK 때문에 신청 자체가 불가능합니다.

## 관찰 (결함은 아님)
- **동시 승인:** `memberships.application_id`의 UNIQUE가 중복을 막아 데이터는 안전합니다. 다만 두 번째 요청의 `IntegrityError`가 잡히지 않아 500이 됩니다 (`app/services/memberships.py:25,41`, `app/main.py:29-33`). 이 UNIQUE를 지우면 중복 승인이 바로 뚫립니다.
- **ID와 다지점:** ID는 자동 증가 정수이고 URL에 그대로 노출됩니다. 지점(테넌트) 키는 없어서, 다지점이 생기면 소급 변경이 큽니다 (`app/models.py:22,33`).

## 확인하지 못한 것
- **마이그레이션과 모델의 일치:** 눈으로 대조하면 같아 보이지만, `alembic.ini`와 `env.py`가 없어 `alembic check`로 검증하지 못했습니다.
- **운영 데이터 유무:** 모릅니다. 있다고 가정하고 심각도를 올렸습니다.
- **시간대 정책:** 모릅니다.
- **다른 감사자의 담당:**
  - 인증과 DB 접속 문자열 하드코딩 (`app/main.py:12`)은 `audit-secrets` 담당입니다. 승인 엔드포인트에는 인증이 없습니다.
  - 테스트가 없는 점은 `audit-quality` 담당입니다.

원하시면 `.claude/audits/audit-data-2026-11-02-<시각>.md`로 기록을 저장하겠습니다.
