<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.17480880000000001 -->

`audit-contract` 감사자를 저장소 전체에 돌렸습니다. 코드는 고치지 않았습니다. 감사자는 파일을 읽기만 했고 실행해 보지는 않았습니다. 대상은 `app/main.py`, `app/schemas.py`, `app/models.py`, `migrations/0001_registrations.py`, `docs/api.md`, `requirements.txt`입니다. 공개 엔드포인트는 `POST /registrations` 하나입니다.

## 결함

**1. NUL 문자(`\x00`)가 검증을 통과해 500이 됩니다.**
- 자리: `app/schemas.py`의 `RegistrationIn`(22–25행)과 검증기 `_present`(11–15행), `app/main.py`의 `post_registration`(27–29행)
- 까닭:
  - `_BLANK`에 NUL이 없습니다.
  - `note`에는 검증기가 아예 없습니다.
  - 그래서 `event_code`, `attendee_name`, `organization`, `note`에 `"\u0000"`이 들어와도 pydantic을 통과합니다.
  - PostgreSQL `text`는 NUL을 저장하지 못하므로 `s.commit()`에서 DB 오류가 나는 것으로 판단합니다.
  - 이 오류를 422로 바꾸는 예외 처리가 없어서, 클라이언트는 문서에 없는 500을 받습니다.
  - 소비자가 5xx를 일시 장애로 보고 같은 요청을 반복해 보낼 수 있습니다.
- 확정도: 코드를 읽어서 판단했습니다. 실제 PostgreSQL에서 돌려 보지는 못했습니다.
- 심각도: 보통

**2. `docs/api.md`가 입력 칸과 제한을 적지 않았습니다.**
- 자리: `docs/api.md:5-10`
- 까닭:
  - 요청 본문의 칸 이름과 필수 여부가 없습니다.
  - 코드에만 있는 길이 상한(`event_code` ≤20, `attendee_name` ≤50, `organization` ≤100, `note` ≤500)이 없습니다.
  - 응답 `{registration_id: int}`의 모양이 없습니다.
  - 실제로 나오는 500(결함 1)이 에러 표에 없습니다.
  - 상한을 나중에 바꾸면 소비자가 모른 채 422를 받게 됩니다.
- 심각도: 낮음

**3. 버전 체계가 없습니다.**
- 자리: `app/main.py:13`, `app/main.py:25`
- 까닭: 경로가 `/registrations`이고 버전 접두사나 헤더 규약이 없으며, 문서에도 호환성 정책이 없습니다. 이후 파괴적 변경이 같은 경로에 그대로 얹힙니다. 지금 깨진 것은 없고 앞으로의 위험입니다.
- 심각도: 낮음

## 판정하지 못한 것
- **과거 대비 항목(필드 삭제·이름 변경·타입 변경, 조용히 깨는 변경):** 기준 커밋이나 diff가 없어서 판정하지 못했습니다. 비교 기준을 주시면 `vibe-audit:audit-brief`로 브리핑을 만들어 다시 돌릴 수 있습니다.
- **500 응답 본문에 SQL이나 스택이 섞이는지:** 테스트 DB에서 `note: "a\u0000b"`를 실제로 보내 봐야 알 수 있습니다.

## 부적합은 아니지만 알아 둘 것
- **눈에 안 보이는 문자:** `_BLANK`(`app/schemas.py:8`)에 U+200B(제로폭 공백) 같은 문자가 없습니다. 그런 문자만 있는 이름은 통과합니다. 문서는 "받을 수 없는 값"을 정의한 적이 없습니다.
- **자동 문서 경로:** 인증이 없고 `/docs`, `/openapi.json`이 열려 있습니다. 자동 생성 스펙이 `docs/api.md`와 어긋나면 소비자가 어느 쪽을 믿을지 알 수 없습니다. 권한 문제는 `audit-secrets` 담당입니다.

## 이번 범위에서 안 본 것
- `session()`이 commit 실패 시 rollback 없이 close만 하는 점은 `audit-data` 담당이라 판정하지 않았습니다.
- 테스트와 CI는 `audit-quality` 담당입니다. 저장소에 테스트가 보이지 않았습니다.
- `app/main.py:14`의 DB 접속 문자열은 `audit-secrets` 담당입니다.

감사자는 이 기록을 `.claude/audits/`에 파일로 저장해 달라고 했습니다. 코드를 고치지 말라는 요청이어서 파일은 만들지 않았습니다. 필요하시면 말씀해 주세요.
