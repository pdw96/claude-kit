<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.1484707 -->

`audit-secrets` 감사자가 결함 3건을 찾았습니다. 모두 인증·권한 쪽입니다. 감사자는 cwd의 `app/` 아래 `auth.py`, `admin.py`, `db.py`, `repo.py`, `models.py`와 `docs/schema.md`를 전부 읽었습니다. 코드는 고치지 않았습니다.

## 결함

**NC-1 · JWT 서명을 검증하지 않음 (높음)**
- 자리: `app/auth.py:13`, 함수 `current_user`
- 까닭: `jwt.decode(..., options={"verify_signature": False})`라서 서명, 키, 알고리즘, `exp`를 하나도 확인하지 않습니다.
  - 공격자가 `{"sub": "1"}` 같은 토큰을 직접 만들어 보내면 그 사용자로 인증됩니다.
  - `docs/schema.md:7`은 토큰 수명을 30일로 적었지만, 이를 강제하는 코드가 없습니다.
  - `sub` 클레임이 없으면 `KeyError`로 500이 납니다.

**NC-2 · 관리자 엔드포인트에 관리자 권한 검사가 없음 (높음)**
- 자리: `app/admin.py:12-17`, 함수 `ban`
- 까닭: `Depends(current_user)`는 로그인한 사용자라면 누구든 통과시킵니다.
  - `User` 모델(`app/models.py:9-14`)에 역할이나 관리자 필드가 없고, 검사 코드도 없습니다.
  - 일반 사용자가 `POST /admin/users/{id}/ban`으로 다른 사용자를 정지시킬 수 있습니다.
  - NC-1과 겹치면 로그인 없이도 가능합니다.

**NC-3 · 정지된 사용자가 계속 인증되고, 없는 대상에서 500이 남 (높음)**
- 자리: `app/auth.py:16-18`, `app/admin.py:14-15`
- 까닭: `current_user`가 `deleted_at`을 보지 않아, 정지된 사용자의 토큰이 계속 통과합니다. `docs/schema.md:4-5`는 정지된 사용자를 "없는 사용자"로 다루라고 합니다. `repo.py`의 두 함수는 `deleted_at`을 거르는데 인증 경로만 거르지 않습니다.
  - `ban`은 대상이 `None`이면 `AttributeError`로 500이 납니다.

## 확인하지 못한 것
- **`/tmp/tmp.7u3u7ENmGJ/vibe-audit`**: 읽기 권한이 거부되어 전혀 보지 못했습니다. 우회하지 않았습니다. 앱 진입점(`FastAPI()`), CORS, 세션 설정이 여기 있을 수 있어서, 그 부분은 판정하지 못했습니다.
- **환경 분리와 배포 상태**: `DATABASE_URL` 말고는 환경 설정이 없습니다. NC-1 코드가 운영에 나갔는지도 알 수 없습니다.
- **JWT 발급 측과 서명 키 관리**: 발급 코드가 cwd에 없습니다.

소스 안의 시크릿 리터럴(`app/db.py:6`은 환경변수에서 읽습니다)과 로그·에러 응답의 자격증명 노출은 cwd 범위에서 문제가 없었습니다.

감사 기록 파일(`.claude/audits/...`)은 감사자가 읽기 전용이라 저장하지 않았습니다. 남기려면 말씀해 주세요.
