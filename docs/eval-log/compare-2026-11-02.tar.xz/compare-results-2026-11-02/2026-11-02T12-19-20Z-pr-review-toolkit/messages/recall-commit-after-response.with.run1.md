<!-- pr-review-toolkit · 맞힘 · 떴는가 False · 비용 0.11505019999999999 -->

저장소 전체를 읽고 정적으로 검토했습니다. 파일은 11개뿐이고, 실행이나 테스트는 하지 않았습니다. 심각한 순서로 적습니다.

## 트랜잭션 경계

1. **직렬화 실패를 재시도하지 않습니다.**
   - 자리: `app/db.py:9`, `app/main.py` `session_scope`와 `post_loan`
   - 까닭: 원칙 3은 `SERIALIZABLE`로 동시 대출을 막습니다. 이 수준은 충돌한 쪽을 SQLSTATE 40001(`SerializationFailure`)로 중단시키고 호출자가 다시 시도하는 것을 전제로 합니다.
   - 지금은 재시도 루프도 오류 변환도 없습니다. 같은 책을 동시에 빌리면 둘 중 하나가 롤백된 뒤 500으로 올라갑니다.
   - 남은 권수가 충분한 정상 요청도 같은 책에 몰리면 실패할 수 있습니다.

2. **커밋이 응답 뒤에 일어나, 저장되지 않은 대출에 201을 줄 수 있습니다.**
   - 자리: `app/main.py` `session_scope`의 `yield` 뒤 `session.commit()`
   - 까닭: `requirements.txt`가 고정한 FastAPI 0.141.1에서는 `yield` 의존성의 종료 코드가 응답을 보낸 뒤에 실행됩니다. 이 동작은 버전별 문서로 확인하지 못했습니다.
   - 그렇다면 `SERIALIZABLE`에서 흔한 커밋 시점의 직렬화 실패나 제약 위반은 201을 이미 보낸 뒤에 터집니다. 클라이언트는 `loan_id`와 `due_on`을 받았는데 행은 없습니다.
   - 커밋은 엔드포인트나 서비스 안에서 응답 전에 하고, 오류를 HTTP 응답으로 바꿔야 합니다.

3. **제약 위반과 `IntegrityError`를 처리하지 않습니다.**
   - 자리: `app/services/loans.py` `lend`, `app/main.py` `post_loan`
   - 까닭: `RefusedLoan`만 잡습니다. `books_available_not_negative`, `loans_due_after_loan` 같은 DB 제약이나 `flush()` 오류는 그대로 500이 됩니다.
   - 예를 들어 `loan_days`가 음수로 들어간 책이면 `due_on >= loaned_on`을 어겨 500이 납니다.

## 동시성과 정합성

4. **재고를 읽고 계산해서 쓰는 방식이라 격리 수준 하나에 전부 기대고 있습니다.**
   - 자리: `lend`의 `book.available_copies <= 0` 검사와 `book.available_copies -= 1`
   - 까닭: 행 잠금(`with_for_update`)도 조건부 `UPDATE ... SET available_copies = available_copies - 1 WHERE available_copies > 0`도 없습니다.
   - ORM은 읽은 값에서 뺀 숫자를 UPDATE로 씁니다. 격리 수준이 낮아지는 경로가 하나라도 있으면 갱신이 사라집니다. 예를 들어 다른 엔진이나 세션, 스크립트, 향후 반납 코드가 기본 `READ COMMITTED`로 같은 표를 쓰는 경우입니다.
   - 안전장치가 `CHECK >= 0` 하나뿐이어서, 그 경우 500으로 끝납니다.

5. **`available_copies`가 파생값인데 이를 지켜 주는 장치가 없습니다.**
   - 자리: `app/models.py` `Book`, `Loan`, `docs/schema.md`
   - 까닭: 총 소장 수(`total_copies`)가 없고, `available_copies`와 `returned_on IS NULL`인 대출 수를 맞추는 제약이나 트리거도 없습니다.
   - 반납이나 보정 경로가 `+1`을 하면 소장 수를 넘을 수 있고, 상한을 검사할 방법도 없습니다.
   - 시간이 지나면 값이 어긋나는데 이를 대조할 방법도 없습니다.

6. **반납 경로와 되돌림 코드가 없습니다.**
   - 자리: `app/services/loans.py`, `app/main.py`
   - 까닭: 문서는 "반납하면 `returned_on`이 찬다"고 하지만 반납 코드가 없습니다. `returned_on`을 채우는 곳도 `available_copies`를 되돌리는 곳도 없습니다.
   - 반납을 추가할 때 원칙 1(둘이 함께 선다)을 같은 트랜잭션으로 묶어야 한다는 점이 코드로 강제되어 있지 않습니다.

7. **같은 회원이 같은 책을 중복으로 빌릴 수 있습니다.**
   - 자리: `app/models.py` `Loan`
   - 까닭: `(book_id, member_id) WHERE returned_on IS NULL`에 부분 유니크 인덱스가 없고 서비스에도 검사가 없습니다. 같은 요청을 재전송하면 재고가 두 번 줄고 대출 행이 둘 생깁니다.
   - 멱등성 키도 없습니다.

8. **대출일을 클라이언트가 정합니다.**
   - 자리: `app/schemas.py` `LoanIn.loaned_on`, `lend`의 `due_on` 계산
   - 까닭: 과거나 먼 미래 날짜로 반납 기한을 마음대로 만들 수 있습니다. 서버 시각을 기준으로 하거나 범위를 검증해야 합니다.

## 모델과 스키마

9. **외래키 열에 인덱스가 없습니다.**
   - 자리: `app/models.py`와 `migrations/0001_initial.py`의 `loans.book_id`, `loans.member_id`
   - 까닭: PostgreSQL은 FK에 인덱스를 자동으로 만들지 않습니다. 회원별·도서별 대출 조회와 부모 행 삭제 검사가 전체 스캔이 됩니다.
   - 미반납 대출을 찾는 `returned_on` 부분 인덱스도 없습니다.

10. **값 범위 제약이 부족합니다.**
    - 자리: `Book.loan_days`, `Book.isbn`
    - 까닭: `loan_days > 0` 검사가 없어 0 이하가 들어갈 수 있습니다. ISBN 길이나 정규화(하이픈)도 검사하지 않습니다. `LoanIn`은 10~13자만 확인해서, 하이픈이 든 입력은 저장된 ISBN과 어긋납니다.

11. **제약과 유니크에 이름 규약이 없습니다.**
    - 자리: `app/models.py` `Base`, `migrations/0001_initial.py`
    - 까닭: `Base.metadata`에 `naming_convention`이 없어 유니크와 FK 제약 이름이 DB 기본값에 맡겨집니다. 이후 마이그레이션에서 `drop_constraint`를 쓰기 어렵고, 모델과 마이그레이션이 어긋나는지 비교(autogenerate)도 불안정해집니다. 반면 CHECK에는 이름이 있어 규약이 일관되지 않습니다.

## 마이그레이션

12. **Alembic 환경이 저장소에 없습니다.**
    - 자리: `migrations/`
    - 까닭: `env.py`, `script.py.mako`, `alembic.ini`가 없어 `alembic upgrade`를 실행할 수 없습니다. 마이그레이션은 `0001_initial.py` 하나뿐이고, `branch_labels`·`depends_on`도 정의되어 있지 않습니다.
    - `Base.metadata`가 `target_metadata`로 연결되는 곳도 없어 모델과 스키마의 일치를 확인할 수단이 없습니다.

13. **`downgrade`가 `loans`만 확인하고 `members`·`books`는 조용히 지웁니다.**
    - 자리: `migrations/0001_initial.py` `downgrade`
    - 까닭: 주석은 "지우면 되살릴 길이 없다"는 이유로 대출 기록만 지킵니다. 하지만 대출이 없어도 회원과 도서 마스터 데이터는 사라지고, 이 둘은 확인하지 않습니다.
    - 존재 확인(`SELECT EXISTS`)과 `drop_table` 사이에 잠금이 없어, 그 사이에 들어온 대출도 함께 지워질 수 있습니다. 확인 전에 `loans`를 잠가야 합니다.

14. **마이그레이션과 모델이 두 곳에 손으로 중복 정의되어 있습니다.**
    - 자리: `app/models.py`와 `migrations/0001_initial.py`
    - 까닭: 지금은 일치합니다. 하지만 이를 대조하는 테스트나 autogenerate 검사가 없고(12번), 한쪽만 고치면 어긋납니다.

## 요약

가장 위험한 것은 1번과 2번입니다. "하나만 선다"는 원칙이 실제로는 한 요청의 500 응답이나 저장되지 않은 201 응답으로 이어집니다. 다음으로 5~7번이 데이터 정합성에 영향을 줍니다.

코드는 수정하지 않았습니다.
