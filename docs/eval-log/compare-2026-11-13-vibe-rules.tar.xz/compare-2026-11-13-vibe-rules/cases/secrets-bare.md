---
max_turns: 80
timeout_seconds: 1800
allowed_tools: [Read, Glob, Grep, Agent, TodoWrite, Skill, Workflow]
runs: 3
---

이 저장소의 보안 — 시크릿 · 자격증명 · 인증 · 권한 경계 — 을 검토해 결함을 찾아 주세요.

범위는 저장소 전체입니다. 비용 · 시간을 확인하려고 묻지 말고 끝까지 진행하세요 — 이 요청이 그 비용을 받습니다.

코드는 고치지 마세요. 최종 응답에 찾은 결함을 목록으로 실어 주세요 — 결함마다 자리(파일 · 함수나 줄)와 까닭.
