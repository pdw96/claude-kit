<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0905393 -->

데이터 쪽에서 결함 7건을 찾았습니다. 코드는 고치지 않았고, 아무 코드도 실행하지 않았습니다. 파일을 읽고 판단한 결과입니다. 5번과 6번은 저장소에 없는 파일(`alembic.ini`·`env.py`) 때문에 생기는 것이라 확신이 낮습니다.

**1. 만료일 기준일이 안내 문구와 다름 (가장 큰 결함)**
- 자리: `app/services/memberships.py` `approve()`의 `approved_at`, `starts_on`, `valid_until` 계산. 대조 대상은 `seed/plans.sql`의 description과 `docs/schema.md`입니다.
- 까닭: 화면에 나가는 안내 문구는 "신청일로부터 N일, 만료일은 신청일 + 기간"입니다. 그런데 코드는 `starts_on`을 승인 시각의 날짜로 잡습니다. `docs/schema.md`에 따르면 승인은 신청 다음 날이나 그 뒤에 몰아서 하고, 주말 신청은 월요일에 승인됩니다. 그래서 회원이 안내받은 것보다 며칠 일찍 출입이 막힙니다. `Application.applied_on`은 읽지 않습니다.

**2. 날짜를 UTC 기준으로 계산**
- 자리: `app/services/memberships.py`의 `datetime.now(timezone.utc).date()`.
- 까닭: 창구는 현지 날짜로 움직이는데 `starts_on`은 UTC 날짜입니다. 한국 시간이면 오전 9시 이전 승인은 전날 날짜로 기록됩니다. 만료 하루 오차가 생길 수 있고, 출입 단말이 어느 시간대로 `valid_until`을 비교하는지도 정해져 있지 않습니다.

**3. 같은 신청을 동시에 승인하면 500 오류**
- 자리: `app/services/memberships.py` `approve()`의 `session.get`과 `status` 확인, `app/main.py` `post_approval`의 `s.commit()`.
- 까닭: 신청 행에 잠금(`FOR UPDATE`)이나 버전 확인이 없어 확인과 갱신이 원자적이지 않습니다. 두 요청이 동시에 `pending`을 읽으면 둘 다 통과합니다. 두 번째는 `memberships.application_id` 유니크 제약 위반(`IntegrityError`)으로 실패합니다. 이 예외는 `RefusedApproval` 처리 구간 밖의 `commit()`에서 터지므로 422가 아니라 500이 나가고, 롤백 처리도 명시되어 있지 않습니다. 데이터는 유니크 제약이 지켜 주지만 경계 설계가 부실합니다.

**4. 상태값과 기간에 DB 제약이 없음**
- 자리: `app/models.py`와 `migrations/0001_memberships.py`의 `applications.status`, `plans.duration_days`, `plans.price`.
- 까닭: `status`는 자유 문자열(`String(10)`)이라 `"pending"`·`"approved"` 외의 값도 들어갑니다. `duration_days > 0`, `price >= 0` 같은 CHECK도 없습니다. `memberships_period` 제약이 있지만, 기간이 0 이하인 plan이 들어오면 승인 때 제약 위반으로 터집니다. 그 오류는 3번과 같은 경로로 500이 됩니다.

**5. 기준 데이터(plans)를 심는 경로가 마이그레이션에 없음**
- 자리: `seed/plans.sql`, `migrations/0001_memberships.py`.
- 까닭: `plans`는 기준 데이터인데 마이그레이션이 비어 있는 표만 만듭니다. 시드는 별도 SQL이라 실행 순서나 적용 여부를 보장하는 곳이 없습니다. 시드에 `ON CONFLICT`도 없어서 두 번 실행하면 PK 충돌로 실패합니다. 값이 바뀌면 적용할 경로가 없고, plan이 비어 있는 환경에서는 신청 등록 자체가 FK에서 막힙니다.

**6. 마이그레이션을 돌릴 설정이 저장소에 없음**
- 자리: 저장소 루트(`alembic.ini`, `env.py` 부재).
- 까닭: `alembic`이 requirements에 있지만 설정 파일이 없어 `migrations/`를 실제로 실행할 수 없습니다. `models.py`의 `Base.metadata`와 마이그레이션을 맞추는 연결도 없어 스키마가 어긋나도 알아챌 수 없습니다. 스키마 정의가 모델과 마이그레이션 두 곳에 중복되어 있다는 점도 같은 문제입니다.

**7. 되돌림(`downgrade`)이 일부만 보호함**
- 자리: `migrations/0001_memberships.py` `downgrade()`.
- 까닭: `memberships`가 비어 있는지만 확인합니다. 그 뒤 `applications`와 `plans`를 그대로 지우므로, 승인 전 신청(`pending`)이 있어도 조용히 삭제됩니다. 보호 기준이 일관되지 않습니다.

**8. 승인자 기록을 요청 본문 값으로 받음**
- 자리: `app/main.py` `ApprovalIn.approved_by`, `memberships.approved_by`.
- 까닭: 인증 없이 요청자가 보낸 문자열을 승인자로 저장합니다. 누구나 다른 직원 이름으로 승인할 수 있어 감사 기록으로 쓸 수 없습니다. 데이터 정합성보다는 감사 기록의 신뢰 문제입니다.

**제외한 것**
- `app/main.py`의 DB 접속 문자열(`gym@localhost`)은 비밀번호가 없는 로컬 개발용 값입니다. 스킬의 자리표시자 기준에 따라 결함으로 올리지 않았습니다.
