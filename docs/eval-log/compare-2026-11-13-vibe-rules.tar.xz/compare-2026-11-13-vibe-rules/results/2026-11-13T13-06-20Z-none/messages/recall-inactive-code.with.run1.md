<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.1052964 -->

데이터 쪽에서 찾은 결함입니다. 코드는 고치지 않았고, 파일을 읽고 판단만 했습니다. 실행이나 테스트는 하지 않았습니다.

저장소 파일은 `seed/codes.sql`, `requirements.txt`, `app/main.py`, `app/services/refunds.py`, `app/models.py`, `migrations/0001_refunds.py`, `docs/schema.md`입니다. `main.py`의 `postgresql+psycopg://shop@localhost/shop`은 로컬 개발용 값이라 결함으로 세지 않았습니다. 밖의 자원에 붙거나 프로덕션 경로와 공유된다는 근거가 없습니다.

## 결함

1. **비활성 코드로도 환불이 세워집니다.**
   - 자리: `app/services/refunds.py`의 `_must_be_a_code`(22–24행), `app/models.py`의 `CommonCode` 독스트링(12–13행)
   - 까닭: 이 함수는 코드가 있는지만 보고 `is_active`는 보지 않습니다. 시드에서 꺼 둔 `POINT`와 `PROMO`도 통과합니다. 독스트링은 "새 기록에서는 못 고른다"고 약속하는데, 서비스도 DB도 그 약속을 지키지 않습니다. FK는 존재만 보장하고 활성 여부는 보장하지 않습니다.

2. **"되돌리는 환불"이라는 원칙을 표현할 수 없습니다.**
   - 자리: `docs/schema.md` 원칙 1(11행), `migrations/0001_refunds.py`와 `app/models.py`의 `refunds_amount_positive`(`amount > 0`), `app/main.py`의 `RefundIn.amount`(`gt=0`)
   - 까닭: 문서는 환불을 고치지 않고 되돌리는 환불을 새로 세우라고 합니다. 하지만 `refunds`에는 음수 금액이나 취소 표시, 원 환불을 가리키는 칸이 없고, `amount > 0` 제약이 음수 행을 막습니다. `orders.refunded`를 줄이는 경로도 없습니다. 되돌림이 필요해지면 UPDATE나 DELETE로 갈 수밖에 없습니다.

3. **"지우지 않는다"는 규칙이 DB에서 강제되지 않습니다.**
   - 자리: `app/models.py`의 `Refund`, `CommonCode`, `migrations/0001_refunds.py`
   - 까닭: `refunds`의 UPDATE나 DELETE를 막는 트리거나 권한 제한이 없습니다. `common_codes`도 어떤 환불도 참조하지 않는 코드는 그냥 지울 수 있습니다. FK의 삭제 동작도 기본값(NO ACTION)이고, 명시적인 RESTRICT는 없습니다. 규칙이 문서와 독스트링에만 있습니다.

4. **`downgrade`가 주문과 공통코드를 무조건 지웁니다.**
   - 자리: `migrations/0001_refunds.py`의 `downgrade`(41–47행)
   - 까닭: 환불 기록이 있는지만 확인하고 `orders`와 `common_codes`를 `drop_table`합니다. 환불이 없어도 주문 데이터가 통째로 사라집니다. 검사와 삭제 사이에 잠금이 없어서, 그 사이에 들어온 환불 행도 막지 못합니다.

5. **금액 불변식이 앱 코드에만 있습니다.**
   - 자리: `app/models.py`의 `Order`(`refunded`, `amount`), `migrations/0001_refunds.py`의 `orders` 표
   - 까닭: `refunded >= 0`, `refunded <= amount`, `amount > 0`에 대한 CHECK가 없습니다. 보호는 `refund()`의 `with_for_update`와 33행 검사뿐입니다. 이 경로를 거치지 않는 쓰기(운영 SQL, 다른 서비스)에는 방어가 없습니다.
   - 또 `orders.refunded`는 `refunds` 합계의 사본인데, 두 값이 일치하는지 확인하거나 맞추는 장치가 없습니다.

6. **`refunds`에 생성 시각과 행위자 칸이 없습니다.**
   - 자리: `app/models.py`의 `Refund`, `migrations/0001_refunds.py`
   - 까닭: 원칙 1은 일어난 일을 남기라고 하는데, 언제 누가 한 환불인지 알 수 없습니다. 되돌림과 감사 추적의 전제가 빠져 있습니다.

7. **`refunds.order_id`에 인덱스가 없습니다.**
   - 자리: `migrations/0001_refunds.py`의 `refunds` 표
   - 까닭: 주문별 환불 조회나 합계 대조가 전체 스캔이 됩니다. PostgreSQL은 FK 칸에 인덱스를 자동으로 만들지 않습니다.

8. **시드 SQL을 다시 돌리면 실패하고, 마이그레이션과 연결도 없습니다.**
   - 자리: `seed/codes.sql`(1–8행), `migrations/0001_refunds.py`
   - 까닭: 시드가 `ON CONFLICT` 없는 plain INSERT라, 이미 시드된 DB에 다시 돌리면 PK 충돌로 실패합니다. 반대로 시드는 마이그레이션에 속하지 않아서, 시드 없이 배포하면 모든 환불이 "그런 코드가 없다"로 거부됩니다.
   - 또 `is_active` 값을 바꾸는 이력도 추적되지 않습니다.

9. **마이그레이션을 실행할 환경 파일이 없습니다.**
   - 자리: 저장소 루트
   - 까닭: `alembic.ini`와 `env.py`가 없어서, `requirements.txt`에 alembic이 있어도 `0001`을 실행할 수 없습니다. 모델과 마이그레이션이 어긋나는지 잡아 줄 autogenerate 검증 경로도 없습니다.

10. **트랜잭션 경계가 라우트 핸들러에 흩어져 있습니다.**
    - 자리: `app/main.py`의 `post_refund`(35행), `session` 의존성
    - 까닭:
      - `s.commit()`이 핸들러 안에 있어서 커밋 실패(직렬화나 FK 오류 등)가 처리되지 않고 500으로 샙니다.
      - 거부 경로의 롤백은 `close()`에 암묵적으로 맡겨져 있습니다. 동작은 하지만 경계가 명시적이지 않습니다.
      - 환불 서비스는 호출자가 커밋해야 한다는 규약이 `refund()` 쪽에 적혀 있지 않아서, 다른 호출자가 커밋을 빠뜨릴 수 있습니다.
    - 심각도는 낮습니다.

## 확인이 덜 된 부분
- 동시성 보호(`with_for_update`)가 실제 PostgreSQL에서 맞게 동작하는지는 돌려 보지 않았습니다. 코드 읽기만으로는 `orders` 행 잠금이 올바르게 보입니다.
- `FastAPI==0.141.1` 같은 의존성 버전이 실제로 존재하는지는 확인하지 않았습니다.
