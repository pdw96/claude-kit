<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.10877769999999999 -->

**데이터 쪽 결함 검토 결과** (코드는 고치지 않았고, 저장소 전체 7개 파일을 읽었습니다. `docs/schema.md`에 적힌 원칙 2개를 기준으로 삼았습니다.)

## 확실한 결함

1. **비활성 코드로 새 환불이 만들어집니다.**
   - 자리: `app/services/refunds.py`의 `_must_be_a_code`, 22~24행
   - 까닭: 코드가 있는지만 보고 `is_active`는 보지 않습니다.
   - `seed/codes.sql`에서 `POINT`와 `PROMO`는 `FALSE`인데도 `POST /orders/{id}/refunds`로 고를 수 있습니다.
   - 이는 `app/models.py` `CommonCode`의 독스트링(새 기록에서는 못 고른다)과 어긋납니다.
   - DB의 복합 외래키도 활성 여부는 막지 못하므로, 이 검사가 유일한 방어선입니다.

2. **`downgrade()`가 환불 기록 외의 데이터를 검사 없이 지웁니다.**
   - 자리: `migrations/0001_refunds.py` `downgrade`, 41~47행
   - 까닭: `refunds`가 비어 있는지만 확인한 뒤 `orders`와 `common_codes`를 통째로 drop합니다.
   - 환불이 없어도 주문 데이터와 공통코드(시드 포함)는 사라집니다. `orders`는 이 마이그레이션이 만든 표이긴 하지만, 실제 주문이 들어 있을 수 있습니다.
   - 검사와 drop이 한 트랜잭션 안의 별개 단계라, 그 사이에 들어오는 환불도 막지 못합니다. 이 점은 덜 심각합니다.

3. **"되돌리는 환불을 새로 세운다"는 원칙을 구현한 곳이 없습니다.**
   - 자리: `docs/schema.md` 원칙 1 ↔ `app/models.py` `Refund`, `app/services/refunds.py` `refund`
   - 까닭: 되돌림(역환불)을 나타낼 열이 없습니다. 원환불을 가리키는 열도, 부호나 종류 열도 없습니다.
   - `amount > 0` 체크(`refunds_amount_positive`)와 서비스 검사가 음수를 막기 때문에, 되돌림 기록을 만들 방법이 없습니다.
   - `order.refunded`를 줄이는 경로도 없습니다.
   - 환불을 고치지 못하게 막는 장치(트리거나 권한)도 없습니다. `refund_id`로 `UPDATE`와 `DELETE`를 하면 그대로 됩니다.

4. **`orders.refunded`는 중복 저장 값인데 DB가 정합성을 지키지 않습니다.**
   - 자리: `app/models.py` `Order`, `migrations/0001_refunds.py`의 `orders` 표
   - 까닭: `refunded = SUM(refunds.amount)`라는 관계도, `0 <= refunded <= amount` 체크도 DB에 없습니다.
   - 앱 코드(`refunds.py` 33행)만 상한을 지킵니다. 다른 경로로 쓰거나 수동 수정하면 어긋납니다.
   - `Refund` 쪽만 고쳐도 `refunded`가 따라 바뀌지 않아 정합성이 깨집니다.

5. **금액 범위가 정수 32비트와 맞지 않아 500 오류가 납니다.**
   - 자리: `app/main.py` `RefundIn.amount`(`Field(gt=0)`만 있음), `models.py`의 `sa.Integer`
   - 까닭: 상한이 없는 입력이 `orders.amount` 같은 Integer 열(PostgreSQL int4)을 만납니다.
   - 값이 21억을 넘으면 `DataError`가 납니다. 주문 금액을 넘는 환불은 33행에서 먼저 걸리지만, 이 경로는 DB 오류가 그대로 500으로 나가는 구조적 취약점입니다.
   - 금액을 정수 원 단위로 쓰는 것이 의도라면 열 타입과 입력 상한을 맞춰야 합니다.

## 트랜잭션 경계 · 재시도 쪽

6. **재시도에 중복 방어가 없습니다.**
   - 자리: `app/main.py` `post_refund`, 29~36행
   - 까닭: 멱등 키나 유일 제약이 없습니다.
   - 응답을 못 받은 클라이언트가 같은 요청을 다시 보내면 환불이 중복으로 세워집니다. 총액 상한 안이면 그대로 통과합니다.

7. **커밋 실패가 처리되지 않습니다.**
   - 자리: `app/main.py` 35행 `s.commit()`
   - 까닭: `try` 바깥이라 `IntegrityError`나 직렬화 오류가 잡히지 않아 500으로 나갑니다.
   - 롤백은 `s.close()`가 암묵적으로 해 주기만 합니다. 명시적 트랜잭션 경계가 없고, 커밋과 롤백의 책임이 서비스 함수가 아니라 엔드포인트에 있습니다.

## 마이그레이션 · 모델 관리

8. **마이그레이션을 실행할 수 없는 상태입니다.**
   - 자리: 저장소 루트와 `migrations/`
   - 까닭: `alembic.ini`와 `env.py`가 없고 `script.py.mako`도 없습니다. `requirements.txt`에만 alembic이 있습니다.
   - 이 파일들은 저장소에 없는 것이고 다른 곳에 있는지는 확인하지 못했습니다. 모델과 마이그레이션의 일치를 확인할 자동 검사(autogenerate diff)도 없어서, 두 곳(`models.py`와 `0001`)에 같은 정의가 복제되어 있습니다.

9. **시드가 마이그레이션 체계 밖에 있고 다시 실행할 수 없습니다.**
   - 자리: `seed/codes.sql`
   - 까닭: `ON CONFLICT`가 없는 단순 `INSERT`라, 두 번째 실행에서 PK 충돌로 실패합니다.
   - 어느 마이그레이션도 이 파일을 적용하지 않습니다. 시드 없이 앱을 띄우면 모든 환불이 "그런 코드가 없다"로 거절됩니다.

10. **공통코드 삭제 금지가 문서와 독스트링에만 있습니다.**
    - 자리: `app/models.py` `CommonCode`, `docs/schema.md` 원칙 2
    - 까닭: DB에서는 `refunds`가 참조하는 코드만 외래키가 보호합니다. 아직 쓰이지 않은 코드는 `DELETE`로 지워지고, 나중에 같은 코드를 다시 만들면 뜻이 달라질 수 있습니다.
    - 막으려면 트리거나 권한 회수가 필요합니다.

## 작은 점

11. **`refunds`에 시각 열이 없고 `order_id` 인덱스도 없습니다.**
    - 자리: `Refund` 모델, `migrations/0001_refunds.py`
    - 까닭: "일어난 일"의 기록인데 `created_at`이 없어서 환불이 언제 일어났는지 알 수 없습니다.
    - `order_id` 외래키에 인덱스가 없어, 주문별 환불 조회는 전체를 훑습니다.

**참고로 결함에서 뺀 것:** `app/main.py`의 DB 접속 문자열(`postgresql+psycopg://shop@localhost/shop`)은 비밀번호가 없는 로컬 개발용 값입니다. 환경별 설정으로 빼지 않은 점은 데이터 결함이 아니라서 목록에 넣지 않았습니다.
