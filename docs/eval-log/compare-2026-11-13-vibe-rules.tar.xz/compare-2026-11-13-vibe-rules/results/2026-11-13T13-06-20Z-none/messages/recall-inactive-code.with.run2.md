<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.09635350000000001 -->

데이터 쪽에서 결함 6건을 찾았습니다. 코드는 고치지 않았고, 실행하지 않고 읽어서만 검토했습니다.

## 결함

1. **비활성 코드로 새 환불을 만들 수 있습니다.**
   - 자리: `app/services/refunds.py`의 `_must_be_a_code`, `refund`. 여기에 `app/models.py`의 `CommonCode` 독스트링과 `seed/codes.sql`이 관련됩니다.
   - 까닭: `_must_be_a_code`는 코드가 있는지만 `session.get`으로 봅니다. `is_active`는 확인하지 않습니다.
   - 독스트링은 비활성 코드가 "새 기록에서는 못 고르고"라고 규정합니다. 그런데 시드에서 꺼 둔 `POINT`와 `PROMO`로 `POST /orders/{id}/refunds`를 호출하면 환불이 만들어집니다.
   - `refunds`의 FK도 `is_active`를 보지 않으므로 DB가 막아 주지도 않습니다.

2. **"되돌리는 환불을 새로 세운다"는 원칙을 구현할 수 없습니다.**
   - 자리: `docs/schema.md` 원칙 1, `app/models.py`의 `Refund`, `migrations/0001_refunds.py`의 `refunds_amount_positive`, `app/services/refunds.py`의 `refund`.
   - 까닭: 원칙은 환불을 고치지 않고 되돌리는 환불을 새로 세우라고 합니다. 그런데 `amount > 0` CHECK 제약과 서비스의 `amount <= 0` 거절이 음수나 반대 방향 기록을 막습니다.
   - 되돌림 종류나 원 환불을 가리키는 칸도 없습니다.
   - `orders.refunded`를 줄이는 경로도 없습니다. 취소된 환불은 한도(`order.amount`)를 계속 차지합니다.
   - 환불 시각 칸도 없어서 일어난 일의 이력이 남지 않습니다.

3. **`orders.refunded`는 `refunds`와 따로 갱신되는 중복 집계인데, DB가 그 값을 지키지 않습니다.**
   - 자리: `migrations/0001_refunds.py`의 `orders` 표, `app/models.py`의 `Order`.
   - 까닭: `refunded >= 0`과 `refunded <= amount` CHECK가 없습니다. `refunded`가 `SUM(refunds.amount)`와 같다는 보장도 없습니다.
   - 한도 검사는 `refund()`가 행 잠금을 잡은 채로 하는 앱 코드에만 있습니다. 직접 SQL이나 다른 경로로 쓰면 초과 환불이 들어가고, 집계와 기록이 어긋납니다.

4. **`downgrade`가 `refunds`만 확인하고 `orders`와 `common_codes`는 데이터가 있어도 지웁니다.**
   - 자리: `migrations/0001_refunds.py`의 `downgrade`.
   - 까닭: 환불 기록이 없으면 `orders`를 그대로 `drop_table`합니다. 환불이 없는 주문 데이터가 사라집니다.
   - 공통코드도 삭제 금지 원칙(`docs/schema.md` 원칙 2)에 어긋나게 통째로 지워집니다.
   - 또 `SELECT EXISTS` 확인과 `drop_table` 사이에 잠금이 없습니다. 그 틈에 환불이 들어오면 확인이 무의미해집니다.

5. **`seed/codes.sql`을 다시 실행할 수 없고, 마이그레이션 흐름에도 들어 있지 않습니다.**
   - 자리: `seed/codes.sql`.
   - 까닭: 평문 `INSERT`에 `ON CONFLICT`가 없습니다. 두 번째 실행은 PK 충돌로 실패합니다.
   - 시드가 마이그레이션 밖에 있어서, 마이그레이션만 돌린 환경에는 코드가 하나도 없습니다. 그러면 모든 환불이 "그런 코드가 없다"로 거절됩니다.
   - 시드를 다시 적용해 `is_active`나 이름을 바꿀 수단도 없습니다.

6. **마이그레이션을 실행할 환경이 저장소에 없습니다.**
   - 자리: 저장소 루트와 `migrations/`.
   - 까닭: `alembic.ini`와 `env.py`가 없습니다. `alembic==1.14.0`이 `requirements.txt`에 있고 `0001_refunds.py`만 있으므로, `alembic upgrade`로는 실행되지 않습니다.
   - `app/models.py`의 `Base.metadata`와 마이그레이션이 일치하는지 확인하는 자동 확인(autogenerate 비교)도 설정되어 있지 않습니다.

## 덧붙임

- `refunds.order_id`에는 인덱스가 없습니다. 주문별 환불 조회가 느려질 수 있습니다. 결함이라기보다 개선 사항입니다.
- 코드 검사(`_must_be_a_code`)는 `Order` 행 잠금 뒤에 하지만 코드 행은 잠그지 않습니다. 그 사이 비활성화되는 경합은 결함 1이 해결되어야 의미가 생깁니다.
- `app/main.py`의 DB URL은 비밀번호 없는 로컬 개발 값이라 결함으로 보지 않았습니다. 같은 값이 프로덕션 경로에 쓰이는지는 저장소에서 확인할 수 없습니다.
- `.claude` 폴더는 비어 있었습니다. 저장소에 별도의 의도 문서(`INTENT.md`, `PRD.md`)도 없어서, 기준은 `docs/schema.md`와 `CommonCode` 독스트링으로 삼았습니다.
