<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.1021186 -->

데이터 쪽에서 찾은 결함은 아래와 같습니다. 코드는 고치지 않았고 실행도 하지 않았습니다. 판단은 코드와 문서를 읽은 것만으로 했습니다. 저장소에 `INTENT.md`나 `PRD.md`는 없어서, `docs/schema.md`를 유일한 기준 문서로 삼았습니다.

## 결함

1. **만료일 시작점이 `applied_on`이 아니라 승인 시각이다**
   - 자리: `app/services/memberships.py`의 `approve`, 29~35줄. `seed/plans.sql`의 설명 문구와 `docs/schema.md` 9줄도 관련됩니다.
   - 까닭: 시드 설명은 "신청일로부터 N일, 만료일은 신청일 + 기간"이라고 안내합니다. 코드는 `application.applied_on`을 쓰지 않고 `datetime.now(utc).date()`를 `starts_on`으로 삼습니다.
   - `docs/schema.md`는 승인이 신청 다음 날이나 그 뒤에 몰아서 이뤄진다고 적습니다. 금요일에 신청하면 월요일 승인이 되어 회원권이 며칠 늦게 시작하고 끝납니다. 화면 안내와 실제 만료일이 어긋나고, 출입 단말은 `valid_until`로 막으므로 그 차이가 그대로 드러납니다.

2. **`starts_on` 날짜가 UTC 기준이다**
   - 자리: `app/services/memberships.py:29-30`.
   - 까닭: `approved_at.date()`는 UTC 날짜입니다. 한국 시간 오전 9시 전에 승인하면 `starts_on`이 한국 날짜보다 하루 앞서고 `valid_until`도 하루 빨라집니다.
   - 영업일이나 창구 날짜(`applied_on`)와 기준이 달라 하루씩 어긋납니다.

3. **동시 승인 경합에서 500 오류가 난다**
   - 자리: `app/services/memberships.py:22-26`, 39~41줄, 그리고 `app/main.py:29-33`.
   - 까닭: 신청을 `session.get`으로 읽고 `status`를 확인하는데 행 잠금(`with_for_update`)이 없습니다. 두 요청이 동시에 `pending`을 보면 둘 다 통과합니다.
   - 이때 `memberships.application_id`의 UNIQUE 제약이 중복 삽입을 막긴 합니다. 하지만 `flush`에서 나는 `IntegrityError`를 `RefusedApproval`로 바꾸지 않아서, 뒤에 온 요청은 422가 아니라 500을 받습니다.
   - 상태 전이도 조건부 UPDATE(`WHERE status='pending'`)가 아니라서, 잠금이 없으면 먼저 쓴 쪽이 이깁니다.

4. **`session.get(Plan, ...)`이 `None`일 때를 처리하지 않는다**
   - 자리: `app/services/memberships.py:27`, 35줄.
   - 까닭: FK가 있어 평소엔 문제가 없습니다. 하지만 `plan`이 `None`이면 `plan.duration_days`에서 `AttributeError`로 500이 납니다.
   - 시드나 마이그레이션으로 plans를 지우거나 바꾸는 경로가 생기면 드러납니다.

5. **`status` 값에 DB 제약이 없다**
   - 자리: `app/models.py:26`, `migrations/0001_memberships.py:25`.
   - 까닭: `String(10)`에 기본값 `pending`만 있고 CHECK나 ENUM이 없습니다. 코드는 `pending`/`approved` 문자열 비교에 의존하므로, 오타나 직접 SQL로 들어간 값을 DB가 막지 못합니다.
   - 상태가 `approved`인데 회원권이 없거나, 그 반대인 불일치도 DB 수준에서 막지 못합니다.

6. **관계 제약과 값 제약이 부족하다**
   - 자리: `app/models.py:23, 34`, `migrations/0001_memberships.py:22, 31`.
   - 까닭:
     - `member_id`는 정수일 뿐 `members` 표나 FK가 없습니다. 존재하지 않는 회원의 신청과 회원권이 생길 수 있습니다.
     - `plans.duration_days`와 `price`에 `> 0` CHECK가 없습니다. 0 이하 기간이면 `valid_until > starts_on` CHECK에 걸려 승인이 `IntegrityError`(500)로 실패합니다.
     - 같은 회원의 회원권 기간이 겹치는 것을 막는 제약이 없습니다. 신청을 중복으로 내면 기간이 겹치는 회원권이 여러 개 생깁니다.

7. **트랜잭션 경계가 라우트 계층에 걸쳐 있고 예외 시 롤백이 명시되지 않았다**
   - 자리: `app/main.py:15-20, 33`.
   - 까닭: `commit`은 라우트에서 하고 서비스는 `flush`만 합니다. 예외가 나면 `session.close()`가 롤백을 대신할 뿐 명시적 `rollback`은 없습니다.
   - `approve`의 `flush` 예외(`IntegrityError` 등)는 그대로 전파됩니다. 경계가 두 곳에 나뉘어 있어 승인 외 작업이 추가되면 부분 커밋이나 누락이 생기기 쉽습니다.

8. **마이그레이션 `downgrade`가 되돌림으로 불완전하다**
   - 자리: `migrations/0001_memberships.py:40-46`.
   - 까닭: `memberships` 행이 있으면 `RuntimeError`로 막습니다. 데이터 보호로는 맞지만, 그 경우 어떤 단계도 되돌릴 수 없고 `applications`나 `plans`의 데이터는 따로 확인하지 않습니다.
   - 사전 확인과 삭제 사이에 새 승인이 끼어들 수 있고, 잠금도 없습니다.
   - 시드 데이터(`plans`)는 마이그레이션 밖에 있습니다. `seed/plans.sql`에는 `ON CONFLICT`가 없어서 재실행하면 PK 충돌로 실패합니다. 멱등성이 없습니다.

9. **마이그레이션과 모델이 이중 정의라 어긋날 수 있다**
   - 자리: `app/models.py`, `migrations/0001_memberships.py`.
   - 까닭: 같은 스키마를 손으로 두 번 적었고, 어긋났는지 확인하는 장치(autogenerate 비교 테스트 등)가 없습니다.
   - `alembic.ini`와 `env.py`가 저장소에 없어서 이 마이그레이션을 실제로 실행할 수 있는지도 확인되지 않습니다. `down_revision`과 `revision` 문자열만 있습니다.
   - `Base.metadata`에 `naming_convention`이 없어서 FK, UNIQUE 이름이 DB 기본 이름에 맡겨집니다. 이후 마이그레이션에서 제약을 이름으로 다루기 어렵습니다.

10. **엔진 설정이 코드에 박혀 있다**
    - 자리: `app/main.py:12`.
    - 까닭: 접속 문자열이 `postgresql+psycopg://gym@localhost/gym`으로 고정돼 있고, 모듈을 import할 때 엔진이 만들어집니다. 환경별 설정을 바꿀 수 없고, 프로덕션과 로컬의 구분이 없습니다.
    - 비밀번호가 없는 로컬 개발용 값이라 그 자체가 결함은 아닙니다. 다만 프로덕션에서도 같은 경로가 쓰인다면 설정으로 빼야 합니다.

## 가장 먼저 볼 것
1, 2번은 사용자에게 보이는 만료일이 틀리는 문제이고, 3번은 실제로 일어날 수 있는 경합입니다. 이 셋이 우선입니다.

## 확인하지 못한 것
- 실행 환경에서 돌려 보지 않았고, 테스트도 저장소에 없습니다.
- `applied_on`이 창구 방문일이라는 `docs/schema.md`의 설명을 근거로 1번을 결함으로 봤습니다. 만료일을 승인일 기준으로 하기로 정했다면 결함이 아니라 문구 쪽을 고쳐야 하는 문제입니다.
