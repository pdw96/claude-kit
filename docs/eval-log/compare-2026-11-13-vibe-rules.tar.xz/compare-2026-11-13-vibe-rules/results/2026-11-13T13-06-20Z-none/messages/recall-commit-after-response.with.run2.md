<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.10935500000000001 -->

데이터 쪽(모델·마이그레이션·트랜잭션 경계·되돌림)을 전체 파일 기준으로 읽고 검토했습니다. 코드는 고치지 않았고, 앱·마이그레이션·테스트는 실행하지 않았습니다. 저장소에는 `app/`, `migrations/0001_initial.py`, `docs/schema.md`만 있습니다. 로컬용 기본 `database_url`(`app/settings.py`)은 비밀번호가 없는 예시 값이라 결함으로 세지 않았습니다.

## 트랜잭션 경계

1. **커밋이 응답 뒤에 일어날 수 있습니다.** (`app/main.py` `session_scope`, `post_loan`)
   - 커밋은 `yield` 의존성의 종료 부분에서 합니다. FastAPI는 0.118 이후 이 종료 코드를 기본으로 응답을 보낸 뒤에 실행하는 것으로 알고 있습니다. `requirements.txt`의 0.141.1이 이에 해당합니다.
   - 이 동작은 설치해서 확인하지 못했고 제 기억에 의존한 판단입니다. 틀렸다면 이 항목은 빼십시오.
   - 맞다면 `SERIALIZABLE` 충돌이나 제약 위반이 커밋 시점에 나도 클라이언트는 이미 201과 `loan_id`를 받습니다. 실제로는 대출이 서지 않았는데도 서 있는 것으로 보입니다.
   - 원칙 1("한 번에 선다")이 응답 의미에서는 지켜지지 않습니다. 커밋을 엔드포인트나 서비스 안에서 하거나, 의존성의 `scope="function"`을 써야 합니다.

2. **직렬화 실패 재시도가 없습니다.** (`app/db.py` 9행, `app/main.py`)
   - `SERIALIZABLE`에서는 동시 요청 중 하나가 SQLSTATE 40001로 실패하는 것이 정상 동작입니다. 이를 받아 재시도하거나 409/503으로 바꾸는 곳이 없습니다.
   - 그래서 원칙 3이 "하나만 선다"가 아니라 "나머지는 500"으로 나타납니다. 마지막 남은 한 권을 두 명이 동시에 빌리면 진 쪽은 `RefusedLoan`(422) 대신 500을 받습니다.
   - 위 1번과 겹치면 응답 뒤 커밋 실패로 조용히 사라질 수도 있습니다.

3. **DB 예외가 사용자 오류로 번역되지 않습니다.** (`app/main.py` `post_loan`, `app/services/loans.py` `lend`)
   - `post_loan`은 `RefusedLoan`만 처리합니다. `IntegrityError`나 `OperationalError`는 전부 500입니다.
   - 대표적인 경우가 `loan_days`가 0 이하인 책입니다. `loans_due_after_loan` CHECK가 걸려 어느 요청에서든 500이 납니다.
   - `books.loan_days`에는 양수 CHECK가 없어서 이런 값이 들어갈 수 있습니다. (`app/models.py` 25행, `migrations/0001_initial.py` 23행)

## 데이터 모델

4. **`available_copies`가 `loans`에서 파생되는 값인데 정합성 장치가 없습니다.**
   - (`app/models.py` `Book`, `docs/schema.md` 표)
   - 총 소장 수 열이 없고, 반납 때 권수를 되돌리는 코드도 없습니다. 쓰기 경로는 `lend` 하나뿐입니다.
   - `returned_on`을 채우는 경로가 생기면 `available_copies`를 올리는 일이 별도 구현에 달립니다. 올라가는 값의 상한도 없습니다. 총 권수 열이나 `loans`에서 계산한 값으로 맞춰야 합니다.

5. **대출 기록 제약이 부족합니다.** (`app/models.py` `Loan`, `migrations/0001_initial.py` loans 표)
   - `returned_on >= loaned_on` CHECK가 없습니다.
   - 같은 회원이 같은 책을 반납 전에 중복 대출하는 것을 막는 부분 유니크 인덱스(`WHERE returned_on IS NULL`)가 없습니다.
   - `book_id`와 `member_id`에 인덱스가 없습니다. 회원별·책별 미반납 조회가 풀스캔이 됩니다.
   - 이 중복 대출 항목은 업무 규칙 쪽이라 확신이 낮습니다.

6. **`loaned_on`을 클라이언트가 임의로 정합니다.** (`app/schemas.py` `LoanIn.loaned_on`, `app/services/loans.py` 45행)
   - 과거나 먼 미래 날짜를 넣어 연체 기준일(`due_on`)을 조작할 수 있습니다. 서버 시각으로 정하거나 범위 검증이 필요합니다.

7. **ISBN 정규화가 없습니다.** (`app/schemas.py` 7행, `app/services/loans.py` 31행)
   - 길이만 10~13으로 검사합니다. 하이픈이 든 값이나 10자리/13자리 표기 차이는 정확 일치 조회에서 "없는 도서"가 됩니다.
   - 반대로 `String(13)` 때문에 하이픈이 든 값을 저장하는 경로는 막혀 있습니다.

8. **모델에 제약 이름 규칙이 없습니다.** (`app/models.py` `Base`)
   - `MetaData(naming_convention=...)`이 없어서 유니크·FK 제약 이름이 DB 기본값에 맡겨집니다. 이후 마이그레이션에서 제약을 지우거나 바꾸기가 어렵습니다.
   - CHECK만 이름이 있습니다. 중요도는 낮습니다.

## 마이그레이션·되돌림

9. **마이그레이션을 실행할 구성이 저장소에 없습니다.** (`migrations/`)
   - `alembic.ini`와 `env.py`가 없습니다. `0001_initial.py`는 파일 하나뿐이라, 지금 상태로는 `alembic upgrade`를 돌릴 수 없습니다.
   - `Base.metadata`를 `target_metadata`로 연결하는 곳이 없어서 모델과 마이그레이션이 어긋나도 검출되지 않습니다.
   - 지금도 두 곳(`app/models.py`와 `migrations/0001_initial.py`)에 같은 스키마가 손으로 중복되어 있습니다.

10. **`downgrade`의 안전장치가 반쪽입니다.** (`migrations/0001_initial.py` 39~46행)
    - `loans`가 비어 있는지만 보고 `books`와 `members`를 지웁니다. 대출이 없어도 도서와 회원 데이터는 소실됩니다. 주석이 말하는 "지우면 되살릴 길이 없다"는 이 두 표에도 똑같이 해당합니다.
    - 검사(`SELECT EXISTS`)와 `drop_table` 사이에 잠금이 없습니다. 그 사이에 앱이 대출을 쓰면 기록이 지워집니다.
    - 트랜잭션 DDL이 있는 PostgreSQL이라 앞의 경우는 `LOCK TABLE`로 막을 수 있습니다.

11. **`revision`에 `branch_labels`와 `depends_on`이 없습니다.** (`migrations/0001_initial.py` 6~7행)
    - 일부 Alembic 버전과 도구는 이 속성을 요구합니다. 위 9번과 함께 한 번 실제로 돌려 보는 게 좋습니다. 확신은 낮습니다.

## 가장 먼저 볼 것

가장 먼저 볼 것은 1번과 2번입니다. 둘 다 이 서비스가 존재하는 이유인 "대출 한 건은 한 번에 서고, 동시 대출은 하나만 선다"를 직접 깨뜨립니다.
