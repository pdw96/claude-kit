<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.11614640000000001 -->

`app/`, `migrations/`, `docs/schema.md`을 전부 읽고 정적으로만 검토했습니다. 코드는 실행하지 않았고 수정도 하지 않았습니다. 아래 결함은 확실한 것부터 순서대로 적었습니다.

## 트랜잭션 경계

1. **직렬화 실패에 재시도가 없습니다.**
   - 자리: `app/db.py:9`(`isolation_level="SERIALIZABLE"`), `app/main.py:16-29`(`session_scope`), `app/services/loans.py:30-49`(`lend`).
   - 까닭: 같은 책을 동시에 빌리면 PostgreSQL이 한쪽을 SQLSTATE 40001(`SerializationFailure`)로 중단시킵니다. 이 오류는 `RefusedLoan`이 아니어서 `post_loan`이 잡지 않고, `session_scope`는 롤백 후 다시 던지기만 합니다. 그래서 클라이언트는 정상 경합인데도 500을 받습니다. 원칙 3은 "하나만 선다"까지만 보장하고, 진 쪽을 다시 시도하는 장치는 없습니다.

2. **커밋이 응답을 만든 뒤에 실행됩니다.**
   - 자리: `app/main.py:22-24`.
   - 까닭: `session.commit()`이 yield 의존성의 종료 구간에 있어서, 핸들러가 `LoanOut`(201, `loan_id`, `available_copies`)을 만든 뒤에 돕니다. SERIALIZABLE에서는 충돌이 커밋 시점에 드러나는 경우가 많습니다. 커밋이 실패해도 클라이언트가 이미 201을 받았을 수 있고, 그러면 대출이 서지 않았는데 선 것으로 보입니다.
   - 단서: 이 구간이 응답 전송 전에 도는지 후에 도는지는 FastAPI 버전에 따라 다릅니다. 고정된 0.141.1에서의 동작은 확인하지 않았습니다. 어느 쪽이든 커밋 실패를 HTTP 상태로 옮기는 자리가 없습니다.

3. **제약 위반이 500으로 새어 나옵니다.**
   - 자리: `app/services/loans.py:40-48`, `app/main.py:40-41`.
   - 까닭: `IntegrityError`(`books_available_not_negative`, `loans_due_after_loan`)를 번역하는 곳이 없습니다.
   - 예: `loan_days`가 0 미만으로 저장된 책이면 `due_on < loaned_on`이 되어 CHECK에 걸립니다.

## 데이터 모델

4. **반납 경로가 없고 되돌릴 수단도 없습니다.**
   - 자리: `app/` 전체(엔드포인트는 `POST /loans`뿐), `docs/schema.md:7`.
   - 까닭: `returned_on`을 채우는 코드가 없고 `available_copies`를 늘리는 코드도 없습니다. 문서는 "반납하면 `returned_on`이 찬다"고 하지만 구현이 없습니다. 대출할 때마다 권수만 줄고 복구되지 않아 책이 결국 전부 "없음"이 됩니다. 취소나 정정 경로도 없습니다.

5. **빌려 간 권수와 `available_copies`가 일치한다는 보장이 없습니다.**
   - 자리: `app/models.py:18-26`.
   - 까닭: 전체 소장 권수 컬럼이 없습니다. `returned_on IS NULL`인 대출 수와 `available_copies`의 관계를 강제하는 제약이나 트리거도 없습니다. 원칙 1은 애플리케이션 코드의 약속일 뿐 DB가 지켜 주지 않습니다. 반납 로직을 붙이면 상한도 없어서 권수가 소장 수를 넘어 늘어날 수 있습니다.

6. **같은 회원이 같은 책을 여러 번 빌릴 수 있습니다.**
   - 자리: `app/models.py:29-38`, `app/services/loans.py:37-47`.
   - 까닭: `(book_id, member_id)`에 `returned_on IS NULL` 조건의 부분 유니크 인덱스가 없습니다. 서비스에도 중복 확인이 없어서 같은 요청을 재전송하면 대출이 중복으로 생깁니다. 요청에 멱등 키도 없습니다.
   - 단서: 한 회원이 같은 책을 여러 권 빌리는 것이 의도된 정책인지는 문서에 없습니다. 의도라면 이 항목은 해당하지 않습니다.

7. **`loan_days`와 `loaned_on`을 검증하지 않습니다.**
   - 자리: `app/models.py:25`, `app/schemas.py:9`(`loaned_on: date`).
   - 까닭: `loan_days`에 `> 0` 같은 CHECK가 없습니다. `loaned_on`은 클라이언트가 보내는 값이라 과거나 먼 미래 날짜로 대출을 세울 수 있고, 연체 계산이 그 값에 좌우됩니다. 서버 날짜를 쓰거나 범위를 제한하는 곳이 없습니다.

8. **ISBN-10과 ISBN-13을 같은 책으로 보지 않습니다.**
   - 자리: `app/schemas.py:7`(10~13자 허용), `app/models.py:23`, `app/services/loans.py:31`.
   - 까닭: 정규화(하이픈 제거, 10→13 변환)와 형식 검증이 없습니다. 같은 책이 다른 문자열로 조회되어 "없는 도서"가 되거나 `books`에 중복 등록될 수 있습니다. 길이 11~12 같은 무효 값도 통과합니다.

9. **FK 컬럼에 인덱스가 없습니다.**
   - 자리: `migrations/0001_initial.py:30-31`, `app/models.py:34-35`.
   - 까닭: `loans.book_id`와 `loans.member_id`에 인덱스가 없습니다. 부모 행 삭제 검사와 회원·책별 대출 조회가 전체 스캔이 됩니다.

## 마이그레이션 · 되돌림

10. **`downgrade`가 대출 기록만 지키고 나머지는 지웁니다.**
    - 자리: `migrations/0001_initial.py:39-46`.
    - 까닭: `loans`가 비어 있으면 `books`와 `members`를 아무 확인 없이 `drop_table`합니다. `loans`만 검사하므로, 회원과 도서만 있는 상태(대출 전 운영 초기 등)에서 복구 불가능한 삭제가 일어납니다. `members`는 문서에서 "지우지 않는다"고 한 표입니다(`docs/schema.md:5`). 주석이 말하는 "지우면 되살릴 길이 없다"는 이유가 `books`와 `members`에도 똑같이 적용됩니다.

11. **마이그레이션을 실행할 환경 파일이 저장소에 없습니다.**
    - 자리: 저장소 루트(`alembic.ini`와 `env.py` 없음).
    - 까닭: `alembic==1.14.0`이 의존성에 있고 마이그레이션 파일은 있지만 실행 설정이 없어서 `alembic upgrade`를 그대로 돌릴 수 없습니다. `target_metadata`가 없으니 `app/models.py`와 마이그레이션이 어긋나는지 점검하는 autogenerate 검사도 불가능합니다. 지금은 모델과 마이그레이션이 손으로 두 번 적혀 있습니다(`models.py`와 `0001_initial.py`).

## 기타

12. **엔진 전체가 SERIALIZABLE로 고정되어 있습니다.**
    - 자리: `app/db.py:9`.
    - 까닭: 읽기 전용 작업까지 같은 격리 수준을 쓰면 서술 잠금 비용과 직렬화 실패 가능성이 늘어납니다. 쓰기 경로(`lend`)에만 필요한 요구인데 전역으로 걸려 있어서, 이후에 읽기 엔드포인트가 생기면 불필요한 실패 원인이 됩니다.

## 제외한 것
`app/settings.py:5`의 기본 `database_url`(비밀번호 없는 `localhost`)은 로컬 개발용 자리표시자로 보고 결함으로 올리지 않았습니다. 같은 값이 프로덕션 경로에 쓰이는지는 저장소 안에서 확인되지 않습니다. `PRD.md`나 `INTENT.md` 같은 기준 문서도 저장소에 없어서, 위 항목은 `docs/schema.md`와 코드 내부 일관성만 기준으로 판단했습니다.
