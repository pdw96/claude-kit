<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.09422559999999999 -->

`app/schemas.py` 경계에 NUL 문자 구멍이 하나 있고, 그 밖에 규약과 구현이 어긋난 곳이 몇 개 있습니다. 코드를 읽어서 찾았고 실행해서 확인하지는 않았습니다. 저장소는 `app/`, `migrations/`, `docs/api.md`, `requirements.txt` 뿐이고 테스트는 없습니다. 의도 문서(`INTENT.md`, `PRD.md`)도 없어서 기준은 `docs/api.md` 로 삼았습니다.

## 결함

1. **NUL 문자(`\x00`)가 경계를 통과해 500 이 됩니다.**
   - 자리: `app/schemas.py` 의 `RegistrationIn` 네 칸(`event_code`, `attendee_name`, `organization`, `note`)과 `_present`, `app/main.py:post_registration` 의 `s.commit()`.
   - 까닭: 길이와 공백만 검사하고 NUL 은 거르지 않습니다. `"a\u0000b"` 같은 값은 검증을 통과합니다. PostgreSQL `text` 는 NUL 을 담을 수 없어서 psycopg 가 `DataError` 를 내고, 이 예외는 처리하는 곳이 없어 500 이 됩니다.
   - `docs/api.md` 는 "받을 수 없는 요청은 경계에서 422, 경계를 지난 요청은 저장된다"고 약속합니다. 이 입력은 그 약속을 어깁니다. `schemas.py` 의 독스트링("데이터베이스까지 가면 이름 없는 실패가 된다")이 막으려던 바로 그 실패입니다.
   - `note` 는 `Present` 도 쓰지 않아서 NUL 을 막을 장치가 전혀 없습니다.

2. **공백 판정 목록이 좁아서 비어 보이는 값이 통과합니다.**
   - 자리: `app/schemas.py` 의 `_BLANK` 와 `_present`.
   - 까닭: 스페이스, 탭, 개행, 복귀, 전각 공백, NBSP 만 압니다. `\x0b`, `\x0c`, `\u0085`, `\u2003`(em space), `\u200b`(폭 없는 공백) 같은 값은 "비어 있다"로 걸러지지 않습니다. 그래서 `"\u2003"` 한 글자로 된 `attendee_name` 도 201 로 저장됩니다. 파이썬 기본 `str.strip()` 은 유니코드 공백을 더 넓게 다루는데, 직접 만든 목록이 그보다 좁습니다.

3. **`docs/api.md` 가 500 을 말하지 않고, 경계 밖 실패를 처리하는 규약이 없습니다.**
   - 자리: `docs/api.md` 응답 표, `app/main.py:post_registration`.
   - 까닭: 표에 201 과 422 만 있습니다. DB 가 내려가 있거나 제약에 걸리는 경우처럼 경계 밖에서 실패하면 FastAPI 기본 500 이 나갑니다. 1번이 이 틈으로 드러난 사례입니다. DB 예외를 잡는 곳이 없고 에러 응답 형식도 정해져 있지 않습니다.

4. **DB 접속 문자열이 코드에 박혀 있습니다.**
   - 자리: `app/main.py:14`.
   - 까닭: `postgresql+psycopg://events@localhost/events` 가 설정이나 환경 변수 없이 임포트 시점에 엔진을 만듭니다. 비밀번호가 없는 로컬 개발용 값 자체는 결함이 아닙니다. 다만 이 값이 앱의 유일한 경로여서 프로덕션에서도 그대로 쓰입니다. 환경별로 바꿀 방법이 없고, 임포트만 해도 엔진이 만들어져 테스트에서 갈아끼우기도 어렵습니다.

5. **같은 신청을 막는 규칙이 없습니다.**
   - 자리: `app/models.py:Registration`, `migrations/0001_registrations.py`.
   - 까닭: `(event_code, attendee_name)` 유일 제약이 없고 `event_code` 가 실제 행사인지 확인하지도 않습니다. 같은 요청을 다시 보내면 201 이 계속 나가면서 행이 쌓입니다(재시도 시 중복). 의도된 동작이라면 `docs/api.md` 에 적혀 있어야 하는데 없습니다.

6. **`organization` 과 `note` 의 검증 기준이 다릅니다.**
   - 자리: `app/schemas.py:24-25`.
   - 까닭: `organization` 은 공백만이면 422 를 내지만 `note` 는 공백만인 값도 저장합니다. 의도한 차이인지 문서에 없습니다. 둘 다 선택 칸인데 `organization: "   "` 은 거절하고 `null` 은 받아서, 호출자가 어느 쪽을 보내야 하는지 계약에서 알 수 없습니다.

7. **응답 형식이 최소입니다.**
   - 자리: `app/main.py:25-30`, `docs/api.md`.
   - 까닭: 201 응답에 `Location` 헤더가 없고, 본문은 `registration_id` 하나뿐입니다. 이 ID 로 조회하는 공개 엔드포인트도 없어서 호출자는 저장된 결과를 확인할 수 없습니다. 문서에 응답 본문 형식(`registration_id`)과 각 칸의 길이 한도(20/50/100/500)도 적혀 있지 않습니다.

8. **`requirements.txt` 에 `pydantic` 이 빠져 있습니다.**
   - 자리: `requirements.txt`, `app/schemas.py:5`.
   - 까닭: 코드가 `pydantic` 을 직접 임포트하는데 의존성에는 FastAPI 를 통한 간접 설치뿐입니다. 검증 동작(`AfterValidator`, `Field` 제약)이 버전에 달려 있는데 고정되지 않았습니다.

## 걸러낸 것

`events@localhost` 접속 값(비밀번호 없음)은 자리표시자 수준의 로컬 값이라 비밀번호 노출 결함으로 올리지 않았습니다. 4번은 하드코딩 설정 문제로만 올렸습니다. 마이그레이션과 모델의 컬럼 정의는 서로 일치하고, `downgrade` 가 데이터가 있으면 거절하는 것은 의도된 동작으로 보여 결함으로 올리지 않았습니다.
