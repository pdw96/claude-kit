<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0976592 -->

데이터 쪽에서 결함 7건을 찾았습니다. 코드는 고치지 않았고, 파일은 읽기만 했습니다. 실행해서 확인한 것은 없고, 모두 코드를 읽어서 낸 결론입니다. 확신이 큰 것부터 적었습니다.

## 결함 목록

1. **만료일을 신청일이 아니라 승인 시각으로 계산합니다.**
   - 자리: `app/services/memberships.py` `approve()` 29~35행. `starts_on = approved_at.date()`, `valid_until = starts_on + duration_days`입니다.
   - 까닭: `seed/plans.sql`의 안내 문구는 "신청일로부터 30일. 만료일은 신청일 + 기간"이라고 합니다. `docs/schema.md`는 `applied_on`을 회원이 창구에 온 날이라고 정의합니다. 같은 문서는 승인이 신청 다음 날이나 그 뒤에 몰아서 이뤄진다고도 합니다. 주말 신청은 월요일에 승인되므로 회원은 최대 2일 이상 손해를 봅니다. `application.applied_on`은 `approve()`에서 한 번도 읽지 않습니다. 이 문구는 화면 안내로도 나가므로, 안내와 실제 만료일이 어긋납니다.

2. **동시에 승인하면 막는 장치가 없고, 막혀도 500 오류가 납니다.**
   - 자리: `approve()` 22~26행의 `session.get()`과 `status` 검사, `app/main.py` `post_approval()` 29~33행.
   - 까닭: 행을 잠그지 않고(`with_for_update` 없음) 읽은 뒤 검사하고 씁니다. 두 요청이 모두 `pending`을 보고 통과할 수 있습니다. 이때는 `memberships.application_id`의 unique 제약이 두 번째를 막습니다. 그런데 그 시점의 `IntegrityError`는 `flush()`에서 올라오는데 `RefusedApproval`로 바뀌지 않습니다. 호출자는 "이미 처리한 신청" 422 대신 500을 받습니다. `status` 갱신도 조건부 `UPDATE`가 아니라 읽은 값에 덮어쓰는 방식입니다.

3. **`starts_on`을 UTC 날짜로 잡습니다.**
   - 자리: `approve()` 29~30행. `datetime.now(timezone.utc).date()`입니다.
   - 까닭: 체육관은 지역 시간대로 영업하고, `valid_until`이 지나면 출입 단말이 막습니다. 한국이라면 KST 00:00~09:00에 승인한 건은 시작일이 하루 전으로 기록됩니다. 만료일도 하루 일찍 잡힙니다. 시간대 기준이 코드나 문서 어디에도 없습니다.

4. **`plan`이 `None`일 때 처리가 없습니다.**
   - 자리: `approve()` 27행과 35행. `plan = session.get(...)` 뒤에 검사가 없습니다.
   - 까닭: `plans` 시드는 마이그레이션에 들어 있지 않습니다. `migrations/0001`은 표만 만들고, 데이터는 별도 `seed/plans.sql`에만 있습니다. 시드를 안 넣은 환경이나 코드가 삭제·비활성화된 환경에서는 `plan.duration_days`가 `AttributeError`가 되어 500이 납니다. 다른 거절 사유처럼 `RefusedApproval`로 처리해야 합니다. FK가 있어서 보통은 안 일어나지만, 방어 없이 가정만 하고 있습니다.

5. **시드가 멱등하지 않습니다.**
   - 자리: `seed/plans.sql` 2행. 단순 `INSERT`입니다.
   - 까닭: 다시 실행하면 PK 중복으로 실패합니다. 이 표는 "기준 데이터"인데 가격이나 기간을 바꾸는 경로가 없습니다. `ON CONFLICT`나 마이그레이션 기반 데이터 변경이 필요합니다. 마이그레이션과 시드가 분리되어 있어 배포 순서에 따라 시드가 빠질 수도 있습니다.

6. **`downgrade()`가 지우는 데이터를 일부만 지킵니다.**
   - 자리: `migrations/0001_memberships.py` `downgrade()` 40~46행.
   - 까닭: `memberships`가 비었는지만 확인하고, `applications`와 `plans`는 내용이 있어도 그냥 `DROP`합니다. 승인 전(`pending`) 신청이 쌓여 있으면 말없이 사라집니다. 검사 대상 표가 지우는 표와 다릅니다. 또 검사와 `DROP` 사이에 쓰기를 막지 않습니다.

7. **무결성 제약이 모델과 마이그레이션에서 빠져 있습니다.**
   - 자리: `app/models.py`의 `Application.status`(26행), `Application.member_id`·`Membership.member_id`(23, 35행), `Plan.duration_days`(14행). `migrations/0001`에도 같은 내용이 있습니다.
   - 까닭:
     - `status`는 `String(10)`뿐입니다. `pending`/`approved` 외의 값을 막는 CHECK나 enum이 없습니다.
     - `member_id`는 FK가 없습니다. 존재하지 않는 회원의 신청과 회원권이 만들어집니다.
     - `duration_days`와 `price`에 양수 CHECK가 없습니다.
     - 같은 회원의 회원권 기간이 겹치는 것을 막는 제약이 없습니다.
     - "승인된 신청에는 회원권이 정확히 하나"라는 `status`와 `memberships`의 일관성은 앱 코드에만 의존합니다.
     - 모델과 마이그레이션이 같은 정의를 따로 적어 두어, 한쪽만 바뀌면 어긋나는데 이를 잡아내는 장치가 없습니다.

## 결함으로 내지 않은 것
- `app/main.py` 12행의 `postgresql+psycopg://gym@localhost/gym`은 비밀번호 없는 로컬 연결 문자열입니다. 밖에서 닿는 자원에 붙는 값인지, 프로덕션 경로에도 쓰이는지는 저장소에서 확인되지 않아 결함으로 보지 않았습니다. 다만 접속 정보가 코드에 고정되어 있어 환경별 설정으로 빼야 합니다.
- `s.commit()`이 엔드포인트에 있고 실패 시 `s.close()`로 롤백되는 구조 자체는 트랜잭션 경계로 문제가 없습니다. 위 2번의 예외 처리만 빠져 있습니다.
