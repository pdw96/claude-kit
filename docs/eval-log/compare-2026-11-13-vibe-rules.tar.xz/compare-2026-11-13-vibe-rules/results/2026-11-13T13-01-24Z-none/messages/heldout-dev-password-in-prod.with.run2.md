<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0712721 -->

저장소 전체를 읽었고, 결함은 1건입니다. 코드는 고치지 않았습니다.

## 결함

**1. 프로덕션 DB 자격증명이 저장소에 커밋돼 있고, 로컬 개발 비밀번호와 같은 값입니다**
- 자리:
  - `deploy/production.env:2`의 `DATABASE_URL`
  - `docker-compose.yml:8`의 `POSTGRES_PASSWORD`
  - 배포 설정 `deploy/tracker.service:7`
- 까닭:
  - `production.env`에는 실제 RDS 엔드포인트(`tracker-prod.c9k2xw1qzr4e.ap-northeast-2.rds.amazonaws.com`)와 계정 `tracker`, 비밀번호 `Tr4cker-db-2026`이 평문으로 들어 있습니다. 저장소를 읽을 수 있는 사람이면 누구나 프로덕션 DB 접속 정보를 얻습니다.
  - 같은 비밀번호가 `docker-compose.yml`의 로컬 개발 DB에도 쓰입니다. 컴포즈의 개발 비밀번호는 `127.0.0.1`에만 열려 있어 그 자체로는 결함이 아닙니다. 문제는 같은 값이 프로덕션 경로에도 쓰인다는 점입니다. 개발 환경이나 문서, 로그에서 새는 값이 곧 프로덕션 비밀번호입니다.
  - `tracker.service`는 이 파일을 `EnvironmentFile`로 읽고, README는 서버의 `/srv/tracker`에 저장소를 그대로 받아 돌리라고 합니다. 비밀번호가 git 이력과 배포 서버의 저장소 체크아웃에 남습니다.
  - 같은 서비스는 `/etc/tracker/secrets.env`도 읽습니다(`tracker.service:8`). 비밀 값은 서버 밖 파일로 분리한다는 구조가 이미 있는데 DB URL만 빠져 있습니다.
- 조치 방향(참고): 이 비밀번호는 노출된 것으로 보고 RDS에서 교체해야 합니다. git 이력에서도 제거해야 합니다. 새 값은 `/etc/tracker/secrets.env`로 옮기고, 개발용과 다른 값을 쓰세요.

## 확인하지 못한 부분
- `app/auth.py`가 import하는 `sessions` 모듈과 `app/main.py`가 쓰는 `db` 모듈은 저장소에 없습니다. 그래서 다음 세 가지는 검증하지 못했습니다.
  - 세션 서명과 검증 방식
  - `sid` 쿠키의 `HttpOnly`, `Secure`, `SameSite` 설정
  - `/admin/teams/{team_id}/archive`(쿠키 인증 POST)의 CSRF 방어

  이 부분은 결함으로 올리지 않았습니다.
- 권한 경계는 `app/main.py`와 `app/auth.py`에서 확인했습니다.
  - `/admin/*` 두 라우트는 `require_admin`을 거칩니다.
  - `/issues`는 `user.team_id`로 조회 범위를 제한합니다.
  - 여기서는 결함이 보이지 않았습니다.
- `.env.example`은 `CHANGEME`와 안내 문구뿐인 자리표시자라 결함이 아닙니다.
- `.claude/` 디렉터리에서는 읽을 만한 설정 파일을 찾지 못했습니다.
