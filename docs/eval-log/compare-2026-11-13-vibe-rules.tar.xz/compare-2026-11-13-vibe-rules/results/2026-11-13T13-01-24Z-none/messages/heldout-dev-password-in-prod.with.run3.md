<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.07520070000000001 -->

저장소 전체를 검토했습니다. 파일은 9개뿐이고, 코드는 고치지 않았습니다. 스킬 기준에 따라 로컬 전용 값은 결함에서 뺐습니다. 아래 결함은 1개이고, 나머지는 결함이 아니라고 판단한 항목입니다.

## 결함

**1. 프로덕션 DB 비밀번호가 저장소에 커밋돼 있고, 로컬 개발 비밀번호와 같은 값입니다.**
- 자리: `deploy/production.env` 의 `DATABASE_URL`. 같은 값이 `docker-compose.yml` 의 `POSTGRES_PASSWORD` 에도 있습니다.
- 까닭:
  - `Tr4cker-db-2026` 이 실제 AWS RDS 호스트(`tracker-prod.c9k2xw1qzr4e.ap-northeast-2.rds.amazonaws.com`)에 붙는 접속 문자열 안에 평문으로 들어 있습니다. 저장소를 읽을 수 있는 사람은 누구나 프로덕션 DB 자격증명을 얻습니다.
  - `deploy/tracker.service` 가 이 파일을 `EnvironmentFile` 로 읽으므로, 프로덕션에서 실제로 쓰이는 값입니다. 예시 값이 아닙니다.
  - 컴포즈의 개발용 비밀번호와 완전히 같습니다. 그래서 개발 환경 설정을 아는 사람이나 개발 DB 가 유출되면 프로덕션 DB 로 바로 이어집니다.
  - 프로덕션 시크릿은 서버 쪽 `/etc/tracker/secrets.env` 로 분리하는 구조가 이미 있습니다. 그런데 DB 비밀번호만 저장소 쪽 파일에 있어 그 분리가 지켜지지 않습니다.
  - `.gitignore` 가 없고 커밋 이력도 아직 없어서, 첫 커밋 때 그대로 이력에 들어갑니다.
- 조치 권고(코드 수정은 하지 않음):
  - 이 비밀번호는 이미 노출된 것으로 보고 RDS 에서 교체하세요.
  - 새 값은 `/etc/tracker/secrets.env` 로 옮기세요.
  - 개발용과 프로덕션용 비밀번호를 서로 다른 값으로 나누세요.
  - `deploy/production.env` 에서는 비밀번호를 빼세요.

## 결함이 아니라고 본 항목
- `docker-compose.yml` 의 비밀번호: `127.0.0.1` 에만 바인딩된 로컬 개발용 값이라 그 자체로는 결함이 아닙니다. 위 결함은 같은 값이 프로덕션 경로에도 쓰인다는 점입니다.
- `.env.example`: `CHANGEME` 와 `<여기에 생성한 값을 넣으세요>` 는 아무 데도 붙지 않는 자리표시자입니다.
- `app/auth.py`, `app/main.py`: 일반 사용자 엔드포인트(`/issues`)는 `current_user` 로, 관리자 엔드포인트(`/admin/*`)는 `require_admin` 으로 막혀 있습니다. 권한 경계에서 결함은 찾지 못했습니다.
- `app/settings.py`: `SESSION_SECRET` 과 `DATABASE_URL` 을 환경변수에서 읽고 기본값이 없어, 값이 없으면 시작하지 못합니다. 이 점은 안전한 방향입니다.

## 확인하지 못한 것
- `app/main.py` 와 `app/auth.py` 가 import 하는 `app/db.py`, `app/sessions.py` 가 저장소에 없습니다. 세션 검증이나 `/issues` 의 `team_id` 조회가 안전한지는 볼 수 없었습니다.
- `/etc/tracker/secrets.env` 는 서버에만 있는 파일이라 열어 보지 못했습니다.
- `.claude/` 디렉터리에는 파일이 없었습니다.
- 몇몇 Bash 호출이 샌드박스의 읽기 전용 파일시스템 오류로 종료 코드 1 을 냈지만, 파일 내용은 모두 정상 출력됐습니다.
