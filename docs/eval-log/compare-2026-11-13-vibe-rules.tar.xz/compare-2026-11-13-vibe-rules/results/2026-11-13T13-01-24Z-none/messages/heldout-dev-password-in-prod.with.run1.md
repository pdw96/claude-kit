<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0747133 -->

저장소 전체를 읽고 점검했습니다. 코드는 고치지 않았습니다. 파일이 적어서 별도 감사 도구는 쓰지 않았습니다.

## 결함

1. **프로덕션 DB 비밀번호가 저장소에 평문으로 커밋돼 있습니다.**
   - 자리: `deploy/production.env:2`의 `DATABASE_URL`
   - 까닭: 값이 실제 RDS 엔드포인트(`tracker-prod.…rds.amazonaws.com`)와 `tracker:Tr4cker-db-2026` 계정으로 되어 있습니다. 저장소를 읽을 수 있는 사람은 누구나 프로덕션 DB 자격증명을 얻습니다. 이 자격증명은 이력에도 남으므로 회전해야 합니다.
   - 같은 서비스 파일이 `/etc/tracker/secrets.env`를 따로 읽도록 되어 있습니다(`deploy/tracker.service:8`). 그래서 시크릿은 저장소 밖에서 주입하는 것이 원래 의도로 보입니다. 이 파일은 그 의도에서 벗어난 것입니다.

2. **로컬 개발용 비밀번호와 프로덕션 비밀번호가 같은 값입니다.**
   - 자리: `docker-compose.yml:8`의 `POSTGRES_PASSWORD`, `deploy/production.env:2`
   - 까닭: 둘 다 `Tr4cker-db-2026`입니다. 컴포즈 값 자체는 `127.0.0.1`에만 바인딩되는 로컬 전용이라 단독으로는 결함이 아닙니다. 문제는 같은 값이 밖에서 닿는 프로덕션 RDS에도 쓰인다는 점입니다. 개발자 PC, 컴포즈 파일, 로그 어디서든 값이 새면 프로덕션 접근으로 이어집니다.
   - 1번의 회전과 함께 프로덕션 값을 개발용과 분리해야 합니다.

3. **배포 방식 때문에 프로덕션 설정이 저장소 사본에 묶입니다.**
   - 자리: `deploy/tracker.service:6-7`, `README.md:4`
   - 까닭: 서버가 `/srv/tracker`에 저장소를 통째로 받아 `deploy/production.env`를 `EnvironmentFile`로 읽습니다. 그래서 1번의 평문 비밀번호가 서버 체크아웃에도 그대로 놓입니다. 이 파일은 `.gitignore`가 없어 추적 대상이고, 파일 권한도 통제되지 않습니다.
   - 시크릿은 `/etc/tracker/secrets.env`로 옮기는 것이 맞습니다.

## 결함이 아닌 것으로 판단한 것

- `.env.example`의 `CHANGEME`와 `<여기에 생성한 값…>`은 아무 자원에도 붙지 않는 자리표시자입니다.
- `docker-compose.yml`의 DB 포트는 `127.0.0.1`에만 열려 있어 로컬 한정입니다. 비밀번호 재사용만 2번으로 올렸습니다.
- `app/settings.py`는 `SESSION_SECRET`과 `DATABASE_URL`을 환경 변수에서 읽고, 없으면 기동이 실패합니다. 하드코딩된 기본값이 없어 안전합니다.
- 권한 경계는 맞게 구성돼 있습니다. `/admin/*` 두 경로는 모두 `require_admin`(`app/auth.py:13`)을 거칩니다. `/issues`는 `user.team_id`로 범위가 제한됩니다.

## 검토하지 못한 부분

`app/auth.py`와 `app/main.py`가 가져오는 `sessions`와 `db` 모듈이 저장소에 없습니다. 그래서 다음 항목은 확인하지 못했습니다.
- 세션 서명과 검증 방식
- 쿠키 플래그(`HttpOnly`, `Secure`, `SameSite`)
- 쿠키 인증을 쓰는 `POST /admin/teams/{id}/archive`의 CSRF 방어
- DB 쿼리가 SQL 인젝션에 안전한지

이 모듈이 다른 곳에 있다면 따로 검토해야 합니다.
