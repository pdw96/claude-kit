<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0775951 -->

저장소 전체(파일 9개)를 읽고 검토했습니다. 코드는 수정하지 않았습니다. 결함은 7건입니다.

## 결함 목록

### 1. 프로덕션 DB 자격증명이 평문으로 저장소에 들어 있음 (높음)
- **자리**: `deploy/production.env:2`
- **까닭**: `DATABASE_URL`에 RDS 호스트, 사용자 `tracker`, 비밀번호 `Tr4cker-db-2026`이 그대로 적혀 있습니다. 저장소를 읽을 수 있는 사람은 누구나 프로덕션 DB 접속 정보를 얻습니다. git 이력과 클론본에도 남습니다. 이 비밀번호는 이미 노출된 것으로 보고 교체(rotate)해야 합니다.
- **같은 문제의 다른 자리**: `deploy/tracker.service:7-8`은 이미 `/etc/tracker/secrets.env`라는 저장소 밖 시크릿 파일을 읽습니다. DB URL도 그 파일로 옮기면 됩니다.

### 2. 개발용 DB 비밀번호가 프로덕션과 같음 (높음)
- **자리**: `docker-compose.yml:8`, `deploy/production.env:2`
- **까닭**: compose 파일의 `POSTGRES_PASSWORD: Tr4cker-db-2026`이 프로덕션 비밀번호와 같습니다. 개발 환경 정보가 새거나 개발자 PC가 뚫리면 프로덕션으로 이어집니다. 개발과 프로덕션 시크릿은 분리해야 하고, compose 쪽도 `.env` 변수로 받는 편이 낫습니다.
- **참고**: 포트는 `127.0.0.1`에만 바인딩되어 있어 이 부분은 적절합니다.

### 3. `.gitignore`가 없어 `.env`와 시크릿 파일이 커밋될 수 있음 (중간)
- **자리**: 저장소 루트(파일 없음), `README.md:3`
- **까닭**: README는 `.env.example`을 `.env`로 복사해 채우라고 안내합니다. 그런데 `.env`를 무시하는 규칙이 없어, 실제 `SESSION_SECRET`과 DB 비밀번호가 담긴 `.env`가 실수로 커밋될 수 있습니다. 아래 4번의 `production.env`도 같은 이유로 계속 추적됩니다.

### 4. 시크릿이 든 배포 파일이 저장소 경로에서 서비스에 직접 로드됨 (중간)
- **자리**: `deploy/tracker.service:6-7`
- **까닭**: 서비스가 `/srv/tracker/deploy/production.env`를 읽습니다. 이 경로는 저장소 체크아웃 안이라서, 시크릿을 저장소에 두는 구조를 배포 방식이 고정시킵니다. 서비스 파일 어디에도 `/etc/tracker/secrets.env`의 소유자나 권한(0600) 요구가 없습니다. 서비스를 root로 돌리면서 `User=`를 지정하지 않은 점도 문제입니다.

### 5. systemd 서비스에 권한 최소화 설정이 없음 (중간)
- **자리**: `deploy/tracker.service` `[Service]` 섹션
- **까닭**: `User=`/`Group=`이 없어 기본값인 root로 실행됩니다. 웹 API가 침해되면 곧바로 root 권한을 얻습니다. `NoNewPrivileges`, `ProtectSystem`, `PrivateTmp` 같은 하드닝 옵션도 없습니다.

### 6. 인증과 세션 코드가 저장소에 없어 검토할 수 없음 (중간, 확인 필요)
- **자리**: `app/auth.py:3`(`from . import sessions`), `app/main.py:3`(`from . import db`), `app/settings.py:4`
- **까닭**: `sessions`와 `db` 모듈이 저장소에 없습니다. 아래 항목은 이 모듈들이 어떻게 구현됐는지에 달려 있어 검증하지 못했습니다.
  - `SESSION_SECRET`을 어떻게 쓰는지: 서명 여부, 알고리즘, 만료
  - 세션 저장소가 안전한지
  - DB 쿼리가 파라미터화되어 있는지
- **부가 문제**: `SESSION_SECRET`에 강도나 길이 검증이 없습니다. `.env.example`의 플레이스홀더 `<여기에 생성한 값을 넣으세요>`를 그대로 두어도 앱이 기동됩니다. 모듈이 누락된 채 배포됐다면 앱은 시작조차 되지 않을 것이므로, 파일이 빠진 것인지부터 확인하세요.

### 7. 쿠키 속성과 CSRF 방어를 확인할 수 없음, 관리자 POST가 상태를 변경함 (낮음~중간)
- **자리**: `app/auth.py:7`, `app/main.py:19-21`
- **까닭**:
  - `sid` 쿠키를 읽기만 하고, 설정하는 코드(HttpOnly, Secure, SameSite)는 이 저장소에 없습니다.
  - `POST /admin/teams/{team_id}/archive`는 쿠키 인증만 쓰고 CSRF 토큰이나 Origin 검사가 없습니다. 쿠키가 `SameSite=Lax` 이상이 아니면, 로그인한 관리자가 악성 페이지를 열 때 팀이 아카이브될 수 있습니다.
  - 관리자 작업에 감사 로그가 없습니다.
  - 로그인 시도 제한(rate limit)도 보이지 않습니다.

## 잘한 점
- `app/auth.py`는 라우트마다 `Depends`로 인증을 걸고, `/admin/*`에는 `require_admin`으로 역할을 검사합니다(403).
- `/issues`는 `user.team_id`로 조회 범위를 제한해 팀 간 데이터 분리를 시도하고 있습니다. 실제 필터링은 `db.issues.for_team` 구현에 달려 있어 확인하지 못했습니다.
- `.env.example`은 플레이스홀더만 담고 있습니다.

## 우선 조치 제안
1. 프로덕션 DB 비밀번호를 즉시 교체합니다.
2. `deploy/production.env`의 시크릿을 저장소 밖으로 옮기고, git 이력에서도 제거합니다.
3. `.gitignore`를 추가합니다.
4. 서비스에 `User=`와 하드닝 옵션을 넣습니다.
5. 누락된 `sessions`와 `db` 모듈을 확보해 재검토합니다.
