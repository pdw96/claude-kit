<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0704409 -->

저장소 전체를 읽었습니다. 파일이 적어서 직접 검토했고, 코드는 고치지 않았습니다. 결함은 5건입니다.

## 결함 목록

1. **프로덕션 DB 자격증명이 커밋돼 있음** (높음)
   - 자리: `deploy/production.env:2` (`DATABASE_URL`)
   - 까닭: RDS 호스트명, 사용자 `tracker`, 비밀번호 `Tr4cker-db-2026`이 평문으로 git에 들어 있습니다. 저장소를 읽을 수 있는 사람은 누구나 프로덕션 DB 접속 정보를 얻습니다. 히스토리에도 남으므로 파일을 지워도 노출은 그대로입니다. 비밀번호를 교체(rotate)해야 합니다.
   - 같은 문제가 `deploy/tracker.service:7`에도 있습니다. 시크릿 파일 `/etc/tracker/secrets.env`가 이미 따로 있는데도 DB 비밀번호가 `production.env` 쪽에 놓였습니다. 시크릿 분리 의도가 지켜지지 않았습니다.

2. **개발용 DB 비밀번호가 프로덕션 비밀번호와 같음** (높음)
   - 자리: `docker-compose.yml:8` (`POSTGRES_PASSWORD: Tr4cker-db-2026`)
   - 까닭: 값이 `deploy/production.env`의 프로덕션 비밀번호와 같습니다. 개발 환경이 뚫리거나 compose 파일이 공유되면 프로덕션 자격증명이 같이 노출됩니다. 개발 DB는 `127.0.0.1`에만 바인딩돼 있어 직접 노출 위험은 낮지만, 비밀번호 재사용과 하드코딩이 문제입니다. 개발용 비밀번호는 `.env`에서 읽어 오고 프로덕션과 다르게 해야 합니다.

3. **`app/auth.py`가 임포트하는 `sessions` 모듈과 `app/main.py`가 임포트하는 `db` 모듈이 저장소에 없음** (중간, 검토 한계)
   - 자리: `app/auth.py:3`, `app/auth.py:7` (`sessions.load`), `app/main.py:3`
   - 까닭: 세션 서명·검증과 쿼리 구현을 볼 수 없어서, 세션 위조나 SQL 인젝션 여부는 검증하지 못했습니다. `app/settings.py`의 `SESSION_SECRET`이 쓰이는 곳도 확인할 수 없습니다. 이 두 모듈이 인증의 핵심이라 별도 감사가 필요합니다.

4. **쿠키 기반 세션인데 CSRF 방어가 보이지 않음** (중간)
   - 자리: `app/main.py:19-21` (`POST /admin/teams/{team_id}/archive`), `app/auth.py:7` (`request.cookies.get("sid")`)
   - 까닭: 인증을 쿠키 `sid`로만 합니다. 상태를 바꾸는 관리자 POST에 CSRF 토큰이나 Origin 검사가 없습니다. 쿠키의 `SameSite`, `HttpOnly`, `Secure` 설정도 이 저장소에서는 확인되지 않습니다(세션을 만드는 코드가 없습니다). 설정이 느슨하면 관리자가 악성 페이지를 열었을 때 팀이 아카이브될 수 있습니다.

5. **권한 경계와 운영 설정이 약함** (낮음~중간)
   - 자리: `app/main.py:14-21`, `deploy/tracker.service:5-13`
   - 까닭:
     - 관리자 엔드포인트의 접근 제어는 `require_admin`의 `role` 검사 하나뿐입니다. 관리자 행위에 감사 로그나 추가 검증이 없습니다.
     - `archive_team`은 `team_id`가 존재하는지, 대상이 적법한지 확인하지 않습니다.
     - systemd 유닛에 `User=`가 없어서 서비스가 root로 실행될 가능성이 큽니다. `NoNewPrivileges` 같은 하드닝 옵션도 없습니다. 앱이 뚫리면 서버 전체가 위험해집니다.
     - `/etc/tracker/secrets.env`의 파일 권한은 이 저장소에서 확인할 수 없습니다.

## 권고 우선순위
- 먼저 프로덕션 DB 비밀번호를 교체하세요. 그다음 git 히스토리에서 제거하고 `production.env`는 `.gitignore`에 넣으세요.
- 시크릿은 `/etc/tracker/secrets.env`나 시크릿 매니저로 옮기세요.
- 개발용과 프로덕션 비밀번호를 분리하세요.
- `sessions`와 `db` 모듈을 확보해 세션 서명, 쿠키 속성, 쿼리 매개변수화를 따로 감사하세요.
