<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0773681 -->

저장소 전체를 읽었습니다(파일 9개, 코드는 수정하지 않았습니다). 결함은 다음과 같습니다.

1. **프로덕션 DB 자격증명이 저장소에 평문으로 들어 있음** (심각)
   - 자리: `deploy/production.env:2`, `DATABASE_URL`
   - 까닭: 프로덕션 RDS 호스트와 계정(`tracker`), 비밀번호(`Tr4cker-db-2026`)가 커밋되어 있습니다. 저장소에 접근하는 사람과 백업, 포크 모두 프로덕션 DB 비밀번호를 얻습니다. 이 비밀번호는 유출된 것으로 보고 교체해야 합니다. git 이력에도 남아 있을 수 있습니다.
   - 설계도 같은 문제입니다. `deploy/tracker.service:7`은 이 파일을 `EnvironmentFile`로 읽습니다. 같은 서비스가 `/etc/tracker/secrets.env`(8행)도 읽으므로, 시크릿은 원래 그 파일에 둬야 합니다.

2. **개발용 비밀번호가 프로덕션 비밀번호와 같음**
   - 자리: `docker-compose.yml:8`, `POSTGRES_PASSWORD: Tr4cker-db-2026`
   - 까닭: compose 파일의 로컬 DB 비밀번호가 `deploy/production.env`의 프로덕션 비밀번호와 똑같습니다. 개발자 PC나 CI가 뚫리면 프로덕션 DB로 바로 이어집니다. 이 비밀번호는 compose 파일에도 하드코딩되어 있습니다. 로컬 값은 `.env`에서 받아 쓰고, 프로덕션과는 다른 값을 써야 합니다.

3. **프로덕션 DB가 네트워크로 노출되었을 가능성**
   - 자리: `deploy/production.env:2`
   - 까닭: RDS 엔드포인트의 공개 호스트명이 비밀번호와 함께 노출되어 있습니다. 보안 그룹이나 퍼블릭 접근 설정은 저장소에서 확인할 수 없습니다. RDS가 외부에서 접근 가능하면 1번 결함이 곧바로 DB 침해로 이어집니다. 인프라 쪽에서 확인이 필요합니다.

4. **세션 관리 코드가 저장소에 없고, 세션 보안을 검증할 수 없음**
   - 자리: `app/auth.py:3`(`from . import sessions`), `app/main.py:3`(`from . import db`)
   - 까닭: `sessions` 모듈과 `db` 모듈이 저장소에 없어서 `SESSION_SECRET`을 어떻게 쓰는지, 세션 서명과 만료, 팀 격리 쿼리(`db.issues.for_team`)가 안전한지 확인하지 못했습니다. 이 파일들이 .gitignore나 누락으로 빠졌다면 앱이 이 저장소만으로는 실행되지 않습니다. 검토 범위의 한계이기도 합니다.

5. **관리자 변경 동작에 CSRF 방어와 감사 기록이 없음**
   - 자리: `app/main.py:19-21`, `archive_team`
   - 까닭: `sid` 쿠키만으로 인증하는 상태 변경 `POST`입니다. 쿠키의 `SameSite` 설정은 `sessions` 모듈에 달려 있는데 저장소에 없어서 확인할 수 없습니다. 쿠키가 `SameSite=None`이거나 설정이 없으면, 관리자가 악성 페이지를 열 때 팀이 보관 처리될 수 있습니다. CSRF 토큰도, 누가 보관했는지 남기는 로그도 없습니다.

6. **`current_user`에서 쿠키 이름이 단순하고 기본 보호가 보이지 않음**
   - 자리: `app/auth.py:7`, `request.cookies.get("sid", "")`
   - 까닭: 세션 ID를 빈 문자열 기본값으로 `sessions.load`에 넘깁니다. `load`가 빈 값과 위조된 값을 안전하게 거부하는지는 확인하지 못했습니다. 이 점은 4번과 같은 이유로 미확인입니다.

7. **서비스 유닛의 권한 경계가 느슨함**
   - 자리: `deploy/tracker.service:5-9`
   - 까닭: `User=`가 없어서 서비스가 root로 실행됩니다. `NoNewPrivileges`, `ProtectSystem`, `PrivateTmp` 같은 하드닝도 없습니다. 앱이 뚫리면 서버 전체가 넘어갑니다. 또 `/srv/tracker/deploy/production.env`는 저장소 체크아웃 안에 있어서, 앱과 같은 권한으로 읽히고 배포 도구를 거치면 노출되기 쉽습니다.

8. **`.env.example`의 안내와 `settings.py`의 검증이 약함**
   - 자리: `.env.example:1-2`, `app/settings.py:3-4`
   - 까닭: 예시 값(`CHANGEME`, `<여기에 생성한 값을 넣으세요>`)을 그대로 두어도 앱이 시작됩니다. `SESSION_SECRET`의 길이나 엔트로피 검사가 없어서 약한 값이나 자리표시자 문자열이 프로덕션에 들어갈 수 있습니다. 생성 방법(`openssl rand -hex 32` 등)도 안내가 없습니다. `.gitignore`가 없어서 `.env`가 실수로 커밋될 위험도 있습니다.

**우선순위:** 1번과 2번이 확정된 결함입니다. 프로덕션 DB 비밀번호를 지금 교체하고, 저장소 이력에서도 제거하세요. 4번에서 6번은 누락된 모듈 때문에 확인하지 못한 항목이라, 그 파일을 받으면 다시 검토해야 합니다.
