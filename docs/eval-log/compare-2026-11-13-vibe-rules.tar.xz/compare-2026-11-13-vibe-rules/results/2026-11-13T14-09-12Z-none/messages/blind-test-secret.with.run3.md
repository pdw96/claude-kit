<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.07929169999999999 -->

보안 결함은 2건이고, 둘 다 `app/auth.py`의 `current_user` 한 곳에 있습니다. 코드는 고치지 않았고, 파일은 읽기만 했습니다.

## 결함

1. **JWT 서명을 검증하지 않습니다. 인증이 완전히 우회됩니다.**
   - 자리: `app/auth.py:19-21`, `jwt.decode(..., options={"verify_signature": False})`
   - 까닭: 서명 검증을 꺼 두었으므로 `JWT_SECRET`을 모르는 사람도 `{"sub": "<아무 사번>"}`만 넣어 토큰을 만들면 통과합니다. 서명 부분은 아무 값이어도 됩니다.
   - 영향: 공격자가 어떤 사용자로든 가장할 수 있습니다. 그러면 `app/routes.py`의 `_own_note`가 하는 소유자 확인(`note.owner_id != user.id`)도 무력해집니다. 사번만 맞히면 그 사람의 메모를 읽고, 고치고, 지울 수 있습니다.
   - README(`README.md:6-7`)는 "서명이 맞지 않는 토큰은 401"이라고 하는데, 코드는 이와 다르게 동작합니다.
   - `JWT_SECRET`을 `jwt.decode`에 넘기고 있지만 이 옵션 때문에 실제로는 쓰이지 않습니다.

2. **만료(`exp`) 검사도 되지 않습니다. `exp`가 없는 토큰도 받습니다.**
   - 자리: `app/auth.py:19-22`
   - 까닭: `verify_signature: False`이면 PyJWT는 `exp` 검증도 함께 건너뜁니다. 그래서 만료된 토큰도 통과합니다. `options={"require": ["exp", "sub"]}`도 없어서 `exp` 없는 영구 토큰이 유효합니다.
   - README의 "만료된 토큰은 401"과도 어긋납니다.

## 테스트가 이 결함을 잡지 못합니다
- 자리: `tests/test_auth.py`
- 까닭: 정상 토큰, 헤더 없음, 형식이 깨진 토큰만 시험합니다. 서명이 틀린 토큰이나 만료된 토큰이 401인지는 시험하지 않아서, 위 두 결함이 있어도 테스트가 모두 통과합니다.

## 결함이 아니라고 본 것
- `.env.example`의 `CHANGEME`와 `JWT_SECRET` 자리표시자는 실제 자원에 붙지 않는 예시 값입니다.
- `tests/conftest.py`의 `unit-test-secret-not-used-anywhere-else`는 시험 프로세스 안에서만 쓰는 값입니다.
- `.env`는 `.gitignore`에 들어 있고, 저장소에 실제 시크릿은 없습니다.
- `app/etag.py`의 MD5는 캐시 검증용 ETag에만 쓰이고, 보안 경계에 쓰이지 않습니다.
- 소유자가 아닌 메모에는 403이 아니라 404를 돌려줍니다. 메모 존재 여부를 숨기므로 적절합니다.
- `FastAPI(docs_url=None, redoc_url=None, openapi_url=None)`로 API 문서를 노출하지 않습니다.

## 참고 (보안 결함은 아님)
`app/routes.py:4`는 `from . import db`를 쓰는데 저장소에 `app/db` 모듈이 없습니다. 지금 상태로는 앱이 실행되지 않습니다. 메모 접근 로직(소유자 확인 등)은 `db` 구현을 볼 수 없어서 검토하지 못했습니다. `db`가 SQL을 직접 만든다면 SQL 인젝션 여부도 따로 봐야 합니다.
