<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0986753 -->

결함은 하나 확인했고, 위험 한 건은 따로 적습니다. 코드는 고치지 않았고 읽기만 했습니다. 기준 문서는 `INTENT.md`, `CLAUDE.md`, `docs/master-plan.md`, `docs/slices/1-booking`, `docs/slices/2-settlement`입니다.

## 결함

**1. 취소가 예약 행을 지웁니다.**
- 자리: `app/bookings.py:26-29`의 `cancel()`. `delete(bookings).where(...)`를 실행하고, 이를 `app/main.py:18-22`의 `POST /bookings/{id}/cancel`이 부릅니다.
- 어긴 규칙:
  - `CLAUDE.md` 앵커볼트: "`app/` 의 코드는 예약 행을 지우지 않는다 — 취소는 `cancelled_at` 을 채운다. 월 정산이 취소 건수를 센다." 바꾸려면 먼저 물어보라고 한 항목입니다.
  - `docs/slices/1-booking/design.md` ②·④: 취소한 예약은 행이 남고 `cancelled_at`이 찹니다.
- 까닭과 영향:
  - 취소하면 행이 사라져서 `app/settlement.py:20-23`의 취소 건수가 항상 0입니다. 조각 2의 성공 기준(입주사별 취소 건수)이 운영에서 나오지 않습니다.
  - `cancelled_at`을 채우는 곳이 `app/`에 없습니다. 그래서 `active()`와 `book()`이 `cancelled_at.is_(None)`으로 거르는 조건도 실제로는 쓰이지 않습니다.
  - `tests/test_settlement.py`는 행을 직접 `insert`해서 시험합니다. 그래서 `cancel()` 경로의 이 문제를 잡지 못합니다.

## 위험 (규칙 위반은 아님)

**2. 겹침 검사가 동시 요청에 약합니다.**
- 자리: `app/bookings.py:11-22`의 `book()`.
- 까닭: 겹침을 조회한 뒤 삽입하는 방식이고, DB 제약은 없습니다. 같은 방 같은 시간에 요청이 동시에 들어오면 둘 다 통과할 수 있습니다. 이는 `docs/slices/1-booking/design.md` ②가 보장한다고 한 "살아 있는 예약끼리 겹치지 않는다"와 어긋날 수 있습니다. 다만 SQLite 쓰기 직렬화 정도에 따라 달라지므로 재현은 해 보지 않았습니다.

## 결함이 아니라고 가른 것

- **`scripts/import_legacy.py`의 pandas**: `CLAUDE.md`와 조각 2 설계 ④가 일회성 이전 스크립트는 스택 제한 밖이고 dev 의존성(pandas)을 써도 된다고 정했습니다. `pyproject.toml`에서도 pandas는 `dev`에만 있고 `app/`은 pandas를 가져오지 않습니다.
- **정산의 달 경계 계산**: 12월에서 다음 해 1월로 넘어가는 경우를 포함해 맞습니다. 시작 시각 기준 집계도 설계 ②와 같습니다.
- **`tests/test_settlement.py`의 `delete(bookings)`**: `app/` 밖의 임시 DB에서만 돕니다.
- **자리표시자·비밀번호 값**: 저장소에 없습니다.
- **「하지 않을 일」 위반**: 의도 문서와 조각 요구사항 어느 쪽도 어긴 코드가 없습니다.
