<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.20505120000000002 -->

`audit-internal` 감사자를 저장소 전체에 돌렸고, 규칙을 어긴 결함은 1건 나왔습니다. 코드는 고치지 않았습니다.

감사자가 기준으로 삼은 문서는 `CLAUDE.md`, `INTENT.md`, `docs/master-plan.md`, 조각 1·2 `requirements.md`/`design.md`입니다. README, ADR, `CHECKLIST.md`는 저장소에 없습니다.

## 결함

**NC-1: 예약 취소가 행을 삭제함 (심각도 높음)**
- **자리:** `app/bookings.py:26-29`의 `cancel()`, 특히 28줄입니다. `delete(bookings).where(bookings.c.id == booking_id)`를 실행합니다. 이 함수는 `app/main.py:18-22`의 `/bookings/{id}/cancel`이 호출합니다.
- **어긴 규칙:** `CLAUDE.md:11`은 "`app/`의 코드는 예약 행을 지우지 않는다. 취소는 `cancelled_at`을 채운다. 월 정산이 취소 건수를 센다"고 정했습니다. `docs/slices/1-booking/design.md`의 ②와 ④도 같은 내용입니다.
- **까닭:** `app/` 안에 `cancelled_at`을 채우는 경로가 없습니다. 그래서 `app/settlement.py:22-23`의 취소 건수는 `scripts/import_legacy.py`로 옮긴 옛 기록에서만 0이 아닌 값이 나옵니다. 새로 취소한 예약은 정산에서 빠집니다. 삭제된 행은 복구할 수 없습니다.
- **어느 쪽이 틀렸나:** 코드입니다. 문서 세 곳은 서로 일치합니다. 앵커볼트 규칙이므로 문서를 바꾸려면 사람이 먼저 결정해야 합니다.
- **제안:** `cancel()`을 `cancelled_at`을 채우는 `update`로 바꿉니다. 취소 후 정산 건수가 오르는 시험을 `tests/`에 추가합니다. `app/`에서 `delete(`를 grep하는 CI 검사도 둘 수 있습니다.

## 판정하지 못한 것
- **U-1:** 운영 DB에서 이미 삭제된 취소 건이 몇 건인지는 알 수 없습니다. 운영 배포 여부와 배포 뒤 취소 요청 수를 알아야 합니다. 배포 기록이나 접근 로그, DB 백업과 대조해야 합니다.

## 문서에 없어서 결함으로 세지 않은 것
- `/admin/settlement`에 인증·권한이 없습니다. 문서에 요구가 없습니다.
- `scripts/import_legacy.py`가 중복 실행을 막지 않습니다. 같은 CSV를 두 번 돌리면 중복 행이 들어갑니다. "2026년 1~8월" 범위도 검사하지 않고, 취소 행과 살아 있는 예약의 겹침도 검사하지 않습니다.
- 존재하지 않는 회의실 이름에 대한 규칙이 없습니다.
- **OB-1:** `app/main.py:20-21`은 이미 취소된 건과 없는 건을 둘 다 404로 응답합니다. 재취소 동작을 정한 문서가 없습니다. NC-1을 고치면 이 동작도 정해야 합니다.

## 이 감사에서 본 범위가 아닌 것
- **트랜잭션:** 겹침 검사와 삽입 사이의 경합(`app/bookings.py:11-22`)은 `audit-data` 담당입니다.
- **시험과 CI:** 취소 경로에 시험이 없습니다. CI 유무와 함께 `audit-quality` 담당입니다.
- **인증과 환경 변수:** `/admin/settlement` 인증과 `ROOMS_DB` 값 취급은 `audit-secrets` 담당입니다.
- **API 모양:** 쿼리 파라미터 기반 POST API의 모양과 상태 코드는 `audit-contract` 담당입니다.

이번이 첫 회차라 비교할 지난 기록은 없습니다. 감사자는 기록을 `.claude/audits/audit-internal-2026-11-13-<시각>.md`로 저장하라고 했습니다. 읽기 전용 감사였으므로 저장하지 않았습니다.
