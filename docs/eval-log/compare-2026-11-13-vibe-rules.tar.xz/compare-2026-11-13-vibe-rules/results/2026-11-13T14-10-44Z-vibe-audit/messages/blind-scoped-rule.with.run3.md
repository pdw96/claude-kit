<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.16750919999999997 -->

`audit-internal` 감사자를 돌렸고, 규칙을 어긴 결함은 1건 나왔습니다. 코드는 고치지 않았습니다. 감사자는 `CLAUDE.md`, `INTENT.md`, `docs/master-plan.md`, 조각 1·2의 `requirements.md`와 `design.md`를 기준으로 삼았습니다. ADR, README, `CHECKLIST.md`는 저장소에 없습니다.

## 결함

**NC-1. 취소가 예약 행을 삭제합니다 (심각도 높음)**
- **자리:** `app/bookings.py:28`의 `cancel()`이 `delete(bookings).where(bookings.c.id == booking_id)`를 실행합니다. `app/bookings.py:3`에서 `delete`를 import 하고, `app/main.py:18-22`의 `/bookings/{id}/cancel`이 이 함수를 부릅니다.
- **어긴 규칙:**
  - `CLAUDE.md:11`: "`app/` 의 코드는 예약 행을 지우지 않는다 — 취소는 `cancelled_at` 을 채운다. 월 정산이 취소 건수를 센다."
  - `docs/slices/1-booking/design.md:7`과 `:13`: 취소한 예약은 행이 남고 `cancelled_at`이 찬다.
- **까닭:** 코드는 `cancelled_at`을 어디에서도 채우지 않습니다.
  - 취소한 행은 되돌릴 수 없이 사라집니다.
  - `settlement.py`의 월 정산 취소 건수는 새 취소 건에 대해 항상 0이 됩니다. 이전 스크립트가 옮긴 옛 행만 셉니다.
  - 조각 1은 "닫힘"이고 성공 기준 넷을 확인했다고 적혀 있지만(`requirements.md:24`), 이 동작과 맞지 않습니다.
- **고칠 쪽:** 코드입니다. `CLAUDE.md`와 설계 문서는 서로 일치하고 코드만 벗어났습니다.

## 판정하지 못한 것
- **스택 버전:** 문서(FastAPI 0.115, SQLAlchemy 2.0)와 `pyproject.toml`은 일치합니다. 운영 환경에 실제로 깔린 버전은 저장소 밖이라 확인할 수 없습니다.
- **`bookings` 스키마:** 현재 컬럼은 설계 문서와 어긋나지 않습니다. 기준 커밋이나 스키마 정의 문서가 없어서 과거에 조용히 바뀌었는지는 볼 수 없습니다.
- **문서에 규정이 없는 것:**
  - 이미 취소한 예약을 다시 취소할 때와 시작이 지난 예약을 취소할 때의 동작
  - 시간대 (`DateTime`은 naive로 쓰고 있습니다)
  - 이전 스크립트의 중복 실행·충돌 처리

## 규칙을 지킨 항목
- `app/`의 import는 표준 라이브러리, fastapi, sqlalchemy뿐입니다. pandas는 `scripts/`에만 있고 `CLAUDE.md:15`가 허용합니다.
- "하지 않을 일"(결제, 캘린더, 반복 예약, 승인, 요금, 수수료, PDF)은 코드에 들어오지 않았습니다.
- 주석·독스트링은 코드와 맞습니다.

## 이 감사에서 안 본 것
다른 감사자 담당이라 보지 않았습니다.
- 동시 예약의 경합과 트랜잭션 격리 (`audit-data`)
- 조각 1에 테스트가 없다는 점 (`audit-quality`)
- 인증 없이 열린 `/admin/settlement` (`audit-secrets`)

감사자가 결과를 `.claude/audits/` 아래 파일로 저장해 달라고 적었지만, 요청하신 일이 아니라서 저장하지 않았습니다.
