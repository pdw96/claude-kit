<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.1505735 -->

`audit-secrets` 감사자를 저장소 전체에 돌렸고, 확정된 결함은 1건입니다. 인증과 권한 쪽은 판정에 필요한 파일이 저장소에 없어서 확인하지 못했습니다. 코드는 고치지 않았습니다.

## 확정된 결함

**NC-1: 프로덕션 DB 비밀번호가 평문으로 저장소에 있고, 개발용 비밀번호와 같습니다. (심각도 높음)**
- 자리:
  - `deploy/production.env:2` (`DATABASE_URL`)
  - `docker-compose.yml:8`
- 까닭:
  - `production.env`에 실제 RDS 호스트(`tracker-prod…ap-northeast-2.rds.amazonaws.com`), 사용자 `tracker`, 비밀번호가 그대로 들어 있습니다. 이 저장소를 볼 수 있는 사람은 누구나 프로덕션 DB 자격증명을 얻습니다.
  - `README.md:4`는 서버가 이 저장소를 받아 그대로 돌린다고 적고, `tracker.service:7`은 이 파일을 `EnvironmentFile`로 읽습니다. 그래서 이 값은 실제 프로덕션에서 쓰입니다.
  - `docker-compose.yml:8`의 로컬 DB 비밀번호가 프로덕션과 같은 값입니다. 로컬 환경이 유출되면 프로덕션도 뚫립니다.
  - `.gitignore`가 없고 커밋도 아직 없습니다. 커밋하면 이력에 남고, 이력에 남은 비밀번호는 파일을 지워도 회수되지 않습니다.
  - RDS가 인터넷에서 닿는지는 저장소로 알 수 없어서, 닿는 것으로 가정해 심각도를 높게 잡았습니다.

## 확인하지 못한 항목

| # | 자리 | 막힌 까닭 |
|---|---|---|
| U-1 | `app/auth.py:3,7`, `app/main.py` | `app/sessions.py`와 `app/db`가 저장소에 없습니다. 세션 서명과 검증, 만료, 쿠키 속성(`HttpOnly`/`Secure`/`SameSite`), 로그인 경로, CORS 설정을 판정하지 못했습니다. 라우트마다 `Depends`가 걸려 있지만 검사의 실체를 볼 수 없습니다. |
| U-2 | `app/main.py:19-21` (`archive_team`) | `admin`이 전역 관리자인지 팀별 관리자인지 알 수 없습니다. 팀별 관리자라면 `team_id` 소유 확인이 없어서 결함입니다. `list_issues`(`app/main.py:9-11`)는 `user.team_id`로 범위를 한정하고 있어 문제없습니다. |
| U-3 | `deploy/production.env:3` | 로깅 설정과 예외 핸들러 코드가 없어서 로그나 에러 응답에 민감정보가 나가는지 판단하지 못했습니다. |
| U-4 | RDS 설정 | 퍼블릭 접근 설정과 보안 그룹은 AWS 쪽 정보라 저장소로는 볼 수 없습니다. |

## 참고
- 소스에 박힌 우회 분기나 디버그 플래그는 읽은 `app/*.py` 범위에서는 없었습니다.
- LLM 호출 코드가 없어서 프롬프트 시크릿과 모델 도구 권한 항목은 해당 없음입니다.
- `tracker.service`에 `User=`가 없고 `uvicorn`이 `--host` 없이 뜹니다. 서비스 하드닝과 운영 문제라 `audit-ops` 몫입니다.
- 감사자 보고서가 `.claude/audits/`에 기록 파일을 저장하라고 했지만, 코드를 고치지 말라는 요청이라 만들지 않았습니다. 필요하면 말씀해 주세요.

U-1과 U-2를 판정하려면 `app/sessions.py`, `app/db` 소스와 관리자 권한 범위에 대한 제품 쪽 답이 필요합니다.
