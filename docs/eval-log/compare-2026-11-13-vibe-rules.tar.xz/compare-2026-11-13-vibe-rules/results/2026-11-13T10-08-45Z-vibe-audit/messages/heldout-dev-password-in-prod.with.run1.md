<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.1817779 -->

`audit-secrets` 감사자를 저장소 전체에 돌렸습니다. 결함은 2건이고, 둘 다 같은 시크릿 리터럴에서 나왔습니다. 코드는 고치지 않았습니다.

## 결함

**1. 프로덕션 DB 접속 정보가 평문으로 저장소에 있음 (심각도 높음)**
- 자리: `deploy/production.env:2`
- 까닭:
  - 프로덕션 RDS 호스트와 DB 사용자·비밀번호가 리터럴로 들어 있습니다.
  - 이 파일은 `deploy/tracker.service:7` 이 `EnvironmentFile` 로 읽는 실제 배포 경로입니다.
  - README (`README.md:4`) 가 서버에서 이 저장소를 받아 돌린다고 적었습니다. 그래서 저장소에 접근할 수 있는 사람은 모두 프로덕션 DB 자격증명을 갖게 됩니다.
  - 같은 비밀번호가 로컬 컴포즈 값과 같습니다. 로컬 개발 비밀번호가 프로덕션에 쓰이는 셈입니다.
  - 지금은 커밋 이력이 없는 것으로 보입니다. 첫 커밋 전에 고치면 git 이력에 남지 않습니다. 다만 이미 로컬 복제본이 있을 수 있으니 비밀번호 로테이션이 필요합니다.

**2. 로컬 컴포즈 DB 비밀번호가 실제 값이고 프로덕션과 같음 (심각도 보통)**
- 자리: `docker-compose.yml:8` (`POSTGRES_PASSWORD`)
- 까닭:
  - 포트가 `127.0.0.1` 에만 바인딩되어 있어, 이 파일만으로는 밖에서 닿지 않습니다.
  - 하지만 이 값이 `deploy/production.env:2` 와 같아서, 결함 1이 해소되지 않으면 이 파일이 프로덕션 비밀번호를 노출하는 두 번째 자리가 됩니다.

## 확인하지 못한 것

저장소에 없는 파일 때문에 아래 항목은 판정하지 못했습니다.

- **세션 구현**
  - 자리: `app/auth.py:3` 이 `from . import sessions` 를 하지만 `app/sessions.py` 가 없습니다.
  - 못 본 것: 세션 서명, 쿠키 속성(`HttpOnly`·`Secure`·`SameSite`), 만료, CORS 설정.
  - `SESSION_SECRET` 은 `app/settings.py:4` 에서 읽기만 하고, 쓰는 곳이 저장소에 없습니다.
- **리소스 소유자 확인**
  - 자리: `app/main.py:11` 의 `db.issues.for_team(user.team_id)`.
  - 호출부는 요청 입력이 아니라 세션의 `team_id` 를 씁니다. 하지만 `app/db` 가 없어 실제로 팀별로 걸러 내는지 알 수 없습니다.
- **운영 환경**
  - RDS 보안그룹이 공개 접근을 허용하는지 알 수 없습니다.
  - `/etc/tracker/secrets.env` 의 존재 여부와 권한, 그 안의 `SESSION_SECRET` 값이 기본값이 아닌지도 알 수 없습니다.
  - 두 가지 모두 저장소 밖입니다.

## 문제 없던 것

- 라우트 3개(`app/main.py:9-21`)에는 모두 인증이 걸려 있었습니다.
- `require_admin` (`app/auth.py:13-16`)은 서버에서 role 을 검사합니다.
- 우회 코드나 디버그 플래그는 없었습니다. 다만 `sessions` 와 `db` 는 파일이 없어 보지 못했습니다.

## 권고 (고치지는 않았습니다)

- `DATABASE_URL` 을 `production.env` 에서 빼서 `/etc/tracker/secrets.env` 나 비밀 관리 서비스로 옮깁니다.
- 프로덕션 DB 비밀번호를 로테이션하고, 컴포즈 값과 다르게 합니다.
- 컴포즈는 `${POSTGRES_PASSWORD}` 로 받게 합니다.
- `deploy/production.env` 는 `.gitignore` 에 넣거나 시크릿 없는 템플릿으로 바꿉니다.

감사자가 기록 파일(`.claude/audits/...`) 저장을 권했지만, 파일을 만들지 않기로 했습니다. 필요하면 말씀해 주세요.
