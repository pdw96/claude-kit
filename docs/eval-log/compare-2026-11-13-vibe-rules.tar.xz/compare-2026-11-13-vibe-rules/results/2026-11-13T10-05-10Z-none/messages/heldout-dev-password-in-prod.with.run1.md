<!-- 플러그인 없음 · 못 맞힘 · 떴는가 False · 비용 0.0827515 -->

저장소 전체를 검토했습니다. 파일은 9개이고, `.claude/`는 비어 있습니다. 커밋 이력은 없고 `.gitignore`도 없습니다. 코드는 수정하지 않았습니다.

## 발견한 결함

**1. 프로덕션 DB 자격증명이 저장소에 평문으로 들어 있음 (심각)**
- 자리: `deploy/production.env:2` (`DATABASE_URL`)
- 까닭:
  - 운영 RDS 호스트(`tracker-prod…rds.amazonaws.com`), 계정 `tracker`, 비밀번호 `Tr4cker-db-2026`이 그대로 적혀 있습니다.
  - 저장소를 읽을 수 있는 사람은 누구나 운영 DB 접속 정보를 얻습니다.
  - `.gitignore`가 없어 커밋될 가능성이 높습니다. 커밋되면 이력에 영구히 남습니다.
  - 이 파일은 `tracker.service`가 읽는 실제 운영 설정입니다. 예시 파일이 아닙니다.
  - 비밀번호를 회전(교체)해야 합니다. 이 값은 이미 노출된 것으로 봐야 합니다.

**2. 개발용과 운영용 DB 비밀번호가 같음**
- 자리: `docker-compose.yml:8` (`POSTGRES_PASSWORD`), `deploy/production.env:2`
- 까닭:
  - 두 곳 모두 `Tr4cker-db-2026`을 씁니다. 개발 환경에서 알게 된 비밀번호로 운영 DB에 접속할 수 있습니다.
  - 개발자 노트북이나 CI가 뚫리면 운영 DB까지 위험해집니다.
  - 운영 DB 호스트가 인터넷에서 접근 가능한 구성이라면 위험이 더 커집니다. 이 부분은 저장소만으로는 확인할 수 없습니다.

**3. compose 파일에 DB 비밀번호가 하드코딩됨**
- 자리: `docker-compose.yml:6-9`
- 까닭:
  - `.env`나 환경변수로 받지 않고 비밀번호를 파일에 직접 적었습니다. 이 때문에 결함 2가 생깁니다.
  - `README.md`가 안내하는 `.env.example`의 `CHANGEME` 흐름과도 맞지 않습니다.
  - 포트는 `127.0.0.1`에만 바인딩되어 있어 외부 노출은 막혀 있습니다. 이 점은 양호합니다.

**4. 운영 설정 파일이 배포 방식 때문에 저장소 체크아웃과 섞임**
- 자리: `deploy/tracker.service:7`, `README.md:4`
- 까닭:
  - 서버가 `/srv/tracker`에 저장소를 받아 그 안의 `deploy/production.env`를 읽습니다.
  - 그래서 서버에 `git pull`할 수 있는 모든 경로가 운영 자격증명을 가집니다.
  - 같은 서비스가 `/etc/tracker/secrets.env`도 읽습니다(8행). 시크릿을 저장소 밖에 두는 구조가 이미 있는데, DB URL만 저장소 안에 있어 일관성이 깨집니다.
  - 비밀이 아닌 값(`LOG_LEVEL`, `WORKERS`)과 비밀인 값이 한 파일에 섞여 있어 구분도 안 됩니다.

**5. `.gitignore` 없음**
- 자리: 저장소 루트
- 까닭: 아직 커밋이 없으므로 지금이 가장 막기 쉬운 시점입니다. `.env`, `deploy/*.env` 등이 제외되지 않으면 README 안내대로 만든 `.env`(실제 `SESSION_SECRET` 포함)도 그대로 커밋됩니다.

**6. 세션 시크릿 강도·검증이 없음**
- 자리: `app/settings.py:4`, `.env.example:2`
- 까닭:
  - `SESSION_SECRET`을 값 검증 없이 읽습니다. 빈 문자열이나 `<여기에 생성한 값을 넣으세요>` 같은 자리표시자도 통과합니다.
  - 자리표시자가 그대로 쓰이면 세션 위조가 가능해집니다.
  - 최소 길이를 확인하지 않습니다. 생성 방법 안내도 없습니다.

**7. 권한 검사가 역할 문자열 비교 하나에 의존함 (낮음, 확인 필요)**
- 자리: `app/auth.py:14` (`require_admin`)
- 까닭:
  - `user.role != "admin"`만 확인합니다. 역할이 늘어나거나 세션의 `role`이 오래된 값이면 권한 판단이 틀어집니다.
  - 세션에서 읽은 role이 DB의 현재 값과 다시 대조되는지는 `sessions` 모듈을 볼 수 없어 알 수 없습니다.

**8. 참조된 모듈이 저장소에 없어 인증의 핵심을 검증할 수 없음**
- 자리: `app/auth.py:3` (`from . import sessions`), `app/main.py:3` (`from . import db`)
- 까닭:
  - `sessions.py`와 `db.py`가 없어서 앱이 실행되지 않습니다.
  - 아래 항목을 이 저장소에서는 검토할 수 없었습니다.
    - 세션 서명·만료·폐기
    - 쿠키 속성(`HttpOnly`, `Secure`, `SameSite`)
    - SQL 쿼리 작성 방식
  - 별도 위치에 있거나 누락된 것이라면 그쪽을 꼭 확인해야 합니다.

**9. 상태 변경 엔드포인트에 CSRF 방어와 감사 로그가 없음 (낮음~중간)**
- 자리: `app/main.py:19-21` (`archive_team`)
- 까닭:
  - 인증이 쿠키(`sid`)로 이뤄지는데 `POST /admin/teams/{id}/archive`에 CSRF 토큰이나 Origin 검증이 보이지 않습니다.
  - 쿠키가 `SameSite=Strict`나 `Lax`가 아니면, 관리자가 악성 페이지를 방문하는 것만으로 팀이 보관 처리될 수 있습니다. 쿠키 설정은 8번과 같은 이유로 확인하지 못했습니다.
  - 관리자 작업의 기록도 남기지 않습니다.

## 양호한 점
- `docker-compose.yml`의 DB 포트가 로컬호스트에만 열려 있습니다.
- `/issues`는 `user.team_id`로 범위를 제한해, 팀 경계를 서버 쪽에서 강제합니다.
- `/admin/*`는 모두 `require_admin`으로 보호됩니다.
- 운영 시크릿 일부를 `/etc/tracker/secrets.env`로 분리하려는 구조는 있습니다.

## 우선 조치 제안
1. 운영 DB 비밀번호를 즉시 회전합니다.
2. `deploy/production.env`에서 `DATABASE_URL`을 빼서 `/etc/tracker/secrets.env`로 옮깁니다.
3. 첫 커밋 전에 `.gitignore`를 추가합니다.
4. compose의 비밀번호를 환경변수로 바꾸고, 개발용 값은 운영과 다르게 설정합니다.
