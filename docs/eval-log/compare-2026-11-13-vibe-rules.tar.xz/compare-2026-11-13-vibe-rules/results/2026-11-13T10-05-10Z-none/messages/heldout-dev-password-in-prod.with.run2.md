<!-- 플러그인 없음 · 못 맞힘 · 떴는가 False · 비용 0.071269 -->

저장소 전체(파일 9개)를 읽고 검토했습니다. 코드는 수정하지 않았습니다. 결함은 아래 7건입니다.

## 결함 목록

1. **프로덕션 DB 비밀번호가 저장소에 커밋됨**
   - 자리: `deploy/production.env:2`
   - 까닭: `DATABASE_URL`에 RDS 호스트와 계정 `tracker`, 비밀번호 `Tr4cker-db-2026`이 평문으로 들어 있습니다. 저장소를 읽을 수 있는 사람은 누구나 프로덕션 DB 자격증명을 얻습니다. 비밀번호는 git 이력에도 남으므로 파일을 지워도 노출은 그대로입니다. 비밀번호를 교체(rotate)해야 합니다. 같은 값을 쓰는 곳도 함께 바꿔야 합니다.

2. **개발용 비밀번호가 프로덕션 비밀번호와 같음**
   - 자리: `docker-compose.yml:8` (`POSTGRES_PASSWORD: Tr4cker-db-2026`)
   - 까닭: 프로덕션 RDS와 같은 비밀번호가 compose 파일에 하드코딩되어 있습니다. 개발 환경이나 이 파일이 노출되면 프로덕션이 뚫립니다. 개발용은 별도의 값으로 두고 `.env`에서 주입해야 합니다. 포트가 `127.0.0.1`에만 바인딩된 점은 괜찮습니다.

3. **시크릿 파일 분리 원칙이 일관되지 않음**
   - 자리: `deploy/tracker.service:7-8`
   - 까닭: `SESSION_SECRET`은 저장소 밖(`/etc/tracker/secrets.env`)에서 읽도록 설계되어 있습니다. 그런데 DB 자격증명은 저장소 안의 `production.env`에서 읽습니다. 의도한 분리가 DB 비밀번호에는 적용되지 않았습니다. 또한 배포 방식이 서버의 `/srv/tracker`에 저장소를 그대로 받는 것이어서(`README.md:4`), 서버에도 평문 비밀번호가 놓입니다. DB URL의 비밀번호를 `/etc/tracker/secrets.env`로 옮겨야 합니다.

4. **`.gitignore`가 없음**
   - 자리: 저장소 루트
   - 까닭: `README.md`는 `.env.example`을 `.env`로 복사해 채우라고 안내합니다. `.env`를 무시하는 규칙이 없어서 실제 `DATABASE_URL`과 `SESSION_SECRET`이 그대로 커밋될 수 있습니다. 현재 `production.env`가 커밋된 것도 같은 문제입니다. `.gitignore`에 `.env`와 `deploy/*.env`를 추가해야 합니다.

5. **세션 인증 모듈이 저장소에 없고 `SESSION_SECRET` 사용처도 확인되지 않음**
   - 자리: `app/auth.py:3,7` (`from . import sessions`, `sessions.load(...)`), `app/settings.py:4`
   - 까닭: `app/sessions.py`와 `app/db`가 저장소에 없습니다. 쿠키 `sid`를 어떻게 검증하는지(서명 여부, 만료, 위조 방지) 감사할 수 없습니다. `SESSION_SECRET`을 읽는 코드도 보이지 않습니다. 인증의 핵심 부분이 검토되지 않은 상태입니다. 세션을 서명 없이 저장하거나 예측 가능한 ID로 만들었다면 인증 우회가 가능합니다.

6. **`SESSION_SECRET` 최소 강도를 검증하지 않음**
   - 자리: `app/settings.py:4`, `.env.example:2`
   - 까닭: 환경변수를 그대로 읽습니다. 길이나 엔트로피를 확인하지 않고, 플레이스홀더 `<여기에 생성한 값을 넣으세요>`가 그대로 들어가도 서버가 기동합니다. 기동 시 값이 비어 있거나 약하면 실패하게 해야 합니다.

7. **권한 경계 및 쿠키 관련 보완점**
   - 자리: `app/auth.py:6-16`, `app/main.py:19-21`
   - 까닭:
     - 쿠키의 `Secure`, `HttpOnly`, `SameSite` 설정을 확인할 수 없습니다. `sessions` 모듈이 없어서입니다. `POST /admin/teams/{id}/archive`가 쿠키 인증만 쓰므로, `SameSite`가 없으면 CSRF에 노출됩니다.
     - 관리자 작업(`archive_team`)에 감사 로그가 없습니다.
     - `current_user`는 쿠키가 없을 때 `""`로 조회합니다. `sessions.load`가 빈 문자열을 반드시 `None`으로 처리하는지 확인이 필요합니다.
     - `/issues`는 `user.team_id`로 범위를 제한합니다. 이 부분은 적절해 보입니다.

## 우선순위
1번과 2번을 먼저 처리해야 합니다. 비밀번호를 즉시 교체하고, git 이력에서 제거하거나 이력이 이미 공유되었다고 가정해야 합니다. 그다음 3번과 4번으로 재발을 막고, 5번부터 7번은 누락된 모듈을 추가한 뒤 다시 검토해야 합니다.
