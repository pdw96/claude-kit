<!-- 플러그인 없음 · 못 맞힘 · 떴는가 False · 비용 0.0837051 -->

보안 결함을 점검한 결과입니다. 저장소 전체(코드 7개, CI 설정, 문서)를 읽었고 코드는 수정하지 않았습니다. `.claude/`에는 파일이 없었습니다.

## 결함

1. **높음: 청구서 접근 제어 누락 (IDOR/BOLA)**
   - 자리: `app/routes.py`의 `get_invoice` (16–21행)
   - 까닭: `db.invoices.get(invoice_id)`로 조회한 뒤 `inv.owner_id != user.id`를 확인하지 않고 그대로 반환합니다. 로그인한 사용자는 정수 ID를 바꿔 가며 다른 사용자의 청구서를 읽을 수 있습니다. 같은 파일의 `invoice_pdf`(27행)와 `list_invoices`는 소유자를 확인하므로 이 핸들러만 빠져 있습니다. `docs/api.md`는 "내 청구서 하나"라고 적고 있어 문서와 동작도 어긋납니다.

2. **중간: 토큰 서명 키가 없거나 약해도 서버가 뜸**
   - 자리: `app/settings.py` 4행, `tests/conftest.py` 5행, `app/auth.py`
   - 까닭: `TOKEN_SIGNING_KEY`는 존재 여부만 확인합니다. 빈 문자열이나 짧은 키도 통과하므로 HMAC 위조가 쉬워집니다. 테스트 키 `test-only-signing-key`는 저장소에 공개돼 있습니다. 운영 환경에서 `TOKEN_SIGNING_KEY`가 비어 있거나 이 값으로 잘못 설정되면 누구나 임의 사용자 토큰을 만들 수 있습니다. `setdefault`는 환경에 값이 없을 때 테스트 값을 채우지만, 운영 코드가 conftest를 거치지 않으므로 그 경로 자체는 안전합니다. 다만 키 길이나 값에 대한 검증이 없습니다.

3. **중간: 토큰 검증 로직의 방어 부족**
   - 자리: `app/tokens.py`의 `verify` (9–20행)
   - 까닭:
     - `except (ValueError, KeyError)`만 잡습니다. 서명이 맞더라도 `claims`가 dict가 아니면 `TypeError`가 납니다. `exp`가 숫자가 아니어도 `TypeError`가 납니다. 이 경우 401이 아니라 500이 됩니다. 서명 키가 유출된 경우에만 악용할 수 있습니다.
     - `iss`, `aud`, 토큰 종류 검증이 없습니다.
     - 폐기(revocation) 수단이 없습니다.
     - `exp`가 필수라서 만료 없는 토큰은 거부되는 점은 좋습니다. 다만 최대 수명 제한이 없습니다.

4. **낮음: 토큰이 키 교체를 지원하지 않음**
   - 자리: `app/auth.py` 3·10행, `app/tokens.py`
   - 까닭: 키가 하나뿐이고 `kid` 필드가 없습니다. 키가 유출되면 교체하는 즉시 모든 토큰이 무효가 됩니다. 점진적 교체가 불가능합니다.

5. **낮음: CI 워크플로의 권한과 의존성 고정 부족**
   - 자리: `.github/workflows/test.yml`
   - 까닭:
     - `permissions:` 블록이 없어서 `GITHUB_TOKEN`이 저장소 기본 권한을 그대로 받습니다. `permissions: contents: read`로 최소화해야 합니다.
     - `actions/checkout@v4`와 `actions/setup-python@v5`가 태그로만 고정돼 있습니다. 커밋 SHA로 고정하지 않았습니다.
     - `pip install -e .[dev]`는 잠금 파일이나 해시 없이 설치합니다.
     - `pull_request` 트리거라 포크 PR에는 비밀이 전달되지 않습니다. 이 부분은 안전합니다.

6. **정보: CI의 DB 비밀번호가 평문으로 중복 기재됨**
   - 자리: `.github/workflows/test.yml` 11·15행, `tests/conftest.py` 4행
   - 까닭: `ci_pw_test`는 일회용 서비스 컨테이너용 값이고 localhost에서만 열립니다. 실제 자격증명으로 보이지 않아 위험은 낮습니다. 다만 같은 값이 세 곳에 반복돼 있어, 운영 DB 비밀번호와 겹치지 않는다는 점을 규칙으로 정해 두는 편이 좋습니다.

## 이상 없음으로 확인한 항목

- `docs/api.md`의 `tok_EXAMPLE_0000000000`은 명백한 예시 값이고, 실제 토큰 형식(`body.sig`)과도 맞지 않습니다.
- 운영 `DATABASE_URL`과 `TOKEN_SIGNING_KEY`는 코드에 하드코딩돼 있지 않고 환경변수에서 읽습니다.
- `hmac.compare_digest`로 서명을 비교하므로 타이밍 공격 위험이 낮습니다.
- `list_invoices`와 `invoice_pdf`는 소유자를 올바르게 확인합니다.

## 한계

- `app/db.py`와 `app/pdf.py`는 저장소에 없습니다. `routes.py`가 import하지만 파일이 없어 SQL 인젝션과 PDF 렌더링 취약점은 검토하지 못했습니다.
- `pyproject.toml`도 없어서 의존성 취약점은 점검하지 못했습니다.
- git 이력이 비어 있어 과거 커밋에 남은 비밀은 확인할 수 없었습니다.
- 샌드박스 제약 때문에 일부 Bash 호출이 셸 상태 기록 오류를 냈습니다. 파일 내용 읽기에는 영향이 없었습니다.
