<!-- 플러그인 없음 · 못 맞힘 · 떴는가 False · 비용 0.07215080000000001 -->

저장소 전체를 읽었습니다. 파일은 10개 안팎이라 별도 도구 없이 직접 검토했고, 코드는 수정하지 않았습니다. 결함은 아래 6건입니다.

## 결함 목록

1. **운영 DB 자격증명이 저장소에 평문으로 커밋됨 (높음)**
   - 자리: `deploy/production.env:2`, `DATABASE_URL`
   - 까닭: 운영 RDS 호스트와 계정 `tracker`, 비밀번호 `Tr4cker-db-2026`이 들어 있습니다. 저장소를 읽을 수 있는 사람은 누구나 운영 DB 접속 정보를 얻습니다. 이 파일은 `tracker.service`가 읽는 운영 설정이라 실제 값으로 보입니다.
   - 같은 서비스의 다른 비밀(`SESSION_SECRET`)은 `/etc/tracker/secrets.env`로 분리돼 있습니다. DB 비밀번호만 저장소에 있는 것은 일관성이 없습니다. 이 비밀번호는 유출된 것으로 보고 교체해야 합니다.

2. **운영 비밀번호가 개발용 compose 파일에 재사용됨 (높음)**
   - 자리: `docker-compose.yml:8`, `POSTGRES_PASSWORD`
   - 까닭: 개발 DB 비밀번호가 결함 1의 운영 비밀번호와 같습니다. 개발 환경이나 저장소가 노출되면 운영 DB도 뚫립니다. `.env.example`의 `CHANGEME` 방식처럼 환경변수로 받아야 합니다.
   - 포트는 `127.0.0.1`에만 바인딩돼 있어 그 부분은 문제가 없습니다.

3. **`.gitignore`가 없어 비밀 파일이 커밋될 위험이 큼 (중간)**
   - 자리: 저장소 루트, `.gitignore` 없음
   - 까닭: README는 `.env.example`을 `.env`로 복사해 채우라고 안내합니다. 그런데 `.env`를 무시하는 규칙이 없어 실제 시크릿이 실수로 커밋될 수 있습니다. `deploy/production.env`가 이미 커밋된 것도 같은 문제로 보입니다.
   - 커밋 이력이 비어 있어 과거 유출 여부는 확인하지 못했습니다.

4. **세션 모듈과 DB 모듈이 저장소에 없어 인증·권한 로직을 검증할 수 없음 (중간)**
   - 자리: `app/auth.py:3`의 `from . import sessions`, `app/main.py:3`의 `from . import db`
   - 까닭: `app/sessions.py`와 `app/db.py`가 없습니다.
     - 세션 서명과 검증은 `SESSION_SECRET` 사용, 만료, 위조 방지를 모두 이 모듈이 맡습니다. 이 부분은 감사하지 못했습니다.
     - SQL 인젝션 여부와 테넌트 격리도 `db` 모듈이 결정합니다. 이 부분도 감사하지 못했습니다.
     - 지금 상태로는 앱이 import 단계에서 실패합니다.
   - 누락된 파일이 다른 곳에 있다면 그쪽도 검토해야 합니다.

5. **`SESSION_SECRET`에 강도 검증이 없고 플레이스홀더로 기동될 수 있음 (낮음~중간)**
   - 자리: `app/settings.py:4`, `.env.example:2`
   - 까닭: 값이 존재하기만 하면 통과합니다. `.env.example`의 `<여기에 생성한 값을 넣으세요>`를 그대로 복사해 두면 예측 가능한 키로 서버가 뜹니다. 그러면 세션을 위조해 `admin` 역할을 얻을 수 있습니다. 최소 길이나 플레이스홀더 값을 거부하는 검사가 필요합니다.

6. **쿠키 보안 속성과 CSRF 방어를 확인할 수 없음 (낮음, 확인 필요)**
   - 자리: `app/auth.py:7`(쿠키 `sid` 읽기), `app/main.py:19`(`POST /admin/teams/{team_id}/archive`)
   - 까닭: 쿠키 기반 인증으로 상태를 바꾸는 POST를 받는데, CSRF 토큰이나 Origin 검사가 없습니다. 쿠키의 `SameSite`, `HttpOnly`, `Secure` 설정은 `sessions`에서 정해지는데 그 코드가 없어 확인하지 못했습니다. 이 속성이 없다면 admin 권한의 팀 보관 작업을 CSRF로 실행할 수 있습니다.
   - `archive_team`은 대상 `team_id`가 존재하는지, 이미 보관됐는지 확인하지 않고 감사 로그도 남기지 않습니다.

## 문제가 없었던 부분
- `/admin/*` 엔드포인트는 모두 `require_admin`으로 보호됩니다.
- `/issues`는 `user.team_id`로 범위를 제한해 팀 간 격리 의도가 코드에 보입니다. 실제 격리는 `db.issues.for_team` 구현에 달려 있습니다.
- DB 포트는 로컬 호스트에만 바인딩돼 있습니다.

## 권장 조치 순서
1. 운영 DB 비밀번호를 즉시 교체합니다.
2. `deploy/production.env`에서 비밀번호를 제거해 `/etc/tracker/secrets.env`로 옮기고, git 이력에서도 지웁니다.
3. `.gitignore`를 추가합니다.
4. 누락된 `sessions`, `db` 모듈을 확보해 다시 검토합니다.
