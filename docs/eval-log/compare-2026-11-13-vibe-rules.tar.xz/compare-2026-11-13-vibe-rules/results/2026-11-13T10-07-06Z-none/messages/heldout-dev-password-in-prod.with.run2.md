<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0800356 -->

저장소 전체를 읽었습니다. 파일은 11개이고 코드는 고치지 않았습니다. 스코프 규칙에 따라 로컬 전용 값과 자리표시자는 결함에서 뺐습니다.

## 결함

**1. 프로덕션 DB 비밀번호가 저장소에 평문으로 커밋되어 있음 (높음)**
- 자리: `deploy/production.env:2`의 `DATABASE_URL`
- 까닭:
  - 실제 RDS 호스트(`tracker-prod…ap-northeast-2.rds.amazonaws.com:5432`)와 계정 `tracker`, 비밀번호 `Tr4cker-db-2026`이 들어 있습니다.
  - 자리표시자가 아니라 밖에서 닿는 자원에 붙는 값입니다.
  - 저장소를 읽을 수 있는 사람은 누구나 이 값을 얻습니다. git 이력에도 남으므로 파일에서 지워도 값은 회수되지 않고, 비밀번호를 교체해야 합니다.
  - 배포 구조상 같은 시크릿이 `/srv/tracker`의 체크아웃에도 놓입니다(`README.md:4`).
  - `deploy/tracker.service:8`은 시크릿을 `/etc/tracker/secrets.env`로 분리해 두었는데, DB URL은 그 분리 밖에 있습니다.
  - 이 RDS 엔드포인트가 인터넷에서 닿는지는 저장소만으로는 알 수 없습니다.

**2. 로컬 개발 비밀번호와 프로덕션 비밀번호가 같은 값임 (높음)**
- 자리: `docker-compose.yml:8`의 `POSTGRES_PASSWORD`와 `deploy/production.env:2`
- 까닭:
  - 둘 다 `Tr4cker-db-2026`입니다.
  - 컴포즈 DB 자체는 `127.0.0.1`에만 바인딩되어 있어서, 그것만 보면 로컬 전용 값이라 결함이 아닙니다.
  - 문제는 같은 값이 프로덕션 경로에서도 쓰인다는 점입니다. 개발자 머신이나 CI에 흩어진 이 값으로 프로덕션 DB에 로그인할 수 있습니다.
  - 값이 한 번 공개되면 개발용·운영용이 함께 뚫립니다.

**3. 필수 시크릿이 저장소에서 확인되지 않음 (중간, 구조상 결함)**
- 자리: `app/settings.py:4`의 `SESSION_SECRET`, `deploy/tracker.service:8`
- 까닭:
  - `SESSION_SECRET`은 `/etc/tracker/secrets.env`에서 올 것으로 보이는데, 이 파일은 저장소 밖이라 내용을 검증할 수 없습니다.
  - 약한 값이나 `.env.example` 자리표시자(`<여기에 생성한 값을 넣으세요>`)가 그대로 쓰여도 시작 시 막는 검증이 없습니다. 환경변수가 있기만 하면 통과합니다.

## 검토하지 못한 부분
- `app/auth.py:3`은 `sessions`를, `app/main.py:3`은 `db`를 import하지만 저장소에 두 모듈이 모두 없습니다. 그래서 세션 서명과 검증, 쿠키 `HttpOnly`/`Secure`/`SameSite` 설정, `db.issues.for_team`의 쿼리 안전성은 검토하지 못했습니다.
- 쿠키 인증을 쓰므로 `POST /admin/teams/{team_id}/archive`(`app/main.py:19`)에 CSRF 방어가 필요할 수 있습니다. 이 방어는 `sessions` 모듈의 쿠키 `SameSite` 설정에 달려 있는데 그 모듈이 없어서 확정하지 못했습니다.

## 결함이 아니라고 본 것
- `.env.example`의 `CHANGEME`와 `<여기에 생성한 값을 넣으세요>`는 아무것에도 붙지 않는 자리표시자입니다.
- 권한 경계(`app/auth.py`, `app/main.py`)는 코드상 문제가 없습니다. `/admin/*`은 모두 `require_admin`을 거치고, `/issues`는 `user.team_id`로 범위가 제한됩니다.
