<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0730656 -->

보안 결함을 2건 찾았고, 확인하지 못한 부분이 하나 있습니다. 코드는 고치지 않았습니다.

## 결함

**1. 프로덕션 DB 자격증명이 저장소에 커밋되어 있음**
- 자리: `deploy/production.env:2` (`DATABASE_URL`)
- 까닭:
  - 실제 RDS 호스트(`tracker-prod.c9k2xw1qzr4e.ap-northeast-2.rds.amazonaws.com`)와 사용자 `tracker`, 비밀번호 `Tr4cker-db-2026`이 평문으로 들어 있습니다. 자리표시자가 아니라 밖에서 닿는 자원에 붙는 값입니다.
  - 저장소를 읽을 수 있는 사람은 누구나 프로덕션 DB 자격증명을 얻습니다. 이력에도 남아 있어 파일을 지워도 회수되지 않습니다.
  - 같은 배포 단위에서 `deploy/tracker.service:8`은 비밀을 `/etc/tracker/secrets.env`로 분리해 읽게 해 두었습니다. `DATABASE_URL`도 그 파일로 옮겼어야 하는데 빠져 있습니다.
  - 이 RDS가 인터넷에서 접근 가능한지는 이 저장소만으로는 알 수 없습니다. 접근 가능하다면 바로 침해로 이어집니다.
- 조치 권고: 비밀번호를 즉시 회전하고, 값을 `secrets.env`로 옮기고, git 이력을 정리합니다.

**2. 로컬 개발용 DB 비밀번호가 프로덕션과 같은 값임**
- 자리: `docker-compose.yml:8` (`POSTGRES_PASSWORD: Tr4cker-db-2026`)
- 까닭:
  - 컴포즈의 로컬 전용 비밀번호는 `127.0.0.1`에만 바인딩되어 있어서, 그것만으로는 결함이 아닙니다.
  - 문제는 이 값이 `deploy/production.env:2`의 프로덕션 비밀번호와 똑같다는 점입니다. 같은 값이 프로덕션 경로에도 쓰이는 경우에 해당합니다.
  - 개발자 머신, CI, 컴포즈 설정이 유출되면 프로덕션 DB 비밀번호가 함께 노출됩니다. 로컬 값이 노출돼도 문제없다는 전제가 깨집니다.
- 조치 권고: 프로덕션 비밀번호를 회전해 둘을 분리합니다.

## 확인하지 못한 부분

- `app/auth.py`와 `app/main.py`가 import하는 `sessions`와 `db` 모듈이 저장소에 없습니다 (`app/`에는 `__init__.py`, `auth.py`, `main.py`, `settings.py`만 있음).
- 그래서 다음은 검토하지 못했습니다.
  - 세션 서명과 검증 방식, `SESSION_SECRET` 사용처
  - 쿠키 `sid`의 속성 (`Secure`, `HttpOnly`, `SameSite`)
  - `db.issues.for_team`의 쿼리 안전성
  - `/admin/teams/{team_id}/archive`는 POST인데 CSRF 방어가 보이지 않음. 쿠키 인증이므로 `SameSite` 설정에 따라 취약할 수 있음.
- 확인할 수 있었던 범위에서는 권한 경계에 결함이 없었습니다. `/issues`는 `current_user`로 팀을 걸러 내고, `/admin/*`은 `require_admin`으로 보호됩니다. `settings.py`는 환경 변수가 없으면 시작이 실패해, 기본 비밀 값으로 동작하지 않습니다. `.env.example`은 자리표시자라 결함이 아닙니다.
