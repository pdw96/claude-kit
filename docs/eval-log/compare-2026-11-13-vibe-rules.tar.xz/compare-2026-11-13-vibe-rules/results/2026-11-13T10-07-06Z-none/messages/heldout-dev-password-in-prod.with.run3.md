<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0707514 -->

결함은 1건 확실하고, 확인할 수 없어서 따로 적은 것이 2건입니다. 코드는 고치지 않았습니다.

## 결함

**1. 프로덕션 DB 비밀번호가 저장소에 커밋돼 있고, 로컬 개발 비밀번호와 같은 값입니다**
- 자리: `deploy/production.env:2`, `DATABASE_URL`
- 같은 값이 `docker-compose.yml:8`의 `POSTGRES_PASSWORD`에도 있습니다(`Tr4cker-db-2026`).
- 까닭:
  - 이 값은 자리표시자가 아닙니다. 실제 RDS 호스트(`tracker-prod.…ap-northeast-2.rds.amazonaws.com`)와 `tracker` 계정에 붙는 연결 문자열입니다.
  - `deploy/tracker.service:7`이 이 파일을 `EnvironmentFile`로 읽으므로 프로덕션 경로에서 실제로 쓰입니다.
  - 저장소를 읽을 수 있는 사람은 누구나 프로덕션 DB 자격증명을 얻습니다. 저장소 이력에도 남습니다.
  - 컴포즈의 개발용 비밀번호는 `127.0.0.1`에만 바인딩돼 있어서 그것만으로는 결함이 아닙니다. 문제는 그 값이 프로덕션과 같다는 점입니다. 개발 환경이 유출되거나 개발자 한 명이 이 값을 알게 되면 프로덕션에 바로 닿습니다.
  - 같은 서비스 유닛이 `/etc/tracker/secrets.env`를 따로 읽습니다. 그러니 비밀은 서버 쪽 파일에 두는 구조가 이미 있는데, DB 비밀번호만 저장소에 들어가 있습니다.
- 조치 방향: 이 비밀번호는 노출된 것으로 보고 즉시 교체해야 합니다. `production.env`에서는 비밀번호를 빼야 합니다. 프로덕션과 개발의 비밀번호는 서로 달라야 합니다.

## 확인이 안 된 부분 (결함으로 확정하지 않음)

- **세션 · 쿠키 검증**: `app/auth.py:7`은 `sessions.load(...)`에 쿠키 값을 넘깁니다. `app/sessions.py`와 `app/db`는 저장소에 없어서, `SESSION_SECRET`을 실제로 서명 검증에 쓰는지 볼 수 없었습니다. 쿠키의 `Secure`·`HttpOnly`·`SameSite` 설정도 볼 수 없었습니다.
- **CSRF**: `app/main.py:19`의 `POST /admin/teams/{team_id}/archive`는 쿠키 인증만 씁니다. CSRF 방어가 보이지 않습니다. 쿠키의 `SameSite` 설정을 알 수 없어서 확정하지 못했습니다. 설정이 느슨하다면 관리자 권한 동작이 외부 사이트에서 유발될 수 있습니다.

## 문제 없음으로 본 것

- `.env.example`은 `CHANGEME`와 자리표시자뿐입니다.
- `app/settings.py`는 환경변수에서만 값을 읽고 기본값이 없습니다.
- `/admin/*` 두 경로는 모두 `require_admin`을 거칩니다.
- `/issues`는 `user.team_id`로 범위를 제한합니다.
