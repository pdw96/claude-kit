<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0757789 -->

저장소 전체를 읽어 검토했고, 결함은 아래 3건입니다. 코드는 고치지 않았습니다. 코드는 `app/`의 `auth.py`, `config.py`, `etag.py`, `main.py`, `routes.py`와 `tests/`입니다. 설정은 `.env.example`, `.gitignore`, `pyproject.toml`, README입니다.

## 결함

**1. [치명] JWT 서명 검증이 꺼져 있어 인증을 우회할 수 있습니다.**
- 자리: `app/auth.py:19-21`, `current_user()`의 `jwt.decode(..., options={"verify_signature": False})`.
- 까닭:
  - 서명을 검증하지 않아 `JWT_SECRET`을 모르는 사람도 임의의 `sub`가 든 토큰을 만들 수 있습니다. 예를 들면 `alg=none`이나 아무 키로 서명한 토큰입니다. 그러면 다른 사번으로 가장해 그 사람의 메모를 읽고, 고치고, 지울 수 있습니다.
  - PyJWT는 `verify_signature=False`이면 `exp` 검증도 기본으로 끕니다. 그래서 만료된 토큰도 통과합니다.
  - README는 "서명이 맞지 않거나 만료된 토큰은 401"이라고 하지만 코드는 그렇게 동작하지 않습니다.
  - `routes.py`의 `_own_note`가 소유자를 확인해도 `user.id` 자체를 위조할 수 있어 권한 경계가 무너집니다.

**2. [중간] 토큰 클레임 요구 조건이 없습니다.**
- 자리: `app/auth.py:19-22`.
- 까닭:
  - `options={"require": ["exp", "sub"]}`가 없습니다. 1번을 고쳐도 `exp`가 없는 영구 토큰이 통과합니다.
  - `iss`와 `aud` 검증이 없어, 같은 비밀을 쓰는 다른 사내 서비스의 토큰도 이 API에서 통하게 됩니다.

**3. [중간] 인증 테스트가 위 결함을 잡지 못합니다.**
- 자리: `tests/test_auth.py`.
- 까닭:
  - 정상 토큰, 헤더 없음, 형식이 깨진 토큰만 검사합니다.
  - 잘못된 키로 서명한 토큰, `alg=none` 토큰, 만료된 토큰, `exp`가 없는 토큰에 대한 테스트가 없습니다.
  - 그래서 1번 결함이 있어도 테스트가 모두 통과합니다.

## 한계와 참고

- **`app/db` 모듈이 저장소에 없습니다.** `routes.py:4`의 `from . import db`가 가리키는 모듈이 없어 앱이 import 단계에서 실패합니다. `db.notes.get/for_owner/create/update/delete`의 SQL 인젝션과 소유자 필터는 검토하지 못했습니다. `.gitignore`나 누락으로 빠졌다면 별도 검토가 필요합니다.
- **[낮음] 메모 길이 제한이 없습니다.** `NoteIn.text`(`routes.py:11-12`)에 `max_length`가 없어 큰 본문으로 저장소와 메모리를 소모시킬 수 있습니다.
- **문제 없음으로 본 항목:**
  - ETag의 MD5(`etag.py`)는 보안 용도가 아니고, 소유자 확인(`_own_note`) 뒤에만 계산합니다.
  - 시크릿은 환경 변수로 받고 `.env`는 `.gitignore`에 있습니다. `.env.example`과 `conftest.py`의 값은 자리표시자나 시험용입니다.
  - 다른 사람의 메모에는 404를 돌려주고, 문서 엔드포인트는 꺼져 있습니다.
