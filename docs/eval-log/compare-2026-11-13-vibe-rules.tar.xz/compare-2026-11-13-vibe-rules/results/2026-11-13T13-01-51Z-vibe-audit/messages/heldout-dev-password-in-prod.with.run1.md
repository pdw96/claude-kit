<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.1653766 -->

`audit-secrets` 감사자를 저장소 전체(파일 9개)에 돌렸고, 결함 2건을 찾았습니다. 코드는 고치지 않았습니다.

## 결함

**1. 프로덕션 DB 비밀번호가 평문으로 소스에 있고 로컬 값과 같습니다. 심각도는 높음입니다.**
- 자리: `deploy/production.env:2`(`DATABASE_URL`), `docker-compose.yml:8`(`POSTGRES_PASSWORD`)
- 까닭
  - `production.env`에 프로덕션 RDS 접속 문자열과 비밀번호가 그대로 들어 있습니다.
  - `deploy/tracker.service:7`이 이 파일을 `EnvironmentFile`로 읽으므로, 프로덕션에서 실제로 쓰이는 값입니다.
  - 같은 비밀번호가 로컬 compose에도 있어서, 로컬 값이 새면 프로덕션이 뚫립니다.
  - 저장소를 읽을 수 있는 사람은 누구나 프로덕션 DB 자격증명을 갖게 됩니다.
  - `.gitignore`도 커밋 이력도 없어서, 이미 어디에 올라갔는지는 알 수 없습니다.
- 권장 조치: 이 비밀번호를 폐기하고 교체하세요. 새 값은 저장소 밖의 `/etc/tracker/secrets.env`로 옮기세요. compose의 비밀번호는 프로덕션과 다른 값으로 두세요.

**2. `.gitignore`가 없어서 실값이 든 `.env`가 커밋될 수 있습니다. 심각도는 보통입니다.**
- 자리: 저장소 루트(파일 없음), `README.md:3`
- 까닭
  - README가 `.env.example`을 `.env`로 복사해 실값(DB 비밀번호, `SESSION_SECRET`)을 채우라고 안내합니다.
  - 그 `.env`를 무시하는 규칙이 없어서 `git add .` 한 번이면 올라갑니다.
  - 지금은 가능성만 있고, 올라가면 심각도가 높음이 됩니다.

## 확인불가 항목

아래는 결함이라고 단정하지 못한 항목입니다.

- **세션 구현이 저장소에 없습니다.**
  - `app/auth.py:3`이 `sessions`를, `app/main.py:3`이 `db`를 import하는데 `app/` 안에 `sessions.py`와 `db.py`가 없습니다.
  - 이 때문에 서명과 검증, 만료, `SESSION_SECRET` 사용, 쿠키 속성(`HttpOnly`/`Secure`/`SameSite`)을 확인하지 못했습니다.
  - 지금 상태에서는 `app.main`이 import 단계에서 실패합니다.
  - 인증 검사가 라우트에 연결된 것까지만 확인했고, 그 검사가 안전하다는 뜻은 아닙니다.
- **소유자 확인이 DB 계층에 있는지 모릅니다.**
  - 자리는 `app/main.py:11`(`db.issues.for_team`)입니다. `for_team`이 `team_id`로 실제 필터링하는지 `db` 소스가 있어야 판단할 수 있습니다.
  - `archive_team`(`app/main.py:21`)은 admin 전용이고 팀 범위 제한이 없습니다. admin이 전 팀을 다루는 것이 의도인지는 사람이 답해야 합니다.
- **프로덕션 RDS의 외부 접근 여부를 모릅니다.** 퍼블릭 접근 설정과 보안그룹 인바운드 규칙은 저장소 밖(AWS)에 있습니다. 결함 1의 심각도는 이 답에 따라 달라질 수 있습니다.

## 참고

- `SESSION_SECRET`은 `deploy/tracker.service:8`이 저장소 밖 `/etc/tracker/secrets.env`로 주입하고, `app/settings.py:4`는 값이 없으면 기동에 실패하게 되어 있습니다. 이 방식은 바람직합니다.
- 결함 1을 고칠 때 `DATABASE_URL`은 두 env 파일 중 한쪽에만 두세요. 같은 키가 둘 다 있으면 나중에 읽는 파일이 이깁니다.
- 라우트 3개는 전수로 확인했습니다. 인증 없이 열린 엔드포인트와 클라이언트에만 있는 권한 검사는 없었고, 로그나 에러 응답으로 자격증명이 노출되는 코드도 없었습니다.

감사자가 결과를 `.claude/audits/`에 저장해 달라고 요청했지만, 코드 수정 금지 지시와 별개로 요청받지 않은 파일 생성이라 하지 않았습니다. 필요하면 말씀해 주세요.
