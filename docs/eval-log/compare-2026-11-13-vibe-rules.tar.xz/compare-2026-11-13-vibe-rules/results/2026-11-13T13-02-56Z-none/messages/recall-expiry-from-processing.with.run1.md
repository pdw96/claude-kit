<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.10171670000000001 -->

`app/`, `migrations/`, `seed/` and `docs/` 안의 파일 9개를 전부 읽고 검토했습니다. 코드는 고치지 않았고, 실행도 하지 않았습니다. 아래 결함은 모두 코드를 읽어서 찾은 것입니다.

## 높음

1. **회원권 시작일을 신청일이 아니라 승인일로 잡습니다.**
   - 자리: `app/services/memberships.py` 의 `approve` 29~35행.
   - 까닭: `starts_on` 과 `valid_until` 을 `datetime.now()` 에서 계산하고, `application.applied_on` 은 읽지 않습니다. `seed/plans.sql` 안내 문구는 "신청일로부터 N일" 이라고 하는데, `docs/schema.md` 9행은 승인이 신청 다음 날이나 그 뒤(주말 신청은 월요일)에 이뤄진다고 합니다. 그러면 승인이 늦은 만큼 회원이 낸 돈에 비해 이용 기간이 짧아집니다. 이 날짜는 출입 단말이 막는 기준이기도 합니다.

2. **날짜를 UTC 로 자릅니다.**
   - 자리: `approve` 29~30행, `datetime.now(timezone.utc).date()`.
   - 까닭: 체육관의 현지 날짜와 UTC 날짜는 하루 중 일정 시간 동안 어긋납니다. 한국 시간이라면 매일 00:00~09:00 에 승인하면 `starts_on` 이 전날로 찍힙니다. 1번과 겹치면 만료일이 하루 어긋납니다.

3. **같은 신청을 동시에 승인하면 경합이 납니다.**
   - 자리: `approve` 22~26행의 `session.get(...)` 뒤 `status` 검사, 그리고 `app/main.py` 의 `post_approval`.
   - 까닭: 행 잠금(`with_for_update`)이 없고 상태 전이도 조건부 UPDATE 가 아닙니다. 직원 두 명이 몰아서 승인하는 운영이라 실제로 일어날 만한 상황입니다.
   - 결과: 두 번째 요청은 `flush` 에서 `memberships.application_id` 의 unique 위반(`IntegrityError`)을 만납니다. 이 예외는 `RefusedApproval` 이 아니라서 잡히지 않고 500 이 됩니다. 이미 처리한 신청이라는 422 가 나가야 합니다.

4. **마이그레이션이 plans 를 채우지 않고, 시드도 안전하지 않습니다.**
   - 자리: `migrations/0001_memberships.py` 와 `seed/plans.sql`.
   - 까닭: 이 마이그레이션은 표만 만들고 `plans` 를 채우지 않습니다. 시드는 마이그레이션 밖의 별도 SQL 입니다. 기준 데이터가 없으면 모든 신청이 `plan_code` 의 FK 에 걸립니다.
   - 시드는 `INSERT` 만 있고 `ON CONFLICT` 가 없어서, 두 번 돌리면 PK 충돌로 실패합니다. 가격이나 기간을 바꾸는 경로도 버전 관리되지 않습니다.

## 중간

5. **`downgrade` 가 데이터를 지우고, 점검과 삭제 사이에 경합이 있습니다.**
   - 자리: `migrations/0001_memberships.py` 의 `downgrade` 40~46행.
   - 까닭: `memberships` 가 비었는지만 확인합니다. 처리 중이거나 대기 중인 `applications` 와 `plans` 는 확인 없이 `drop_table` 합니다.
   - 점검(`SELECT EXISTS`)과 `DROP` 사이에 테이블 잠금이 없습니다. 그 틈에 승인이 들어오면 방금 만든 회원권이 사라집니다.

6. **`create_table` 의 FK 컬럼에 타입이 없습니다.**
   - 자리: `migrations/0001_memberships.py` 23행과 30행의 `sa.Column("plan_code", sa.ForeignKey(...))`, `sa.Column("application_id", sa.ForeignKey(...))`.
   - 까닭: `models.py` 는 같은 `MetaData` 안에 참조 표가 있어서 타입이 추론됩니다. Alembic 의 `op.create_table` 은 새 `MetaData` 를 쓰기 때문에 참조 표를 찾지 못해 타입 추론이 실패할 가능성이 큽니다. 실행해서 확인하지는 않았습니다. 명시적으로 `String(10)` 과 `Integer` 를 적는 편이 안전합니다.
   - 덧붙여 저장소에 `alembic.ini` 와 `env.py` 가 없습니다. 이 마이그레이션을 어떻게 실행하는지, `target_metadata` 가 어디 연결되는지 알 수 없습니다.

7. **트랜잭션 경계가 라우터 쪽에 있습니다.**
   - 자리: `app/main.py` 33행의 `s.commit()`.
   - 까닭: `approve` 는 `flush` 까지만 하고 커밋은 핸들러가 합니다. 커밋 실패(직렬화 오류, 연결 끊김)는 처리되지 않습니다. 하나의 승인에 필요한 변경(회원권 생성 + 신청 상태 변경)의 원자성이 서비스가 아니라 호출자에게 달려 있습니다. 다른 호출 경로(배치 승인 등)가 생기면 커밋을 빠뜨리기 쉽습니다.

8. **`plan` 이 `None` 일 때를 처리하지 않습니다.**
   - 자리: `approve` 27행의 `session.get(Plan, ...)` 직후 `plan.duration_days`.
   - 까닭: FK 가 있어서 일반적으로는 일어나지 않습니다. 그래도 시드가 비었거나 플랜이 삭제된 경우 `AttributeError` 로 500 이 납니다. 4번과 맞물리는 문제입니다.

## 낮음 (제약 · 모델 누락)

9. **`applications.status` 에 허용값 제약이 없습니다.**
   - 자리: `app/models.py` 26행과 마이그레이션 25행.
   - 까닭: `String(10)` 에 `CHECK (status IN ('pending','approved',...))` 가 없어서 오타나 임의 값이 들어갑니다. `"pending"` 과 `"approved"` 는 코드에 문자열로 흩어져 있습니다.
   - 신청을 거절하거나 취소하는 상태도 없습니다.

10. **다른 컬럼 제약도 빠져 있습니다.**
    - 자리: `plans` 와 `applications`, `memberships` 의 컬럼들.
    - 까닭:
      - `plans.duration_days > 0` 과 `price >= 0` 의 CHECK 가 없습니다. `duration_days` 가 0 이하이면 `memberships_period` 에 걸려 승인 자체가 터집니다.
      - `member_id` 가 어떤 표도 가리키지 않습니다(회원 표가 없음).
      - `applications.member_id` 와 `plan_code` 에 인덱스가 없습니다.
      - 한 회원의 회원권 기간이 겹치는 것을 막는 제약이 없습니다(예: `EXCLUDE` 로 막을 수 있음).

11. **승인자를 클라이언트가 보낸 문자열로 기록합니다.**
    - 자리: `ApprovalIn.approved_by`, `app/main.py` 23~24행.
    - 까닭: 인증된 주체가 아니라 본문 값을 `memberships.approved_by` 에 그대로 넣습니다. 감사 기록으로서 믿을 수 없습니다.
    - 승인을 되돌리는 경로(취소, 환불, 상태 복구)도 없습니다. 잘못 승인하면 DB 를 직접 고쳐야 합니다.

12. **시드의 `description` 이 계산 방식을 설명하는 문장입니다.**
    - 자리: `seed/plans.sql` 3~5행.
    - 까닭: "만료일은 신청일 + 기간에서 시스템이 계산해 단다" 라는 문구가 화면 안내로 나가는데, 1번 때문에 실제 동작과 다릅니다. 같은 문구가 세 줄에 복제돼 있어서 규칙이 바뀌면 같이 고쳐야 합니다. "1개월 = 30일", "12개월 = 365일" 도 이름과 기간이 어긋나는 점이 있습니다.

13. **승인 재시도가 멱등하지 않습니다.**
    - 자리: `post_approval`.
    - 까닭: 응답이 유실되어 재시도하면 이미 처리했다는 422 가 돌아옵니다. 첫 번째 결과(membership id)를 다시 돌려주지 않습니다.
