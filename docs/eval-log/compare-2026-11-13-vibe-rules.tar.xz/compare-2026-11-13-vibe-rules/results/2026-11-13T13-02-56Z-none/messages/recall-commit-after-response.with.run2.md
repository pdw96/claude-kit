<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.1127976 -->

저장소 전체(코드 약 150줄, 파일 10개)를 읽고 검토했습니다. 코드는 고치지 않았고 실행도 하지 않았습니다. 아래 결함은 모두 코드를 읽고 추론한 것입니다. 서버를 띄우거나 DB를 붙여 재현한 것은 아닙니다.

## 높음

1. **커밋이 응답 뒤에 일어날 수 있어서, 201을 받고도 대출이 저장되지 않을 수 있습니다.**
   - 자리: `app/main.py`의 `session_scope()`, 특히 `yield` 뒤의 `session.commit()` (24행).
   - 까닭: 커밋이 `yield` 의존성의 종료 코드에 있습니다. 최근 FastAPI는 이 종료 코드를 응답을 보낸 뒤에 실행하는 것으로 알고 있습니다. 다만 requirements에 고정된 0.141.1은 제가 직접 확인하지 못했습니다. 그 동작이 맞다면 클라이언트는 `loan_id`가 든 201을 이미 받은 상태에서 커밋이 실패할 수 있습니다. `SERIALIZABLE`에서는 직렬화 실패가 `COMMIT` 시점에 가장 흔히 터집니다. 그러면 응답에는 있는 대출이 DB에는 없습니다. 이는 원칙 1(한 번에 선다)을 깨뜨리고, 실패는 클라이언트에 닿지도 못합니다.
   - 대응 방향: 커밋을 엔드포인트나 서비스 안에서 응답 전에 하거나, 의존성에 `scope="function"`을 지정하는 방법이 있습니다. 어느 쪽이든 확인이 필요합니다.

2. **직렬화 실패를 처리하지 않아서, 동시에 빌리면 진 쪽이 500을 받습니다.**
   - 자리: `app/db.py` 9행의 `isolation_level="SERIALIZABLE"`, `app/services/loans.py`의 `lend()`, `app/main.py`의 `post_loan()`.
   - 까닭: PostgreSQL의 SERIALIZABLE은 충돌한 트랜잭션 하나를 SQLSTATE 40001로 중단시킵니다. 호출하는 쪽이 재시도하는 것이 전제입니다. 이 저장소에는 재시도도, 40001을 409/503으로 바꾸는 처리도 없습니다. 원칙 3의 "하나만 선다"는 지켜지지만, 진 요청은 아무 설명 없는 500으로 끝납니다. 마지막 한 권을 두고 경쟁할 때만이 아니라 서로 다른 책을 동시에 빌릴 때도, 술어 잠금 때문에 오탐으로 실패할 수 있습니다.

3. **마이그레이션이 Alembic에서 실제로 돌지 않을 구조입니다.**
   - 자리: `migrations/0001_initial.py`, 저장소 루트.
   - 까닭: `alembic.ini`, `env.py`, `script.py.mako`, `versions/` 디렉터리가 없습니다. `requirements.txt`에는 alembic이 있지만 설정이 없어서 `alembic upgrade`를 실행할 수 없습니다. 스키마를 만드는 방법이 저장소 안에 없는 셈입니다. 또 `Base.metadata`를 가리키는 설정이 없어서 autogenerate로 모델과 마이그레이션이 어긋난 곳을 잡을 수도 없습니다.

## 중간

4. **`available_copies`는 `loans`와 따로 저장된 값인데, 둘을 맞춰 주는 장치가 없습니다.**
   - 자리: `app/models.py`의 `Book.available_copies`, `docs/schema.md`.
   - 까닭: 총 소장 수 컬럼이 없어서 `available_copies <= 총수`를 CHECK로 막을 수 없습니다. 반납 경로도 없습니다. `returned_on`을 채우거나 `available_copies`를 되돌리는 코드가 저장소 어디에도 없습니다. 반납은 두 값을 함께 바꿔야 하는데, 이 경계는 이 저장소에서 아예 정의되어 있지 않습니다. `docs/schema.md`는 반납하면 `returned_on`이 찬다고 쓰지만 구현이 없습니다.

5. **`downgrade()`가 대출 기록이 없으면 회원과 도서를 말없이 지웁니다.**
   - 자리: `migrations/0001_initial.py`의 `downgrade()` 42~46행.
   - 까닭: 주석은 "지우면 되살릴 길이 없다"는 이유로 대출 기록만 지킵니다. 그런데 `loans`가 비어 있기만 하면 실제 데이터가 든 `members`와 `books`는 그대로 `drop_table`됩니다. 지키는 기준이 일관되지 않습니다. `EXISTS` 검사와 `drop_table`이 한 트랜잭션 안에서 잠금 없이 이어지므로, 그 사이에 들어온 대출도 막지 못합니다. PostgreSQL에서 DDL은 `drop_table` 때 `ACCESS EXCLUSIVE` 잠금을 잡으므로, 검사 뒤에 끼어든 쓰기가 있으면 그 쓰기를 기다리거나 그 쓰기와 충돌할 수 있습니다.

6. **중복 대출과 대출 규칙을 막는 제약이 없습니다.**
   - 자리: `app/models.py`의 `Loan`, `app/services/loans.py`의 `lend()`.
   - 까닭: 같은 회원이 같은 책을 반납 전에 또 빌려도 막지 못합니다. `(book_id, member_id) WHERE returned_on IS NULL` 같은 부분 유니크 인덱스가 없습니다. 회원별 대출 한도도 없습니다. 이 규칙은 앱 코드에도 없고 DB에도 없습니다.

7. **`loaned_on`을 클라이언트가 정합니다.**
   - 자리: `app/schemas.py`의 `LoanIn.loaned_on`, `app/services/loans.py` 45행.
   - 까닭: 과거나 먼 미래 날짜로도 대출이 서고, 연체 계산의 기준이 되는 `due_on`이 요청 값에 따라 달라집니다. 서버 시각이나 DB `CURRENT_DATE`를 쓰거나 허용 범위를 검증해야 합니다.

8. **`loan_days`와 `available_copies`에 값 범위 CHECK가 없습니다.**
   - 자리: `app/models.py`의 `Book.loan_days`, 그리고 마이그레이션의 같은 컬럼.
   - 까닭: `loan_days`가 음수이면 `due_on < loaned_on`이 되어 `loans_due_after_loan` 제약에 걸립니다. 이 위반은 `lend()`의 `flush()`에서 `IntegrityError`로 터지는데 잡는 곳이 없어서 500이 됩니다. `loan_days > 0` CHECK가 없고 `RefusedLoan`으로 바꾸는 처리도 없습니다.

## 낮음

9. **FK 컬럼에 인덱스가 없고 삭제 정책도 없습니다.**
   - 자리: `Loan.book_id`, `Loan.member_id`, 그리고 마이그레이션의 같은 컬럼.
   - 까닭: PostgreSQL은 FK 컬럼에 인덱스를 자동으로 만들지 않습니다. 회원별·도서별 대출 조회와 FK 검사가 `loans`가 커질수록 전체 스캔이 됩니다. `ON DELETE`도 지정하지 않아서 기본값 `NO ACTION`에 기댑니다. 이 정책이 의도인지 문서에 없습니다.

10. **ISBN 길이 검증이 맞지 않습니다.**
    - 자리: `app/schemas.py`의 `LoanIn.isbn` (`min_length=10, max_length=13`), `app/models.py`의 `Book.isbn`.
    - 까닭: 10~13자 사이의 길이는 모두 통과하므로 11자나 12자 같은 잘못된 ISBN도 들어옵니다. 하이픈이나 ISBN-10과 ISBN-13 표기 차이를 정규화하지 않아서, 같은 책이 다른 문자열로 조회되어 "없는 도서"로 거절될 수 있습니다. `unique`도 문자열 단위라서 같은 책의 두 표기가 따로 들어갈 수 있습니다.

11. **모든 세션이 SERIALIZABLE입니다.**
    - 자리: `app/db.py`의 엔진 설정.
    - 까닭: 엔진 전체에 격리 수준이 걸려 있어서, 앞으로 읽기 전용 조회가 생겨도 같은 비용과 충돌 위험을 집니다. 대출 쓰기에만 걸고 나머지는 기본값으로 두는 편이 낫습니다.

12. **제약 이름 규칙을 정하지 않았습니다.**
    - 자리: `app/models.py`의 `Base`.
    - 까닭: `MetaData(naming_convention=...)`이 없어서 `UNIQUE`와 FK 제약 이름이 DB가 정하는 대로 생깁니다. 나중에 제약을 바꾸는 마이그레이션을 쓰기 어렵습니다.

## 확인하지 못한 것
- 1번은 FastAPI 0.141.1이 `yield` 종료 코드를 언제 실행하는지에 달려 있습니다. 설치된 패키지나 문서로 확인하지 못했습니다.
- 설치된 리뷰·감사 도구는 쓰지 않았습니다. 규모가 작아서 직접 읽는 편이 빨랐습니다.
