<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.1021033 -->

저장소 전체(모델, 마이그레이션, 서비스, 엔드포인트, 시드, 문서)를 읽고 검토했습니다. 코드는 고치지 않았고, 코드를 실행하거나 테스트하지도 않았습니다. 아래 결함은 모두 코드를 읽어서 찾은 것입니다. 중요도 순으로 적었습니다.

## 높음

1. **만료일을 승인일 기준으로 계산함** (`app/services/memberships.py`, `approve`의 29~35행)
   - `starts_on`을 승인 시각의 날짜로 잡고 `valid_until = starts_on + duration_days`로 계산합니다.
   - `seed/plans.sql`은 "신청일로부터 N일"이라고 안내합니다. `docs/schema.md`는 승인이 신청 다음 날이나 그 뒤(주말 신청은 월요일)에 이뤄진다고 적습니다. 그래서 `application.applied_on`이 기준이어야 합니다.
   - 지금 코드는 `applied_on`을 전혀 쓰지 않습니다. 주말에 신청한 회원은 약관상 보장 기간보다 이틀 이상 더 받거나, 기준을 반대로 보면 기간이 어긋납니다. 승인이 늦어질수록 어긋남이 커집니다.
   - 출입 단말이 `valid_until`로 출입을 막으므로 결과가 바로 출입 가능 여부에 영향을 줍니다.

2. **날짜를 UTC로 잘라 씀** (같은 파일 29~30행)
   - `datetime.now(timezone.utc).date()`는 한국 시간 00:00~09:00 사이에 전날 날짜가 됩니다.
   - 출입 단말은 현지 날짜를 쓸 가능성이 큽니다. 그러면 시작일과 만료일이 하루씩 어긋납니다.
   - 1번을 고쳐 `applied_on` 기준으로 바꾸면 이 문제도 같이 사라집니다.

3. **동시 승인 경쟁과 잘못된 오류 응답** (`approve`의 22~26행, 41행, `app/main.py`의 `post_approval`)
   - `session.get(Application, ...)`에 행 잠금(`FOR UPDATE`)이 없습니다. 두 요청이 동시에 `status == "pending"` 검사를 통과할 수 있습니다.
   - 이때 `memberships.application_id`의 UNIQUE 제약이 이중 생성은 막습니다. 하지만 그 위반은 `flush()`나 `commit()`에서 `IntegrityError`로 터집니다.
   - 핸들러는 `RefusedApproval`만 잡으므로 이 경우 422가 아니라 500이 나갑니다. `s.commit()`은 `try` 밖에 있어서 커밋 시점 오류도 처리되지 않습니다.
   - 락이 없으므로 두 요청이 서로 다른 값(`approved_by`, `starts_on`)으로 경쟁합니다. 지는 쪽은 롤백되지만 호출자에게는 원인을 알려 주지 못합니다.

4. **승인자 값을 요청 본문에서 그대로 받음** (`app/main.py`의 `ApprovalIn.approved_by`)
   - 인증이나 권한 확인이 없고, 호출자가 보낸 문자열이 감사 기록(`memberships.approved_by`)에 그대로 저장됩니다.
   - 누구든 다른 직원 이름으로 승인할 수 있어서 승인 이력을 믿을 수 없습니다.

## 중간

5. **기준 데이터가 마이그레이션 밖에 있고 재실행에 안전하지 않음** (`seed/plans.sql`, `migrations/0001_memberships.py`)
   - `plans` 시드는 마이그레이션에 들어 있지 않고 따로 있는 SQL 파일입니다. 새 DB에 `alembic upgrade`만 하면 `plans`가 비어 있습니다.
   - 시드는 단순 `INSERT`라서 두 번 돌리면 PK 충돌로 실패합니다. `ON CONFLICT`가 없습니다.
   - 시드의 `description`은 "화면의 안내 문구"로도 쓰이는데, 승인일 기준 계산(1번)과 모순되는 문구가 DB에 박혀 있습니다.

6. **다운그레이드가 일부 데이터만 지킴** (`migrations/0001_memberships.py`, `downgrade`의 40~46행)
   - `memberships`가 비어 있는지만 확인합니다. `applications`에 처리 전 신청이 남아 있어도 그대로 `drop_table`하므로 신청 데이터가 사라집니다.
   - `plans`도 운영 중에 바뀐 가격이나 설명이 있으면 함께 사라집니다.
   - 검사와 삭제 사이에 잠금이 없습니다. 검사 후 삭제 전에 승인이 들어오면 그 회원권이 유실됩니다.

7. **상태값에 제약이 없음** (`app/models.py`의 `Application.status`, `migrations/0001_memberships.py` 25행)
   - `String(10)`에 `CHECK`나 enum이 없어서 임의 문자열이 들어갈 수 있습니다. 코드는 `"pending"`과 `"approved"`만 가정합니다.
   - 상태 전이 시각이나 거절 경로도 없습니다.
   - `applications.status = 'approved'`와 `memberships` 행의 존재가 DB 차원에서 묶여 있지 않아서, 어긋난 데이터를 막지 못합니다.

8. **값 범위 제약이 없음** (`plans`)
   - `duration_days > 0`과 `price >= 0`을 검사하지 않습니다.
   - `duration_days`가 0이거나 음수이면 `memberships_period` 제약에 걸려 승인 시점에 500이 납니다. 잘못된 기준 데이터가 승인 단계에서야 드러납니다.

9. **회원 정보가 중복되고 겹침을 막지 못함** (`memberships.member_id`)
   - 이 값은 `applications.member_id`의 사본입니다. 둘이 같다는 것을 보장하는 복합 FK나 제약이 없습니다.
   - 한 회원에 기간이 겹치는 회원권을 막는 장치도 없습니다. 같은 회원이 여러 신청을 내서 승인되면 겹치는 회원권이 생깁니다.
   - `member_id`는 `members` 같은 표를 가리키는 FK도 없고, 이 저장소에는 그런 표 자체가 없습니다.

## 낮음

10. **인덱스가 없음**
    - 출입 단말이 `member_id`와 `valid_until`로 조회할 텐데 `memberships`에 해당 인덱스가 없습니다.
    - `applications.member_id`와 `applications.status`에도 인덱스가 없습니다. 직원이 "처리 대기" 목록을 볼 때 전체 스캔이 됩니다.

11. **마이그레이션 환경 파일이 없음**
    - `alembic.ini`와 `env.py`가 저장소에 없습니다. 마이그레이션을 실제로 돌릴 수 없고, `models.py`의 `Base.metadata`와 마이그레이션이 일치하는지 검사하는 `autogenerate`도 쓸 수 없습니다.
    - 모델과 마이그레이션에 같은 정의가 이중으로 적혀 있어서 어긋날 위험이 큽니다.
    - 마이그레이션 파일명과 리비전이 `0001`로 고정되어 있어 Alembic 기본 규칙과 다릅니다.

12. **트랜잭션 경계가 라우트에 흩어져 있음** (`app/main.py`)
    - 커밋은 라우트가 하고 `flush`는 서비스가 합니다. 서비스를 다른 곳에서 호출하면 커밋 책임이 모호합니다.
    - 예외 시 명시적 `rollback`은 없고, `session.close()`가 암묵적으로 롤백할 뿐입니다.
    - 연결 문자열이 하드코딩되어 있고(`create_engine("postgresql+psycopg://gym@localhost/gym")`) 풀 설정도 없습니다.

13. **"1개월/3개월/12개월"을 일수로 환산함** (`seed/plans.sql`)
    - 30, 90, 365일로 계산하므로 달력상의 한 달, 석 달과 맞지 않습니다. 이것이 의도인지 명시되어 있지 않습니다.

## 확인하지 못한 것

- 실제 DB에서 돌려 보지 않았습니다. 3번의 경쟁 상황은 코드와 제약 조건만으로 추론한 것입니다.
- 이 저장소에는 `members` 표, 인증 계층, 출입 단말 코드가 없습니다. 2번과 4번, 10번은 그 부분이 어떻게 구현되어 있는지에 따라 심각도가 달라집니다.
