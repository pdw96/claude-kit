<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.087737 -->

결함은 6건입니다. 코드는 고치지 않았고 실행도 하지 않았습니다. 파일 4개(`app/models.py`, `migrations/versions/0006_orders.py`, `migrations/versions/0007_shipping_zone.py`, `docs/schema.md`)를 읽고 판단한 결과입니다.

## 주요 결함

1. **되돌림이 운영자가 먼저 만든 그룹과 코드를 지울 수 있습니다.**
   - 자리: `0007_shipping_zone.py`의 `upgrade()`와 `downgrade()` 끝부분 `DELETE` 두 줄
   - 까닭:
     - `upgrade()`는 이미 있는 줄을 건너뛰고, 이 줄이 리비전이 심은 것인지 표시를 남기지 않습니다.
     - 운영자가 `SHIPPING_ZONE` 그룹이나 `METRO`/`REGION`/`ISLAND` 코드를 값까지 똑같이 미리 만들어 뒀다면, `downgrade()`의 "값이 바뀌었나" 검사를 통과합니다.
     - 그러면 `group_code = 'SHIPPING_ZONE'`인 줄을 전부 지우고 그룹까지 지웁니다.
     - 이는 `docs/schema.md` 원칙 1(사람이 만든 데이터는 지우지 않는다)을 어깁니다.
   - 검사로는 "리비전이 심은 줄"과 "운영자가 같은 값으로 만든 줄"을 구별할 수 없습니다. 출처 표시 컬럼이 필요하고, 최소한 `upgrade()`가 실제로 삽입한 키를 기록해야 합니다.

2. **그룹 줄은 변경 여부를 검사하지 않습니다.**
   - 자리: `0007_shipping_zone.py`의 `downgrade()`
   - 까닭:
     - 코드 줄은 `name`, `sort_order`, `is_active`를 비교합니다.
     - 그룹 줄(`code_groups`)은 `name`, `description`이 심은 값과 같은지 보지 않고 지웁니다.
     - 운영자가 그룹 이름이나 설명을 고쳤어도 그대로 삭제됩니다.

3. **검사와 삭제 사이에 잠금이 없습니다.**
   - 자리: `0007_shipping_zone.py`의 `downgrade()`에서 `SELECT count(*)` 세 개와 `DELETE`, `DROP COLUMN` 사이
   - 까닭:
     - 기본 격리 수준(READ COMMITTED)에서는 검사 뒤에 다른 세션이 커밋한 변경을 막지 못합니다.
     - 그 사이 주문에 권역이 기록되거나 운영자가 코드를 추가·수정하면, 검사를 통과한 뒤 그 데이터가 지워지거나 컬럼과 함께 사라집니다.
     - `LOCK TABLE orders`와 `LOCK TABLE common_codes`(또는 `FOR UPDATE`)가 없습니다.

4. **`orders.shipping_zone`에 참조 무결성이 없습니다.**
   - 자리: `app/models.py`의 `Order.shipping_zone`, `0007`의 `add_column`
   - 까닭:
     - `docs/schema.md`는 이 컬럼이 `SHIPPING_ZONE` 그룹의 코드를 가리킨다고 적었지만, FK나 CHECK가 없는 평범한 `String(30)`입니다.
     - `common_codes`는 `(group_code, code)` 복합 키라서 단일 컬럼 FK를 걸 수 없고, 그룹 값을 고정하는 보조 컬럼이나 트리거도 없습니다.
     - 그래서 존재하지 않는 코드를 주문에 넣을 수 있습니다.
     - 운영자가 관리 화면에서 사용 중인 코드를 지우거나 이름을 바꿔도 막을 수단이 없습니다.
     - 이 경우 `downgrade()`의 "사용 중" 검사도 값 존재 여부만 볼 뿐, 고아가 된 값은 구별하지 못합니다.

## 부수 결함

5. **되돌림 가드가 PostgreSQL 전용 문법에 묶여 있습니다.**
   - 자리: `0007_shipping_zone.py`의 `upgrade()`와 `downgrade()`
   - 까닭:
     - `(VALUES ...) AS v(code, name, sort_order)`와 행 비교 `IS DISTINCT FROM`은 PostgreSQL 문법입니다.
     - 다른 DB에서는 실패하거나 의미가 달라질 수 있습니다.
     - 이런 문법 때문에 SQLAlchemy 방언으로 이식되지 않는데도 `sa.String`과 `sa.Boolean` 같은 중립 타입을 쓰고 있어 일관되지 않습니다.
     - 값도 `f"..."`로 SQL에 직접 이어 붙입니다. 지금은 상수라서 문제가 안 되지만, `ZONES`에 `'`가 든 이름이 들어가면 깨집니다.

6. **`0006`이 되돌림을 막는 방식이 비일관적입니다.**
   - 자리: `0006_orders.py`의 `downgrade()`
   - 까닭:
     - `RuntimeError`로 막으므로 `0007`에서 `0006`으로 내린 뒤 더 내릴 수 없습니다.
     - 이는 의도된 정책으로 보입니다.
     - 다만 이 리비전도 같은 원칙을 따라야 할지 불분명합니다. `0006`은 `orders`를 만드는데, 그 안에 데이터가 쌓여도 어느 쪽으로든 처리하지 않고 일괄 거부만 합니다.

## 참고

모델과 마이그레이션 사이의 스키마 드리프트(컬럼, 타입, nullable)는 찾지 못했습니다. `0006`과 `0007`을 합친 결과가 `models.py`와 일치합니다.
