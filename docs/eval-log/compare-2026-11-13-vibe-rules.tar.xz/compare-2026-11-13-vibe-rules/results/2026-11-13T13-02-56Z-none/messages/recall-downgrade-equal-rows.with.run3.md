<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0896939 -->

코드는 수정하지 않았고 읽기만 했습니다. 마이그레이션을 DB에 돌려 보지는 않아서, 아래는 모두 코드를 읽고 추론한 결과입니다.

검토 범위는 `app/models.py`, `migrations/versions/0006_orders.py`, `migrations/versions/0007_shipping_zone.py`, `docs/schema.md` 전부입니다.

## 결함 목록

1. **다운그레이드가 운영자가 만든 코드 줄을 지울 수 있음** (`0007_shipping_zone.py`, `upgrade()`의 `WHERE NOT EXISTS`와 `downgrade()`의 `DELETE`)
   - 업그레이드는 운영자가 이미 만든 `SHIPPING_ZONE` 줄이 있으면 건너뜁니다. 그 줄을 "이 리비전이 심은 것"으로 표시해 두지는 않습니다.
   - 운영자가 만든 METRO/REGION/ISLAND 줄이 심는 값(이름·순서·활성)과 똑같으면, 다운그레이드의 "바뀜" 검사를 통과합니다.
   - 그러면 `DELETE FROM common_codes WHERE group_code = 'SHIPPING_ZONE'`가 그 줄을 지웁니다. `docs/schema.md` 원칙 1(사람이 만든 데이터는 리비전이 지우지 않는다)에 어긋납니다.
   - 값이 같다는 것만으로는 리비전이 만든 줄인지 알 수 없습니다. 출처를 표시하는 칸이 없거나, 업그레이드가 실제로 넣은 줄을 따로 기록해야 합니다.

2. **`code_groups` 줄은 다운그레이드가 검사하지 않고 지움** (`downgrade()`의 마지막 `DELETE FROM code_groups`)
   - 코드 줄과 달리 그룹 줄은 `name`·`description`이 심은 값과 같은지 확인하지 않습니다.
   - 운영자가 미리 만들었거나 고친 그룹 줄도 그대로 삭제됩니다.
   - 위 1번과 같은 원칙 위반입니다.

3. **검사와 삭제 사이에 잠금이 없음** (`downgrade()` 전체)
   - 주문 건수, 추가 코드, 변경 여부를 읽은 뒤 DELETE와 `drop_column`을 실행하는데, 그 사이에 테이블을 잠그지 않습니다. 격리 수준이 기본(READ COMMITTED)이면 그 틈에 주문이 `shipping_zone` 값을 쓰거나 운영자가 코드를 추가·수정할 수 있습니다.
   - 그러면 검사는 통과했는데 값이 사라지거나 남의 줄이 지워집니다.
   - `LOCK TABLE`이나 `SELECT ... FOR UPDATE`가 필요합니다.

4. **`orders.shipping_zone`에 참조 무결성이 없음** (`models.py` `Order`, `0007` `add_column`)
   - 문서는 이 칸이 `SHIPPING_ZONE` 코드를 가리킨다고 하지만 FK도 CHECK도 없습니다. `common_codes`의 키가 `(group_code, code)` 복합키여서 단순 FK로는 걸 수 없습니다.
   - 존재하지 않는 코드가 주문에 들어갈 수 있고, 운영자가 코드를 지우면 주문에 끊어진 참조가 남습니다.
   - 다운그레이드의 `used` 검사는 "값이 있는지"만 보고 "유효한 코드인지"는 보지 않습니다.

5. **업그레이드의 "건너뜀"이 조용하고 확인이 없음** (`upgrade()`의 두 `INSERT ... WHERE NOT EXISTS`)
   - 운영자가 같은 키로 다른 값(예: 이름이 다르거나 `is_active=false`)을 이미 만들어 두었으면 말없이 넘어갑니다. 코드가 기대하는 상태와 어긋난 채 업그레이드가 성공으로 끝납니다.
   - 이 경우 기록도 경고도 없고, 나중에 다운그레이드가 왜 멈추는지도 알기 어렵습니다.

6. **PostgreSQL 전용 SQL이 DB 중립 마이그레이션에 섞여 있음** (`0007`의 `(VALUES ...) AS v(code, name, sort_order)`, `IS DISTINCT FROM`, 행 비교)
   - SQLite나 MySQL에서는 실패하거나 의미가 달라집니다.
   - `0006`과 `models.py`는 DB 중립이어서 이식성이 어긋납니다.

7. **오프라인(`--sql`) 모드에서 다운그레이드가 동작하지 않음** (`downgrade()`의 `bind.execute(...).scalar()`)
   - 오프라인 모드에서는 쿼리 결과를 읽을 수 없어서, 안전 검사가 실행되지 않거나 실패합니다.
   - 안전장치가 모드에 따라 사라지는 셈입니다.

8. **첫 리비전은 되돌릴 수 없음** (`0006_orders.py` `downgrade()`)
   - 항상 `RuntimeError`를 냅니다. 의도된 동작이지만, `base`까지의 되돌림 경로가 끊기고 테스트 DB 초기화에도 쓸 수 없습니다.
   - 운영 데이터가 있는 표라는 이유라면, 그 이유와 대체 절차가 문서에 없습니다.

9. **SQL을 f-string으로 조립함** (`0007`의 `_values()`, `GROUP` 보간과 `repr(c)` 사용)
   - 지금은 상수라서 주입 위험은 없습니다.
   - 하지만 `repr()`로 따옴표를 만드는 방식은 SQL 이스케이프가 아니고, 이름에 `'`가 들어가면 깨집니다. 바인드 파라미터를 쓰는 편이 안전합니다.

10. **`orders`가 최소한의 칸만 가짐** (`0006` `create_table("orders")`, `models.py` `Order`)
    - `id` 외에 생성 시각이나 상태 같은 칸이 없습니다.
    - 모델이 아직 초안일 가능성이 있어 확신은 낮습니다.

## 확인한 것

`models.py`와 `0006`·`0007`의 칸 정의(타입, `server_default`, nullable)는 서로 일치합니다. 모델과 마이그레이션 사이의 드리프트는 찾지 못했습니다.
