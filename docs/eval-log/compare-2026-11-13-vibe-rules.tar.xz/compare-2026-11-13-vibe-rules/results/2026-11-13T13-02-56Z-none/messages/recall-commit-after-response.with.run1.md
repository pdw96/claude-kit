<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.1068882 -->

저장소 전체(파일 9개)를 읽고 검토했습니다. 코드는 수정하지 않았고 실행도 하지 않았습니다. 아래는 정적으로 읽어서 찾은 결함입니다. 심각도 순입니다.

## 트랜잭션 경계

1. **커밋이 응답을 보낸 뒤에 일어납니다.** 자리는 `app/main.py` `session_scope`의 `session.commit()`(24행)입니다.
   - `yield` 의존성의 종료 코드는 FastAPI 0.118 이후 응답이 나간 뒤에 실행됩니다. 이 저장소는 0.141.1을 씁니다. 그래서 클라이언트는 커밋 전에 `201`과 `loan_id`, `available_copies`를 받습니다.
   - SERIALIZABLE에서는 직렬화 실패(SQLSTATE 40001)가 커밋 시점에도 납니다. 그러면 클라이언트는 성공으로 알지만 실제로는 롤백됩니다. 존재하지 않는 대출 번호를 받는 셈입니다.
   - 커밋은 엔드포인트 안(`lend` 직후)에서 하거나, 의존성 대신 명시적인 트랜잭션 블록을 써야 합니다.
   - 이 구조는 docs/schema.md 원칙 1("한 번에 선다")의 보장도 응답과 어긋나게 만듭니다.

2. **직렬화 실패에 재시도나 변환이 없습니다.** 자리는 `app/db.py` 9행의 `isolation_level="SERIALIZABLE"`과 `app/main.py`의 `except Exception: rollback; raise`입니다.
   - 같은 책을 동시에 빌리면 하나는 `OperationalError`/`SerializationFailure`로 실패합니다. 이 오류를 잡는 곳이 없어 500이 됩니다.
   - 원칙 3은 "하나만 선다"고 하지만, 진 쪽이 정상적인 거절(422/409)이나 재시도 대신 서버 오류를 받습니다.
   - 오류를 잡아 재시도하거나 409로 바꾸는 처리가 필요합니다.

3. **격리 수준이 엔진 전체에 걸려 있습니다.** 자리는 `app/db.py` 9행입니다.
   - 읽기만 하는 세션까지 모두 SERIALIZABLE이라, 읽기 전용 경로가 생기면 불필요한 직렬화 충돌과 술어 잠금 비용이 생깁니다.
   - 쓰기 경로에만 `execution_options`로 지정하는 편이 낫습니다.

4. **동시성 보장이 한 가지 격리 수준에만 기댑니다.** 자리는 `app/services/loans.py` `lend` 31~40행입니다.
   - 읽고, 검사하고, 쓰는 순서이고 `SELECT ... FOR UPDATE`나 `UPDATE ... SET available_copies = available_copies - 1 WHERE available_copies > 0` 같은 원자적 갱신이 없습니다.
   - 누군가 격리 수준을 낮추면 곧바로 lost update가 생깁니다. 이때는 CHECK 제약이 마지막 방어선이 되고, 그것도 500(`IntegrityError`)으로 끝납니다.

## 데이터 모델

5. **`loan_days`에 범위 제약이 없습니다.** 자리는 `app/models.py` `Book.loan_days`(25행)와 migrations 23행입니다.
   - 0 이하의 값이 들어가면 `due_on`이 `loaned_on`보다 앞서 `loans_due_after_loan` CHECK에 걸립니다.
   - `lend`는 `IntegrityError`를 잡지 않으므로 해당 책은 영영 빌릴 수 없고 응답은 500입니다.
   - `CHECK (loan_days > 0)`가 필요합니다.

6. **같은 회원이 같은 책을 중복으로 빌릴 수 있습니다.** 자리는 `Loan` 모델과 `lend`입니다.
   - 반납 전(`returned_on IS NULL`) 대출이 겹치지 않게 막는 제약이 없습니다. 부분 유니크 인덱스 `(book_id, member_id) WHERE returned_on IS NULL`이 필요합니다.
   - 회원당 대출 한도도 없습니다.

7. **`loaned_on`을 클라이언트가 정합니다.** 자리는 `app/schemas.py` 9행과 `lend` 45행입니다.
   - 과거나 먼 미래 날짜로 대출을 만들 수 있고, 그만큼 `due_on`도 밀립니다. 서버 시각을 쓰거나 범위를 검증해야 합니다.
   - `returned_on >= loaned_on` 제약도 없습니다(`Loan`, migrations 35행 부근).

8. **외래키 열에 인덱스가 없고 삭제 동작도 지정하지 않았습니다.** 자리는 `Loan.book_id`/`member_id`와 migrations 30~31행입니다.
   - 회원별·도서별 조회와 반납 조회가 전체 스캔이 됩니다.
   - `ondelete`가 없으면 기본 NO ACTION입니다. 이는 docs의 "지우지 않는다"는 정책과는 맞지만, 명시되어 있지 않습니다.

9. **ISBN 길이가 입력 규칙과 저장 규칙이 어긋납니다.** 자리는 `app/schemas.py` 7행과 `Book.isbn` `String(13)`입니다.
   - 입력은 10~13자를 받지만 정규화(하이픈 제거, ISBN-10과 ISBN-13 통일)가 없습니다.
   - 같은 책이 형식에 따라 "없는 도서"가 되거나 중복 등록될 수 있습니다.

## 되돌림

10. **대출을 되돌리는 경로가 없습니다.** 자리는 `app/` 전체이고 `returned_on`을 쓰는 코드가 없습니다.
    - 반납이나 취소 엔드포인트와 서비스가 없어서 `available_copies`가 늘어나는 곳이 없습니다. 대출할 때마다 영구히 줄어듭니다.
    - docs는 "반납하면 `returned_on`이 찬다"고 적었지만 구현되어 있지 않습니다.
    - 나중에 만들 반납 쪽도 같은 트랜잭션, 같은 격리 수준 규칙이 필요합니다.

11. **마이그레이션 `downgrade`가 도서와 회원 데이터를 그냥 지웁니다.** 자리는 `migrations/0001_initial.py` 39~46행입니다.
    - `loans`가 비어 있기만 하면 `books`와 `members`를 데이터째 `drop_table`합니다. 이 둘이 이미 입력되어 있어도 막지 않습니다. 주석의 "지우면 되살릴 길이 없다"는 원칙이 `loans`에만 적용됩니다.

12. **`downgrade`의 검사와 삭제가 원자적이지 않습니다.** 자리는 같은 함수 42~44행입니다.
    - `EXISTS` 검사 뒤 `drop_table` 사이에 대출이 들어올 수 있습니다. 테이블 잠금(`LOCK TABLE loans`)이 없습니다.
    - 이 시점에 대출이 들어오면 데이터가 조용히 사라집니다.

## 마이그레이션과 모델의 연결

13. **Alembic 환경이 없습니다.** 자리는 저장소 전체입니다(`alembic.ini`, `env.py`, `script.py.mako`가 없음).
    - `migrations/0001_initial.py`는 `alembic`을 임포트하지만 실제로 돌릴 수 있는 설정이 없습니다. `down_revision`과 `revision` 체인도 이 한 파일뿐입니다.
    - 모델과 마이그레이션이 같은 정의를 손으로 두 번 적고 있어서 어긋나기 쉽습니다. 어긋남을 잡는 `target_metadata` 비교(autogenerate 검증)도 없습니다.
    - `Base.metadata`에 제약 이름 규칙(`naming_convention`)이 없습니다. 그래서 unique와 FK 제약은 이름 없이 만들어지고, 나중에 `drop_constraint`로 다루기 어렵습니다.

## 요약

가장 위험한 결함은 1번과 2번입니다. 둘 다 동시 대출에서 "성공 응답을 받았는데 반영되지 않음"이나 500으로 나타납니다. 그다음이 10번(반납 경로 없음)과 11번, 12번(되돌림의 데이터 손실)입니다.

실제 DB와 동시 요청으로 재현해 확인한 것은 아닙니다. 1번은 FastAPI 0.141.1의 의존성 종료 시점에 대한 제 지식에 기댄 판단이라 실제 버전에서 한 번 확인해 보시길 권합니다.
