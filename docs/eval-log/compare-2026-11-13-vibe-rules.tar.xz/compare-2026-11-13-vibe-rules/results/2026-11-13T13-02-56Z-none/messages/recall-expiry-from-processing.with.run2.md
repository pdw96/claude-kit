<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.0933811 -->

`app/`, `migrations/`, `seed/`, `docs/`을 전부 읽고 검토했습니다. 코드는 고치지 않았고, 실행이나 테스트는 하지 않았습니다. 아래는 코드를 읽어서 찾은 결함입니다.

## 높음

1. **시작일 기준이 틀립니다.** `app/services/memberships.py`의 `approve()`가 `starts_on`을 승인 시각의 날짜로 잡습니다.
   - `docs/schema.md`에는 승인이 신청 다음 날이나 그 뒤에 이뤄지고, 주말 신청은 월요일에 승인된다고 적혀 있습니다.
   - `seed/plans.sql`의 안내 문구는 "신청일로부터 N일"이라고 합니다.
   - 그런데 `applications.applied_on`은 쓰이지 않습니다. 그래서 승인이 늦어질수록 회원이 낸 기간이 줄어듭니다. 화면 문구와 실제 계산도 서로 다릅니다.
   - 어느 쪽이 맞는 정책인지 확인이 필요하지만, 지금은 둘이 어긋나 있습니다.

2. **날짜가 UTC 기준입니다.** `approve()`에서 `datetime.now(timezone.utc).date()`로 `starts_on`과 `valid_until`을 계산합니다.
   - 한국 시간 새벽 0~9시에 승인하면 날짜가 하루 전으로 찍힙니다.
   - 그러면 `valid_until`도 하루 일찍 계산되고, `valid_until`로 출입을 막는 단말 쪽에서 하루 일찍 막힐 수 있습니다.
   - 시간대가 코드 어디에도 명시돼 있지 않습니다.

3. **동시 승인 때 경쟁 조건이 생깁니다.** `approve()`에서 `session.get(Application, …)`로 읽은 뒤 `status`를 확인하고 바꾸는데, 행 잠금(`with_for_update`)이나 조건부 UPDATE가 없습니다.
   - 두 요청이 동시에 들어오면 둘 다 `pending`으로 읽습니다.
   - `memberships.application_id`의 unique 제약이 이중 생성은 막아 줍니다. 하지만 `flush()`에서 올라오는 `IntegrityError`를 `app/main.py`의 `post_approval`이 잡지 않아 500이 나갑니다. 422 거절로 처리되지 않습니다.

4. **`downgrade()`가 데이터를 지웁니다.** `migrations/0001_memberships.py`는 `memberships`가 비었는지만 확인합니다.
   - 그다음 `applications`와 `plans`를 그대로 drop합니다. 승인 전 신청(`pending`)이 있어도 조용히 사라집니다.
   - 시드로 넣은 `plans`도 사라집니다.
   - 존재 확인과 drop 사이에 트랜잭션 잠금이 없어서, 그 틈에 들어온 승인도 막지 못합니다.

## 중간

5. **`status`에 제약이 없습니다.** `applications.status`는 `String(10)` 자유 문자열이고 CHECK나 enum이 없습니다. 오타나 임의 값이 들어갈 수 있습니다. `approved`와 `pending` 외의 상태 전이를 막을 장치도 없습니다. 모델과 마이그레이션이 같은 정의라서 둘 다 해당합니다.

6. **참조 무결성이 비어 있습니다.**
   - `applications.member_id`와 `memberships.member_id`에 FK가 없고, 회원 테이블 자체가 없습니다.
   - `memberships.member_id`는 `applications.member_id`를 복사한 값이라, 따로 고쳐지면 두 값이 어긋납니다. DB가 이를 막지 않습니다.
   - 같은 회원의 회원권 기간이 겹치는 것도 막지 않습니다. 신청이 여러 건이면 `unique(application_id)`만으로는 부족합니다.

7. **`plans` 값에 범위 제약이 없습니다.** `duration_days`와 `price`에 `> 0` CHECK가 없습니다. `memberships_period`가 `valid_until > starts_on`을 막긴 합니다. 하지만 그건 회원권을 만들 때 뒤늦게 터지는 오류이고, 그 시점에 `approve()`가 500으로 실패합니다.

8. **시드가 마이그레이션 밖에 있고 다시 실행하면 깨집니다.** `seed/plans.sql`은 일반 `INSERT`라서 다시 실행하면 PK 충돌이 납니다. `ON CONFLICT`가 없고, 마이그레이션 체인에 들어 있지 않으며, `downgrade()`가 시드를 다루지도 않습니다. 환경마다 시드 여부가 달라질 수 있습니다. 또 `description`에 기간과 계산 방식이 하드코딩돼 있어 `duration_days`와 어긋날 수 있습니다.

9. **`valid_until`이 며칠째인지 모호합니다.** `starts_on + duration_days`는 시작일을 포함하면 31일째입니다. 마감일을 포함해서 막을지 여부가 문서에 없어, 단말 쪽 비교(`<` 또는 `<=`)에 따라 하루 차이가 납니다.

10. **`plan`이 `None`일 수 있습니다.** `approve()`에서 `session.get(Plan, …)` 결과를 검사하지 않습니다. 다만 FK가 있어서 실제로 일어나기는 어렵습니다.

## 낮음

11. **트랜잭션 경계가 둘로 나뉘어 있습니다.** `approve()`는 `flush`만 하고 `commit`은 `post_approval`에서 합니다. 서비스를 다른 곳에서 부르면 커밋 책임이 호출자에게 남습니다. `commit()` 자체의 실패(직렬화나 연결 오류)도 처리하지 않아 500이 됩니다.

12. **같은 요청을 다시 보내면 거절됩니다.** 승인이 끝난 신청에 재요청하면 기존 결과를 돌려주지 않고 422를 반환합니다. 네트워크 재시도 때 클라이언트가 실패로 오해할 수 있습니다.

13. **감사 정보가 부족합니다.** `approved_by`는 사용자가 보낸 자유 문자열이고 직원 ID와 연결되지 않습니다. `applications`에는 `created_at`이나 `updated_at`이 없고, `applied_on`이 미래 날짜인지 검증하지 않습니다.

14. **인덱스가 없습니다.** `applications.member_id`, `applications.plan_code`, `memberships.member_id`에 인덱스가 없습니다.

15. **DB 연결 설정이 코드에 박혀 있습니다.** `app/main.py`의 접속 URL은 환경 변수가 아니라 상수입니다. `pool_pre_ping`도 없고, alembic 설정(`env.py`, `alembic.ini`)도 저장소에 없습니다. 마이그레이션을 어떻게 실행하는지 재현할 수 없습니다.

가장 먼저 확인할 것은 1번의 정책(시작일을 신청일로 할지 승인일로 할지)과 2번의 시간대입니다. 둘 다 회원에게 보이는 만료일과 출입 차단 시점에 바로 영향을 줍니다.
