<!-- 플러그인 없음 · 맞힘 · 떴는가 False · 비용 0.1107093 -->

저장소가 작아서(파일 8개) 도구 없이 전부 직접 읽고 검토했습니다. 코드는 고치지 않았습니다. 실행해 확인한 것은 없고, 모두 코드를 읽고 내린 판단입니다.

## 결함 목록

### 높음

1. **비활성 코드를 새 환불에서 막지 않음**
   - 자리: `app/services/refunds.py` 의 `_must_be_a_code` (22–24줄)
   - 까닭: 코드가 있는지만 보고 `is_active` 는 보지 않습니다. `models.py` 의 `CommonCode` 독스트링은 비활성 코드를 "새 기록에서는 못 고른다"고 하는데, `POINT`, `PROMO`(`seed/codes.sql` 4·7줄, `FALSE`)로도 환불이 만들어집니다.
   - DB 쪽 FK 도 `is_active` 를 모르므로 아래에서 막아 주는 곳이 없습니다.

2. **`orders.refunded` 가 비정규화 값인데 DB 가 무결성을 보장하지 않음**
   - 자리: `app/models.py` 의 `Order`, `migrations/0001_refunds.py` 의 `orders` 테이블
   - 까닭:
     - `refunded <= amount`, `refunded >= 0`, `amount >= 0` 인 CHECK 가 없습니다. 한도는 `refund()` 의 앱 코드(33줄)에서만 지킵니다.
     - 행 잠금(`with_for_update`)도 이 함수 안에서만 걸립니다. 다른 경로(스크립트, 수작업 SQL, 다른 서비스)로 `refunded` 나 `refunds` 를 건드리면 `sum(refunds.amount) = orders.refunded` 가 깨져도 잡히지 않습니다.
     - 이 합계를 맞추는 트리거나 제약도 없습니다.

3. **"되돌리는 환불을 새로 세운다" 원칙을 모델이 받쳐 주지 못함**
   - 자리: `docs/schema.md` 원칙 1 ↔ `app/models.py` 의 `Refund` (`amount > 0` CHECK), `refund()`
   - 까닭:
     - 되돌림을 표현할 방법이 없습니다. 부호나 종류 칸이 없고, 원 환불을 가리키는 `reversed_refund_id` 같은 칸도 없습니다.
     - `amount > 0` 이라 음수 환불은 DB 와 API 모두 거부합니다.
     - `refund()` 는 `order.refunded` 를 늘리기만 하므로 되돌림이 들어와도 줄이는 경로가 없습니다.
     - 결과적으로 실제 되돌림은 `refunded` 를 직접 UPDATE 하거나 `refunds` 행을 지우는 것뿐이고, 둘 다 원칙에 어긋납니다.
   - `refunds` 에 불변성(UPDATE/DELETE 차단)도 걸려 있지 않습니다.

4. **마이그레이션이 코드 데이터를 만들지 않고, seed 가 마이그레이션 밖에 있음**
   - 자리: `migrations/0001_refunds.py` 의 `upgrade`, `seed/codes.sql`
   - 까닭:
     - `upgrade()` 가 끝나도 `common_codes` 는 비어 있어서, seed 를 따로 돌리기 전까지 모든 환불이 "그런 코드가 없다"로 거부됩니다.
     - seed 는 `ON CONFLICT` 가 없어서 두 번 돌리면 PK 충돌로 실패합니다. 이미 있는 코드의 `is_active` 나 `name` 변경도 반영하지 못합니다.
     - seed 의 실행 순서와 이력이 마이그레이션 리비전에 묶여 있지 않습니다.

5. **`downgrade` 가 데이터가 있는 테이블을 지움**
   - 자리: `migrations/0001_refunds.py` 의 `downgrade` (41–47줄)
   - 까닭:
     - `refunds` 가 비었는지만 확인하고 `orders` 와 `common_codes` 는 확인 없이 DROP 합니다.
     - `orders` 는 환불과 무관한 주문 원장이므로, 환불이 한 건도 없어도 주문 데이터 전체가 사라집니다.
     - `common_codes` 도 지우면 원칙 2(공통코드는 지우지 않는다)에 어긋납니다.
     - 검사 후 DROP 사이에 새 환불이 끼어들 수 있습니다. 락(`LOCK TABLE`)이 없습니다.

### 중간

6. **환불 요청에 멱등성이 없음**
   - 자리: `app/main.py` 의 `post_refund`, `refund()`
   - 까닭:
     - 멱등 키나 `(order_id, 요청 식별자)` 유니크가 없습니다.
     - 클라이언트나 프록시가 응답 유실로 재시도하면, 한도 안에서는 같은 환불이 중복으로 만들어지고 `refunded` 도 그만큼 늘어납니다.

7. **트랜잭션 경계가 라우트에 흩어져 있고 커밋 실패를 처리하지 않음**
   - 자리: `app/main.py` 35줄, `refund()` 39줄
   - 까닭:
     - 커밋은 라우트가 하고 롤백은 `session.close()` 에만 의존합니다.
     - `s.commit()` 은 `try` 밖이라 `IntegrityError` 나 직렬화 오류가 나면 500 이 그대로 나갑니다.
     - 코드 확인(`session.get`)은 잠금 없이 읽습니다. 확인과 INSERT 사이에 코드가 비활성이나 삭제로 바뀔 수 있고, 이 경우 FK 위반이 500 으로 나옵니다.
     - 서비스 함수가 호출자의 커밋에 의존하는 구조라, 다른 호출 지점이 생기면 커밋을 빠뜨릴 위험이 있습니다.

8. **`refunds` 에 시각과 행위자 기록이 없음**
   - 자리: `app/models.py` 의 `Refund`, 마이그레이션의 `refunds`
   - 까닭:
     - `created_at` 이나 처리자 칸이 없습니다. "일어난 일은 지우지 않는다"는 원칙인데 언제 누가 했는지 남지 않아 감사와 되돌림 추적이 어렵습니다.
     - `orders.refunded` 는 제자리 UPDATE 라서, 변경 이력은 `refunds` 행에만 간접적으로 남습니다.

9. **공통코드 삭제 금지가 문서와 독스트링뿐임**
   - 자리: `app/models.py` 의 `CommonCode`
   - 까닭:
     - DB 에서 DELETE 를 막는 장치가 없습니다. 참조되지 않는 코드는 지울 수 있고, FK 에 `ON DELETE` 를 명시하지 않아 기본 동작에만 의존합니다.
     - 나중에 어떤 환불도 쓰지 않던 코드를 지우면 이후 재사용이나 이력 해석에 문제가 생깁니다. REVOKE 나 트리거가 없습니다.

### 낮음

10. **`refunds.order_id` 에 인덱스가 없음**
    - 자리: `migrations/0001_refunds.py`, `app/models.py`
    - 까닭: Postgres 는 FK 컬럼에 인덱스를 자동으로 만들지 않아서, 주문별 환불 조회와 `orders` 행 변경 시 FK 검사가 느려집니다.

11. **금액이 32비트 `Integer`**
    - 자리: `orders.amount`, `orders.refunded`, `refunds.amount`
    - 까닭: 원화 기준으로는 약 21억 원이 상한입니다. 통화 단위를 정하지 않았고, 한도를 넘으면 오버플로 오류가 납니다. `BigInteger` 나 `Numeric` 을 고려할 만합니다.

12. **마이그레이션 실행 환경이 없음**
    - 자리: `migrations/`
    - 까닭: `env.py`, `alembic.ini`, `script.py.mako` 가 없고 `versions/` 구조도 아닙니다. 이 상태로는 `alembic upgrade` 를 실행할 수 없습니다. 모델과 마이그레이션에 같은 스키마가 중복 정의되어 있어 어긋날 위험도 있습니다. autogenerate 로 어긋남을 검사하지 못합니다.

13. **DB 접속 정보와 커넥션 설정이 하드코딩됨**
    - 자리: `app/main.py` 12줄
    - 까닭: 접속 URL 이 코드에 박혀 있고 비밀번호가 없습니다. 환경 설정으로 뺄 수 없고, `pool_pre_ping` 도 없어서 끊어진 커넥션을 쓰다 실패할 수 있습니다.

## 확인한 범위와 한계
- 읽은 파일: `app/main.py`, `app/services/refunds.py`, `app/models.py`, `migrations/0001_refunds.py`, `docs/schema.md`, `seed/codes.sql`, `requirements.txt`.
- 테스트나 실제 DB 실행으로 검증하지는 않았습니다. 특히 7번의 동시성 시나리오는 코드 구조에서 추론한 것입니다.
- `with_for_update` 로 주문 행을 잠그는 부분(`refund()` 28줄)은 같은 주문에 대한 동시 환불의 초과 환불을 막으므로 문제가 없다고 봤습니다.
