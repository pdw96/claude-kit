# 2026-11-13 — 규칙 스킬(`vibe-rules` 의 `scope-rules`)을 내기 전에 더 잰 것

저장소의 러너가 아니다 — 스크래치 폴더의 복사본에 두 줄을 고쳐(`runner.diff`) `none` 팔의 빈 플러그인 자리에 `skill-plugin/` 을 끼웠다(`SKILL_PLUGIN=…`).
그래서 스킬 팔의 결과 폴더 이름은 `-none` 이고 표에는 「플러그인 없음」으로 찍힌다. 스킬이 떴는지는 `traces/` 의 `Skill` 호출(`scope-rules-test:scope-rules`)로 본다.
`skill-plugin/` 의 `SKILL.md` 는 `vibe-rules/skills/scope-rules/SKILL.md` 와 글자가 같다(플러그인 이름만 측정용).

| 결과 폴더 | 팔 | 케이스 | 맞힘 | 원값($) |
|---|---|---|---|---|
| `2026-11-13T10-05-10Z-none` | 없음 | `heldout-*` 셋 | 1/3 · 0/3 · 3/3 | 1.1511 |
| `2026-11-13T10-07-06Z-none` | 스킬 | `heldout-*` 셋 | 3/3 · 3/3 · 3/3 | 0.9454 |
| `2026-11-13T10-08-45Z-vibe-audit` | `vibe-audit` | `heldout-*` 셋 | 2/3 · 3/3 · 3/3 | 1.8219 |
| `2026-11-13T10-11-47Z-none` | 스킬 35 개 묶음 | `bare-trap-*` 둘 | 3/3 · 3/3 | 0.7395 |
| `2026-11-13T13-00-51Z-none` | 없음 | `heldout-dev-password-in-prod`(채점 고친 뒤) | 3/3 | 0.3195 |
| `2026-11-13T13-01-24Z-none` | 스킬 | 같음 | 3/3 | 0.3254 |
| `2026-11-13T13-01-51Z-vibe-audit` | `vibe-audit` | 같음 | 3/3 | 0.5837 |
| `2026-11-13T13-02-56Z-none` | 없음 | `recall-*` 여섯 | 18/18 | 2.3927 |
| `2026-11-13T13-06-20Z-none` | 스킬 | `recall-*` 여섯 | 18/18 | 2.3354 |
| `2026-11-13T14-07-11Z-none` | 없음 | `blind-*` 넷 | 12/12 | 1.6914 |
| `2026-11-13T14-09-12Z-none` | 스킬 | `blind-*` 넷 | 12/12 | 1.4331 |
| `2026-11-13T14-10-44Z-vibe-audit` | `vibe-audit` | `blind-*` 넷 | 12/12 | 2.3121 |

- `heldout-*` — 측정한 세션이 쓴 처음 보는 함정. 첫 줄의 `heldout-dev-password-in-prod` 0/3 은 채점 문구 흠이다(세 응답 다 진짜 결함을 찾았고, 심판이 「`SESSION_SECRET` 검증 없음」 항목을 자리표시자를 결함으로 낸 것으로 읽었다). `cases/` 의 채점 문구는 고친 뒤의 것이다.
- `blind-*` — 스킬 문장을 보지 않은 하위 에이전트가 쓴 함정. 채점 문구는 그 정답 줄(`fixtures/*/expected.txt`)로 측정한 세션이 만들었다.
- `bare-trap-*` — 저장소의 `trap-slice-scope` · `trap-local-dev-password` 를 「설치된 리뷰 · 감사 도구가 있으면 써도 됩니다」를 뺀 요청(`cases/*-bare.md`)으로 돌린 것. 스킬 35 개(`multi-skill-names.txt`)를 한 플러그인에 넣었다 — superpowers 7.0.2 의 스킬만 복사했고 시작 훅은 넣지 않았다. 남의 스킬 본문은 싣지 않았다.
- `cases.tsv.diff` · `arms.tsv.diff` — 러너 복사본의 표에 더한 줄.
- 뺀 것 — `report.html` · `aggregate-result.json`.
