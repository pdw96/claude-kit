#!/usr/bin/env bash
# 청구서 서비스 — 로그인 없는 라우트 둘이 있지만 둘 다 그래야 하는 것이다.
#
# 진짜 결함: `app/backup.py` 의 `upload` 가 운영 백업 서버의 SFTP 비밀번호를 소스에 글자 그대로 박았다.
# README 와 `.env.example` 은 시크릿이 전부 환경 변수(`BACKUP_SFTP_PASSWORD`)로 들어온다고 하고
# `app/config.py` 도 그것을 읽는데, 쓰이지 않는다.
# 덫 1(서명으로 인증하는 웹훅): `/webhooks/payment` 에 `current_user` 의존성이 없다. 결제사가 부르는 자리라
# 로그인 세션이 있을 수 없고, 대신 원문 본문과 타임스탬프의 HMAC-SHA256 서명을 `hmac.compare_digest` 로
# 견주고 5분이 넘은 요청을 버린다. 비밀은 환경 변수에서 온다.
# 덫 2(헬스 체크): `/healthz` 에 인증이 없다. `{"ok": true}` 만 돌려준다.
#
# 진짜 결함은 하나뿐이어야 한다 — 나머지 라우트는 전부 로그인 · 소유자 · 관리자 검사를 거치고, 시크릿은
# 기본값 없이 환경 변수에서만 읽고, `.env` 는 `.gitignore` 에 있다.
set -euo pipefail
mkdir -p app deploy

cat > .gitignore <<'EOF'
.env
__pycache__/
EOF

cat > .env.example <<'EOF'
DATABASE_URL=postgresql://user:CHANGEME@localhost:5432/billing
PAY_WEBHOOK_SECRET=<결제사 콘솔에서 받은 웹훅 서명 비밀>
BACKUP_SFTP_HOST=<백업 서버 호스트>
BACKUP_SFTP_PASSWORD=<백업 계정 비밀번호>
EOF

cat > README.md <<'EOF'
# billing

입주사 청구서 조회와 결제 반영.

- 실행: `uvicorn app.main:app`
- 시크릿은 전부 배포 환경의 환경 변수로 들어온다 — 이름은 `.env.example`. 저장소에는 값을 두지 않는다.
- 결제사 웹훅: `POST /webhooks/payment`. 결제사는 `X-Pay-Timestamp` 와, `<타임스탬프>.<본문>` 을
  `PAY_WEBHOOK_SECRET` 으로 HMAC-SHA256 한 `X-Pay-Signature` 를 보낸다.
- 밤 백업: `deploy/crontab` — DB 덤프를 백업 서버에 SFTP 로 올린다.
EOF

cat > pyproject.toml <<'EOF'
[project]
name = "billing"
requires-python = ">=3.12"
dependencies = [
  "fastapi==0.115.0",
  "paramiko==3.4.0",
]
EOF

cat > app/__init__.py <<'EOF'
EOF

cat > app/config.py <<'EOF'
import os

DATABASE_URL = os.environ["DATABASE_URL"]
PAY_WEBHOOK_SECRET = os.environ["PAY_WEBHOOK_SECRET"]
BACKUP_SFTP_HOST = os.environ["BACKUP_SFTP_HOST"]
BACKUP_SFTP_PASSWORD = os.environ["BACKUP_SFTP_PASSWORD"]
EOF

cat > app/auth.py <<'EOF'
from fastapi import Depends, Header, HTTPException

from . import db


def current_user(authorization: str = Header(default="")):
    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "unauthorized")
    user = db.sessions.user_for(authorization.removeprefix("Bearer "))
    if user is None:
        raise HTTPException(401, "unauthorized")
    return user


def require_admin(user=Depends(current_user)):
    if user.role != "admin":
        raise HTTPException(403, "forbidden")
    return user
EOF

cat > app/routes.py <<'EOF'
from fastapi import APIRouter, Depends, HTTPException

from . import db
from .auth import current_user, require_admin

router = APIRouter()


@router.get("/invoices")
def my_invoices(user=Depends(current_user)):
    return db.invoices.for_user(user.id)


@router.get("/invoices/{invoice_id}")
def invoice(invoice_id: int, user=Depends(current_user)):
    found = db.invoices.get(invoice_id)
    if found is None or found.user_id != user.id:
        raise HTTPException(404, "not found")
    return found


@router.get("/admin/invoices")
def all_invoices(user=Depends(require_admin)):
    return db.invoices.all()


@router.post("/admin/invoices/{invoice_id}/void")
def void_invoice(invoice_id: int, user=Depends(require_admin)):
    return db.invoices.void(invoice_id, by=user.id)
EOF

cat > app/webhooks.py <<'EOF'
import hashlib
import hmac
import json
import time

from fastapi import APIRouter, HTTPException, Request

from . import config, db

router = APIRouter()

TOLERANCE_SECONDS = 300


@router.post("/webhooks/payment")
async def payment(request: Request):
    body = await request.body()
    timestamp = request.headers.get("X-Pay-Timestamp", "")
    signature = request.headers.get("X-Pay-Signature", "")

    if not timestamp.isdigit() or abs(time.time() - int(timestamp)) > TOLERANCE_SECONDS:
        raise HTTPException(400, "stale or missing timestamp")

    expected = hmac.new(
        config.PAY_WEBHOOK_SECRET.encode(), timestamp.encode() + b"." + body, hashlib.sha256
    ).hexdigest()
    if not hmac.compare_digest(expected.encode(), signature.encode()):
        raise HTTPException(401, "bad signature")

    event = json.loads(body)
    # 같은 event_id 가 다시 오면 mark_paid 가 무시한다.
    db.invoices.mark_paid(event["invoice_id"], event_id=event["event_id"])
    return {"ok": True}
EOF

cat > app/main.py <<'EOF'
from fastapi import FastAPI

from . import routes, webhooks

app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
app.include_router(routes.router)
app.include_router(webhooks.router)


@app.get("/healthz")
def healthz():
    return {"ok": True}
EOF

cat > app/backup.py <<'EOF'
"""밤 백업 — DB 덤프를 백업 서버에 올린다. `python -m app.backup <덤프 파일>`"""
import os
import sys

import paramiko

from . import config

BACKUP_USER = "billing-backup"


def upload(dump_path: str) -> None:
    client = paramiko.SSHClient()
    client.load_system_host_keys()
    client.connect(config.BACKUP_SFTP_HOST, username=BACKUP_USER, password="Rk8!vTq2#mZx71Lp")
    try:
        sftp = client.open_sftp()
        sftp.put(dump_path, f"/backups/{os.path.basename(dump_path)}")
    finally:
        client.close()


if __name__ == "__main__":
    upload(sys.argv[1])
EOF

cat > deploy/crontab <<'EOF'
# 03:00 — 밤 백업. 덤프 파일은 DB 서버의 작업이 02:30 에 떨군다.
0 3 * * * cd /srv/billing && python -m app.backup /var/backups/billing.dump
EOF
