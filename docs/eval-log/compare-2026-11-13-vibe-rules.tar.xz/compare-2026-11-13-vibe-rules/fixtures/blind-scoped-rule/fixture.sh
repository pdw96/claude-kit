#!/usr/bin/env bash
# 공유 오피스 회의실 예약 — 규칙에 적힌 범위와 예외가 있는 레포.
#
# 진짜 결함: `CLAUDE.md` 앵커볼트가 「`app/` 의 코드는 예약 행을 지우지 않는다 — 취소는 `cancelled_at` 을
# 채운다」고 하고 조각 1 설계 ② 도 같은 것을 보장하는데, `app/bookings.py` 의 `cancel` 이 행을 `delete` 한다.
# 그래서 `app/settlement.py` 가 세는 취소 건수가 앱으로 취소한 예약에 대해 늘 0 이다.
# 덫 1(규칙에 적힌 예외): `CLAUDE.md` 스택이 「`app/` 은 표준 라이브러리와 위 셋만」이라는데
# `scripts/import_legacy.py` 가 pandas 를 쓴다. 같은 파일 작업 방식이 `scripts/` 의 일회성 이전 스크립트는
# 스택 제한 밖이고 dev 의존성 pandas 를 써도 된다고 적었고, `pyproject.toml` 도 pandas 를 dev 에만 둔다.
# 덫 2(규칙의 범위): `tests/test_settlement.py` 의 픽스처가 시험마다 `bookings` 행을 `delete` 한다. 규칙은 `app/` 의 코드에
# 걸리고, 시험은 임시 DB 파일에서 돈다.
#
# 진짜 결함은 하나뿐이어야 한다 — 문서가 약속한 나머지(예약 · 겹침 거절 · 현황, 월 정산의 사용 분과 취소
# 건수 셈, 옛 기록 이전, 설계 ⑤ 의 시험)는 코드가 받친다.
set -euo pipefail
mkdir -p app scripts tests docs/slices/1-booking docs/slices/2-settlement

cat > CLAUDE.md <<'MD'
# 회의실 예약 작업 규칙

의도는 `INTENT.md`, 조각 나눔은 `docs/master-plan.md`, 조각의 요구사항 · 설계는 `docs/slices/` 에 있다.

## 스택
- Python 3.12 · FastAPI 0.115 · SQLAlchemy 2.0
- `app/` 은 표준 라이브러리와 위 셋만 쓴다. 운영 서버에는 이것만 깐다.

## 앵커볼트 — 바꾸려면 먼저 물어볼 것
- `bookings` 테이블 스키마
- `app/` 의 코드는 예약 행을 지우지 않는다 — 취소는 `cancelled_at` 을 채운다. 월 정산이 취소 건수를 센다.

## 작업 방식
- 조각 하나씩. 요구사항과 설계를 한 PR 로 낸 뒤 구현한다
- `scripts/` 의 일회성 이전 스크립트는 스택 제한 밖이다 — 관리자 노트북에서 한 번 돌리고, dev 의존성(pandas)을 써도 된다
MD

cat > INTENT.md <<'MD'
# 회의실 예약 — 의도

## Why
입주사들이 회의실을 단체 대화방에서 잡아 자주 겹친다. 월말에는 관리자가 대화방을 거슬러 올라가 입주사별 사용 시간을 손으로 센다.

## What
- 회의실 예약과 취소
- 입주사별 월 정산 — 사용 시간과 취소 건수

## Not
1. 결제를 붙이지 않는다 — 관리자가 정산 결과를 관리비 청구서에 옮겨 적는다.
2. 외부 캘린더와 연동하지 않는다.
MD

cat > docs/master-plan.md <<'MD'
# 회의실 예약 마스터플랜

## 가리키는 문서

| 무엇 | 어디 |
|---|---|
| 의도 — Why · What · Not | `INTENT.md` |
| 작업 규칙 | `CLAUDE.md` |
| 조각의 요구사항 · 설계 | `docs/slices/` |

## 조각 나눔

| 순서 | 조각 | 목표 한 줄 | 의존 | 상태 | 조각 폴더 |
|---|---|---|---|---|---|
| 1 | 예약 | 입주사가 회의실을 예약하고 취소한다. 겹치면 거절한다 | — | 닫힘 | `docs/slices/1-booking/` |
| 2 | 월 정산 | 입주사별 월 사용 시간과 취소 건수를 내고, 옛 엑셀 기록을 옮긴다 | 예약 | 진행 | `docs/slices/2-settlement/` |
MD

cat > docs/slices/1-booking/requirements.md <<'MD'
# 조각 1 — 예약 (2026-08-03 착공)

## 문제
회의실 예약이 단체 대화방에 흩어져 있어 겹친다.

## 핵심 사용자와 시나리오
- 사용자: 입주사 직원
- 시나리오: 회의실과 시간을 골라 예약하고, 못 쓰게 되면 취소한다. 회의실의 예약 현황을 본다.

## 성공 기준
- 회의실 · 시작 · 끝으로 예약한다
- 같은 회의실에 시간이 겹치는 예약은 거절한다
- 예약을 취소하면 그 시간이 다시 빈다
- 회의실의 살아 있는 예약을 본다

## 하지 않을 일
1. 반복 예약은 만들지 않는다.
2. 예약 승인 절차를 두지 않는다 — 먼저 잡은 쪽이 쓴다.

## 제약
- 리뷰 3라운드

## 닫으며 (2026-08-21)
성공 기준 넷을 화면에서 한 번씩 해 봤다. 다음 조각은 조각 나눔 2 「월 정산」.
MD

cat > docs/slices/1-booking/design.md <<'MD'
# 조각 1 설계 — 예약

## ① 바뀌는 것
`app/db.py` 의 `bookings` 테이블, `app/bookings.py` 의 예약 · 취소 · 현황, `app/main.py` 의 라우트.

## ② 보장하는 것 / 보장하지 않는 것
한 회의실에 살아 있는 예약끼리는 시간이 겹치지 않는다. 취소한 예약은 행이 남고 `cancelled_at` 이 찬다 — 겹침 검사와 현황은 그것이 빈 행만 본다.

## ③ 받는 입력
회의실 이름, 입주사 이름, 시작 · 끝 시각.

## ④ 결정
취소를 행 삭제가 아니라 `cancelled_at` 으로 — 정산 때 취소 건수를 세야 한다(`CLAUDE.md` 앵커볼트).

## ⑤ 검증 계획
화면에서 예약 · 겹침 거절 · 취소 · 현황을 한 번씩 해 본다.

## ⑥ PR 나눔
한 PR.
MD

cat > docs/slices/2-settlement/requirements.md <<'MD'
# 조각 2 — 월 정산 (2026-09-01 착공)

## 문제
월말에 관리자가 입주사별 사용 시간과 취소 건수를 손으로 센다.

## 핵심 사용자와 시나리오
- 사용자: 공유 오피스 관리자
- 시나리오: 달을 고르면 입주사별 사용 분과 취소 건수가 나온다. 그 숫자를 관리비 청구서에 옮긴다.

## 성공 기준
- 달(`YYYY-MM`)을 주면 입주사별 사용 분과 취소 건수가 나온다 — 취소한 예약은 사용 분에 넣지 않는다
- 옛 엑셀에서 CSV 로 내보낸 2026년 1 ~ 8월 예약을 한 번 옮긴다

## 하지 않을 일
1. 요금을 계산하지 않는다 — 시간과 건수만 낸다.
2. 취소 수수료를 매기지 않는다.
3. 정산표를 PDF 로 만들지 않는다.

## 제약
- 리뷰 3라운드
MD

cat > docs/slices/2-settlement/design.md <<'MD'
# 조각 2 설계 — 월 정산

## ① 바뀌는 것
`app/settlement.py` 의 월 정산, `app/main.py` 의 `/admin/settlement`, `scripts/import_legacy.py` 의 옛 기록 이전.

## ② 보장하는 것 / 보장하지 않는 것
예약은 시작 시각이 든 달에 센다. 살아 있는 예약은 사용 분에, `cancelled_at` 이 찬 예약은 취소 건수에 든다.

## ③ 받는 입력
`bookings` 테이블, 달(`YYYY-MM`). 이전 스크립트는 `room,tenant,start,end,cancelled_at` 열의 CSV.

## ④ 결정
이전 스크립트에 pandas — 옛 엑셀의 날짜 꼴이 섞여 있어 손으로 읽는 것보다 낫다. 한 번 돌리고 끝이라 `app/` 밖 `scripts/` 에 둔다.

## ⑤ 검증 계획
입주사 둘 · 살아 있는 예약 둘 · 취소한 예약 하나로 정산을 센다 — `tests/test_settlement.py`.

## ⑥ PR 나눔
한 PR.
MD

cat > pyproject.toml <<'TOML'
[project]
name = "room-booking"
requires-python = ">=3.12"
dependencies = [
  "fastapi==0.115.0",
  "sqlalchemy==2.0.30",
]

[project.optional-dependencies]
dev = ["pytest==8.3.3", "pandas==2.2.2"]
TOML

cat > app/__init__.py <<'PY'
PY

cat > app/db.py <<'PY'
import os

from sqlalchemy import Column, DateTime, Integer, MetaData, String, Table, create_engine

metadata = MetaData()

bookings = Table(
    "bookings", metadata,
    Column("id", Integer, primary_key=True),
    Column("room", String, nullable=False),
    Column("tenant", String, nullable=False),
    Column("start", DateTime, nullable=False),
    Column("end", DateTime, nullable=False),
    Column("cancelled_at", DateTime),
)

engine = create_engine(os.environ.get("ROOMS_DB", "sqlite:///rooms.db"))
metadata.create_all(engine)
PY

cat > app/bookings.py <<'PY'
from datetime import datetime

from sqlalchemy import delete, insert, select

from .db import bookings, engine


def book(room: str, tenant: str, start: datetime, end: datetime) -> int:
    if end <= start:
        raise ValueError("끝이 시작보다 늦어야 한다")
    with engine.begin() as c:
        clash = c.execute(
            select(bookings.c.id).where(
                bookings.c.room == room,
                bookings.c.cancelled_at.is_(None),
                bookings.c.start < end,
                bookings.c.end > start,
            )
        ).first()
        if clash is not None:
            raise ValueError("겹치는 예약이 있다")
        r = c.execute(insert(bookings).values(room=room, tenant=tenant, start=start, end=end))
    return r.inserted_primary_key[0]


def cancel(booking_id: int) -> bool:
    with engine.begin() as c:
        r = c.execute(delete(bookings).where(bookings.c.id == booking_id))
    return r.rowcount == 1


def active(room: str) -> list:
    with engine.connect() as c:
        return c.execute(
            select(bookings.c.id, bookings.c.tenant, bookings.c.start, bookings.c.end)
            .where(bookings.c.room == room, bookings.c.cancelled_at.is_(None))
            .order_by(bookings.c.start)
        ).all()
PY

cat > app/settlement.py <<'PY'
from datetime import datetime

from sqlalchemy import select

from .db import bookings, engine


def monthly(month: str) -> dict[str, dict[str, int]]:
    """입주사별 사용 분과 취소 건수. 예약은 시작 시각이 든 달에 센다."""
    first = datetime.strptime(month, "%Y-%m")
    nxt = datetime(first.year + first.month // 12, first.month % 12 + 1, 1)
    with engine.connect() as c:
        rows = c.execute(
            select(bookings.c.tenant, bookings.c.start, bookings.c.end, bookings.c.cancelled_at)
            .where(bookings.c.start >= first, bookings.c.start < nxt)
        ).all()
    out: dict[str, dict[str, int]] = {}
    for r in rows:
        t = out.setdefault(r.tenant, {"minutes": 0, "cancelled": 0})
        if r.cancelled_at is None:
            t["minutes"] += int((r.end - r.start).total_seconds() // 60)
        else:
            t["cancelled"] += 1
    return out
PY

cat > app/main.py <<'PY'
from datetime import datetime

from fastapi import FastAPI, HTTPException

from . import bookings, settlement

app = FastAPI()


@app.post("/bookings")
def book(room: str, tenant: str, start: datetime, end: datetime) -> dict:
    try:
        return {"id": bookings.book(room, tenant, start, end)}
    except ValueError as e:
        raise HTTPException(409, str(e))


@app.post("/bookings/{booking_id}/cancel")
def cancel(booking_id: int) -> dict:
    if not bookings.cancel(booking_id):
        raise HTTPException(404, "예약이 없다")
    return {"ok": True}


@app.get("/rooms/{room}/bookings")
def active(room: str) -> list[dict]:
    return [
        {"id": r.id, "tenant": r.tenant, "start": r.start.isoformat(), "end": r.end.isoformat()}
        for r in bookings.active(room)
    ]


@app.get("/admin/settlement")
def monthly(month: str) -> dict:
    try:
        return settlement.monthly(month)
    except ValueError:
        raise HTTPException(422, "month 는 YYYY-MM")
PY

cat > scripts/import_legacy.py <<'PY'
"""옛 엑셀에서 CSV 로 내보낸 2026년 1 ~ 8월 예약을 한 번 옮긴다.

관리자 노트북에서 돌린다: pip install -e .[dev] 뒤
ROOMS_DB=<운영 DB> python scripts/import_legacy.py legacy.csv
"""
import sys

import pandas as pd
from sqlalchemy import insert

from app.db import bookings, engine


def main(path: str) -> None:
    df = pd.read_csv(path, parse_dates=["start", "end", "cancelled_at"])
    rows = [
        {
            "room": r.room,
            "tenant": r.tenant,
            "start": r.start.to_pydatetime(),
            "end": r.end.to_pydatetime(),
            "cancelled_at": None if pd.isna(r.cancelled_at) else r.cancelled_at.to_pydatetime(),
        }
        for r in df.itertuples()
    ]
    with engine.begin() as c:
        c.execute(insert(bookings), rows)
    print(f"{len(rows)}건 옮김")


if __name__ == "__main__":
    main(sys.argv[1])
PY

cat > tests/test_settlement.py <<'PY'
import os
import tempfile

# 시험은 임시 DB 파일에서 돈다 — app.db 를 들이기 전에 정한다.
os.environ["ROOMS_DB"] = f"sqlite:///{tempfile.mkdtemp()}/test.db"

from datetime import datetime

import pytest
from sqlalchemy import delete, insert

from app.db import bookings, engine
from app.settlement import monthly


@pytest.fixture(autouse=True)
def empty_bookings():
    with engine.begin() as c:
        c.execute(delete(bookings))
    yield


def test_minutes_and_cancellations_per_tenant():
    with engine.begin() as c:
        c.execute(insert(bookings), [
            {"room": "A", "tenant": "가람", "start": datetime(2026, 9, 1, 10), "end": datetime(2026, 9, 1, 11),
             "cancelled_at": None},
            {"room": "A", "tenant": "가람", "start": datetime(2026, 9, 2, 10), "end": datetime(2026, 9, 2, 12),
             "cancelled_at": datetime(2026, 9, 1, 9)},
            {"room": "B", "tenant": "누리", "start": datetime(2026, 9, 30, 23), "end": datetime(2026, 10, 1, 0, 30),
             "cancelled_at": None},
        ])
    assert monthly("2026-09") == {
        "가람": {"minutes": 60, "cancelled": 1},
        "누리": {"minutes": 90, "cancelled": 0},
    }
    assert monthly("2026-10") == {}
PY
