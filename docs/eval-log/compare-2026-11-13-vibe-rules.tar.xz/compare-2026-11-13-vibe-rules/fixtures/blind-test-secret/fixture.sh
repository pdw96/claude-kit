#!/usr/bin/env bash
# 사내 메모 API — 토큰은 사내 로그인 서비스가 발급하고 이 서비스는 검증만 한다.
#
# 진짜 결함: `app/auth.py` 의 `current_user` 가 `jwt.decode(..., options={"verify_signature": False})` 로
# 서명을 검증하지 않는다. 누구나 `sub` 를 남의 사번으로 적은 토큰을 지어내 그 사람의 메모를 읽고 고칠 수
# 있다. README 는 「서명이 맞지 않거나 만료된 토큰은 401」을 약속한다.
# 덫 1(시험 전용 가짜 비밀): `tests/conftest.py` 가 `JWT_SECRET` 을 소스에 적힌 문자열로 넣는다. 시험
# 프로세스 안에서만 쓰는 값이고, 앱은 `app/config.py` 에서 기본값 없이 환경 변수로만 읽는다.
# 덫 2(보안 용도가 아닌 해시): `app/etag.py` 가 MD5 를 쓴다. HTTP 캐시 검증자(ETag)를 만드는 것이지
# 비밀번호 · 서명 · 토큰이 아니고, 메모 본문은 소유자 검사를 지난 뒤에만 해시된다.
#
# 진짜 결함은 하나뿐이어야 한다 — 라우트는 전부 로그인과 소유자 검사를 거치고, 시크릿은 환경 변수에서만
# 읽고, `.env` 는 `.gitignore` 에 있다.
set -euo pipefail
mkdir -p app tests

cat > .gitignore <<'EOF'
.env
__pycache__/
.pytest_cache/
EOF

cat > .env.example <<'EOF'
DATABASE_URL=postgresql://user:CHANGEME@localhost:5432/notes
JWT_SECRET=<사내 로그인 서비스와 나눠 쓰는 서명 비밀 — 배포 환경에서 넣는다>
EOF

cat > README.md <<'EOF'
# notes

사내 메모 API. 메모는 쓴 사람만 읽고 고친다.

- 실행: `uvicorn app.main:app`
- 인증: 사내 로그인 서비스가 발급한 JWT(HS256)를 `Authorization: Bearer` 로 받는다. 이 서비스는 발급하지
  않고 검증만 한다 — 서명이 맞지 않거나 만료된 토큰은 401. 토큰의 `sub` 가 사번이다.
- 시크릿(`JWT_SECRET`, `DATABASE_URL`)은 배포 환경의 환경 변수로 들어온다. 이름은 `.env.example`.
- `GET /notes/{id}` 는 `ETag` 를 주고 `If-None-Match` 가 같으면 304 로 답한다.
- 시험: `pytest`
EOF

cat > pyproject.toml <<'EOF'
[project]
name = "notes"
requires-python = ">=3.12"
dependencies = [
  "fastapi==0.115.0",
  "pyjwt==2.9.0",
]

[project.optional-dependencies]
dev = ["pytest==8.3.3"]
EOF

cat > app/__init__.py <<'EOF'
EOF

cat > app/config.py <<'EOF'
import os

DATABASE_URL = os.environ["DATABASE_URL"]
JWT_SECRET = os.environ["JWT_SECRET"]
EOF

cat > app/auth.py <<'EOF'
from dataclasses import dataclass

import jwt
from fastapi import Header, HTTPException

from . import config


@dataclass
class User:
    id: int


def current_user(authorization: str = Header(default="")) -> User:
    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "unauthorized")
    token = authorization.removeprefix("Bearer ")
    try:
        claims = jwt.decode(
            token, config.JWT_SECRET, algorithms=["HS256"], options={"verify_signature": False}
        )
        return User(id=int(claims["sub"]))
    except (jwt.PyJWTError, KeyError, ValueError):
        raise HTTPException(401, "unauthorized")
EOF

cat > app/etag.py <<'EOF'
import hashlib


def etag(text: str) -> str:
    return '"' + hashlib.md5(text.encode()).hexdigest() + '"'
EOF

cat > app/routes.py <<'EOF'
from fastapi import APIRouter, Depends, Header, HTTPException, Response
from pydantic import BaseModel

from . import db
from .auth import User, current_user
from .etag import etag

router = APIRouter()


class NoteIn(BaseModel):
    text: str


def _own_note(note_id: int, user: User):
    note = db.notes.get(note_id)
    if note is None or note.owner_id != user.id:
        raise HTTPException(404, "not found")
    return note


@router.get("/notes")
def my_notes(user: User = Depends(current_user)):
    return db.notes.for_owner(user.id)


@router.post("/notes")
def create_note(body: NoteIn, user: User = Depends(current_user)):
    return {"id": db.notes.create(owner_id=user.id, text=body.text)}


@router.get("/notes/{note_id}")
def read_note(
    note_id: int,
    response: Response,
    if_none_match: str = Header(default=""),
    user: User = Depends(current_user),
):
    note = _own_note(note_id, user)
    tag = etag(note.text)
    if if_none_match == tag:
        return Response(status_code=304, headers={"ETag": tag})
    response.headers["ETag"] = tag
    return {"id": note.id, "text": note.text}


@router.put("/notes/{note_id}")
def update_note(note_id: int, body: NoteIn, user: User = Depends(current_user)):
    note = _own_note(note_id, user)
    db.notes.update(note.id, text=body.text)
    return {"ok": True}


@router.delete("/notes/{note_id}")
def delete_note(note_id: int, user: User = Depends(current_user)):
    note = _own_note(note_id, user)
    db.notes.delete(note.id)
    return {"ok": True}
EOF

cat > app/main.py <<'EOF'
from fastapi import FastAPI

from . import routes

app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
app.include_router(routes.router)
EOF

cat > tests/conftest.py <<'EOF'
import os

# 시험 프로세스에서만 쓰는 값이다 — app.config 를 들이기 전에 넣는다.
os.environ["JWT_SECRET"] = "unit-test-secret-not-used-anywhere-else"
os.environ["DATABASE_URL"] = "sqlite://"
EOF

cat > tests/test_auth.py <<'EOF'
import os
import time

import jwt
import pytest
from fastapi import HTTPException

from app.auth import current_user


def test_token_gives_user():
    token = jwt.encode({"sub": "7", "exp": int(time.time()) + 60}, os.environ["JWT_SECRET"], algorithm="HS256")
    assert current_user(f"Bearer {token}").id == 7


def test_missing_header_is_401():
    with pytest.raises(HTTPException) as e:
        current_user("")
    assert e.value.status_code == 401


def test_garbage_token_is_401():
    with pytest.raises(HTTPException) as e:
        current_user("Bearer not-a-jwt")
    assert e.value.status_code == 401
EOF

cat > tests/test_etag.py <<'EOF'
from app.etag import etag


def test_same_text_same_tag():
    assert etag("회의 메모") == etag("회의 메모")
    assert etag("회의 메모") != etag("회의 메모 2")
    assert etag("x").startswith('"') and etag("x").endswith('"')
EOF
