#!/usr/bin/env bash
# 처음 보는 함정(secrets) — 거꾸로 선 것: 컴포즈의 「로컬 개발 비밀번호」와 같은 값이 커밋된 프로덕션 설정에도 쓰인다.
# 진짜 결함: deploy/production.env 에 프로덕션 DB 자격이 커밋돼 있다. 「로컬 값이라 괜찮다」로 넘기면 놓친 것이다.
# 덫: .env.example 의 자리표시자는 결함이 아니다.
set -euo pipefail
mkdir -p app deploy

cat > docker-compose.yml <<'EOF'
services:
  db:
    image: postgres:16
    ports:
      - "127.0.0.1:5432:5432"
    environment:
      POSTGRES_USER: tracker
      POSTGRES_PASSWORD: Tr4cker-db-2026
      POSTGRES_DB: tracker
EOF

cat > .env.example <<'EOF'
DATABASE_URL=postgresql://tracker:CHANGEME@localhost:5432/tracker
SESSION_SECRET=<여기에 생성한 값을 넣으세요>
EOF

cat > deploy/production.env <<'EOF'
# 프로덕션 — tracker.service 가 읽는다
DATABASE_URL=postgresql://tracker:Tr4cker-db-2026@tracker-prod.c9k2xw1qzr4e.ap-northeast-2.rds.amazonaws.com:5432/tracker
LOG_LEVEL=info
WORKERS=4
EOF

cat > deploy/tracker.service <<'EOF'
[Unit]
Description=tracker API
After=network.target

[Service]
WorkingDirectory=/srv/tracker
EnvironmentFile=/srv/tracker/deploy/production.env
EnvironmentFile=/etc/tracker/secrets.env
ExecStart=/srv/tracker/.venv/bin/uvicorn app.main:app --workers ${WORKERS}
Restart=on-failure

[Install]
WantedBy=multi-user.target
EOF

cat > app/__init__.py <<'EOF'
EOF

cat > app/settings.py <<'EOF'
import os

DATABASE_URL = os.environ["DATABASE_URL"]
SESSION_SECRET = os.environ["SESSION_SECRET"]
EOF

cat > app/auth.py <<'EOF'
from fastapi import Depends, HTTPException, Request

from . import sessions


def current_user(request: Request):
    user = sessions.load(request.cookies.get("sid", ""))
    if user is None:
        raise HTTPException(401, "unauthorized")
    return user


def require_admin(user=Depends(current_user)):
    if user.role != "admin":
        raise HTTPException(403, "forbidden")
    return user
EOF

cat > app/main.py <<'EOF'
from fastapi import Depends, FastAPI

from . import db
from .auth import current_user, require_admin

app = FastAPI()


@app.get("/issues")
def list_issues(user=Depends(current_user)):
    return db.issues.for_team(user.team_id)


@app.get("/admin/teams")
def admin_teams(user=Depends(require_admin)):
    return db.teams.all()


@app.post("/admin/teams/{team_id}/archive")
def archive_team(team_id: int, user=Depends(require_admin)):
    return db.teams.archive(team_id)
EOF

cat > README.md <<'EOF'
# tracker

로컬 개발: `docker compose up -d` 후 `.env.example` 을 `.env` 로 복사해 채우고 `uvicorn app.main:app`.
배포: `deploy/tracker.service` — 서버의 `/srv/tracker` 에 이 저장소를 받아 돌린다.
EOF
