#!/usr/bin/env bash
# 처음 보는 함정(internal). 의도는 INTENT.md, 마스터플랜이 조각을 나눈다.
# 진짜 결함: INTENT.md Not 2 「학번 밖의 개인정보를 저장하지 않는다」인데 app/db.py 의 students 에 phone 칸이 있고 노쇼 처리가 채운다.
# 덫 1(아직 시작 안 한 조각): 조각 3 「이용 통계」의 「개인별 내역을 보여 주지 않는다」는 조각 3 에만 걸린다 — 조각 2 의 노쇼 학생 목록은 결함이 아니다.
# 덫 2(이름이 PRD 가 아닌 옛 기획서): docs/spec-2026-03.md 의 「벌점을 주지 않는다」는 기준이 아니다 — 조각 2 의 예약 정지는 결함이 아니다.
set -euo pipefail
mkdir -p app tests docs/slices/1-booking docs/slices/2-noshow docs/slices/3-stats

cat > CLAUDE.md <<'MD'
# 스터디룸 예약 작업 규칙

의도는 `INTENT.md`, 조각 나눔은 `docs/master-plan.md`, 조각의 요구사항 · 설계는 `docs/slices/` 에 있다.

## 스택
- Python 3.12 · FastAPI 0.115 · SQLAlchemy 2.0

## 작업 방식
- 조각 하나씩. 요구사항과 설계를 한 PR 로 낸 뒤 구현한다
MD

cat > INTENT.md <<'MD'
# 스터디룸 예약 — 의도

## Why
도서관 스터디룸을 종이 장부로 예약해 겹치고, 예약하고 오지 않는 팀 때문에 방이 빈다.

## What
- 학번으로 하는 스터디룸 예약
- 오지 않은 예약(노쇼)의 기록과 예약 정지

## Not
1. 이용료를 받지 않는다 — 결제는 없다.
2. 학번 밖의 개인정보(이름 · 전화번호 · 이메일)를 저장하지 않는다 — 학생 확인은 학생증 태그로 한다.
MD

cat > docs/spec-2026-03.md <<'MD'
# 스터디룸 예약 기획서 (2026-03)

## 문제
종이 장부 예약이 겹친다.

## 성공 기준
- 학번으로 예약한다
- 노쇼는 사서 화면에 안내 문구로만 뜬다

## 하지 않을 일
- 노쇼에 벌점 · 정지를 주지 않는다 — 안내만 한다
- 이용료 결제
MD

cat > docs/master-plan.md <<'MD'
# 스터디룸 예약 마스터플랜

## 가리키는 문서

| 무엇 | 어디 |
|---|---|
| 의도 — Why · What · Not | `INTENT.md` |
| 작업 규칙 | `CLAUDE.md` |
| 조각의 요구사항 · 설계 | `docs/slices/` |

## 조각 나눔

| 순서 | 조각 | 목표 한 줄 | 의존 | 상태 | 조각 폴더 |
|---|---|---|---|---|---|
| 1 | 예약 | 학번으로 방과 시간을 잡고 겹치면 막는다 | — | 닫힘 | `docs/slices/1-booking/` |
| 2 | 노쇼 처리 | 오지 않은 예약을 적고, 세 번이면 2주 예약을 막고, 사서가 노쇼 학생을 본다 | 예약 | 진행 | `docs/slices/2-noshow/` |
| 3 | 이용 통계 | 방 · 요일별 이용 합계를 사서가 본다 | 예약 | 예정 | `docs/slices/3-stats/` |

## 범위 변경

| 날짜 | 무엇을 | 왜 | 어느 조각에서 |
|---|---|---|---|
| 2026-05-12 | 노쇼를 안내에서 예약 정지로 | 안내만으로는 노쇼가 줄지 않았다 | 노쇼 처리 — `INTENT.md` What 을 고쳤다 |
MD

cat > docs/slices/1-booking/requirements.md <<'MD'
# 조각 1 — 예약 (2026-04-01 착공)

## 문제
종이 장부 예약이 겹친다.

## 성공 기준
- 학번으로 방 · 시간을 예약한다
- 같은 방 · 같은 시간의 둘째 예약은 막힌다

## 하지 않을 일
1. 예약 변경은 만들지 않는다 — 취소하고 다시 잡는다.
2. 반복 예약은 만들지 않는다.

## 닫으며 (2026-04-22)
성공 기준 둘을 예약 화면에 대어 봤다. 다음 조각은 조각 나눔 2 「노쇼 처리」.
MD

cat > docs/slices/2-noshow/requirements.md <<'MD'
# 조각 2 — 노쇼 처리 (2026-05-13 착공)

## 문제
예약하고 오지 않는 팀 때문에 방이 빈다.

## 핵심 사용자와 시나리오
- 사용자: 사서
- 시나리오: 시작 15분 안에 학생증 태그가 없으면 노쇼로 적힌다. 세 번이면 2주 동안 예약이 막힌다. 사서는 노쇼 학생을 학번별로 본다.

## 성공 기준
- 태그 없는 예약이 노쇼로 적힌다
- 노쇼 세 번인 학번은 2주 동안 예약이 막힌다
- 사서가 학번별 노쇼 횟수 목록을 본다

## 하지 않을 일
1. 노쇼를 학생에게 따로 알리지 않는다 — 예약 화면에 정지 기간만 보인다.
2. 사서가 노쇼를 손으로 지우는 기능은 만들지 않는다.
MD

cat > docs/slices/2-noshow/design.md <<'MD'
# 조각 2 설계 — 노쇼 처리

## ① 바뀌는 것
`app/noshow.py` — 노쇼 기록 · 정지 판정. `app/main.py` 의 예약 막기와 사서 화면 `/admin/noshows`.

## ② 보장하는 것 / 보장하지 않는 것
예약 하나에 노쇼 기록은 많아야 하나. 정지는 마지막 노쇼부터 14일.

## ⑤ 검증 계획
노쇼 셋인 학번의 예약이 막히는지 — `tests/test_noshow.py`.
MD

cat > docs/slices/3-stats/requirements.md <<'MD'
# 조각 3 — 이용 통계 (초안 · 착공 전)

## 문제
어느 방이 언제 비는지 사서가 모른다.

## 성공 기준
- 방 · 요일별 이용 합계를 사서가 본다

## 하지 않을 일
1. 개인별 이용 내역은 보여 주지 않는다 — 통계 화면은 합계만 보인다.
2. 통계를 파일로 내보내지 않는다.
MD

cat > app/__init__.py <<'PY'
PY

cat > app/db.py <<'PY'
from sqlalchemy import Column, Date, DateTime, ForeignKey, Integer, MetaData, String, Table, create_engine

metadata = MetaData()

students = Table(
    "students", metadata,
    Column("student_no", String, primary_key=True),
    # 노쇼가 쌓이면 사서가 연락할 수 있게 받아 둔다.
    Column("phone", String, nullable=True),
)

bookings = Table(
    "bookings", metadata,
    Column("id", Integer, primary_key=True),
    Column("student_no", String, ForeignKey("students.student_no"), nullable=False),
    Column("room", String, nullable=False),
    Column("starts_at", DateTime, nullable=False),
    Column("tagged_at", DateTime, nullable=True),
)

noshows = Table(
    "noshows", metadata,
    Column("booking_id", Integer, ForeignKey("bookings.id"), primary_key=True),
    Column("student_no", String, nullable=False),
    Column("day", Date, nullable=False),
)

engine = create_engine("sqlite:///rooms.db")
metadata.create_all(engine)
PY

cat > app/noshow.py <<'PY'
from datetime import date, timedelta

from sqlalchemy import func, insert, select, update

from .db import engine, noshows, students

LIMIT = 3
BAN_DAYS = 14


def record(booking_id: int, student_no: str, day: date, phone: str | None = None) -> None:
    with engine.begin() as c:
        c.execute(insert(noshows).values(booking_id=booking_id, student_no=student_no, day=day))
        if phone:
            c.execute(update(students).where(students.c.student_no == student_no).values(phone=phone))


def banned_until(student_no: str) -> date | None:
    with engine.connect() as c:
        n, last = c.execute(
            select(func.count(), func.max(noshows.c.day)).where(noshows.c.student_no == student_no)
        ).one()
    if n < LIMIT:
        return None
    return last + timedelta(days=BAN_DAYS)


def counts() -> list[tuple[str, int]]:
    with engine.connect() as c:
        return [tuple(r) for r in c.execute(
            select(noshows.c.student_no, func.count()).group_by(noshows.c.student_no)
        )]
PY

cat > app/main.py <<'PY'
from datetime import date, datetime
from html import escape

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from sqlalchemy import insert, select

from . import noshow
from .db import bookings, engine

app = FastAPI()


@app.post("/bookings")
def book(student_no: str, room: str, starts_at: datetime) -> dict:
    until = noshow.banned_until(student_no)
    if until and date.today() <= until:
        raise HTTPException(403, f"예약 정지 — {until} 까지")
    with engine.begin() as c:
        taken = c.execute(
            select(bookings.c.id).where(bookings.c.room == room, bookings.c.starts_at == starts_at)
        ).first()
        if taken:
            raise HTTPException(409, "이미 예약된 시간")
        r = c.execute(insert(bookings).values(student_no=student_no, room=room, starts_at=starts_at))
    return {"id": r.inserted_primary_key[0]}


@app.get("/admin/noshows", response_class=HTMLResponse)
def noshow_list() -> str:
    rows = noshow.counts()
    return "<ul>" + "".join(f"<li>{escape(s)} · {n}회</li>" for s, n in rows) + "</ul>"
PY

cat > tests/test_noshow.py <<'PY'
from datetime import date

from app import noshow


def test_three_noshows_ban_for_two_weeks():
    for i in range(3):
        noshow.record(1000 + i, "20261234", date(2026, 5, 20))
    assert noshow.banned_until("20261234") == date(2026, 6, 3)
PY

cat > README.md <<'MD'
# study-rooms

도서관 스터디룸 예약과 노쇼 처리.

- 예약: `POST /bookings` — 정지 중인 학번은 막힌다
- 사서 화면: `/admin/noshows` — 학번별 노쇼 횟수
- 시험: `pytest`
MD
