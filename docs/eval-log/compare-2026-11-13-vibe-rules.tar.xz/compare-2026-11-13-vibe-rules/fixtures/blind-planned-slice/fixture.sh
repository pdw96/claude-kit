#!/usr/bin/env bash
# 작은 도서관 대출 장부 — 조각 셋 중 둘이 섰고 셋째는 착공 전이다.
#
# 진짜 결함: 진행 중인 조각 2 「연체료」의 성공 기준과 설계 ② 가 「책 한 권의 연체료는 3,000원을 넘지
# 않는다」를 약속하는데 `app/fees.py` 의 `late_fee` 는 연체 일수 × 100원을 상한 없이 돌려준다.
# 덫 1(착공 전 조각): `INTENT.md` What 이 「책 예약」을 들지만 코드에 예약이 없다. 마스터플랜 조각 나눔에서
# 조각 3 「책 예약」은 상태가 「예정」이고 조각 폴더도 없다 — 아직 만들 차례가 아니다.
# 덫 2(이름만 닮음): `INTENT.md` Not 1 이 회원에게 알림을 보내지 않는다고 하는데 `app/notice.py` 와
# `/desk/overdue` 가 「연체 안내」를 만든다. 사서가 창구에서 보는 화면(HTML)일 뿐 아무것도 보내지 않고,
# 조각 2 의 성공 기준이 그 화면을 든다. 회원 연락처는 테이블에 없다.
#
# 진짜 결함은 하나뿐이어야 한다 — 문서가 약속한 나머지(책 등록, 대출 · 반납, 기한 14일, 하루 100원,
# 연체 안내 화면, 설계 ⑤ 의 시험)는 코드가 받친다.
set -euo pipefail
mkdir -p app tests docs/slices/1-loans docs/slices/2-late-fee

cat > CLAUDE.md <<'MD'
# 작은 도서관 작업 규칙

의도는 `INTENT.md`, 조각 나눔은 `docs/master-plan.md`, 조각의 요구사항 · 설계는 `docs/slices/` 에 있다.

## 스택
- Python 3.12 · FastAPI 0.115 · SQLAlchemy 2.0

## 앵커볼트 — 바꾸려면 먼저 물어볼 것
- `books` · `loans` 테이블 스키마

## 작업 방식
- 조각 하나씩. 요구사항과 설계를 한 PR 로 낸 뒤 구현한다
- 상태가 「예정」인 조각은 착공(요구사항 + 설계) 전에는 코드를 쓰지 않는다
MD

cat > INTENT.md <<'MD'
# 작은 도서관 — 의도

## Why
자원봉사 사서가 대출을 종이 장부에 적는다. 누가 무엇을 언제까지 돌려줘야 하는지 놓친다.

## What
- 책 등록과 대출 · 반납 기록
- 연체료 계산
- 책 예약 — 대출 중인 책을 다음 사람이 맡아 둔다

## Not
1. 회원에게 알림(이메일 · 문자 · 푸시)을 보내지 않는다 — 연락처를 받지 않는다. 연체는 사서가 창구에서 말한다.
2. 연체료를 온라인으로 받지 않는다 — 창구에서 현금으로 받는다.
MD

cat > docs/master-plan.md <<'MD'
# 작은 도서관 마스터플랜

## 가리키는 문서

| 무엇 | 어디 |
|---|---|
| 의도 — Why · What · Not | `INTENT.md` |
| 작업 규칙 | `CLAUDE.md` |
| 조각의 요구사항 · 설계 | `docs/slices/` |

## 조각 나눔

| 순서 | 조각 | 목표 한 줄 | 의존 | 상태 | 조각 폴더 |
|---|---|---|---|---|---|
| 1 | 대출 · 반납 | 책을 등록하고 대출과 반납을 적는다 | — | 닫힘 | `docs/slices/1-loans/` |
| 2 | 연체료 | 반납 때 연체료를 셈하고 사서가 연체 중인 대출을 본다 | 대출 · 반납 | 진행 | `docs/slices/2-late-fee/` |
| 3 | 책 예약 | 대출 중인 책을 다음 사람이 맡아 둔다 | 대출 · 반납 | 예정 | — (착공 때 만든다) |
MD

cat > docs/slices/1-loans/requirements.md <<'MD'
# 조각 1 — 대출 · 반납 (2026-05-11 착공)

## 문제
대출이 종이 장부에만 있다.

## 핵심 사용자와 시나리오
- 사용자: 창구의 사서
- 시나리오: 새 책을 등록하고, 빌려 갈 때 이름을 적고, 돌려받을 때 반납을 적는다.

## 성공 기준
- 책을 등록한다
- 대출을 적으면 반납 기한이 14일 뒤로 잡힌다
- 대출 중인 책은 다시 빌려 주지 못한다
- 반납을 적는다

## 하지 않을 일
1. 회원 테이블을 만들지 않는다 — 대출에 이름만 적는다.
2. 바코드 스캔은 하지 않는다.

## 제약
- 리뷰 3라운드

## 닫으며 (2026-05-29)
성공 기준 넷을 창구 화면에서 한 번씩 해 봤다. 다음 조각은 조각 나눔 2 「연체료」.
MD

cat > docs/slices/1-loans/design.md <<'MD'
# 조각 1 설계 — 대출 · 반납

## ① 바뀌는 것
`app/db.py` 의 `books` · `loans` 테이블, `app/loans.py` 의 대출 · 반납, `app/main.py` 의 창구 라우트.

## ② 보장하는 것 / 보장하지 않는 것
책 한 권에 반납 안 된 대출은 많아야 하나. 기한은 대출일 + 14일.

## ③ 받는 입력
사서가 넣는 책 제목, 빌리는 사람 이름.

## ④ 결정
없음 — 대안이 없었다.

## ⑤ 검증 계획
창구 화면에서 등록 · 대출 · 반납을 한 번씩 해 본다.

## ⑥ PR 나눔
한 PR.
MD

cat > docs/slices/2-late-fee/requirements.md <<'MD'
# 조각 2 — 연체료 (2026-06-08 착공)

## 문제
연체료를 사서가 달력을 보고 손으로 센다. 사람마다 다르게 받는다.

## 핵심 사용자와 시나리오
- 사용자: 창구의 사서
- 시나리오: 반납을 적으면 받을 연체료가 뜬다. 아침에 연체 중인 대출 목록을 열어 보고, 그 사람이 오면 말한다.

## 성공 기준
- 반납을 적으면 연체료가 나온다 — 기한을 넘긴 하루마다 100원
- 책 한 권의 연체료는 3,000원을 넘지 않는다 — 오래 못 돌려준 사람이 반납을 피하지 않게
- 사서가 연체 안내 화면에서 연체 중인 대출(책 · 이름 · 기한 · 지금까지의 연체료)을 본다

## 하지 않을 일
1. 연체료 납부를 기록하지 않는다 — 현금으로 받고 장부는 따로 쓴다.
2. 휴관일을 빼고 세지 않는다.
3. 사람별 연체 이력 통계를 만들지 않는다.

## 제약
- 리뷰 3라운드
MD

cat > docs/slices/2-late-fee/design.md <<'MD'
# 조각 2 설계 — 연체료

## ① 바뀌는 것
`app/fees.py` 의 연체료 셈, `app/loans.py` 의 반납이 연체료를 돌려주고, `app/notice.py` 와 `/desk/overdue` 가 연체 안내 화면을 그린다.

## ② 보장하는 것 / 보장하지 않는 것
연체료는 0원 이상, 책 한 권에 3,000원 이하. 기한 안에 돌려주면 0원. 연체료를 어디에도 저장하지 않는다.

## ③ 받는 입력
`loans` 의 기한과 반납일(반납 전이면 오늘).

## ④ 결정
없음 — 대안이 없었다.

## ⑤ 검증 계획
기한 안 반납 0원, 3일 연체 300원 — `tests/test_fees.py`.

## ⑥ PR 나눔
한 PR.
MD

cat > pyproject.toml <<'TOML'
[project]
name = "small-library"
requires-python = ">=3.12"
dependencies = [
  "fastapi==0.115.0",
  "sqlalchemy==2.0.30",
]

[project.optional-dependencies]
dev = ["pytest==8.3.3"]
TOML

cat > app/__init__.py <<'PY'
PY

cat > app/db.py <<'PY'
from sqlalchemy import Column, Date, ForeignKey, Integer, MetaData, String, Table, create_engine

metadata = MetaData()

books = Table(
    "books", metadata,
    Column("id", Integer, primary_key=True),
    Column("title", String, nullable=False),
)

# 빌린 사람은 이름만 적는다 — 회원 테이블도 연락처도 없다.
loans = Table(
    "loans", metadata,
    Column("id", Integer, primary_key=True),
    Column("book_id", Integer, ForeignKey("books.id"), nullable=False),
    Column("member_name", String, nullable=False),
    Column("due", Date, nullable=False),
    Column("returned", Date),
)

engine = create_engine("sqlite:///library.db")
metadata.create_all(engine)
PY

cat > app/fees.py <<'PY'
from datetime import date

DAILY_FEE = 100


def late_fee(due: date, returned: date) -> int:
    """기한을 넘긴 날수만큼의 연체료(원)."""
    days = (returned - due).days
    if days <= 0:
        return 0
    return days * DAILY_FEE
PY

cat > app/loans.py <<'PY'
from datetime import date, timedelta

from sqlalchemy import insert, select, update

from .db import books, engine, loans
from .fees import late_fee

LOAN_DAYS = 14


def add_book(title: str) -> int:
    with engine.begin() as c:
        r = c.execute(insert(books).values(title=title))
    return r.inserted_primary_key[0]


def checkout(book_id: int, member_name: str, today: date) -> int:
    with engine.begin() as c:
        out = c.execute(
            select(loans.c.id).where(loans.c.book_id == book_id, loans.c.returned.is_(None))
        ).first()
        if out is not None:
            raise ValueError("이미 대출 중인 책이다")
        r = c.execute(insert(loans).values(
            book_id=book_id, member_name=member_name, due=today + timedelta(days=LOAN_DAYS)))
    return r.inserted_primary_key[0]


def give_back(loan_id: int, today: date) -> int:
    """반납을 적고 받을 연체료를 돌려준다."""
    with engine.begin() as c:
        row = c.execute(
            select(loans.c.due).where(loans.c.id == loan_id, loans.c.returned.is_(None))
        ).first()
        if row is None:
            raise LookupError("반납할 대출이 없다")
        c.execute(update(loans).where(loans.c.id == loan_id).values(returned=today))
    return late_fee(row.due, today)


def overdue(today: date) -> list:
    with engine.connect() as c:
        return c.execute(
            select(books.c.title, loans.c.member_name, loans.c.due)
            .join(books, books.c.id == loans.c.book_id)
            .where(loans.c.returned.is_(None), loans.c.due < today)
            .order_by(loans.c.due)
        ).all()
PY

cat > app/notice.py <<'PY'
"""연체 안내 — 연체 중인 대출마다 한 줄."""
from datetime import date
from html import escape

from .fees import late_fee


def overdue_notice(rows: list, today: date) -> str:
    items = "".join(
        f"<li>{escape(r.title)} · {escape(r.member_name)} · 기한 {r.due.isoformat()}"
        f" · 연체료 {late_fee(r.due, today)}원</li>"
        for r in rows
    )
    return f"<h1>연체 안내 ({today.isoformat()})</h1><ul>{items}</ul>"
PY

cat > app/main.py <<'PY'
from datetime import date

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse

from . import loans
from .notice import overdue_notice

app = FastAPI()


@app.post("/desk/books")
def add_book(title: str) -> dict:
    return {"id": loans.add_book(title)}


@app.post("/desk/loans")
def checkout(book_id: int, member_name: str) -> dict:
    try:
        return {"id": loans.checkout(book_id, member_name, date.today())}
    except ValueError as e:
        raise HTTPException(409, str(e))


@app.post("/desk/loans/{loan_id}/return")
def give_back(loan_id: int) -> dict:
    try:
        return {"late_fee": loans.give_back(loan_id, date.today())}
    except LookupError as e:
        raise HTTPException(404, str(e))


@app.get("/desk/overdue", response_class=HTMLResponse)
def overdue() -> str:
    today = date.today()
    return overdue_notice(loans.overdue(today), today)
PY

cat > tests/test_fees.py <<'PY'
from datetime import date

from app.fees import late_fee


def test_on_time_is_free():
    assert late_fee(date(2026, 6, 20), date(2026, 6, 20)) == 0
    assert late_fee(date(2026, 6, 20), date(2026, 6, 15)) == 0


def test_three_days_late():
    assert late_fee(date(2026, 6, 20), date(2026, 6, 23)) == 300
PY
