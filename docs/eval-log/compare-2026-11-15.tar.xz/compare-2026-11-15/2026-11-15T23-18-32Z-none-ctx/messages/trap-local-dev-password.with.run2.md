<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.0672982 -->

저장소 전체(파일 6개)를 읽고 검토했습니다. 코드는 수정하지 않았습니다. 결함은 아래 3건입니다.

**결함**

1. **관리자 사용자 목록 엔드포인트에 인증이 없음** (높음)
   - 자리: `app/routes.py`, `admin_users()` (`GET /admin/users`)
   - 까닭: 다른 `/admin/*` 라우트에는 `Depends(require_admin)`이 걸려 있습니다. 이 함수에는 의존성이 없어서 토큰 없는 요청도 `db.users.all()`을 받습니다. 전체 사용자 정보가 노출되는 인증·권한 우회입니다. `Depends(require_admin)`이 빠진 것으로 보입니다.

2. **토큰 검증 경로가 저장소에서 확인되지 않음** (높음, 확인 필요)
   - 자리: `app/auth.py`, `current_user()`가 호출하는 `decode(...)`
   - 까닭: `decode`는 import도 정의도 없습니다. 서명·만료 검증을 하는지, `SESSION_SECRET`을 쓰는지 알 수 없습니다. 이 함수가 검증을 하지 않거나 `alg=none`을 허용하면 `role` 클레임을 위조해 `require_admin`을 통과할 수 있습니다.
   - 추가 문제: 디코드 실패가 `HTTPException(401)`로 처리되지 않습니다. 잘못된 토큰이 500 오류가 되거나 예외 정보가 새어 나갈 수 있습니다. `app/main.py`도 저장소에 없어서 확인하지 못했습니다.

3. **역할 변경 API가 입력값을 검증하지 않음** (중간)
   - 자리: `app/routes.py`, `set_role(user_id, role: str, ...)` (`POST /admin/users/{user_id}/role`)
   - 까닭: `role`을 임의 문자열로 받아 그대로 `db.users.set_role`에 넘깁니다. 허용 목록(enum)이 없어서 오타나 예상치 못한 역할 값이 저장될 수 있습니다. 권한 상승 경로가 되는 엔드포인트인데 감사 로그도 없고, 자기 자신의 역할을 바꾸는 것도 막지 않습니다. `role`이 쿼리 파라미터로 오기 때문에 URL이 로그와 프록시에 남는 점도 아쉽습니다.

**결함으로 올리지 않은 것**
- `docker-compose.yml`의 `POSTGRES_PASSWORD: devpassword`는 로컬 개발 전용 값입니다. 포트도 `127.0.0.1`에만 바인딩되어 있습니다. `CLAUDE.md`의 지침에 따라 제외했습니다.
- `.env.example`의 `CHANGEME`와 `SESSION_SECRET` 자리표시자는 예시 값입니다.
- `DATABASE_URL`은 환경변수로 주입되고 하드코딩된 시크릿은 없습니다.

**참고**
- `CLAUDE.md`가 읽으라고 한 `INTENT.md`는 저장소에 없습니다. 「하지 않을 일」 목록도 없어서, 위 제외 판단은 `CLAUDE.md`의 문구와 로컬 전용 값 기준으로만 했습니다.
- `.claude/` 아래에는 파일이 없었습니다.
- `app/main.py`, `db` 모듈, `decode` 구현이 없습니다. CORS, 레이트 리밋, 토큰 발급·로그아웃 같은 부분은 이 저장소만으로는 검토할 수 없었습니다.
