<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.14212989999999998 -->

`audit-secrets` 감사자를 돌렸고, 결함 2건을 찾았습니다. 코드는 고치지 않았습니다. 감사자의 보고를 `app/routes.py`, `app/auth.py`, `docker-compose.yml`, `.env.example`와 대조해 확인했습니다.

## 결함

1. **`/admin/users`에 인증·권한 검사가 없습니다.** (높음)
   - 자리: `app/routes.py:22-24`의 `admin_users`.
   - 까닭: 다른 `/admin/*` 라우트는 `Depends(require_admin)`을 쓰는데 이 라우트만 의존성이 없습니다. 토큰 없는 요청도 `db.users.all()`로 전 사용자 목록을 받습니다.
   - 영향: 어떤 필드가 나가는지는 `db` 정의가 저장소에 없어 알 수 없습니다. 이메일이나 비밀번호 해시가 포함되면 유출은 되돌릴 수 없습니다.

2. **토큰 `decode`가 정의되거나 임포트되어 있지 않습니다.** (보통)
   - 자리: `app/auth.py:7`(`current_user`). 파일 안에서는 `decode(...)` 호출이 `return decode(authorization.removeprefix("Bearer "))` 줄입니다.
   - 까닭: 이대로 실행하면 `NameError`가 나서 인증이 필요한 요청이 모두 500이 됩니다. 서명 검증이 어디서 일어나는지 저장소 안에서 확인되지 않습니다.
   - 영향: 실패 방향이 닫힘이라 우회는 아닙니다.
   - 연관: `.env.example`의 `SESSION_SECRET`을 읽는 코드도 없습니다.

## 확인불가

- **프로덕션 DB 접속 정보가 개발 값과 분리되어 있는지.**
  - 자리: `docker-compose.yml:6-9`, `README.md:4`.
  - 까닭: 개발용 `dev/devpassword`는 `127.0.0.1`에만 바인딩되어 있어 그 자체는 문제가 없습니다. 배포 환경의 `DATABASE_URL` 값은 저장소에서 볼 수 없습니다.
- **`app/main.py`(`app.main:app`)와 `db` 모듈, `decode` 구현이 저장소에 없습니다.**
  - 까닭: CORS·미들웨어·JWT 검증 설정과 라우터 수준 의존성은 판정하지 못했습니다.

## 관찰 (결함은 아님)

- **`set_role`의 `role: str`이 검증 없이 저장됩니다.**
  - 자리: `app/routes.py:27-29`.
  - 까닭: 호출자가 admin으로 제한되어 있고, 알 수 없는 역할은 `require_admin`에서 비관리자로 취급되어 안전한 쪽입니다. 허용 역할 목록 검증은 없습니다.

## 범위

- **전수로 본 것:** 파일 5개 전부, 소스 내 시크릿 리터럴, 우회 코드·디버그 플래그.
- **표본으로 본 것:** 소유자 확인(`/orders`의 `for_user(user.id)`).
- **감사 기록 파일:** 감사자가 기록 파일 저장을 제안했지만 요청하지 않으셨고, 코드도 건드리지 않기로 해서 저장하지 않았습니다.
