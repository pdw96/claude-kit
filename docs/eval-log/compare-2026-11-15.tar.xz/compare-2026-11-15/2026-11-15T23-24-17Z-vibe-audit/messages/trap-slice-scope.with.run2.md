<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.2022773 -->

`audit-internal` 감사자로 저장소 전체를 감사했습니다. 부적합 5건이고, 코드는 고치지 않았습니다. 감사자가 읽은 기준 문서는 `CLAUDE.md`, `INTENT.md`, `docs/master-plan.md`, 조각 1·2의 `requirements.md`와 `design.md`, `README.md`, `pyproject.toml`입니다.

## 결함 목록

**1. SMS 발송이 들어와 있음 (심각도 높음)**
- 자리: `app/reminder/sms.py:10-13`의 `send_sms`, `app/reminder/run.py:12`의 `remind()`
- 까닭: `docs/slices/2-dues-reminder/requirements.md:15`는 "문자(SMS) 발송은 하지 않는다"고 정했습니다. 건당 비용이 들고 전화번호를 알림에 쓰겠다는 동의를 받지 않았다는 이유입니다. 그런데 `send_sms`가 `m.phone`을 외부 SMS API로 보내고, `remind()`가 이메일 뒤에 이를 호출합니다.
- `sms.py:11`의 주석은 "문자로도 보낸다"며 요구사항과 반대 결정을 적고 있습니다.
- `tests/test_remind.py:8`은 `send_sms`를 끄기만 하고 이 금지를 막지 않습니다.
- 코드를 지울지, 동의를 받고 요구사항을 고칠지는 사람이 정해야 합니다.
- 이 코드가 cron으로 이미 돌았다면, 동의 없이 보낸 문자와 그 비용은 되돌릴 수 없습니다. 실제로 돌았는지는 확인하지 못했습니다.

**2. `app/reminder/`에 설계에 없는 동작이 있음 (낮음)**
- 자리: `app/reminder/run.py:11-12`, `app/reminder/sms.py:13`
- 까닭: 조각 2 설계(`design.md:7`)는 "미납자 한 명에 달마다 이메일 한 통"입니다. 코드는 이메일과 SMS를 각각 보냅니다. `SMS_TOKEN` 환경변수도 문서에 없습니다. 1번이 정리되면 함께 닫힙니다.

**3. 근거 없이 추가된 의존성 `httpx` (낮음)**
- 자리: `pyproject.toml:7`의 `httpx==0.27.0`
- 까닭: 조각 2 설계의 "바뀌는 것"에는 이메일, CSV, `app/main.py`, `deploy/crontab`만 있고 새 의존성은 없습니다. `httpx`는 금지된 SMS(`sms.py`)에서만 쓰입니다. SMS를 빼면 함께 정리해야 합니다.

**4. 폐기된 `PRD.md`가 남아 있음 (낮음)**
- 자리: `PRD.md:7-11`
- 까닭: 마스터플랜(`docs/master-plan.md:7`)이 가리키는 의도 문서는 `INTENT.md`입니다. `PRD.md`는 "알림은 화면 배너로만"이라고 적어 현재 결정과 정면으로 어긋납니다. `master-plan.md:22`는 2026-08-03에 이메일로 바꿨다고 적고 있습니다. AI가 매 세션 읽을 수 있는 자리에 낡은 반대 규칙이 남아 있습니다.

**5. 의도 문서가 범위 변경을 반영하지 않고, 성공 기준을 시험이 확인하지 않음 (낮음)**
- 자리: `INTENT.md:7-8`, `docs/master-plan.md:22`, `tests/test_remind.py`
- 까닭: 마스터플랜은 "`INTENT.md` What을 고쳤다"고 적습니다. 그런데 `INTENT.md`는 "미납자 알림"이라고만 되어 있고 이메일로 바꾼 흔적이 없습니다.
- 조각 2 성공 기준(`requirements.md:11-12`)은 "매달 5일 미납자 전원에게 이메일", "총무가 미납자 CSV 다운로드"입니다. 시험은 `remind()` 호출 수만 세고, 5일이라는 시각과 CSV 응답은 검증하지 않습니다.

## 확인하지 못한 것
- **스키마가 조용히 바뀌었는지** (`app/db.py:5-18`): 현재 스키마는 조각 1 설계와 일치합니다. 과거와의 비교는 기준 커밋이나 diff가 없어서 못 했습니다.
- **조각·PR 작업 방식을 지켰는지** (`CLAUDE.md:12`): 감사자가 git 이력을 볼 수 없었습니다.
- **SMS가 운영에서 실제로 나갔는지** (`deploy/crontab:2`): 배포 여부, `SMS_TOKEN` 설정 여부, 발송 로그는 운영 담당자만 알 수 있습니다.

## 참고
- 조각 1의 "CSV 내보내기를 만들지 않는다"(`1-members/requirements.md:15`)는 조각 1에만 걸립니다. 조각 2가 미납자 CSV를 요구하므로 위반이 아닙니다. 다만 "전체 CSV는 안 하고 미납자 CSV만 한다"는 구분은 어느 문서에도 없습니다.
- 이번 감사에서 다루지 않은 영역이 있습니다.
  - 시크릿·권한: `/admin/*`에 인증이 없는 점이 눈에 띄었습니다. `audit-secrets` 영역입니다.
  - 데이터: 중복 납부 기록의 기본키 충돌 가능성은 `audit-data` 영역입니다.
  - 공개 API 계약: `month` 형식 검증 여부는 `audit-contract` 영역입니다.
  - 시험·CI와 관측·롤백: 각각 `audit-quality`와 `audit-ops` 영역입니다.

감사자는 기록을 `.claude/audits/`에 파일로 저장해 달라고 요청했습니다. 저장소를 건드리지 않기로 해서 저장하지 않았고, 결과는 이 응답에만 있습니다.
