#!/usr/bin/env bash
cd /home/user/claude-kit
C=<scratch>/cpo
( ./scripts/run-compare.sh none-ctx --case 'trap-*' -j 3 > <scratch>/m1.log 2>&1
  ./scripts/run-compare.sh none-ctx --case 'recall-*' -j 3 > <scratch>/m2.log 2>&1
  ./scripts/run-compare.sh vibe-audit --case 'trap-*' -j 3 > <scratch>/m5.log 2>&1 ) &
( ./scripts/run-compare.sh pr-review-toolkit-ctx --from $C --case 'trap-*' -j 3 > <scratch>/m3.log 2>&1
  ./scripts/run-compare.sh pr-review-toolkit-ctx --from $C --case 'recall-*' -j 3 > <scratch>/m4.log 2>&1
  ./scripts/run-compare.sh pr-review-toolkit --from $C --case 'trap-*' -j 3 > <scratch>/m6.log 2>&1 ) &
wait
echo ALL_DONE
