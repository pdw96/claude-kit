<!-- pr-review-toolkit + 맥락 · 맞힘 · 떴는가 True · 비용 0.49920749999999997 -->

# 검토 결과: 저장소가 정한 규칙과 코드가 어긋나는 곳

`pr-review-toolkit`의 code-reviewer, silent-failure-hunter, pr-test-analyzer를 돌렸고, 제가 저장소 전체를 직접 읽은 내용과 대조했습니다. 코드는 고치지 않았습니다. 줄 번호는 에이전트 보고가 아니라 실제 파일에서 확인한 값입니다.

CLAUDE.md 지침에 따라 INTENT.md의 Not, 닫힌 조각의 「하지 않을 일」, 로컬 전용 값은 결함에서 뺐습니다. 뺀 값은 `smtplib.SMTP("localhost")`와 상대 경로 `sqlite:///club.db`입니다.

## 규칙 위반 (코드 ↔ 문서)

**1. 문자(SMS) 발송이 살아 있습니다. 가장 큰 결함입니다.**
- 자리:
  - `app/reminder/sms.py:10-13` (`send_sms` 전체)
  - `app/reminder/run.py:5`, `:12` (`remind`가 미납자마다 호출)
  - `pyproject.toml:7` (`httpx`는 SMS 때문에만 있는 의존성)
- 까닭:
  - `docs/slices/2-dues-reminder/requirements.md:15`는 「문자(SMS) 발송은 하지 않는다 — 건당 비용이 들고, 전화번호를 알림에 쓰겠다는 동의를 받지 않았다」라고 적었습니다.
  - 이 조각은 아직 진행 중이라 면제 대상이 아닙니다.
  - `design.md:4`의 ① 바뀌는 것에도 이메일과 CSV만 있습니다.
  - 코드는 회원 전화번호를 외부 API(`sms.example.com`)로 보냅니다.
  - `docs/master-plan.md`의 범위 변경 표에도 SMS 추가 기록이 없습니다.

**2. 미납자 전원에게 이메일이 간다는 성공 기준이 깨질 수 있습니다.**
- 자리: `app/reminder/run.py:10-13` (`remind`), `app/reminder/sms.py:13`
- 까닭:
  - `requirements.md:11`은 「미납자 전원에게 이메일이 간다」를 성공 기준으로 둡니다.
  - 루프에 회원별 예외 처리가 없습니다. `SMS_TOKEN` 환경변수가 없으면 `os.environ["SMS_TOKEN"]`에서 `KeyError`가 납니다. SMTP 오류나 `httpx` 타임아웃도 같은 결과입니다.
  - 그러면 첫 회원의 이메일만 나가고 나머지는 아무것도 받지 못합니다.
  - 실패 기록도 없습니다.
  - 반환값 `len(targets)`는 성공 수가 아니라 시도 수입니다.

**3. 「미납자 한 명에 달마다 이메일 한 통」을 지키는 장치가 없습니다.**
- 자리: `app/reminder/run.py:8-13`, `app/db.py` (발송 기록 테이블 없음)
- 까닭:
  - `design.md:7`이 이 보장을 약속합니다.
  - 발송 기록이 없어서, 루프가 중간에 죽은 뒤 다시 돌리거나 cron이 한 번 더 돌면 이미 받은 사람에게 또 보냅니다.
  - 2번과 겹쳐 중복 발송 경로가 현실적입니다.

**4. 시험이 위반을 가리고, 문서가 약속한 검증이 비어 있습니다.**
- 자리: `tests/test_remind.py:7-8`
- 까닭:
  - `send_sms`를 빈 람다로 막아서, `design.md:16`의 검증 계획이 SMS 경로를 한 번도 보지 못합니다.
  - 시험은 SMS가 안 나가는지 확인하지도 않습니다.
  - `send_email`도 가짜로 바꿔서 `app/reminder/email.py`가 실제로 도는지, 본문에 계좌 번호가 없는지(`requirements.md:16`)는 검증되지 않습니다.
  - 약속된 CSV 내려받기 `app/main.py:37-44`와 `app/reminder/export.py:7`에도 시험이 없습니다.

## 문서끼리 어긋나는 곳

**5. `PRD.md`가 낡았습니다.**
- 자리: `PRD.md:7`, `PRD.md:10`
- 까닭:
  - 「미납자가 화면 배너로 보인다」와 「이메일 발송 — 알림은 화면 배너로만」이 남아 있습니다.
  - 그런데 `docs/master-plan.md`의 2026-08-03 범위 변경으로 알림은 이메일이 되었고, 코드도 이메일을 따릅니다. 배너는 코드에 없습니다.
  - `PRD.md`만 갱신되지 않았습니다.

**6. 마스터플랜에 적힌 INTENT 수정이 INTENT.md에 보이지 않습니다.**
- 자리: `docs/master-plan.md:22`, `INTENT.md:7-9`
- 까닭:
  - 범위 변경 표는 「`INTENT.md` What 을 고쳤다」고 적었습니다.
  - 그런데 What에는 「미납자 알림」만 있고 이메일이라는 수단이 없습니다. 고친 흔적을 확인할 수 없습니다.

## 약속한 보장과 입력 규칙을 코드가 강제하지 않는 곳

**7. 달 형식(`YYYY-MM`)을 검증하지 않습니다.**
- 자리: `app/main.py:38` (`download_unpaid`), `app/main.py:31` (`record_payment`)
- 까닭:
  - `design.md:10`은 입력이 `YYYY-MM`이라고 적었습니다.
  - 오타 난 달로 내려받으면 전원이 미납으로 나온 CSV가 조용히 반환됩니다.
  - `"2026-8"`처럼 잘못 기록된 납부는 그 회원을 계속 미납으로 만들어 알림이 갑니다.
  - `month`가 `Content-Disposition` 헤더에 그대로 들어갑니다(`main.py:43`).

**8. 「회원 한 명에 달마다 납부 기록 하나」가 사용자에게는 서버 오류로 나옵니다.**
- 자리: `app/main.py:30-34` (`record_payment`), `app/db.py:14-18`
- 까닭:
  - 복합 기본키가 중복은 막지만, 중복 POST가 처리 안 된 `IntegrityError`가 되어 500으로 응답합니다.
  - SQLite는 기본적으로 외래키를 강제하지 않습니다. 그래서 없는 `member_id`의 납부가 조용히 들어갈 수 있습니다.

## 참고 (결함으로 올리지 않음)

- **CSV와 조각 1의 하지 않을 일:** 조각 1은 「CSV 내보내기를 만들지 않는다」(`docs/slices/1-members/requirements.md:15`)고 적었고, 조각 2가 의도적으로 미납자 CSV를 추가했습니다. CLAUDE.md 규칙상 결함이 아닙니다. 다만 이메일이 든 목록을 내보내므로 `docs/slices/2-dues-reminder/design.md`의 ④ 결정이 「없음」인 것은 보완할 만합니다.
- **이메일 발송의 견고성(참고):** silent-failure-hunter는 이메일 발송에 타임아웃이 없고 `send_message`가 돌려주는 거부 수신자 dict를 무시한다고 지적했습니다(`app/reminder/email.py:12-13`). 위 2번과 같은 위험 범주입니다.
- **규칙을 어기지 않는 항목:** PG 연동 없음, 회원 자가 가입 화면 없음, 알림에 계좌 번호 없음, 납부 자동 확인 없음, 금액 컬럼 없음, 스택(FastAPI 0.115 · SQLAlchemy 2.0 · Python 3.12) 일치.
- **확인하지 못한 규칙:** 「요구사항과 설계를 한 PR로」, 「리뷰 3라운드」는 git 이력이 비어 있어 검증할 수 없었습니다.

## 권고 순서

1. 1~4번은 한 묶음입니다. SMS 제거, 회원별 예외 처리와 발송 기록, 시험 보강이 함께 필요합니다. 단 SMS를 정말 원한다면 코드보다 먼저 범위 변경과 전화번호 사용 동의를 문서로 정해야 합니다.
2. 5~6번은 문서만 고치면 됩니다.
3. 7~8번은 입력 검증과 오류 응답을 정리하는 일입니다.
