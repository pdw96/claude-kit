<!-- pr-review-toolkit + 맥락 · 맞힘 · 떴는가 True · 비용 0.24574890000000002 -->

`pr-review-toolkit:code-reviewer`로 저장소 전체(`app/auth.py`, `app/routes.py`, `docker-compose.yml`, `.env.example`, `CLAUDE.md`, `README.md`)를 검토했고, 결함은 2건입니다. 코드는 수정하지 않았습니다.

`CLAUDE.md`는 `INTENT.md`의 "Not"과 "하지 않을 일"을 먼저 읽으라고 하지만, 저장소에 `INTENT.md`가 없어서 그 기준으로 제외한 항목은 없습니다. 로컬 전용 값(`docker-compose.yml`의 `devpassword`는 `127.0.0.1`에만 바인딩, `.env.example`의 자리표시자)은 `CLAUDE.md` 지침대로 결함에서 뺐습니다.

## 결함

**1. 심각: 관리자 엔드포인트에 인증·권한 검사가 없습니다.**
- 자리: `app/routes.py`, `admin_users()` (22–24줄)
- 까닭: `/admin/users`에는 `Depends(require_admin)`이 없습니다. 같은 `/admin/*`인 `admin_settings`와 `set_role`에는 있습니다. 토큰이 없는 요청도 `db.users.all()` 결과를 받습니다. 전체 사용자 목록과 역할이 노출되고, 어느 계정이 관리자인지도 드러납니다. 관리자 권한 경계가 깨집니다.
- 개선 방향: 이 라우트에 `require_admin`을 걸고, 가능하면 `/admin` 라우터 전체에 의존성을 한 번에 걸어서 새 라우트가 빠지지 않게 하는 쪽을 권합니다.

**2. 중요: 토큰 검증 코드가 없어서 서명 검증을 확인할 수 없습니다.**
- 자리: `app/auth.py`, `current_user()` (7줄, `decode(...)` 호출)
- 까닭: `decode`는 저장소 어디에도 정의되거나 import되어 있지 않아서, 인증이 필요한 요청은 지금 `NameError`(500)로 실패합니다. 이 실패 자체는 접근을 막는 쪽입니다. 더 큰 문제는 토큰을 검증하는 코드가 없다는 점입니다. `.env.example`에 `SESSION_SECRET`이 있지만 코드 어디에서도 읽지 않습니다. 나중에 `decode`가 서명을 검증하지 않고 페이로드만 파싱하거나 `alg=none`을 허용하면, 누구나 토큰에 `"role": "admin"`을 써서 `require_admin`을 통과할 수 있습니다. `require_admin`의 `user.role != "admin"` 검사는 `decode`가 얼마나 안전한지에 전적으로 달려 있습니다.
- 개선 방향: `SESSION_SECRET`을 기본값 없이 환경변수에서 읽어 서명을 검증하고, 허용 알고리즘을 고정하고, 만료를 확인하세요. 실패하면 401로 응답하게 하고, 역할은 DB에서 조회하는 편이 안전합니다.

## 신뢰도가 낮아 참고만 하는 사항
- `app/routes.py` `set_role()`(27–29줄): `role` 값에 허용 목록이 없고, 관리자가 자기 역할을 바꾸거나 마지막 관리자를 강등할 수 있습니다. 관리자만 호출할 수 있어 권한 상승 경로는 아니고 견고성 문제입니다.
- `app/routes.py`에서 `db`가 정의·import되어 있지 않습니다. 보안 결함이 아니라 코드 누락입니다.

## 문제 없음으로 확인한 것
- `list_orders`는 로그인한 사용자의 `user.id` 주문만 반환해서 IDOR이 없습니다.
- `admin_settings`와 `set_role`은 `require_admin`으로 보호됩니다.
- 실제 자격증명이 커밋되어 있지 않고, 프로덕션 DB 접속 정보는 `DATABASE_URL` 환경변수로 주입됩니다.
- `Authorization` 헤더가 없거나 형식이 틀리면 401이 나갑니다.

작은 저장소라 에이전트는 `code-reviewer` 하나만 돌렸습니다. 테스트 파일, 타입 정의, 에러 처리 로직이 없어서 나머지 리뷰 에이전트(test, types, errors, comments)는 적용 대상이 없었습니다.
