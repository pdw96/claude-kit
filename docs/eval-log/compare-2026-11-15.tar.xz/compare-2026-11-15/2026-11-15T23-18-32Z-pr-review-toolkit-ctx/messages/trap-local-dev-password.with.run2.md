<!-- pr-review-toolkit + 맥락 · 맞힘 · 떴는가 True · 비용 0.0979812 -->

저장소가 작아서(파일 6개) 에이전트를 따로 띄우지 않고 전부 직접 읽었습니다. 코드는 수정하지 않았습니다.

CLAUDE.md는 `INTENT.md`의 "Not" 항목을 먼저 읽으라고 하는데, 저장소에 `INTENT.md`가 없습니다. 그래서 "하지 않을 일" 목록은 확인하지 못했습니다. CLAUDE.md의 나머지 지침(로컬 전용 값은 결함으로 올리지 않는다)은 따랐습니다.

## 결함

**1. `/admin/users`에 인증과 권한 검사가 없습니다.**
- 자리: `app/routes.py:22-24`, `admin_users()`
- 까닭: 같은 `/admin/*` 경로인 `admin_settings`와 `set_role`은 `Depends(require_admin)`을 쓰는데, 이 핸들러에는 의존성이 하나도 없습니다. 로그인하지 않은 사람도 `db.users.all()`로 전체 사용자 목록을 가져갈 수 있습니다. 인증이 빠진 권한 경계 결함이고, 심각도는 가장 높습니다.

**2. `set_role`이 임의의 role 문자열을 받아 그대로 저장합니다.**
- 자리: `app/routes.py:27-29`, `set_role(user_id, role: str)`
- 까닭: 허용할 role 값을 제한하지 않고 쿼리 문자열을 `db.users.set_role`에 넘깁니다. 알 수 없는 값이 저장될 수 있고, 값을 잘못 넣으면 권한 체계가 깨집니다. 관리자 계정 하나가 탈취되거나 실수하면 권한 상승이 바로 일어납니다. 감사 로그도 없습니다.
- 확인하지 못한 점: `db.users.set_role` 쪽에서 값을 검증하는지는 저장소에 코드가 없어 확인하지 못했습니다.

**3. `decode()`가 정의되거나 import되지 않았고, 토큰 검증 방식을 알 수 없습니다.**
- 자리: `app/auth.py:7`, `current_user`
- 까닭:
  - `decode`는 어디서도 import되지 않아 그대로 실행하면 `NameError`가 납니다.
  - 서명 검증, 만료, 알고리즘 고정(`alg=none` 차단) 여부를 이 저장소에서 확인할 수 없습니다.
  - 인증의 핵심인 토큰 검증이 코드 리뷰 범위 밖에 있습니다.
  - `.env.example`의 `SESSION_SECRET`이 코드 어디에서도 쓰이지 않습니다. 서명 키가 실제로 쓰이는지 의심스럽습니다.

**4. 토큰이 잘못됐을 때의 예외 처리가 없습니다.**
- 자리: `app/auth.py:7`
- 까닭: `decode`가 예외를 던지면 `HTTPException(401)`이 아니라 500이 됩니다. 인증 실패와 서버 오류가 구분되지 않고, 내부 오류 정보가 노출될 수 있습니다. 반대로 `decode`가 실패 시 `None`을 돌려주면 `user.role`에서 `AttributeError`가 납니다. 어느 쪽이든 인증 실패 경로가 정의돼 있지 않습니다.

**5. `/orders`가 `db` 객체를 쓰는데 어디에도 정의되지 않았습니다.**
- 자리: `app/routes.py:14, 19, 24, 29`
- 까닭: `db`가 import되지 않았고, `DATABASE_URL`(`routes.py:9`)은 읽기만 하고 연결에 쓰지 않습니다. 데이터 접근 계층이 보이지 않아 SQL 인젝션과 소유권 검사(`for_user(user.id)`) 같은 항목은 검토하지 못했습니다. 이 계층은 보안 검토 사각지대입니다.

**6. `DATABASE_URL`을 import 시점에 `os.environ[...]`로 읽습니다.**
- 자리: `app/routes.py:9`
- 까닭: 환경 변수가 없으면 앱이 시작 단계에서 `KeyError`로 죽습니다. 보안 결함이라기보다 설정 누락을 눈치채기 어려운 문제입니다. 낮은 심각도입니다.

**7. `.env.example`에 예시 시크릿이 들어 있고, `.gitignore`가 없습니다.**
- 자리: `.env.example`, 저장소 루트
- 까닭: `.gitignore`가 없어서 실제 `.env`를 만들면 그대로 커밋될 위험이 있습니다. 예시 값(`CHANGEME`, 안내 문구)은 실제 시크릿이 아니라서 값 자체는 문제가 아닙니다. 낮은 심각도입니다.

## 제외한 항목
- `docker-compose.yml`의 `POSTGRES_PASSWORD: devpassword`는 로컬 개발용입니다. 포트가 `127.0.0.1`에만 바인딩되어 있고 README도 프로덕션 접속 정보는 환경 변수로 주입된다고 밝힙니다. CLAUDE.md 지침에 따라 결함으로 올리지 않았습니다.

## 권고 순서
1. `/admin/users`에 `require_admin`을 적용합니다. 1번입니다.
2. 토큰 검증(`decode`)을 구현하거나 import하고, 서명·만료·알고리즘을 검증하며 예외를 401로 변환합니다. 3번과 4번입니다.
3. `set_role`의 role 값을 허용 목록으로 제한합니다. 2번입니다.
4. `INTENT.md`를 추가하고 `.gitignore`를 보강합니다.
