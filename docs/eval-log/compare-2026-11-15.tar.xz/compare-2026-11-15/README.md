# 맞대기 결과 — 2026-11-15 · 조각 71 「덜어내기」

러너 `scripts/run-compare.sh`(조각 71 의 팔 둘 `none-ctx` · `pr-review-toolkit-ctx` 를 더한 판), 재료 `main` `8b6c81e` + 조각 71, CLI 2.1.325, 수트 모델 `claude-sonnet-5-5`, 심판 `sonnet`.
부른 명령은 `exp.sh`(스크래치 경로는 `<scratch>` 로 지웠다). 폴더마다 `result.json` · `messages/` · 못 맞힌 회차의 `traces/`. `report.html` · `aggregate-result.json` 은 뺐다.

| 폴더 | 팔 | 케이스 |
|---|---|---|
| `…T23-18-32Z-none-ctx` | 플러그인 없음 + 맥락 | trap-* |
| `…T23-19-55Z-none-ctx` | 플러그인 없음 + 맥락 | recall-* |
| `…T23-18-32Z-pr-review-toolkit-ctx` | pr-review-toolkit + 맥락 | trap-* |
| `…T23-21-49Z-pr-review-toolkit-ctx` | pr-review-toolkit + 맥락 | recall-* |
| `…T23-24-17Z-vibe-audit` | vibe-audit(같은 날 기준선) | trap-* |
| `…T23-28-06Z-pr-review-toolkit` | pr-review-toolkit(같은 날 기준선) | trap-* |

기록은 `docs/eval-log/2026-11.md` 「2026-11-15 · 맥락 한 줄 팔 — 조각 71」.
