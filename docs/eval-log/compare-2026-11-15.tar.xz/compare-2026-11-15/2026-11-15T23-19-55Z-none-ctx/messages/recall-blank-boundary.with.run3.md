<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.0867644 -->

저장소에서 찾은 결함은 4건입니다. 실행은 해 보지 않았고 코드를 읽어서 판단했습니다. `docs/api.md`의 계약(201과 422만 약속하고, 500은 서버 잘못이라 창구 직원이 고칠 수 없다고 적은 부분)을 기준으로 삼았습니다.

`CLAUDE.md`는 INTENT.md의 Not 항목과 "닫힌 조각"의 「하지 않을 일」을 먼저 읽으라고 합니다. 이 저장소 안에는 그 파일이 없습니다. 같은 이름의 파일이 `/home/user/claude-kit/INTENT.md`에 있기는 합니다. 하지만 이 저장소 밖에 있어서 열지 않았습니다. 그래서 거기에 적힌 제외 항목은 반영하지 못했습니다. DB 접속 문자열이 `app/main.py`에 하드코딩된 것은 로컬 전용 값으로 보고 결함에 넣지 않았습니다.

## 결함

1. **공백만 있는 값이 422 대신 500으로 나갑니다.**
   - 자리: `app/schemas.py`의 `AppointmentIn`(`patient_name`, `department`, `phone`)과 `app/main.py`의 `post_appointment`(`s.commit()`)
   - 까닭:
     - 스키마는 `min_length=1`만 검사하므로 `"   "`, 탭, 전각 공백(U+3000), nbsp(U+00A0)만 있는 값도 통과합니다.
     - DB의 `appointments_*_present` CHECK 제약(`app/constraints.py`)이 이 값을 거부해 `commit()`에서 `IntegrityError`가 납니다.
     - 어디에서도 잡지 않으므로 500이 됩니다.
   - `phone`은 패턴이 스페이스를 허용해서 `"   "`도 같은 경로로 500이 됩니다.
   - 계약은 받을 수 없는 요청을 422로 돌려준다고 했습니다. 검증 규칙이 DB 제약에만 있고 API 층에는 없는 것이 원인입니다.

2. **NUL 문자(`\x00`)가 들어가면 500이 납니다.**
   - 자리: `app/schemas.py`의 `patient_name`, `department`, `memo` 등 문자열 칸 전체
   - 까닭: pydantic은 NUL을 막지 않습니다. PostgreSQL 텍스트 칸은 NUL을 받지 못하므로 psycopg가 `DataError`를 내고, 이것도 잡히지 않아 500이 됩니다. 이 요청도 고쳐서 다시 보낼 수 있는 입력인데 422가 아닙니다.

3. **DB 오류를 처리하지 않고 롤백도 없습니다.**
   - 자리: `app/main.py`의 `post_appointment`(`s.add`/`s.commit`)와 `session()`
   - 까닭:
     - `IntegrityError`와 `DataError`를 422로 바꾸는 처리가 없습니다. 1번과 2번이 500으로 새는 직접 원인입니다.
     - 예외 시 `rollback()`을 명시하지 않고 `close()`에만 맡깁니다.
     - 앞으로 제약이나 칸이 늘면 같은 종류의 500이 계속 생깁니다.

4. **422 응답의 `detail` 형식이 두 가지입니다.**
   - 자리: `app/main.py`의 `HTTPException(... detail="지난 날짜로는 예약하지 않는다")`와 FastAPI 기본 검증 오류
   - 까닭:
     - 날짜 검사는 `detail`을 문자열로 돌려줍니다. 스키마 검증 실패는 `[{loc, msg, type}, …]` 목록으로 돌려줍니다.
     - `docs/api.md`는 "`detail`이 칸과 까닭을 말한다"고만 하고 형식을 정하지 않았습니다.
     - 창구 화면이 `detail`을 그대로 보여 준다면 목록이 날것으로 나오거나, 문자열일 때는 어느 칸의 문제인지 알 수 없습니다.
     - 날짜 오류에는 칸 정보(`visit_on`)가 없습니다.

## 확신이 낮은 항목

- `app/main.py`의 `date.today()`는 서버 시간대 기준입니다. 자정 부근에는 병원 현지 날짜와 어긋나 당일 예약이 지난 날짜로 거절될 수 있습니다. 서버 시간대가 정해져 있지 않아 확정하지는 못했습니다.
- `docs/api.md`는 201 본문을 "예약 번호"라고만 적었고 JSON 키(`appointment_id`)를 밝히지 않았습니다. 계약 문서가 응답 형식을 충분히 정하지 못한 것입니다.
