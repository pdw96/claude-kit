<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.1066896 -->

`INTENT.md` 는 저장소 안에 없습니다. `CLAUDE.md` 가 먼저 읽으라고 한 파일입니다. 저장소 밖 `/home/user/claude-kit/INTENT.md` 는 이 프로젝트 것으로 보지 않아 열지 않았습니다. 그래서 "하지 않을 일" 목록은 확인하지 못했습니다. 아래 결함 중 그 목록과 겹치는 것이 있을 수 있습니다. 코드는 수정하지 않았습니다.

## 결함 목록

**1. 비활성 공통코드로 새 환불이 만들어집니다.**
- 자리: `app/services/refunds.py` 의 `_must_be_a_code`, `app/models.py` 의 `Refund.__table_args__`, `seed/codes.sql`
- 까닭: `CommonCode` 독스트링은 비활성 코드를 "새 기록에서는 못 고른다"고 합니다. 그런데 `_must_be_a_code` 는 행이 있는지만 보고 `is_active` 는 보지 않습니다. 복합 FK 도 `is_active` 를 강제하지 못합니다. 시드의 비활성 코드 `POINT` 와 `PROMO` 로 `POST /orders/{id}/refunds` 를 호출하면 201 이 나옵니다.

**2. "되돌리는 환불을 새로 세운다"는 원칙을 구현할 방법이 없습니다.**
- 자리: `docs/schema.md` 원칙 1, `refunds_amount_positive` 제약, `RefundIn.amount` 의 `gt=0`, `refund()` 의 `amount <= 0` 검사
- 까닭: 취소나 역분개를 담을 수 있는 구조가 없습니다. 음수 금액, 원 환불을 가리키는 칼럼, 종류 칼럼이 모두 없습니다. 음수 금액은 DB 제약, 입력 검증, 서비스 검사에서 세 번 막힙니다. 잘못 세운 환불을 바로잡으려면 행을 지우거나 고치거나 `orders.refunded` 를 직접 고치는 수밖에 없습니다. 이는 원칙 1 과 어긋납니다.

**3. `orders.refunded` 가 `refunds` 합계와 같다는 보장이 없습니다.**
- 자리: `app/models.py` 의 `Order.refunded`, `refund()` 의 `order.refunded += ...`, `migrations/0001_refunds.py`
- 까닭: 파생값을 변경 가능한 카운터로 따로 저장합니다. DB 에는 `refunded >= 0` 이나 `refunded <= amount` 를 막는 CHECK 가 없습니다. 이 한도는 서비스 코드에서만 지켜집니다. 서비스를 거치지 않는 쓰기나 수동 보정으로 쉽게 깨집니다. 깨졌을 때 `refunds` 합계와 대조해 복구할 수단도 없습니다.

**4. 같은 요청이 재시도되면 환불이 중복으로 세워집니다.**
- 자리: `app/main.py` 의 `post_refund`, `refunds` 표
- 까닭: 멱등 키나 유일 제약이 없습니다. 클라이언트가 타임아웃으로 재시도하거나 더블 클릭하면, 한도 안에서는 같은 환불이 두 번 기록됩니다.

**5. 커밋이 서비스 밖 엔드포인트에 있고 커밋 실패는 처리되지 않습니다.**
- 자리: `app/main.py` 의 `post_refund` 의 `s.commit()`, `refunds.py` 의 `refund()`
- 까닭: `refund()` 는 flush 만 하고, 락(`with_for_update`)은 커밋 때까지 유지됩니다. 따라서 락이 풀리는 시점이 호출자의 `commit()` 에 달려 있습니다. 서비스를 다른 곳에서 호출하면 커밋이 빠지거나 겹칠 수 있습니다. `commit()` 의 예외(직렬화나 연결 오류)는 잡지 않아 500 이 되고, 클라이언트는 환불이 됐는지 알 수 없습니다. 이 점은 4번과 겹쳐 위험을 키웁니다.

**6. 시드가 마이그레이션 밖에 있고 다시 실행할 수 없습니다.**
- 자리: `seed/codes.sql`, `migrations/0001_refunds.py`
- 까닭: `upgrade()` 는 `common_codes` 를 비워 둡니다. 시드를 따로 넣지 않으면 모든 환불이 "그런 코드가 없다"로 거절됩니다. 시드는 `ON CONFLICT` 가 없어, 두 번 실행하면 PK 위반으로 실패합니다. 기존 코드의 `is_active` 나 `name` 변경도 반영하지 못합니다.

**7. `downgrade()` 의 보호가 일부만 됩니다.**
- 자리: `migrations/0001_refunds.py` 의 `downgrade`
- 까닭: `refunds` 가 비어 있는지만 확인합니다. 그 뒤 `orders` 와 `common_codes` 를 무조건 `drop_table` 해서, 주문 데이터와 공통코드는 확인 없이 사라집니다. 코드의 `is_active` 이력도 함께 사라집니다. 검사와 삭제 사이에 잠금이 없어, 그 틈에 들어온 환불은 지워질 수 있습니다.

**8. Alembic 실행 환경이 없어 마이그레이션을 실행할 수 없습니다.**
- 자리: 저장소 전체. `alembic.ini` 와 `env.py` 가 없고, `migrations/` 에는 `0001_refunds.py` 하나뿐입니다.
- 까닭: `requirements.txt` 에 alembic 이 있지만 설정이 없습니다. 모델 정의(`models.py`)와 마이그레이션이 손으로 이중 관리되고, 둘이 어긋나는지 자동으로 확인할 수단도 없습니다.

**9. `refunds` 에 시각이나 행위자가 없고 `order_id` 인덱스도 없습니다.**
- 자리: `app/models.py` 의 `Refund`, `migrations/0001_refunds.py` 의 `refunds` 표
- 까닭: "일어난 일은 지우지 않는다"는 원칙이 있는데, 언제 누가 환불했는지 기록할 칼럼이 없습니다. 감사나 되돌림 근거로 쓸 수 없습니다. `order_id` 에 인덱스가 없어 주문별 환불 조회와 합계 대조(3번)가 전체 스캔이 됩니다. 이는 낮은 중요도입니다.

**10. 금액이 32비트 정수이고 통화 단위가 없습니다.**
- 자리: `Order.amount`, `Order.refunded`, `Refund.amount` (모두 `sa.Integer`)
- 까닭: 약 21억을 넘으면 오버플로합니다. 통화 단위나 소수 처리 규칙이 스키마에 없습니다. 이는 낮은 중요도입니다.

## 제외한 항목
`app/main.py` 에 하드코딩된 DB 접속 문자열은 로컬 전용 값으로 보고 올리지 않았습니다. `CLAUDE.md` 가 그런 값을 결함으로 올리지 말라고 합니다.

## 가장 먼저 볼 것
1번, 2번, 3번이 데이터 정합성에 직접 영향을 줍니다. 4번과 5번은 운영 중 실제 돈 문제로 이어질 수 있습니다.
