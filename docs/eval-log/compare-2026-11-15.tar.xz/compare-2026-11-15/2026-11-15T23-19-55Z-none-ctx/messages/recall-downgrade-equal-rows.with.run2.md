<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.10270850000000001 -->

`INTENT.md`가 저장소에 없어서 CLAUDE.md가 말하는 「하지 않을 일」은 확인하지 못했습니다. 닫힌 조각도 없고 커밋 이력도 비어 있습니다. 그래서 제외한 항목은 없습니다. 파일은 수정하지 않았고, 코드를 읽기만 했습니다. 대상은 `app/models.py`, `migrations/versions/0006·0007`, `docs/schema.md`입니다.

## 결함

**1. 0007 `downgrade()`가 리비전이 만들지 않은 코드 줄까지 지웁니다 (높음).**
- 자리: `migrations/versions/0007_shipping_zone.py`, `upgrade()`의 `WHERE NOT EXISTS`와 `downgrade()` 끝의 `DELETE FROM common_codes WHERE group_code = ...`.
- 까닭: `upgrade()`는 운영자가 먼저 만든 줄이 있으면 건너뜁니다. 그러면 그 줄은 리비전이 만든 것이 아닌데도 `downgrade()`가 지웁니다.
- 예: 운영자가 `METRO / 수도권 / 1 / 활성`을 미리 만들어 뒀다고 합시다. 값이 심는 값과 같으면 `changed` 검사를 통과하고, `DELETE`가 그 줄을 지웁니다.
- 이는 `docs/schema.md` 원칙 1(되돌리기는 그 리비전이 만든 것만 거둔다)을 어깁니다.
- 줄에 출처 표시가 없어서 "심은 줄"과 "같은 값으로 만든 줄"을 구분할 수 없습니다. 값 비교로는 출처를 알 수 없습니다.

**2. `downgrade()`가 `code_groups`의 `SHIPPING_ZONE` 줄을 내용 검사 없이 지웁니다 (높음).**
- 자리: `0007`의 `downgrade()`, `DELETE FROM code_groups WHERE group_code = ...`.
- 까닭: 코드 줄은 `extra`와 `changed`로 검사하지만, 그룹 줄은 `name`과 `description`을 심은 값과 비교하지 않습니다.
- 운영자가 먼저 만들었거나 나중에 고친 그룹도 그대로 지워집니다. `upgrade()`는 그룹이 이미 있으면 건너뛰므로 1번과 같은 문제입니다.

**3. `orders.shipping_zone`에 참조 무결성이 없습니다 (중간).**
- 자리: `app/models.py`의 `Order.shipping_zone`, `0007`의 `op.add_column`.
- 까닭: 문서는 이 칸이 `SHIPPING_ZONE` 그룹의 코드를 "가리킨다"고 하지만, 실제로는 `String(30)` 칸일 뿐입니다. FK도 CHECK도 없습니다.
- 운영자가 관리 화면에서 코드를 지우거나 이름을 바꾸면, 주문에 고아 값이 남습니다.
- 임의 문자열도 들어갈 수 있습니다.
- `common_codes`의 기본키가 `(group_code, code)` 복합키라서 단순 FK로는 걸 수 없습니다. 그래서 `shipping_zone`용 그룹 칸을 따로 두거나, 복합 FK와 고정 그룹 값 CHECK를 함께 써야 합니다.

**4. `downgrade()`의 검사와 삭제가 잠금 없이 이어집니다 (중간).**
- 자리: `0007`의 `downgrade()`, `used`·`extra`·`changed` 조회와 `DELETE`·`drop_column`.
- 까닭: 검사 시점과 삭제 시점 사이에 잠금이 없습니다. 그 사이에 운영자가 코드를 더하거나 고치거나, 주문에 권역이 기록될 수 있습니다.
- 그러면 검사를 통과한 뒤에도 사람이 만든 데이터가 지워지거나 `drop_column`으로 사라집니다.
- `LOCK TABLE ... IN SHARE ROW EXCLUSIVE MODE`나 `SELECT ... FOR UPDATE`가 필요합니다.

**5. `upgrade()`의 `NOT EXISTS` 삽입이 동시 실행에 안전하지 않습니다 (낮음~중간).**
- 자리: `0007`의 `upgrade()`, 두 개의 `INSERT ... WHERE NOT EXISTS`.
- 까닭: 운영자가 같은 키를 동시에 만들면 PK 위반으로 실패할 수 있습니다. `ON CONFLICT DO NOTHING`이 맞는 방식입니다.
- 건너뛴 줄이 있어도 로그가 남지 않습니다. 그래서 1번에서 말한 출처 구분도 나중에 할 수 없습니다.

**6. `downgrade()`가 한 번 멈추면 영구히 막힐 수 있고, 안내가 없습니다 (낮음).**
- 자리: `0007`의 `downgrade()`, `extra`와 `changed`의 `RuntimeError`.
- 까닭: 운영자가 그룹에 코드를 하나만 더해도 되돌리기가 영구히 막힙니다. 해소 절차가 없습니다.
- `docs/schema.md`에 "남의 것이 섞여 있으면 멈춘다"는 원칙만 있고, 멈춘 뒤에 할 일은 적혀 있지 않습니다.

**7. `0006`의 `downgrade()`가 항상 예외를 던집니다 (낮음).**
- 자리: `0006_orders.py`의 `downgrade()`.
- 까닭: 의도된 동작일 수 있지만, 이 리비전까지 되돌리는 것은 불가능합니다. 환경을 처음부터 다시 만들 수도 없습니다.
- `0007`에서 `0006`으로 내려가는 것까지만 가능합니다.

**8. SQL을 f-string으로 조립하고, PostgreSQL 전용 문법을 씁니다 (낮음).**
- 자리: `0007`의 `_values()`, `upgrade()`, `downgrade()` 전반.
- 까닭: 값이 모듈 상수라 지금은 주입 위험이 없습니다. 하지만 이름에 따옴표가 들어가면 깨집니다. 바인드 파라미터나 `sa.table`/`insert`를 쓰는 편이 안전합니다.
- `VALUES ... AS v(...)`와 `IS DISTINCT FROM`의 행 비교는 PostgreSQL 전용입니다. 다른 DB를 지원할 계획이 있다면 이식되지 않습니다.

**9. Alembic 실행 설정이 저장소에 없습니다 (낮음, 확인 필요).**
- 자리: `migrations/` 전체.
- 까닭: `env.py`, `alembic.ini`, `script.py.mako`가 없습니다. 그래서 트랜잭션 경계(`transaction_per_migration`, `transactional_ddl`)를 확인할 수 없습니다.
- `downgrade()` 안에서 예외가 나면 앞선 단계가 함께 롤백되는지도 알 수 없습니다. 이는 설정이 다른 곳에 있다면 해당하지 않습니다.

**10. 모델에 `shipping_zone` 인덱스가 없습니다 (낮음).**
- 자리: `app/models.py`의 `Order`.
- 까닭: `downgrade()`의 `WHERE shipping_zone IS NOT NULL` 검사와 권역별 조회가 전체 스캔이 됩니다. 주문이 많아지면 문제입니다.

## 정리

가장 중요한 것은 1번과 2번입니다. `docs/schema.md`의 원칙 1이 "사람이 만든 데이터는 지우지 않는다"고 명시했는데, 값이 같으면 사람이 만든 줄도 지우는 구조입니다. 해결하려면 출처를 기록(예: `seeded_by` 칸)하거나, `upgrade()`가 실제로 넣은 줄만 되돌리도록 해야 합니다. 그 다음이 3번(참조 무결성)과 4번(검사와 삭제 사이의 경쟁)입니다.
