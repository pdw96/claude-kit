<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.1147445 -->

`INTENT.md` 와 닫힌 조각은 저장소에 없습니다. CLAUDE.md 가 읽으라고 한 문서가 없어서 제외할 항목 없이 전부 봤습니다. 코드는 읽기만 했고 실행하지 않았습니다. 아래 결함은 모두 코드를 읽고 추론한 것입니다.

## 트랜잭션 경계

1. **커밋이 응답 뒤에 일어날 수 있습니다.** 자리는 `app/main.py` 의 `session_scope` 입니다.
   - `session.commit()` 이 `yield` 의존성의 종료부에 있습니다. 최근 FastAPI 는 이 종료부를 응답을 보낸 뒤에 실행합니다.
   - SERIALIZABLE 에서는 직렬화 실패(40001)가 commit 시점에 가장 흔하게 납니다.
   - 그 경우 클라이언트는 이미 201 과 `loan_id`, `available_copies` 를 받았는데 대출은 롤백됩니다.
   - 에러를 HTTP 응답으로 바꿀 수도 없습니다. 커밋은 엔드포인트 안이나 `lend` 호출 경계에서 해야 합니다.

2. **직렬화 실패를 재시도하거나 번역하지 않습니다.** 자리는 `app/db.py` 의 `isolation_level="SERIALIZABLE"` 와 `app/main.py` 의 `post_loan` 입니다.
   - 원칙 3 은 SERIALIZABLE 에만 기대고 있습니다. 동시에 같은 책을 빌리면 한쪽은 `OperationalError`/`SerializationFailure` 로 실패합니다.
   - 이 예외를 잡는 곳이 없어서 500 이 되고, 재시도도 없습니다. "하나만 선다"는 지켜져도 나머지 요청은 정상 거절(422)이 아니라 서버 오류를 받습니다.
   - `available_copies` 가 남아 있어도 같은 일이 생깁니다.

3. **남은 권수를 읽고 파이썬에서 계산해 되씁니다.** 자리는 `app/services/loans.py` 의 `lend` 에 있는 `book.available_copies -= 1` 입니다.
   - 이 줄은 `SET available_copies = <읽은 값 - 1>` 로 나갑니다. 원자적 `UPDATE ... SET available_copies = available_copies - 1 WHERE available_copies > 0` 이 아닙니다.
   - 안전은 전적으로 엔진 전체 SERIALIZABLE 에 달려 있습니다. 격리 수준이 바뀌거나 다른 세션 팩토리가 쓰이면 갱신 손실이 납니다.
   - 그때 방어선은 CHECK 하나뿐이고, CHECK 는 음수만 막습니다. 두 요청이 같은 값을 쓰면 대출 두 줄에 권수는 1만 줄어듭니다. 원칙 1 이 깨집니다.

## 데이터 모델

4. **반납 경로가 없습니다.** 자리는 `app/` 전체와 `docs/schema.md` 입니다.
   - 문서는 "반납하면 `returned_on` 이 찬다"고 하지만 반납 코드가 없습니다.
   - `available_copies` 를 되돌리는 쪽도 없습니다. 한 번 줄면 영영 늘지 않아, 되돌림(복구)이 설계 밖에 있습니다.
   - 이 상태에서 `returned_on` 과 `available_copies` 는 서로 정합을 지킬 수단이 없습니다.

5. **`available_copies` 가 파생값인데 근거가 없습니다.** 자리는 `app/models.py` 의 `Book` 과 `migrations/0001_initial.py` 의 `books` 입니다.
   - 전체 소장 권수(`total_copies`)가 없습니다. 상한 CHECK(`available_copies <= total_copies`)가 없고, `loans` 의 미반납 건수와 맞는지 검증할 수도 없습니다.
   - 어긋나면 고칠 기준이 없습니다. 컬럼에 기본값도 없어서 도서를 넣을 때마다 값을 직접 넣어야 합니다.

6. **같은 회원이 같은 책을 여러 번 빌릴 수 있습니다.** 자리는 `loans` 표입니다.
   - `(book_id, member_id)` 에서 `returned_on IS NULL` 인 줄에 부분 유니크 인덱스가 없습니다.
   - 회원당 대출 한도도 없습니다. 한 회원이 같은 책을 연달아 빌려 남은 권수를 모두 가져갈 수 있습니다.

7. **`loans` 의 날짜 제약이 부족합니다.** 자리는 `app/models.py` 의 `Loan` 과 마이그레이션의 `loans` 입니다.
   - `returned_on >= loaned_on` CHECK 가 없습니다.
   - `books.loan_days` 에 `> 0` CHECK 가 없습니다. 음수 값이면 `loans_due_after_loan` 위반이 `IntegrityError` 로 올라와 500 이 됩니다.
   - 이 위반은 `RefusedLoan` 처럼 이름 붙은 거절로 번역되지 않습니다.

8. **`loaned_on` 을 클라이언트가 정합니다.** 자리는 `app/schemas.py` 의 `LoanIn.loaned_on` 과 `lend` 의 `due_on` 계산입니다.
   - 대출일에 서버 기준 시각이 아니라 요청 값을 그대로 씁니다. 과거나 먼 미래 날짜로 반납 기한(`due_on`)을 마음대로 만들 수 있습니다.
   - 범위 검증이 없습니다.

9. **외래키 열에 인덱스가 없습니다.** 자리는 `loans.book_id` 와 `loans.member_id` 입니다.
   - PostgreSQL 은 FK 열에 인덱스를 자동으로 만들지 않습니다.
   - 반납 조회, 회원별 대출 조회, 부모 행 갱신 시 검사가 `loans` 전체를 훑습니다.
   - SERIALIZABLE 에서는 이 풀스캔이 술어 잠금 범위를 넓혀 직렬화 실패(결함 2)를 더 늘립니다.

## 마이그레이션 · 되돌림

10. **`downgrade` 의 보호가 `loans` 에만 걸려 있습니다.** 자리는 `migrations/0001_initial.py` 의 `downgrade` 입니다.
    - 대출 줄이 없으면 `books` 와 `members` 를 무조건 `drop_table` 합니다.
    - 회원과 도서 데이터는 "지우면 되살릴 길이 없다"는 같은 이유가 적용되는데도 검사하지 않습니다.
    - 대출 없이 회원과 도서만 있는 운영 DB 에서 되돌리면 그 데이터가 사라집니다.

11. **Alembic 을 실제로 돌릴 설정이 없습니다.** 자리는 `migrations/` 와 저장소 루트입니다.
    - `alembic.ini` 와 `migrations/env.py` 가 없습니다. `alembic upgrade` 를 실행할 수 없습니다.
    - `target_metadata` 가 없어서 `--autogenerate` 로 모델과 마이그레이션이 어긋났는지 확인할 방법도 없습니다.
    - 마이그레이션 파일은 `branch_labels` 와 `depends_on` 도 선언하지 않았습니다.

12. **모델과 마이그레이션이 이중 정의입니다.** 자리는 `app/models.py` 와 `0001_initial.py` 입니다.
    - 컬럼, CHECK, 기본값이 두 곳에 손으로 복제돼 있습니다.
    - 위 결함 5~9 를 고칠 때 한쪽만 바꾸면 어긋나는데, 어긋남을 잡아 줄 장치(결함 11)가 없습니다.

13. **스키마 문서와 코드의 불일치 가능성이 큽니다.** 자리는 `docs/schema.md` 입니다.
    - 문서는 원칙 1~3 이 지켜진다고 말하지만 위 결함 1~3 에서 보듯 응답 시점에는 보장되지 않습니다.
    - 반납(결함 4)도 문서에만 있습니다.

결함 1, 2, 3 은 서로 이어져 있어서 가장 먼저 볼 만합니다. 대출이 몰릴 때 거짓 성공과 500 이 함께 나옵니다.
