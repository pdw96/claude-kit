<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.0935493 -->

검토 결과입니다. 코드는 고치지 않았고, 실행해서 확인한 것도 없습니다. 전부 코드와 `docs/api.md`를 읽고 판단했습니다.

`CLAUDE.md`는 `INTENT.md`의 Not과 닫힌 조각의 「하지 않을 일」을 먼저 읽으라고 합니다. 그런데 저장소에는 `INTENT.md`가 없고 `.claude/`에도 파일이 없습니다. 그래서 제외할 항목을 확인하지 못했습니다. 로컬 전용 값으로 보이는 `app/main.py`의 DB URL(`postgresql+psycopg://events@localhost/events`)만 결함에서 뺐습니다.

## 결함 (중요한 순)

1. **NUL 문자(`\u0000`)가 검증을 통과해 500이 됩니다.**
   - 자리: `app/schemas.py`의 `RegistrationIn` 네 칸 전부(`event_code`, `attendee_name`, `organization`, `note`)와 `app/main.py`의 `post_registration`(`s.commit()`).
   - 까닭: PostgreSQL의 `text`는 NUL을 저장하지 못해서, `commit()`에서 psycopg `DataError`가 납니다. 이 예외를 잡는 곳이 없어 클라이언트는 500을 받습니다.
   - 어긋나는 약속: `docs/api.md`는 "경계를 지난 요청은 저장된다"고 하고 응답을 201과 422만 적었습니다. `_present`의 docstring도 "데이터베이스까지 가면 이름 없는 실패가 된다"고 하는데, 이 경로가 바로 그런 실패입니다.

2. **"비어 보이는 값" 걸러내기가 불완전합니다.**
   - 자리: `app/schemas.py`의 `_BLANK`와 `_present`.
   - 까닭: `_BLANK`는 스페이스, 탭, `\n`, `\r`, U+3000, U+00A0만 담고 있습니다. `\v`, `\f`, U+0085, U+2003 같은 유니코드 공백이나 U+200B(폭 없는 공백)만으로 된 값은 통과합니다. 주석은 "눈에는 비어 보이는 값"을 거른다고 하는데 목록이 그만큼 넓지 않습니다. `str.strip()`을 인자 없이 쓰는 방법도 있었습니다.

3. **`note`만 공백 검증이 없습니다.**
   - 자리: `app/schemas.py`의 `RegistrationIn.note`.
   - 까닭: `organization`에 `"  "`를 보내면 422인데, `note`에 보내면 그대로 저장됩니다. 선택 칸끼리 규칙이 다릅니다. 의도라면 문서에 없습니다.

4. **정의되지 않은 필드를 조용히 버립니다.**
   - 자리: `app/schemas.py`의 `RegistrationIn`. `extra="forbid"` 설정이 없습니다.
   - 까닭: pydantic 기본값이 extra 무시라서, `organisation`처럼 오타 난 칸을 보내도 201이 나가고 그 값은 사라집니다. "경계를 지난 요청은 저장된다"는 약속과 달리 보낸 데이터가 일부 저장되지 않습니다.

5. **에러 규약이 DB 쪽 실패를 다루지 않습니다.**
   - 자리: `docs/api.md`의 응답 표와 `app/main.py`의 `post_registration`, `session`.
   - 까닭: 표에는 201과 422만 있습니다. DB 연결 실패, commit 실패(1번 포함), 제약 위반은 모두 FastAPI 기본 500으로 나갑니다. 이 응답의 본문 형식은 정해져 있지 않습니다. 명시적인 `rollback`이나 예외 변환도 없습니다.

6. **중복 신청을 막지 못합니다.**
   - 자리: `migrations/0001_registrations.py`와 `app/models.py`. 유니크 제약이 없고 `app/main.py`에도 중복 확인이 없습니다.
   - 까닭: 같은 `event_code`와 `attendee_name`으로 요청이 재전송되거나 두 번 눌리면 행이 둘 생기고 각각 201을 받습니다. 멱등성 규약이 없고 문서에도 언급이 없습니다. 이 항목은 어디까지가 약속인지 정해져 있지 않아서 확실한 결함이라기보다 규약의 빈틈입니다.

7. **`event_code`를 형식이나 존재 여부로 검증하지 않습니다.**
   - 자리: `app/schemas.py`의 `RegistrationIn.event_code`.
   - 까닭: 길이 1~20과 공백 아님만 봅니다. 존재하지 않는 행사 코드나 임의 문자열도 201로 저장됩니다. 코드 형식의 규약이 문서에 없습니다.

8. **앞뒤 공백을 정리하지 않고 그대로 저장합니다.**
   - 자리: `app/schemas.py`의 `_present`. 검사만 하고 `value`를 그대로 돌려줍니다.
   - 까닭: `" A1 "`과 `"A1"`이 다른 행사 코드로 저장되어, 이후 조회나 중복 판정이 어긋납니다.

9. **422 본문 형식이 문서에 약속된 만큼 정리되어 있지 않습니다.**
   - 자리: `docs/api.md`의 "`detail`이 칸과 까닭을 말한다"와 `app/schemas.py`의 `_present`.
   - 까닭: 실제 본문은 FastAPI 기본인 `detail`의 객체 배열(`loc`, `msg`, `type`)입니다. `_present`가 던진 메시지는 pydantic이 "Value error, 비어 있다"로 접두어를 붙입니다. 문서에 이 구조의 예시나 스키마가 없어서 클라이언트가 의존할 형식이 정해지지 않았습니다.

10. **운영 보조 파일이 없습니다.**
    - 자리: 저장소 전체. `alembic.ini`와 `env.py`가 없습니다. `requirements.txt`에는 `pydantic`이 직접 고정되어 있지 않습니다(의존성으로만 들어옴).
    - 까닭: 마이그레이션을 실행하는 방법이 저장소 안에 없습니다. 검증 동작이 pydantic 버전에 따라 달라질 수 있습니다.

작은 사항으로, 요청 본문 크기 제한이 없습니다. `max_length`는 본문을 다 파싱한 뒤에 적용됩니다.
