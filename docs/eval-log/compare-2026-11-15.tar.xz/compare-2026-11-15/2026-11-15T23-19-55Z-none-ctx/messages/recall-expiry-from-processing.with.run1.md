<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.0903093 -->

데이터 쪽에서 결함 7건을 찾았습니다. 저장소에는 파일이 9개뿐입니다. CLAUDE.md가 읽으라고 한 `INTENT.md`는 없었고 닫힌 조각도 없었습니다. 그래서 제외할 항목은 없었습니다. 코드는 고치지 않았고, 실행해서 확인한 것도 없습니다. 아래는 모두 코드를 읽고 추론한 결과입니다.

**1. 회원권 시작일을 신청일이 아니라 승인일로 잡습니다 (확실)**
- 자리: `app/services/memberships.py` `approve`, 29–35줄
- 까닭: `starts_on`을 `datetime.now()`의 날짜로 정하고 `valid_until = starts_on + duration_days`로 계산합니다. `application.applied_on`은 읽지 않습니다.
  - `seed/plans.sql`의 안내 문구는 "신청일로부터 N일, 신청일 + 기간"이라고 합니다. `docs/schema.md`는 승인이 신청 다음 날이나 그 뒤(주말 신청은 월요일)에 난다고 적습니다.
  - 그래서 승인이 늦은 만큼 회원이 일수를 잃고, 화면에 나가는 약속과 실제 만료일이 어긋납니다.

**2. 날짜를 UTC 기준으로 잘라 하루가 어긋납니다 (확실)**
- 자리: `approve`, 29–30줄
- 까닭: `datetime.now(timezone.utc).date()`로 시작일을 구합니다. `applied_on`은 창구에 온 현지 날짜입니다.
  - 한국 시간 00:00~09:00에 승인하면 UTC 날짜는 전날입니다. 시작일과 만료일이 하루 앞당겨집니다.
  - 출입 단말은 `valid_until`로 막으므로, 이 어긋남이 그대로 출입 차단일에 반영됩니다.

**3. 동시 승인이 막히지 않고 500으로 샙니다 (확실)**
- 자리: `approve` 22–26줄과 41줄, `app/main.py` `post_approval` 29–33줄
- 까닭: 신청을 잠금 없이 읽고(`session.get`), `status`를 확인한 뒤, 상태를 바꿉니다. `with_for_update`나 조건부 UPDATE가 없습니다.
  - 같은 신청에 요청이 둘 겹치면 둘 다 `pending`을 보고 통과합니다.
  - `memberships.application_id`의 unique 제약이 이중 생성은 막아 줍니다.
  - 하지만 `flush()`에서 나는 `IntegrityError`는 `RefusedApproval`이 아니어서 잡히지 않습니다. 진 쪽은 422 "이미 처리한 신청" 대신 500을 받습니다.
  - `s.commit()`도 `try` 밖에 있어, 커밋 단계 오류는 모두 처리 없이 500이 됩니다.

**4. downgrade가 데이터를 지우는데 보호는 일부뿐입니다**
- 자리: `migrations/0001_memberships.py` `downgrade`, 40–46줄
- 까닭: `memberships`에 행이 있는지만 확인합니다. `memberships`가 비어 있으면 `applications`(대기 중인 신청 포함)와 `plans`를 확인 없이 `drop_table`합니다. 승인 전 신청 기록이 조용히 사라집니다.

**5. 마이그레이션이 기준 데이터를 심지 않습니다**
- 자리: `migrations/0001_memberships.py` `upgrade`, `seed/plans.sql`
- 까닭: `docs/schema.md`는 `plans`를 기준 데이터라고 하고 `seed/plans.sql`이 심는다고 합니다. 하지만 마이그레이션과 seed가 이어져 있지 않습니다.
  - upgrade만 하면 `plans`가 빈 채로 남고, 신청의 `plan_code` FK도 만족시킬 수 없습니다.
  - seed는 멱등이 아닌 단순 `INSERT`라서, 다시 실행하면 PK 충돌로 실패합니다.

**6. 상태값과 기간 제약이 느슨합니다**
- 자리: `app/models.py`와 마이그레이션의 `applications.status`(String(10)), `plans.duration_days`, `plans.price`
- 까닭:
  - `status`에 `pending/approved` 같은 값 제한(CHECK나 enum)이 없어, 오타나 임의 값이 들어갈 수 있습니다. 위 3번의 상태 확인이 문자열 비교에만 의존합니다.
  - `duration_days`와 `price`에도 양수 검사가 없습니다. 0 이하의 기간이 들어가도 `memberships_period` 제약이 승인 시점에야 막습니다.

**7. 같은 회원의 회원권이 겹쳐도 막지 못합니다**
- 자리: `app/models.py` `Membership`, `memberships` 표
- 까닭: unique 제약은 `application_id`에만 있습니다. 같은 `member_id`로 신청 여러 건을 승인하면 기간이 겹치거나 중복된 회원권이 생깁니다.
  - `member_id`에는 FK도 인덱스도 없습니다. 회원 조회와 출입 판정이 전체 스캔이 될 수 있고, 존재하지 않는 회원 번호도 들어갑니다.
  - `approved_by`도 요청 본문의 자유 문자열이고 직원 표를 참조하지 않아, 승인 이력의 신뢰성이 떨어집니다.

우선순위는 1, 2, 3번입니다. 이용자가 바로 손해를 보거나 500이 나는 문제입니다. 4번과 5번은 운영 중 마이그레이션이나 배포 때 문제가 됩니다.
