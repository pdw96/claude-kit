<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.12427470000000002 -->

데이터 쪽을 전부 읽고 검토했습니다. 코드는 고치지 않았습니다. 이 저장소에는 `app/`, `migrations/0001_initial.py`, `docs/schema.md`가 있고, 파일은 모두 읽었습니다. 실행은 하지 않았습니다.

`CLAUDE.md`는 리뷰 전에 `INTENT.md`의 Not과 「하지 않을 일」을 읽으라고 합니다. 이 저장소 안에는 `INTENT.md`가 없습니다. `/home/user/claude-kit/INTENT.md`가 따로 있지만 다른 프로젝트 것으로 보여 쓰지 않았습니다. 그래서 제외할 항목을 확인하지 못했습니다. 로컬 전용 값인 `settings.py`의 기본 DB URL은 결함으로 올리지 않았습니다.

## 결함

**높음**

1. **`SERIALIZABLE` 충돌에 재시도나 변환이 없습니다.**
   - 자리: `app/db.py:9`, `app/main.py:16-29`(`session_scope`), `app/main.py:35-42`
   - 까닭: `SERIALIZABLE`에서 같은 책을 동시에 빌리면 PostgreSQL은 진 쪽에 serialization failure(40001)를 냅니다. 이 오류는 `lend` 안의 `flush`나 `session_scope`의 `commit`에서 나옵니다. `RefusedLoan`만 잡고 있어서 이 오류는 처리되지 않고 500이 됩니다. 재시도도 409 같은 응답도 없습니다. 원칙 3의 "하나만 선다"는 지켜지지만, 진 쪽은 일시적 충돌인데도 서버 오류로 끝납니다.

2. **반납 경로가 없고, 권수와 대출 줄이 맞는지 보장하는 장치도 없습니다.**
   - 자리: `app/services/loans.py` 전체, `docs/schema.md:5-6`
   - 까닭: 문서는 반납하면 `returned_on`이 차고 `available_copies`는 지금 빌려 줄 수 있는 권수라고 합니다. 코드에는 `returned_on`을 쓰거나 권수를 되돌리는 곳이 없습니다. 이 상태로는 대출할 때마다 권수가 줄기만 하고 늘지 않습니다. 총 보유 권수 컬럼(`total_copies`)이나 `available_copies <= 총권수` 제약도 없습니다. 열린 대출 수와 `available_copies`가 어긋나도 찾을 수 없고, 나중에 반납을 넣을 때 이중 반납으로 권수가 부풀어도 막지 못합니다. 이것이 "되돌림" 쪽의 가장 큰 구멍입니다.

3. **마이그레이션을 실행할 수 없는 구조입니다.**
   - 자리: `migrations/` (`0001_initial.py`만 있음)
   - 까닭: `alembic.ini`, `env.py`, `script.py.mako`, `versions/`가 없습니다. 파일이 `migrations/` 바로 아래에 있어서 alembic이 개정으로 읽지 못합니다. `requirements.txt`에는 alembic이 있지만 어디에도 연결되지 않았습니다. 스키마를 만드는 길이 코드에 없으니, 모델(`models.py`)과 마이그레이션이 실제로 일치하는지 검증할 방법도 없습니다. 지금은 두 곳에 같은 정의를 손으로 복사해 둔 상태입니다.

**중간**

4. **`downgrade`의 안전장치가 반쪽입니다.**
   - 자리: `migrations/0001_initial.py:39-46`
   - 까닭: 주석은 지우면 되살릴 길이 없어 되돌리지 않는다고 하는데, 검사는 `loans`에 행이 있는지만 봅니다. `loans`가 비어 있고 `members`나 `books`에 데이터가 있으면 `drop_table`이 그대로 지워 버립니다. 회원은 탈퇴해도 지우지 않는다는 원칙(`docs/schema.md:5`)과도 맞지 않습니다. 검사와 삭제 사이에 잠금이 없어서, 그 사이에 대출이 들어와도 막지 못합니다.

5. **대출일을 클라이언트가 정합니다.**
   - 자리: `app/schemas.py:9`, `app/services/loans.py:41-46`
   - 까닭: `loaned_on`을 요청 본문에서 받아 그대로 저장하고, 거기에 `loan_days`를 더해 `due_on`을 만듭니다. 과거나 먼 미래의 날짜를 넣으면 처음부터 연체이거나 한참 뒤에 반납하는 대출이 만들어집니다. 대출일은 서버가 정하는 값이어야 합니다. 의도된 동작인지 문서에 적혀 있지 않습니다.

6. **같은 회원이 같은 책을 여러 번 빌릴 수 있고, 회원당 한도도 없습니다.**
   - 자리: `app/models.py:29-38`, `app/services/loans.py:30-49`
   - 까닭: `(member_id, book_id)`에 `returned_on IS NULL`인 행은 하나뿐이라는 부분 유일 인덱스가 없습니다. 같은 요청을 다시 보내면 권수가 또 줄고 대출 줄도 또 생겨서, 재전송에 멱등하지 않습니다. 이는 원칙 1이 말하는 "한 건은 한 번에 선다"에도 어긋납니다. 의도가 아니라면 결함입니다.

7. **응답이 커밋 전에 만들어집니다.**
   - 자리: `app/main.py:35-42`와 `session_scope`의 `session.commit()`
   - 까닭: `LoanOut`(`loan_id`, `available_copies`)은 `flush` 직후, 커밋 전의 값으로 만들어집니다. 커밋은 의존성 정리 단계에서 합니다. 커밋이 실패해도 응답이 이미 나갔는지는 FastAPI의 yield 의존성 종료 시점에 달렸고, 이 버전(0.141.1)에서는 확인하지 못했습니다. 커밋을 엔드포인트 안에서 하고 그 뒤에 응답을 만드는 편이 확실합니다.

**낮음**

8. **FK 컬럼에 인덱스가 없습니다.**
   - 자리: `app/models.py:34-35`, `migrations/0001_initial.py:30-31`
   - 까닭: PostgreSQL은 외래키에 인덱스를 자동으로 만들지 않습니다. `loans.book_id`와 `loans.member_id`가 비어 있어서, 회원이나 도서별 대출 조회와 `members`/`books` 쪽 갱신이 `loans` 전체 스캔으로 이어집니다. 열린 대출(`returned_on IS NULL`)을 찾는 부분 인덱스도 없습니다.

9. **값 범위 제약이 부족합니다.**
   - 자리: `app/models.py:25`, `app/models.py:31`, `app/models.py:38`
   - 까닭:
     - `loan_days > 0` 제약이 없습니다. 0이나 음수면 `loans_due_after_loan` 위반으로 `IntegrityError`가 나고 500이 됩니다.
     - `returned_on >= loaned_on` 제약이 없습니다.

10. **ISBN과 카드번호를 정규화하지 않습니다.**
    - 자리: `app/schemas.py:7-8`, `app/services/loans.py:31`, `app/services/loans.py:34`
    - 까닭: 길이 10~13을 허용하지만 ISBN-10과 ISBN-13을 같은 책으로 묶지 않고 하이픈이나 공백도 처리하지 않습니다. 같은 책인데 "없는 도서"로 나올 수 있습니다. 카드번호는 대소문자나 공백이 다르면 다른 회원으로 취급됩니다.

## 확인하지 못한 것
- 동시 대출의 실제 동작은 DB를 띄워 실행해 보지 않았습니다. 1번은 PostgreSQL의 `SERIALIZABLE` 동작과 코드가 `RefusedLoan` 외에는 잡지 않는다는 점에서 추론한 것입니다.
- 7번은 FastAPI 0.141.1이 yield 의존성 종료 코드를 응답 전후 어느 쪽에서 실행하는지 확인하지 못했습니다.
