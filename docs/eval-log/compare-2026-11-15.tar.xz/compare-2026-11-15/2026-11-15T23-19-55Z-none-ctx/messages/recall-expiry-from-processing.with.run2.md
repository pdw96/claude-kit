<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.09760640000000001 -->

데이터 쪽에서 결함 9건을 찾았습니다. 코드는 고치지 않았고 테스트나 실행도 하지 않았으며, 모두 코드를 읽어서 찾았습니다. `CLAUDE.md`는 리뷰 전에 `INTENT.md`의 Not과 닫힌 조각의 「하지 않을 일」을 읽으라고 합니다. 하지만 저장소에 `INTENT.md`와 닫힌 조각이 없어서 제외할 항목 없이 전부 올렸습니다.

## 높음

1. **만료일을 신청일이 아니라 승인 시각에서 계산합니다.**
   - 자리: `app/services/memberships.py` `approve()`의 `starts_on = approved_at.date()`와 `valid_until = starts_on + timedelta(...)`.
   - 까닭:
     - `seed/plans.sql`의 안내 문구는 "신청일로부터 N일, 만료일은 신청일 + 기간"이라고 합니다. `docs/schema.md`도 `applied_on`을 회원이 창구에 온 날이라고 하고, 승인은 다음 날이나 그 뒤에 몰아서 한다(주말 신청은 월요일 승인)고 합니다.
     - 그러면 승인이 늦어진 만큼 만료일이 뒤로 밀려, 화면 안내와 실제 만료일이 어긋납니다. 이 경우 회원은 안내받은 기간보다 더 오래 이용하게 됩니다.
     - `applied_on`은 어디에서도 읽지 않습니다.
   - 어느 쪽이 맞는지는 결정이 필요합니다. 코드가 틀렸거나 안내 문구가 틀렸거나 둘 중 하나입니다.

2. **날짜를 UTC 기준으로 잘라 씁니다.**
   - 자리: `memberships.py`의 `datetime.now(timezone.utc)`와 `.date()`.
   - 까닭: 체육관은 한국 시간대로 운영될 텐데, KST 00:00~09:00에 승인하면 `starts_on`이 전날이 됩니다. `valid_until`도 하루씩 어긋나고, 출입 단말이 막는 시점도 하루 달라집니다.

3. **동시 승인에 대한 보호가 없습니다.**
   - 자리: `approve()`의 `session.get(Application, ...)`과 `status != "pending"` 검사.
   - 까닭:
     - 행 잠금(`with_for_update`)이나 낙관적 버전이 없는 check-then-act입니다. 직원 둘이 같은 신청을 동시에 승인하면 둘 다 pending으로 읽습니다.
     - `memberships.application_id` UNIQUE가 마지막 방어선이라 한쪽은 `flush()`에서 `IntegrityError`가 납니다. 그런데 `post_approval`은 `RefusedApproval`만 잡으므로, 의도한 422가 아니라 500이 됩니다.
     - 몰아서 승인하는 운영 방식이라 겹칠 가능성이 큽니다.

## 중간

4. **트랜잭션 경계가 서비스와 핸들러로 갈라져 있습니다.**
   - 자리: `app/main.py` `post_approval`의 `s.commit()`, `approve()`의 `flush()`.
   - 까닭:
     - 커밋이 `try` 밖에 있어, 커밋 시점에 나는 제약 위반이나 연결 오류는 매핑되지 않고 그대로 500이 됩니다.
     - 명시적 `rollback`도 없고 `session.close()`에 의존합니다.
     - 승인 단위(상태 변경과 회원권 생성)를 한 곳에서 책임지지 않아, 다른 호출 경로가 생기면 커밋을 빠뜨릴 수 있습니다.

5. **`downgrade()`의 보호가 불완전합니다.**
   - 자리: `migrations/0001_memberships.py` `downgrade()`.
   - 까닭:
     - `memberships`가 비어 있는지만 확인하고 `applications`와 `plans`를 삭제합니다.
     - 아직 승인 전인 pending 신청이나 거절된 신청이 있어도 막지 않아 데이터가 사라집니다.
     - 이 삭제는 되돌릴 수 없습니다. 보호 대상을 `applications`까지 넓혀야 일관됩니다.

6. **기준 데이터가 마이그레이션 밖에 있고 멱등하지 않습니다.**
   - 자리: `seed/plans.sql`.
   - 까닭:
     - 마이그레이션이 `plans`를 만들지만 데이터는 별도 파일이 심어서, 심는 걸 잊으면 `applications.plan_code` FK 때문에 신청 자체가 안 됩니다.
     - 단순 `INSERT`라 재실행하면 PK 충돌로 실패합니다(`ON CONFLICT` 없음).
     - `description`에 만료 규칙이 문구로 박혀 있어, 1번 결함이 나면 안내도 같이 틀어집니다.

## 낮음

7. **도메인 제약이 DB에 없습니다.**
   - 자리: `models.py`와 마이그레이션의 `applications.status`, `plans.duration_days`, `plans.price`.
   - 까닭:
     - `status`는 자유 문자열(`String(10)`)이라 `pending`과 `approved` 외의 값이 들어가도 막지 못합니다.
     - `duration_days > 0`과 `price >= 0` CHECK도 없습니다. `duration_days`가 0이나 음수면 `memberships_period` CHECK가 늦게 터져 500이 됩니다.

8. **참조 무결성과 중복 가능성이 비어 있습니다.**
   - 자리: `models.py`의 `member_id`와 `approved_by`.
   - 까닭:
     - `applications.member_id`와 `memberships.member_id`에 FK가 없습니다. 회원 표가 이 저장소에 없습니다.
     - `memberships.member_id`는 신청에서 복사한 값이라 어긋날 수 있고, 일치를 강제하는 제약이 없습니다.
     - 같은 회원이 기간이 겹치는 회원권을 여러 개 가질 수 있고, `approved_by`는 자유 문자열입니다.
     - 인덱스도 `applications(member_id)`와 `applications(status)`에는 없습니다.

9. **`plan`이 없을 때의 처리와 연결 설정이 허술합니다.**
   - 자리: `approve()`의 `plan = session.get(Plan, ...)`, `main.py`의 `create_engine(...)`.
   - 까닭:
     - `plan`이 `None`인지 확인하지 않아 `AttributeError`(500)가 납니다. FK 때문에 현실에서는 드뭅니다.
     - 접속 문자열이 코드에 고정되어 있고 `pool_pre_ping`이 없습니다. 이 항목은 데이터 모델보다는 설정에 가깝습니다.

저장소에 alembic 환경(`alembic.ini`나 `env.py`)이 없어서 마이그레이션을 실행해 볼 방법도 없습니다.
