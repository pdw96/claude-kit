<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.11451090000000001 -->

`.claude` 아래에는 파일이 없습니다. CLAUDE.md가 읽으라고 한 `INTENT.md`와 "닫힌 조각"도 이 저장소에는 없습니다. 파일시스템에서 `/home/user/claude-kit/INTENT.md`가 나오긴 했습니다. 하지만 이 저장소 밖에 있는 파일이라 열지 않았고, 이 저장소의 의도 문서로 보지도 않았습니다. 그래서 "하지 않을 일"로 걸러낸 항목은 없습니다.

## 찾은 결함

검토한 파일은 `app/models.py`, `migrations/versions/0006_orders.py`, `migrations/versions/0007_shipping_zone.py`, `docs/schema.md`입니다.

### 되돌림 (`0007_shipping_zone.py` `downgrade()`)

1. **운영자가 먼저 만든 그룹 행도 지웁니다.** `upgrade()`는 `SHIPPING_ZONE` 그룹이 이미 있으면 넘어갑니다(`WHERE NOT EXISTS`). 그런데 `downgrade()` 끝의 `DELETE FROM code_groups WHERE group_code = 'SHIPPING_ZONE'`는 그 행이 누구 것인지 보지 않고 지웁니다. 운영자가 만든 그룹이어도 지워지므로 `docs/schema.md` 원칙 1("리비전이 만든 것만 거둔다")을 어깁니다.

2. **그룹 행의 name과 description 변경을 검사하지 않습니다.** 코드 행에는 `extra`와 `changed` 검사가 있지만 `code_groups` 행에는 없습니다. 운영자가 그룹 이름이나 설명을 고쳐도 멈추지 않고 지웁니다.

3. **운영자가 먼저 만든 코드 행도 지웁니다.** 운영자가 `METRO` 같은 코드를 심은 값과 똑같이 미리 만들어 뒀다고 하겠습니다. `upgrade()`는 그 코드를 건너뛰어 그 행이 리비전 소유가 아닙니다. 그런데 `downgrade()`의 `changed` 검사는 값이 같으면 통과시키고, 마지막 `DELETE ... WHERE group_code = 'SHIPPING_ZONE'`가 그 행을 지웁니다. 코드에도 문서에도 소유 표시가 없어서, 값이 같은 행은 리비전이 심은 것인지 운영자가 만든 것인지 구분할 방법이 없습니다.

4. **심은 코드 중 일부가 빠진 상태를 허용합니다.** `changed` 검사는 지금 있는 행만 심은 값과 비교합니다. 운영자가 `ISLAND`를 지웠거나 비활성화 후 정리했어도 통과합니다. 값이 다른 행은 `changed`에서 멈추지만, 없는 행은 멈추지 않습니다. 운영자가 정리한 상태를 모르는 채 나머지를 지우게 됩니다.

5. **검사와 삭제 사이에 잠금이 없습니다.** `downgrade()`는 `count(*)`로 검사한 뒤 별도 문장으로 `DELETE`를 실행합니다. 기본 격리 수준(read committed)에서는 그 사이에 운영 화면이 주문을 만들거나 코드를 고치거나 더할 수 있습니다. 그러면 검사를 통과한 뒤에 `shipping_zone`이 적힌 주문이 생기고, 이어서 `drop_column`으로 그 값이 사라질 수 있습니다. `LOCK TABLE`이나 `SELECT ... FOR UPDATE`가 필요합니다.

### 데이터 모델

6. **`orders.shipping_zone`에 참조 무결성이 없습니다.** `docs/schema.md`는 "`SHIPPING_ZONE` 그룹의 코드를 가리킨다"고 쓰지만, 컬럼은 `String(30)` 하나뿐입니다(`models.py` `Order`, `0007` `add_column`). 외래키가 없습니다. `common_codes`의 기본키는 `(group_code, code)`라서 코드 값만 저장해서는 외래키를 걸 수도 없습니다. 존재하지 않는 권역도 저장되고, 운영자가 코드를 삭제하거나 이름을 바꿔도 막는 장치가 없습니다. `downgrade()`의 `orders` 검사가 앱 쪽 방어를 대신 맡고 있습니다.

7. **기존 주문의 `shipping_zone`을 채우지 않습니다.** 컬럼이 `nullable=True`이고 백필이 없어서, 기존 주문은 모두 `NULL`로 남습니다. 이 값이 배송비 계산 축이라면(그룹 설명이 "배송비를 가르는 축이다") `NULL` 처리 규칙이 어디에도 없습니다.

8. **`CommonCode.is_active`를 쓰는 곳에서 비활성 코드를 막지 않습니다.** 비활성 코드를 주문이 계속 가리킬 수 있습니다. 6번과 같은 뿌리의 문제입니다.

### 마이그레이션 구조

9. **PostgreSQL 전용 SQL입니다.** `(VALUES ...) AS v(code, name, sort_order)`와 행 비교 `IS DISTINCT FROM`은 PostgreSQL 문법입니다. SQLite와 MySQL에서는 실패하거나 의미가 달라집니다. 테스트 DB가 다른 엔진이면 `upgrade()`와 `downgrade()`를 검증할 수 없습니다.

10. **SQL을 문자열로 이어 붙입니다.** `_values()`와 `downgrade()`의 `repr(c)`로 SQL을 만들고, `repr`로 SQL 인용을 대신합니다. 지금은 상수라서 문제가 없습니다. 하지만 이름에 `'`가 들어간 코드를 `ZONES`에 추가하면 깨집니다. `op.bulk_insert`나 바인드 파라미터를 쓰는 편이 안전합니다.

11. **마이그레이션 실행 환경이 저장소에 없습니다.** `alembic.ini`와 `env.py`가 없습니다. 그래서 `transaction_per_migration`과 `transactional_ddl` 설정을 알 수 없고, 데이터 `INSERT`/`DELETE`와 DDL이 한 트랜잭션에 들어가는지 확인할 수 없습니다. 중간에 실패하면 컬럼만 더해지거나 시드만 들어간 반쪽 상태가 될 수 있습니다. 여기서 트랜잭션 경계를 보장할 수 없습니다.

12. **`0006`의 `downgrade()`는 항상 예외를 던집니다.** 첫 리비전이라 의도했을 수 있지만, `alembic downgrade base`가 반드시 실패합니다. 표를 만든 리비전이 되돌릴 방법을 남기지 않았습니다. 의도 문서를 못 읽어서 확정하지 못했습니다.

13. **모델과 마이그레이션이 같다는 보장이 없습니다.** `models.py`를 손으로 `0006`과 `0007`에 맞춰 놨습니다. `FK` 이름과 제약 이름이 지정되지 않았고, 자동 비교(`alembic check`)를 돌릴 설정도 없습니다.

## 확인하지 못한 것

코드는 고치지 않았고 실행도 하지 않았습니다. 이 저장소에는 DB 연결, `alembic` 설정, 테스트가 없어서 위 결함은 모두 코드를 읽고 판단한 것입니다. 1~5번이 `docs/schema.md` 원칙 1과 직접 맞닿아 있어 가장 중요합니다.
