<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.1041621 -->

저장소 전체(`app/`, `migrations/`, `docs/`)를 읽고 검토했습니다. 코드는 고치지 않았습니다. 설치된 리뷰·감사 도구는 쓰지 않았고, 파일이 6개뿐이라 직접 읽었습니다.

**INTENT.md를 읽지 못했습니다.** `CLAUDE.md`는 리뷰 전에 `INTENT.md`의 Not과 닫힌 조각의 「하지 않을 일」을 읽으라고 합니다. 이 저장소에는 `INTENT.md`가 없습니다. 파일시스템에서 `/home/user/claude-kit/INTENT.md`가 하나 보였지만, 이 저장소의 것인지 알 수 없는 다른 프로젝트 경로라 열지 않았습니다. 그래서 아래 결함 중 INTENT.md가 "하지 않을 일"로 적어 둔 것이 있을 수 있습니다. 해당되면 제외해 주세요.

## 결함

1. **`downgrade`가 그룹 행의 내용을 확인하지 않고 지웁니다.**
   - 자리: `migrations/versions/0007_shipping_zone.py`, `downgrade()`의 마지막 `DELETE FROM code_groups WHERE group_code = 'SHIPPING_ZONE'`(63행).
   - 까닭: `upgrade`는 운영자가 먼저 만든 그룹이 있으면 넘어갑니다(21~25행). 그런데 `downgrade`는 코드 행(`common_codes`)의 값만 검사하고(51~59행), 그룹의 `name`/`description`은 검사하지 않습니다. 운영자가 `SHIPPING_ZONE` 그룹을 다른 이름이나 설명으로 만들어 뒀다면, 리비전이 만들지 않은 행인데도 지워집니다. `docs/schema.md` 원칙 1(남의 것이 섞여 있으면 지우지 않고 멈춘다)에 어긋납니다.

2. **`upgrade`가 건너뛴 행과 직접 심은 행을 구분할 수 없어서, `downgrade`가 운영자의 행을 지울 수 있습니다.**
   - 자리: `0007`의 `upgrade()` 21~30행(건너뛰기)과 `downgrade()` 51~62행(값 비교 후 삭제).
   - 까닭: 운영자가 먼저 만든 행이 시드와 값까지 같으면, `upgrade`는 그 행을 건너뛰고 `downgrade`의 "바뀌지 않았다" 검사는 통과합니다. 결국 리비전이 만들지 않은 행을 지웁니다. 시드한 행을 가리키는 표시(출처 컬럼이나 기록)가 없어서, "이 리비전이 만든 것만 거둔다"(`docs/schema.md` 원칙 1)를 지킬 수 없는 구조입니다.

3. **`downgrade`의 검사와 삭제 사이에 잠금이 없습니다.**
   - 자리: `0007`의 `downgrade()` 36~64행.
   - 까닭: 검사(`SELECT count`)와 `DELETE`/`drop_column`이 따로 실행되고, 행이나 표 잠금이 없습니다. 운영 중 DB라면 검사 직후에 운영자가 코드를 더하거나 주문에 권역이 기록될 수 있습니다. 그러면 `DELETE`와 `drop_column`이 검사하지 않은 데이터를 지웁니다. 되돌릴 수 없는 손실입니다.

4. **`orders.shipping_zone`에 무결성 제약이 없습니다.**
   - 자리: `migrations/versions/0007_shipping_zone.py` 19행, `app/models.py` 31행, `docs/schema.md` 7행.
   - 까닭: 문서는 `shipping_zone`이 `SHIPPING_ZONE` 그룹의 코드를 "가리킨다"고 하지만 FK도 CHECK도 없는 자유 `String(30)`입니다. `common_codes`의 키가 복합키(`group_code`, `code`)라 단일 컬럼 FK는 걸 수 없고, 고정 그룹 값을 쓰는 복합 FK나 트리거도 없습니다. 존재하지 않는 코드나 비활성 코드가 주문에 저장될 수 있습니다. 운영자가 코드를 지우거나 이름을 바꿔도 주문 쪽이 어긋납니다.

5. **`downgrade`의 `used` 검사가 "코드가 실제로 존재하는 주문"과 "고아 값"을 구분하지 않습니다.**
   - 자리: `0007`의 `downgrade()` 36~38행.
   - 까닭: 4번과 이어지는 문제입니다. 제약이 없어서 시드 밖 값이 들어간 주문도 `NOT NULL`로 세어져 막힙니다. 반대로 권역을 비워 둔 주문(`NULL`)은 통과합니다. 의도한 동작일 수는 있지만, 막는 기준이 데이터 의미가 아니라 "비어 있지 않은가"뿐입니다.

6. **`CodeGroup`과 `CommonCode`의 삭제 규칙이 없습니다.**
   - 자리: `app/models.py` 20행, `migrations/versions/0006_orders.py` 19행.
   - 까닭: `ForeignKey("code_groups.group_code")`에 `ondelete`가 없고 ORM 쪽 `relationship`/`cascade`도 없습니다. 관리 화면에서 그룹을 지울 때 동작이 DB 기본값(에러)에 맡겨집니다. 코드가 주문에 쓰이는 중인지는 아무도 확인하지 않습니다.

7. **첫 리비전의 `downgrade`가 항상 예외를 던집니다.**
   - 자리: `0006_orders.py` 31~32행.
   - 까닭: `raise RuntimeError`라서 `0007` 이후에서 `0006` 아래로 내려가는 경로가 끊깁니다. 첫 리비전이라 일부러 막은 것으로 보이지만, 다른 환경(개발·테스트)에서 스키마를 비울 수단이 없어집니다. INTENT.md에 "하지 않을 일"로 있으면 제외하세요.

8. **마이그레이션 SQL을 문자열로 이어 붙입니다.**
   - 자리: `0007`의 `_values()`(14~15행)와 `upgrade`/`downgrade`의 f-string SQL.
   - 까닭: 지금은 상수(`ZONES`)만 들어가서 실제 주입 위험은 없습니다. 다만 이름에 `'`가 들어가는 값을 `ZONES`에 추가하면 SQL이 깨집니다. 낮은 우선순위입니다.

9. **모델과 리비전이 서로 다른 곳에서 정의됩니다.**
   - 자리: `app/models.py`와 `migrations/versions/0006`·`0007`.
   - 까닭: 컬럼 정의가 두 곳에 복사되어 있어 어긋나도 잡을 장치(autogenerate 비교나 테스트)가 없습니다. `app/__init__.py`는 비어 있어서 세션·트랜잭션 경계를 정의하는 코드도 저장소에 없습니다. 그래서 트랜잭션 경계는 Alembic 기본 동작에 맡겨져 있고, 검토할 애플리케이션 쪽 코드는 없었습니다.

가장 무거운 것은 1·2번입니다. 둘 다 `downgrade`가 운영자의 데이터를 지울 수 있고, 이는 저장소가 스스로 세운 원칙을 어기는 경우입니다.
