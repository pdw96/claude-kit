<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.10825619999999997 -->

`INTENT.md` 는 이 저장소에 없고, `.claude` 도 비어 있습니다. 그래서 CLAUDE.md 가 말하는 "하지 않을 일" 목록을 읽지 못했습니다. 다른 경로(`/home/user/claude-kit/INTENT.md`)에 같은 이름의 파일이 있었지만 이 저장소 것이 아니라서 근거로 쓰지 않았습니다. 아래 결함 중 그 목록에 적힌 것이 있으면 제외하세요. 로컬 전용 값(`app/main.py` 의 DB URL 등)은 올리지 않았습니다.

코드는 고치지 않았고 실행도 하지 않았습니다. 전부 코드를 읽고 판단한 것입니다.

## 결함

**1. 만료일을 승인일 기준으로 계산합니다. 문서와 시드는 신청일 기준이라고 합니다.**
- 자리: `app/services/memberships.py` 의 `approve` (`starts_on = approved_at.date()`, `valid_until = starts_on + timedelta(days=plan.duration_days)`)
- 까닭:
  - `seed/plans.sql` 은 "신청일로부터 30일, 만료일은 신청일 + 기간"이라고 안내합니다. 이 문구는 화면에도 나갑니다.
  - `docs/schema.md` 는 `applied_on` 을 회원이 창구에 온 날로 정의합니다. 코드는 `application.applied_on` 을 한 번도 읽지 않습니다.
  - 승인은 신청 다음 날이나 그 뒤에 몰아서 합니다. 주말 신청은 월요일에 승인되므로, 만료일이 안내보다 며칠 밀립니다.
  - 되돌릴 수 없는 `valid_until` 이 어긋난 채로 저장됩니다.

**2. "오늘"을 UTC 날짜로 잡습니다.**
- 자리: `app/services/memberships.py` 의 `approve` (`datetime.now(timezone.utc).date()`)
- 까닭:
  - 날짜 컬럼(`starts_on`, `valid_until`)에 UTC 달력 날짜가 들어갑니다.
  - 체육관의 현지 날짜와는 하루 어긋날 수 있습니다. 한국 시간 00:00~09:00 에 승인하면 전날로 기록됩니다.
  - 출입 단말은 `valid_until` 로 막으므로 만료가 하루 일찍 오거나 늦게 옵니다.
  - 1번을 고쳐 `applied_on` 기준으로 바꾸면 이 문제는 사라집니다.

**3. 같은 신청을 동시에 승인하면 막을 장치가 없습니다.**
- 자리: `app/services/memberships.py` 의 `approve` (`session.get(Application, ...)` 후 `status` 확인)
- 까닭:
  - 확인 후 갱신(check-then-act) 구조인데 행 잠금(`with_for_update`)이 없습니다. 조건부 UPDATE 나 낙관적 버전도 없습니다.
  - 두 요청이 모두 `pending` 을 읽고 통과할 수 있습니다.
  - 마지막 방어선은 `memberships.application_id` 의 unique 제약뿐입니다.

**4. 중복 승인 때 DB 오류를 처리하지 않습니다.**
- 자리: `app/main.py` 의 `post_approval` (`approve(...)` 후 `s.commit()`)
- 까닭:
  - `RefusedApproval` 만 잡습니다.
  - 3번의 경합에서 늦은 쪽은 `flush` 나 `commit` 에서 `IntegrityError` 가 납니다. 이 오류는 잡히지 않아 500 이 됩니다. 다른 요청과 같은 "이미 처리한 신청" 422 가 아닙니다.
  - `commit()` 이 `try` 밖에 있어서 커밋 시점 실패는 어떤 경우든 처리되지 않습니다.
  - 트랜잭션 경계가 라우트 함수에 있고, 서비스는 `flush` 까지만 합니다. 명시적 `rollback` 도 없고 `close()` 의 암묵적 롤백에 기댑니다.

**5. 상태값과 금액·기간에 DB 제약이 없습니다.**
- 자리: `app/models.py` 와 `migrations/0001_memberships.py` 의 `applications.status`, `plans.duration_days`, `plans.price`
- 까닭:
  - `status` 는 자유 문자열(`String(10)`)이고 허용 값 CHECK 나 enum 이 없습니다.
  - `duration_days` 에 `> 0` 제약이 없습니다. 0 이하이면 `memberships_period` CHECK 에 걸려 승인이 항상 500 으로 실패합니다.
  - `price` 에 `>= 0` 제약이 없습니다.

**6. `applications.status` 와 `memberships` 행의 일치를 DB 가 보장하지 않습니다.**
- 자리: `migrations/0001_memberships.py`, `app/models.py`
- 까닭:
  - `approved` 인데 회원권이 없거나, `pending` 인데 회원권이 있는 상태를 DB 가 막지 못합니다.
  - 그 정합성은 `approve` 한 함수에만 걸려 있습니다.
  - 또 `memberships.member_id` 가 `applications.member_id` 의 사본이라 둘이 달라질 수 있습니다.

**7. 한 회원의 기간이 겹치는 회원권을 막지 않습니다.**
- 자리: `memberships` 표 (`member_id` 에 제약이 없음)
- 까닭:
  - 같은 회원이 신청을 여러 번 내고 각각 승인되면 기간이 겹치는 회원권이 생깁니다.
  - 겹침이 허용되는 정책인지 문서에 없습니다.
  - 허용이 의도라면 출입 단말이 어느 행을 볼지도 정해져 있지 않습니다.

**8. `member_id` 에 외래키가 없고, 회원 표도 없습니다.**
- 자리: `applications.member_id`, `memberships.member_id`
- 까닭:
  - 존재하지 않는 회원 번호로도 신청과 승인이 됩니다.
  - 회원이 지워지거나 바뀌었을 때 참조 무결성이 없습니다.

**9. 조회 경로에 인덱스가 없습니다.**
- 자리: `migrations/0001_memberships.py`
- 까닭:
  - 단말이 쓰는 `memberships (member_id, valid_until)` 에 인덱스가 없습니다.
  - 승인 대기 목록용 `applications (status)` 와 `applications (member_id)` 에도 없습니다.
  - `plan_code` 외래키 컬럼에도 없습니다.
  - 데이터가 쌓이면 전수 조회가 됩니다.

**10. downgrade 가 데이터를 조용히 지웁니다.**
- 자리: `migrations/0001_memberships.py` 의 `downgrade`
- 까닭:
  - `memberships` 가 비어 있는지만 확인합니다.
  - `applications`(대기 중인 신청 포함)와 `plans` 는 데이터가 있어도 그대로 `drop_table` 합니다. 신청 내역이 사라집니다.
  - 검사와 삭제 사이에 잠금도 없어서, 그 사이에 들어온 승인이 검사를 지나칠 수 있습니다.

**11. 기준 데이터(plans)가 마이그레이션 체인 밖에 있고, 시드를 다시 돌릴 수 없습니다.**
- 자리: `seed/plans.sql`
- 까닭:
  - 순수 `INSERT` 라서 두 번 실행하면 PK 충돌이 납니다. `ON CONFLICT` 가 없고 트랜잭션 표시도 없습니다.
  - 마이그레이션이 아니라서 버전이 없습니다. 단가나 기간을 바꾸는 변경이 추적되지 않습니다.
  - 마이그레이션 직후 `plans` 가 빈 채로 앱이 뜰 수 있습니다. 그러면 신청을 받을 수 없고, 반대로 `plan` 이 없을 때 `approve` 는 `plan.duration_days` 에서 `AttributeError` 가 납니다.
  - `description` 에 기간 숫자(30·90·365)가 `duration_days` 와 따로 적혀 있어 이중 관리됩니다.

**12. 저장소에 alembic 설정이 없습니다.**
- 자리: 저장소 전체 (`alembic.ini`, `env.py` 없음)
- 까닭:
  - `requirements.txt` 에 alembic 이 있고 마이그레이션 파일도 있습니다. 그런데 이를 실행할 설정이 없어 `upgrade` 와 `downgrade` 를 돌릴 수 없습니다.
  - `Base.metadata` 와 마이그레이션이 일치하는지 검사할 수단도 없습니다. 지금은 손으로 같게 써 두었을 뿐입니다.

## 확인한 것 (결함 아님)
- `models.py` 와 마이그레이션의 컬럼, 제약, `server_default` 는 서로 맞습니다.
- `approved_at` 은 시간대 포함 컬럼이고 값도 UTC 로 넣습니다.
- `application_id` 의 unique 제약은 중복 승인의 마지막 방어선으로 작동하긴 합니다(3·4번 참고).

가장 먼저 볼 것은 1번과 2번(만료일이 잘못 저장됨)과 3·4번(동시 승인)입니다.
