<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.09173089999999999 -->

`POST /appointments`(`app/main.py`, `app/schemas.py`, `app/models.py`, `app/constraints.py`, `migrations/0001_appointments.py`, `docs/api.md`)에서 결함 6건을 찾았습니다. 코드는 고치지 않았습니다. 앱을 실행하거나 DB에 붙여 보지 않았고, 코드를 읽고 추론한 결과입니다.

`CLAUDE.md`는 리뷰 전에 `INTENT.md`의 Not과 닫힌 조각의 「하지 않을 일」을 읽으라고 합니다. 저장소에는 `INTENT.md`가 없고 닫힌 조각 기록도 없어서, 제외할 항목을 확인하지 못했습니다. 로컬 전용 값(`main.py`에 박힌 DB 접속 문자열)만 결함에서 뺐습니다.

## 결함

1. **공백만 있는 값이 422가 아니라 500으로 나갑니다. (높음)**
   - 자리: `app/schemas.py`의 `AppointmentIn`(`patient_name`, `department`, `phone`)과 `app/main.py`의 `post_appointment`.
   - 까닭: 스키마는 `min_length=1`만 검사하므로 `"   "`가 통과합니다. 그러면 DB의 `is_present` CHECK 제약(`appointments_*_present`)이 걸리고, 여기서 나는 `IntegrityError`를 잡는 곳이 없어 500이 됩니다.
   - 근거: `docs/api.md`는 받을 수 없는 요청은 422로 돌려주며 500은 창구 직원이 고칠 수 없다고 못 박습니다. 그 약속을 어깁니다.
   - 같은 문제: `phone`에 `" "`를 보내면 패턴 `^[0-9\- ]+$`을 통과하고 DB에서 걸려 500이 됩니다.

2. **NUL 문자(`\x00`)가 들어간 문자열이 500을 냅니다.**
   - 자리: `app/schemas.py`의 문자열 칸 전부(`patient_name`, `department`, `phone`, `memo`).
   - 까닭: pydantic은 NUL을 받지만 PostgreSQL 텍스트 칸은 받지 못합니다. psycopg가 `DataError`를 내고 이것도 처리하지 않아 500이 됩니다. 입력 검증이 DB가 받는 범위보다 넓습니다.

3. **스키마 검증과 DB 제약의 공백 기준이 다릅니다.**
   - 자리: `app/constraints.py`의 `BLANK_CHARACTERS`와 `app/schemas.py`.
   - 까닭: DB는 스페이스, 탭, 개행, 복귀, `\u3000`, `\u00a0`만 공백으로 칩니다. 스키마는 아예 검사하지 않습니다.
   - 결과: 제로폭 공백(`\u200b`)이나 `\u2003` 같은 문자만으로 된 이름은 DB 제약도 통과해 그대로 저장됩니다. 사실상 빈 값인데 받아 줍니다.
   - 입력 가장자리 공백도 다듬지 않아서 `" 홍길동 "`이 그대로 저장됩니다.

4. **`phone` 패턴이 너무 느슨합니다.**
   - 자리: `app/schemas.py`의 `phone` 패턴 `^[0-9\- ]+$`.
   - 까닭: `"-"`나 `"---"`는 패턴과 DB 제약을 모두 통과합니다. 숫자가 하나도 없어도 전화번호로 저장됩니다.

5. **422 응답의 `detail` 형식이 두 가지입니다.**
   - 자리: `app/main.py`의 `post_appointment`에서 직접 던지는 `HTTPException(422, detail="지난 날짜로는 예약하지 않는다")`.
   - 까닭: 이 경우 `detail`은 문자열입니다. 그런데 FastAPI가 스키마 검증 실패에 내는 422는 `detail`이 `[{loc, msg, type}]` 목록입니다. `docs/api.md`는 `detail`이 "칸과 까닭"을 말한다고만 쓰고 형식을 정하지 않았습니다. `detail`을 그대로 화면에 보여 주는 창구 화면은 문자열과 목록 가운데 한쪽을 제대로 못 보여 줍니다.

6. **"지난 날짜" 판정이 서버 시간대에 매인 `date.today()`입니다.**
   - 자리: `app/main.py`의 `payload.visit_on < date.today()`.
   - 까닭: 병원 현지 시간대를 명시하지 않습니다. 서버가 UTC라면 한국 기준 새벽(00~09시)에 오늘 날짜 예약이 "지난 날짜"로 거절되거나, 반대로 하루 전 날짜가 통과할 수 있습니다.

## 문서와 규약 쪽 누락 (낮음)

- `docs/api.md`가 201 본문의 키 `appointment_id`를 밝히지 않습니다.
- 깨진 JSON이나 필수 칸 누락도 422가 나오지만 이 경우는 문서에 없습니다.
- 서버 오류(500) 응답 형식은 정해진 규약이 없습니다.
- `AppointmentIn`에 `extra="forbid"`가 없어서 모르는 칸(오타 낸 `memo` 등)을 말없이 버립니다.
- 중복 예약을 막지 못합니다. 같은 요청을 재전송하면 예약이 또 만들어지고, 멱등성 키도 없습니다.

가장 먼저 손볼 것은 1번과 2번입니다. 입력 검증이 DB가 받는 범위보다 좁아야 하고, `IntegrityError`·`DataError`는 422로 바꿔 주는 편이 문서의 약속과 맞습니다.
