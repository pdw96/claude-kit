<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.10189229999999999 -->

저장소 전체를 읽었습니다. 코드는 건드리지 않았습니다. 작은 저장소라 파일을 직접 읽었고, 서브에이전트나 감사 도구는 쓰지 않았습니다. 코드를 실행하거나 DB에 붙어 보지도 않았습니다. 아래는 모두 코드를 읽고 추론한 내용입니다.

`CLAUDE.md`는 리뷰 전에 `INTENT.md`의 Not과 닫힌 조각의 「하지 않을 일」을 읽으라고 하는데, 저장소에 둘 다 없습니다(`.claude/`도 비어 있음). 그래서 제외할 항목을 확인하지 못했습니다. 코드에 박힌 DB 접속 문자열은 로컬 전용 값으로 보고 올리지 않았습니다.

## 결함

**1. 비활성 코드로도 새 환불이 만들어집니다.** (높음)
- 자리: `app/services/refunds.py`의 `_must_be_a_code`
- 이 함수는 `session.get(CommonCode, (group, code)) is None`만 확인하고 `is_active`는 보지 않습니다.
- `app/models.py`의 `CommonCode` 독스트링은 `is_active`를 끄면 "새 기록에서는 못 고른다"고 합니다. 그런데 시드의 `POINT`와 `PROMO`(`is_active=FALSE`)가 그대로 통과합니다.
- 복합 FK는 존재만 보장하므로 DB에서도 막지 못합니다.
- 삭제 대신 비활성화한다는 설계의 절반이 동작하지 않습니다.

**2. 환불을 되돌릴 방법이 없습니다.** (높음)
- 자리: `docs/schema.md` 원칙 1, `app/models.py`의 `Refund`, `app/main.py`의 `RefundIn.amount`, `refund()`
- 원칙 1은 "환불은 고치지 않고 되돌리는 환불을 새로 세운다"고 합니다.
- 그런데 `refunds_amount_positive` CHECK, `Field(gt=0)`, 서비스의 `amount <= 0` 거절이 모두 양수만 받습니다.
- 환불이 어느 환불을 되돌리는지 가리키는 열이나 종류 구분 열이 없습니다.
- `orders.refunded`를 줄이는 경로도 없어서, 잘못 낸 환불을 정정하면 한도가 영구히 줄어듭니다.

**3. `orders`의 불변식을 DB가 지키지 않습니다.** (중간)
- 자리: `app/models.py`의 `Order`, `migrations/0001_refunds.py`의 `orders` 테이블
- `refunded >= 0`, `refunded <= amount`, `amount >= 0` CHECK가 없습니다.
- 한도 검사는 `refund()` 안에만 있어서, 다른 경로나 수동 SQL이 한도를 넘기거나 음수로 만들 수 있습니다.
- `orders.refunded`는 `refunds.amount` 합계를 복제한 값입니다. 둘이 어긋나지 않게 하는 트리거나 제약이 없습니다.

**4. 환불 생성이 멱등하지 않습니다.** (중간)
- 자리: `app/main.py`의 `post_refund`, `refunds` 테이블
- 멱등 키나 요청 식별자, 유니크 제약이 없습니다.
- 클라이언트가 타임아웃 뒤에 재시도하면 한도 안에서 같은 환불이 중복 생성됩니다.
- 응답을 못 받은 상태에서 커밋만 성공한 경우를 구분할 수 없습니다.

**5. 마스터 데이터가 마이그레이션에 없습니다.** (중간)
- 자리: `migrations/0001_refunds.py`, `seed/codes.sql`
- 마이그레이션이 `common_codes`를 만들기만 하고 채우지 않습니다.
- 시드는 별도 SQL이라 적용 순서가 보장되지 않습니다. 시드 없이 배포하면 모든 환불이 "그런 코드가 없다"로 거절됩니다.
- 시드는 `ON CONFLICT` 없이 `INSERT`만 해서 재실행하면 PK 충돌로 실패합니다. 코드 값을 바꿔야 할 때도 이력이 남지 않습니다.

**6. `downgrade()`의 안전장치가 불완전합니다.** (낮음~중간)
- 자리: `migrations/0001_refunds.py`의 `downgrade`
- `refunds`가 비어 있을 때만 막습니다. `orders`에 주문이 있거나 `common_codes`에 데이터가 있어도 `drop_table`로 지웁니다. 이 테이블들은 이 마이그레이션이 만들었더라도, `refunds`가 비어 있다는 이유만으로 지워도 되는 데이터가 아닙니다.
- 검사와 삭제 사이에 잠금이 없어서 그 틈에 환불이 들어올 수 있습니다.
- 마이그레이션 실행에 필요한 `alembic.ini`와 `env.py`도 저장소에 없습니다.

**7. 환불 기록에 시각과 행위자가 없습니다.** (낮음~중간)
- 자리: `app/models.py`의 `Refund`, `refunds` 테이블
- "일어난 일은 지우지 않는다"는 원칙을 내세우면서 `created_at`과 처리자 열이 없습니다. 언제 누가 낸 환불인지 복원할 수 없습니다.
- 지우기·수정 금지도 DB 차원에서는 강제하지 않습니다. 삭제나 UPDATE를 막는 권한이나 트리거가 없습니다.

**8. 인덱스가 없습니다.** (낮음)
- 자리: `refunds.order_id`
- FK 열인데 인덱스가 없어서 주문별 환불 조회나 주문 삭제 시 FK 확인이 전체 스캔이 됩니다.

**9. 금액 타입이 모호합니다.** (낮음)
- 자리: `orders.amount`, `orders.refunded`, `refunds.amount`
- 모두 32비트 `Integer`입니다. 통화나 최소 단위가 어디에도 없고, 약 21억을 넘는 금액은 오버플로합니다.
- `RefundIn.amount`에는 상한이 없어서 큰 값은 검증이 아니라 DB 오류(500)로 드러납니다.

**10. 코드 검증과 환불 생성 사이에 틈이 있습니다.** (낮음)
- 자리: `app/services/refunds.py`의 `refund`
- 주문 행만 `FOR UPDATE`로 잠그고, 코드 행은 잠그거나 `FOR SHARE`로 읽지 않습니다.
- 검증 직후 코드가 비활성화되어도 환불이 만들어집니다.
- 결함 1을 고친 뒤에도 남는 틈입니다.

## 확인했고 문제로 보지 않은 것
- 주문 행 잠금(`with_for_update`)과 `order.refunded` 갱신, `flush`, 이후 `commit`의 흐름은 정상입니다.
- `RefusedRefund`나 예외가 나면 `session.close()`로 롤백되어 부분 반영이 남지 않습니다.
- `method_group`과 `reason_group`의 CHECK와 복합 FK 조합은 의도대로 동작합니다.
