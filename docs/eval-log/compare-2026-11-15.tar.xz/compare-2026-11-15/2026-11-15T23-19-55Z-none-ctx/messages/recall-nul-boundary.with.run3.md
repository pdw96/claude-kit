<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.09507820000000002 -->

결함은 확실한 것 하나와 덜 확실한 것 둘, 문서 쪽 하나를 찾았습니다. 코드는 고치지 않았고, 실행해서 확인하지도 않았습니다. 읽고 추론한 결과입니다.

`CLAUDE.md`는 리뷰 전에 `INTENT.md`의 Not과 닫힌 조각의 「하지 않을 일」을 읽으라고 합니다. 그런데 저장소에 `INTENT.md`가 없고 `.claude/`도 비어 있습니다. 그래서 제외 목록 없이 전체를 기준으로 봤습니다. DB 접속 문자열(`app/main.py:14`의 `postgresql+psycopg://events@localhost/events`)은 로컬 전용 값으로 보고 올리지 않았습니다.

## 결함

**1. NUL 문자(`\x00`)가 경계를 통과해 500이 됩니다.**
- 자리: `app/schemas.py`의 `RegistrationIn` 전 필드(`event_code`, `attendee_name`, `organization`, `note`), `_present`(11–15행), `app/main.py:29`의 `s.commit()`.
- 까닭:
  - 스키마는 길이와 공백만 검사하고 NUL은 거르지 않습니다. `"a\x00b"` 같은 값은 422 없이 통과합니다.
  - PostgreSQL의 `text` 칸은 NUL을 저장할 수 없습니다. psycopg가 commit 때 `DataError`를 내고, 이를 잡는 곳이 없어서 이름 없는 500이 됩니다.
  - `_present`의 docstring이 막겠다고 한 "데이터베이스까지 가면 이름 없는 실패"가 NUL에서는 그대로 생깁니다.
  - `docs/api.md:10`의 "받을 수 없는 요청은 경계에서 422, 경계를 지난 요청은 저장된다"와 응답 표(201/422뿐)를 어깁니다.
  - 가장 낮은 비용으로 낼 수 있는 외부 입력이라 우선순위가 높습니다.

**2. "비어 보이는 값" 목록이 불완전합니다.**
- 자리: `app/schemas.py:8`의 `_BLANK`와 `_present`.
- 까닭:
  - 목록에는 스페이스, 탭, 개행, 복귀, 전각 공백(`U+3000`), NBSP(`U+00A0`)만 있습니다.
  - 수직 탭(`\x0b`), 폼 피드(`\x0c`), `U+0085`, `U+2000`–`U+200A`(en/em space 등), `U+2028`/`2029`, `U+202F`, `U+205F`, `U+1680`은 빠졌습니다.
  - 폭 없는 공백(`U+200B`, `U+2060`, `U+FEFF`)도 빠졌습니다.
  - 이런 문자만 있는 `event_code`나 `attendee_name`은 422 없이 201로 저장됩니다. 눈에는 빈 값인데 `nullable=False` 칸을 채웁니다.
  - 필요한 범위는 `str.isspace()`나 유니코드 공백 범주로 잡아야 하는지 정해야 합니다.

**3. 공백만 있는 `note`는 검사하지 않습니다.**
- 자리: `app/schemas.py:25`.
- 까닭:
  - `organization`은 `Present | None`이라 공백만 있으면 422입니다. `note`는 일반 `str | None`이라 `"   "`가 그대로 저장됩니다.
  - 선택 칸인데 한쪽은 거절하고 다른 쪽은 받는 규약 불일치입니다.
  - 공백만 있는 `organization`이 null 대신 422가 되는 점도 문서에 없습니다.
  - `note`가 일부러 면제인지 `INTENT.md`가 없어 알 수 없습니다. 의도라면 문서에 적어야 합니다.

**4. 공개 계약 문서가 실제 응답을 다 말하지 않습니다.**
- 자리: `docs/api.md`의 응답 표(5–8행).
- 까닭:
  - 표에는 201과 422만 있습니다. DB 연결 실패나 commit 실패의 5xx 응답이 없고, 코드에도 그것을 다루는 곳이 없습니다(`app/main.py:26–30`).
  - 응답 본문 형식도 문서에 없습니다. 201 본문은 `{"registration_id": int}`이고, 422의 `detail`은 FastAPI 기본 형식(`loc`/`msg`/`type` 목록)입니다. "칸과 까닭을 말한다"는 말만으로는 클라이언트가 파싱할 수 없습니다.
  - 중복 신청 규약도 없습니다. `app/models.py`와 `migrations/0001_registrations.py`에 유일 제약이 없어, 같은 `(event_code, attendee_name)` 요청을 두 번 보내면 201이 두 번 나오고 행이 둘 생깁니다. 문서가 이것을 허용한다고도, 막는다고도 말하지 않습니다.

## 확인했지만 결함이 아닌 것
- `app/models.py`와 `migrations/0001_registrations.py`의 칸 정의(타입, null 허용)는 서로 일치합니다.
- `max_length`는 문자 수 기준이고 DB 칸은 `Text`라서 길이로 DB가 실패하지는 않습니다.
- `session()`은 `finally`에서 `close()`를 호출해 실패 시 롤백되고 연결이 새지 않습니다.
