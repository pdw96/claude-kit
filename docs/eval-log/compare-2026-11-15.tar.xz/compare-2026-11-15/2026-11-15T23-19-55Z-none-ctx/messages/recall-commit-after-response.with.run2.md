<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.1263593 -->

`INTENT.md`가 저장소에 없습니다. `CLAUDE.md`는 그 파일의 Not과 로컬 전용 값을 결함에서 빼라고 하는데, 뺄 목록이 없어서 제외한 항목은 없습니다. 기본 DB URL(`app/settings.py`)만 로컬 전용 값으로 보고 올리지 않았습니다. 코드는 읽기만 했고 실행하지 않았습니다. 저장소가 작아서 파일 전부를 직접 읽었고, 별도 감사 도구는 쓰지 않았습니다.

## 높음

1. **직렬화 실패를 재시도하지 않고 500으로 넘깁니다.**
   - 자리: `app/db.py:9`, `app/main.py:16-29`(`session_scope`)
   - 까닭: 엔진은 `SERIALIZABLE`인데(원칙 3), 직렬화 실패(SQLSTATE 40001)나 교착을 다시 시도하는 곳이 없습니다.
   - 같은 책을 동시에 빌리면 둘 중 하나는 정상 요청인데도 `rollback` 후 `raise`로 500을 받습니다. 원칙 3은 "하나만 선다"일 뿐이고, 실패한 쪽에는 재시도나 명확한 409/503이 필요합니다.
   - 부하가 있으면 인기 도서에서 자주 터집니다.

2. **커밋이 응답을 만든 뒤에 일어나서, 성공 응답과 실제 저장이 어긋날 수 있습니다.**
   - 자리: `app/main.py:22-24`, `post_loan`의 반환(`app/main.py:42`)
   - 까닭: `commit()`이 yield 의존성의 종료 단계에 있습니다. `SERIALIZABLE`에서는 직렬화 실패가 `flush` 때가 아니라 `COMMIT` 때 나는 일이 흔합니다.
   - `lend`가 `flush()`로 얻은 `loan_id`와 줄어든 `available_copies`를 담아 201을 만든 뒤에야 커밋이 실패할 수 있습니다.
   - 이 FastAPI 버전에서 의존성 종료 코드가 응답 전송 전에 도는지 후에 도는지는 확인하지 못했습니다.
     - 응답 전송 후라면, 클라이언트는 201과 `loan_id`를 받았는데 대출이 저장되지 않습니다.
     - 응답 전송 전이라면 500이 됩니다.
   - 어느 쪽이든 커밋은 서비스나 엔드포인트 안에서 명시적으로 하고, 성공 응답은 그 뒤에 만드는 편이 안전합니다.

3. **반납 경로가 없어서 `available_copies`가 되돌아오지 않습니다.**
   - 자리: `app/services/loans.py`(`lend`만 있음), `docs/schema.md:7`, `app/models.py:38`
   - 까닭: 문서는 "반납하면 `returned_on`이 찬다"고 하지만 `returned_on`을 쓰는 코드도, `available_copies`를 올리는 코드도 없습니다.
   - 대출할 때마다 권수만 줄어서, 모두 반납해도 0까지 내려가면 그 책은 영영 빌릴 수 없게 됩니다.
   - 반납을 구현할 때도 원칙 1(대출 줄과 권수는 함께 움직인다)을 같은 트랜잭션으로 지켜야 합니다.

## 중간

4. **`available_copies`는 파생값인데 대출 줄과 맞는지 지키는 장치가 없습니다.**
   - 자리: `app/models.py:26`, `app/models.py:20`
   - 까닭: 이 값은 "총 권수 − 반납 안 된 대출 수"인데 `total_copies` 열이 없고, 상한 CHECK도 없고, 대출 줄과 대조하는 제약이나 트리거도 없습니다.
   - `CHECK >= 0`은 음수만 막습니다. 수동 보정, 반납 버그, 누락된 갱신이 있으면 조용히 어긋나고, 이를 찾아 고칠 기준값(총 권수)도 없습니다.

5. **마이그레이션 `downgrade`가 대출 기록만 지키고 회원·도서 데이터는 그냥 지웁니다.**
   - 자리: `migrations/0001_initial.py:39-46`
   - 까닭: `loans`가 비어 있을 때만 되돌리게 막았지만, 그 뒤 `members`와 `books`는 데이터가 있어도 `drop_table`합니다.
   - "지우면 되살릴 길이 없다"는 같은 이유가 회원·도서에도 해당합니다. 문서가 회원을 탈퇴해도 지우지 않는다고 한 것과도 어긋납니다.
   - 검사(`SELECT EXISTS`)와 `drop_table` 사이에 대출이 끼어들 틈도 있습니다.

6. **Alembic 환경 파일이 없어서 마이그레이션을 실행할 수 없는 것으로 보입니다.**
   - 자리: `migrations/`(`0001_initial.py`만 있음)
   - 까닭: `env.py`, `alembic.ini`, `script.py.mako`가 없습니다. `revision`과 `down_revision`은 직접 적혀 있지만 이를 돌릴 설정이 없습니다.
   - 모델과 마이그레이션이 어긋나는지 잡아 주는 `target_metadata`(autogenerate 대조)도 연결되어 있지 않습니다.

7. **`loaned_on`을 클라이언트가 정합니다.**
   - 자리: `app/schemas.py:9`, `app/services/loans.py:41-46`
   - 까닭: 대출일을 서버 시각이 아니라 요청 본문에서 받아 그대로 저장하고, `due_on`도 그 값으로 계산합니다.
   - 과거나 미래 날짜로 대출 기록과 연체 판단을 마음대로 만들 수 있습니다. 허용 범위 검사도 없습니다.

## 낮음

8. **`loan_days`와 날짜 열에 값 범위 제약이 없습니다.**
   - 자리: `app/models.py:25`, `app/models.py:31`, `migrations/0001_initial.py:23`, `migrations/0001_initial.py:35`
   - 까닭: `loan_days`에 `> 0` 같은 CHECK가 없습니다. 0 이하 값이 들어간 도서를 빌리면 `loans_due_after_loan` 위반으로 `IntegrityError`가 나고, `RefusedLoan`(422)이 아니라 500이 됩니다.
   - `returned_on >= loaned_on` 제약도 없습니다.

9. **`loans`의 외래키 열에 인덱스가 없습니다.**
   - 자리: `app/models.py:34-35`, `migrations/0001_initial.py:30-31`
   - 까닭: PostgreSQL은 FK 열에 인덱스를 자동으로 만들지 않습니다. 회원별 대출 조회, 책별 미반납 조회, 반납 처리 같은 일이 `loans` 전체 스캔이 됩니다.

10. **같은 회원이 같은 책을 중복 대출하는 것을 막지 않습니다.**
    - 자리: `app/models.py:29-38`
    - 까닭: `(book_id, member_id)`에 `returned_on IS NULL` 부분 유니크도, 회원별 대출 한도도 없습니다. 재고가 남아 있으면 같은 회원이 같은 책을 여러 권 빌릴 수 있습니다. 이것이 의도된 정책이라면 무시해도 됩니다.

11. **재고 갱신을 DB 쪽 식으로 하지 않고 `SERIALIZABLE`에만 기댑니다.**
    - 자리: `app/services/loans.py:37-40`
    - 까닭: "읽고 → 확인하고 → 파이썬에서 계산한 값으로 `UPDATE`"하는 구조(`book.available_copies -= 1`)입니다. 격리 수준이 `app/db.py`의 엔진 하나에만 걸려 있어서, 다른 엔진이나 세션, 스크립트가 이 서비스를 쓰면 곧바로 갱신 손실이 납니다.
    - `UPDATE ... SET available_copies = available_copies - 1 WHERE available_copies > 0`나 `FOR UPDATE`로 서비스 자체가 안전하게 만들 수 있습니다. 지금은 `CHECK`가 마지막 방어선입니다.

가장 먼저 볼 것은 1~3번입니다. 1번과 2번은 같은 `SERIALIZABLE` 선택에서 나온 문제이고, 3번은 기능 자체가 빠진 것입니다.
