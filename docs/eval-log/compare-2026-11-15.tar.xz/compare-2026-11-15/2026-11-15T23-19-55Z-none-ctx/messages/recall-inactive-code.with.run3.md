<!-- 플러그인 없음 + 맥락 · 맞힘 · 떴는가 False · 비용 0.1060011 -->

`INTENT.md`와 "닫힌 조각"은 저장소에 없습니다. `CLAUDE.md`가 그 둘을 읽으라고 하지만 `find`로 찾아도 나오지 않았습니다. 그래서 제외할 항목은 없다고 보고, `localhost` DB 주소 같은 로컬 전용 값만 뺐습니다. 코드는 고치지 않았고, 정적 읽기만 했습니다. 실행이나 DB 검증은 하지 않았습니다.

## 결함

**1. 비활성 코드로 새 환불을 세울 수 있습니다.**
- 자리: `app/services/refunds.py`의 `_must_be_a_code`
- 까닭: `session.get(CommonCode, ...) is None`만 확인하고 `is_active`는 보지 않습니다. `models.py` 독스트링은 비활성 코드를 "새 기록에서는 못 고른다"고 정했습니다. 그런데 시드의 `POINT`와 `PROMO`(`is_active=FALSE`)로도 환불이 만들어집니다. DB의 FK와 CHECK도 활성 여부를 막지 않습니다.

**2. 환불을 되돌리는 길이 없고, 원칙 1과 모델이 어긋납니다.**
- 자리: `docs/schema.md` 원칙 1, `app/models.py`의 `Refund`, `RefundIn`과 `refund()`의 `amount > 0` 검사, `refunds_amount_positive` CHECK
- 까닭: 문서는 "되돌리는 환불을 새로 세운다"고 합니다. 하지만 금액은 API, 서비스, DB 모두 양수만 받습니다. 되돌림 행을 표현할 부호나 종류 칸이 없습니다. 원 환불을 가리키는 칸(`reverses_id` 같은 것)도 없습니다. 되돌림을 만들어도 `orders.refunded`를 줄이는 경로가 없어 환불 한도가 복구되지 않습니다.

**3. `orders.refunded`는 파생 값인데 DB가 정합을 지키지 않습니다.**
- 자리: `app/models.py`의 `Order`, `migrations/0001_refunds.py`의 `orders` 표
- 까닭: `refunded`는 `SUM(refunds.amount)`와 같아야 하는 중복 값입니다. 같은 값을 보장하는 트리거나 제약이 없습니다. `CHECK (refunded >= 0 AND refunded <= amount)`와 `CHECK (amount >= 0)`도 없습니다. 한도는 애플리케이션 코드(`refund()`)만 지킵니다. 다른 경로로 쓰거나 수동 보정하면 한도를 넘거나 합계와 어긋납니다.

**4. 같은 요청을 다시 보내면 환불이 중복됩니다.**
- 자리: `app/main.py`의 `post_refund`, `refunds` 표
- 까닭: 멱등 키가 없고, `(order_id, ...)` 유일 제약도 없습니다. 클라이언트가 타임아웃 뒤에 재시도하면, 한도가 남아 있는 한 환불이 두 번 나갑니다. 금액이 같은 두 번째 요청도 한도 검사만 통과하면 생성됩니다.

**5. 코드 검증이 락 밖에서 이뤄집니다.**
- 자리: `app/services/refunds.py`의 `refund()`, 락은 `session.get(Order, ..., with_for_update=True)`
- 까닭: 주문 행에만 락이 걸립니다. `common_codes` 행은 일반 `SELECT`로 읽습니다. 검사한 뒤 커밋하기 전에 코드를 비활성화하는 쪽과 경합해도 막히지 않습니다. 1번을 고쳐도 이 경합은 남습니다. 비활성화가 커밋돼도 이미 읽은 요청은 그대로 진행합니다.

**6. DB 무결성 오류가 처리되지 않습니다.**
- 자리: `app/main.py`의 `post_refund`
- 까닭: `RefusedRefund`만 잡습니다. `flush()`나 `commit()`에서 나는 `IntegrityError`나 `DBAPIError`는 그대로 500이 됩니다. 롤백은 `session.close()`에 맡기는데, 이는 암묵적입니다. `s.commit()`이 `try` 밖에 있어서 커밋 실패는 어디서도 다뤄지지 않습니다.

**7. `downgrade`가 데이터를 지우는데 검사는 일부만 합니다.**
- 자리: `migrations/0001_refunds.py`의 `downgrade`
- 까닭: `refunds`가 비었는지만 확인합니다. 그다음 `orders`와 `common_codes`를 그대로 `drop_table`합니다. 주문이 있어도, 공통코드를 운영에서 편집했어도 지워집니다. 원칙 2("공통코드는 지우지 않는다")에도 어긋납니다. 또 `refunds`가 비어 있어도 `orders.refunded`가 0이 아닌 행(3번처럼 어긋난 경우)을 확인하지 않습니다.

**8. 마이그레이션이 공통코드를 채우지 않고, 시드가 재실행에 약하며, 연결되어 있지도 않습니다.**
- 자리: `seed/codes.sql`, `migrations/0001_refunds.py`
- 까닭: 코드 시드가 마이그레이션 밖에 있고, 어디서도 호출되지 않습니다. 시드를 넣지 않으면 모든 환불이 "그런 코드가 없다"로 거절됩니다. 시드는 `ON CONFLICT`가 없는 `INSERT`라서 두 번 돌리면 PK 충돌로 실패합니다. 코드 이름이나 활성 상태를 바꿔 다시 반영하는 방법도 없습니다.

**9. Alembic을 실행할 구성이 없습니다.**
- 자리: `migrations/`
- 까닭: `migrations/`에 `0001_refunds.py`만 있고 `env.py`, `script.py.mako`, `alembic.ini`가 없습니다. `alembic upgrade`를 그대로 돌릴 수 없습니다. 모델 메타데이터와 마이그레이션이 일치하는지(autogenerate 비교)도 검증할 수 없습니다. `models.py`와 마이그레이션에 같은 스키마가 이중으로 적혀 있어 어긋날 위험이 있습니다.

**10. 공통코드 삭제 금지가 DB에서 강제되지 않습니다.**
- 자리: `app/models.py`의 `CommonCode`, `migrations/0001_refunds.py`
- 까닭: 삭제 금지는 독스트링에만 있습니다. 환불에서 쓰인 코드는 FK로 막힙니다. 하지만 아직 쓰이지 않은 코드는 `DELETE`할 수 있습니다. 그 뒤 같은 코드를 다른 뜻으로 다시 만들면 옛 기록의 뜻이 바뀝니다. `refunds`의 FK에는 `ondelete`도 지정돼 있지 않습니다.

**11. 환불 기록에 시각과 행위자가 없고, 조회용 인덱스도 없습니다.**
- 자리: `app/models.py`의 `Refund`, 마이그레이션의 `refunds` 표
- 까닭: 원칙 1은 일어난 일을 남기라고 합니다. 그런데 `created_at`도, 처리자도, 승인 번호도 없어 언제 누가 한 환불인지 알 수 없습니다. `order_id`에 인덱스가 없어 주문별 환불을 합산하거나 대조하려면 전체를 훑습니다. 3번의 정합을 검증하려 할 때 특히 그렇습니다.

## 참고 (결함 확정은 아님)
- `Integer`(32비트)로 금액을 저장합니다. 통화 단위(원/센트)가 정해져 있지 않고, 주문 금액이 `int` 한계를 넘는 경우를 `amount` 상한이나 `BigInteger`로 다루지 않습니다.
- `requirements.txt`의 `FastAPI==0.141.1`은 제가 확인하지 못한 버전입니다. 실제로 존재하는 버전인지 설치로 확인하는 편이 안전합니다.
