<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.09360170000000001 -->

코드는 수정하지 않았습니다. 저장소는 파일 5개(`app/auth.py`, `app/routes.py`, `docker-compose.yml`, `.env.example`, `README.md`)로 작아서 전부 직접 읽었습니다. `review-pr` 스킬은 실행했지만, 하위 리뷰 에이전트는 따로 띄우지 않았습니다.

## 결함

**치명적**
1. **`app/routes.py:22-24`, `admin_users()`: 인증이 전혀 없습니다.**
   - `/admin/users`에 `Depends(require_admin)`이 빠져 있어서 토큰 없이 누구나 전체 사용자 목록을 읽을 수 있습니다.
   - 같은 `/admin/*` 경로인 `admin_settings`와 `set_role`은 `require_admin`을 쓰고 있어서, 이 경로만 빠진 것으로 보입니다.

**중요**
2. **`app/auth.py:7`, `current_user()`: 토큰 검증 코드가 저장소에 없습니다.**
   - `decode`는 정의도 import도 없습니다. 그대로 실행하면 `NameError`가 나서, 인증이 필요한 모든 경로가 500을 반환합니다.
   - 서명 검증, 만료 확인, 알고리즘 고정이 이 함수 안에서 이루어지는지 확인할 수 없습니다. 실제 구현이 서명을 검증하지 않으면 인증 전체가 우회됩니다.
   - `.env.example`에는 `SESSION_SECRET`이 있지만 코드 어디에서도 쓰지 않습니다. 서명 키가 어디서 오는지 알 수 없습니다.
3. **`app/routes.py:27-29`, `set_role()`: `role` 값을 검증하지 않습니다.**
   - 임의 문자열이 그대로 `db.users.set_role`에 들어갑니다. 허용 목록(enum)이 없어서 오타나 예상 밖의 역할이 저장될 수 있습니다.
   - 관리자 계정을 스스로 강등하거나 마지막 관리자를 제거하는 것도 막지 못합니다.
   - 역할 변경 감사 로그가 없습니다.
4. **`app/auth.py:4-7`: 잘못된 토큰의 오류 처리가 없습니다.**
   - `decode`가 예외를 던지면 401이 아니라 500이 나갑니다. 오류 내용이 새거나 인증 실패 처리가 일관되지 않을 수 있습니다.
   - `startswith("Bearer ")`는 대소문자를 구분합니다. 이는 RFC 7235와 어긋나지만, 보안 결함이라기보다 호환성 문제입니다.

**낮음 / 확인 필요**
5. **`app/routes.py:9`: `DATABASE_URL`을 import 시점에 `os.environ[...]`으로 읽습니다.**
   - 값이 없으면 `KeyError`로 앱이 시작되지 않습니다. 시크릿이 코드에 박혀 있지는 않아 안전한 방향입니다.
   - 다만 모듈 전역에 올려 두므로 오류 메시지나 디버그 덤프에 접속 문자열이 노출될 여지가 있습니다.
6. **`app/routes.py`: `db`가 정의되지 않았습니다.** 모든 핸들러가 `NameError`를 냅니다. 이 저장소에는 `app/main.py`도 없어서, 라우터가 어떻게 마운트되는지, CORS나 전역 미들웨어가 있는지 검증하지 못했습니다.

## 결함이 아닌 것
- **`docker-compose.yml`의 `POSTGRES_PASSWORD: devpassword`**: 로컬 개발용 DB이고 `127.0.0.1`에만 바인딩되어 있습니다. README도 프로덕션 접속 정보는 `DATABASE_URL`로 주입한다고 설명합니다. 실제 시크릿 유출로 보지 않습니다.
- **`.env.example`**: `CHANGEME`와 안내 문구뿐인 플레이스홀더입니다.
- **`list_orders`**: `user.id`로 범위를 제한해서 다른 사용자의 주문을 읽을 수 없습니다.

## 권고
1. `admin_users`에 `Depends(require_admin)`을 추가하세요.
2. `decode`의 실제 구현을 확인하세요. 서명, 만료, 알고리즘 고정을 검증해야 하고, 실패하면 401을 반환해야 합니다.
3. `set_role`의 `role`은 enum으로 제한하세요.
4. 모든 `/admin` 경로에 인증이 걸려 있는지 보장하세요. 라우터 단위 의존성이나 테스트가 방법입니다.
