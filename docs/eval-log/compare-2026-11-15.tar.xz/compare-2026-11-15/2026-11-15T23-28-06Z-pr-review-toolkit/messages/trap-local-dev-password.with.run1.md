<!-- pr-review-toolkit · 맞힘 · 떴는가 True · 비용 0.26539960000000007 -->

저장소 전체를 검토해 보안 결함 두 건과 보강 사항을 찾았습니다. `pr-review-toolkit`의 `code-reviewer`와 `silent-failure-hunter` 에이전트를 썼고, 코드는 고치지 않았습니다.

저장소는 `app/auth.py`, `app/routes.py`, `docker-compose.yml`, `.env.example`, `README.md`로 작습니다. 다만 `app/`에는 `main.py`와 `db`, `decode` 정의가 없고, `.claude/`에는 빈 `.cc-writes/` 폴더만 있습니다.

## 결함

**1. 관리자 엔드포인트에 인증·인가가 없음 (높음)**
- 자리: `app/routes.py`, `admin_users` 함수, 22–24줄 (`GET /admin/users`)
- 까닭: 같은 `/admin/*` 경로의 `admin_settings`와 `set_role`은 `Depends(require_admin)`을 쓰는데, 이 함수에만 의존성이 없습니다. 로그인하지 않은 사람도 `db.users.all()`로 전체 사용자 목록을 받을 수 있습니다. 그 결과로 `set_role`에 쓸 사용자 ID와 역할 정보를 알아내 권한 상승 시도에 쓸 수 있습니다.

**2. 토큰 검증 로직이 코드에 없어 인증의 안전성을 확인할 수 없음 (중간~높음)**
- 자리: `app/auth.py`, `current_user` 함수, 7줄 (`return decode(...)`)와 `require_admin` 함수, 11줄
- 까닭: `decode`는 정의도 import도 없습니다. 지금은 `Bearer` 헤더가 있는 요청이 `NameError`로 500이 되고, 인증이 필요한 라우트가 모두 동작하지 않습니다.
- 더 큰 위험: `require_admin`은 디코딩된 토큰의 `user.role`을 그대로 믿습니다. 나중에 연결될 `decode`가 서명, 만료, 알고리즘(`alg=none` 거부)을 검증하지 않으면 누구나 `role: admin` 토큰을 만들어 관리자 권한을 얻습니다.
- 디코딩 오류를 401로 바꿔 주는 처리도 없습니다. 오류가 500으로 나가고, `decode`가 `None`을 돌려주면 `AttributeError`가 납니다.
- 역할을 DB에서 다시 확인하지 않아서, 강등된 관리자도 토큰이 만료될 때까지 관리자 권한을 유지합니다.

## 보강 사항 (낮음)

**3. 역할 값 검증이 없음**
- 자리: `app/routes.py`, `set_role` 함수, 27–29줄
- 까닭: `role: str`이 쿼리 문자열로 들어오고 허용 목록 검사가 없어서 임의의 문자열이 저장됩니다. 관리자가 자기 역할을 바꾸거나 마지막 관리자를 강등하는 것도 막지 않습니다. `require_admin`이 제대로 동작하는 한 관리자만 도달할 수 있습니다.

**4. 시크릿 설정 검증이 없음**
- 자리: `.env.example` 2행(`SESSION_SECRET`), `app/routes.py` 9행
- 까닭: `SESSION_SECRET`을 읽거나 검증하는 코드가 없습니다. 나중에 `os.getenv("SESSION_SECRET", "기본값")` 같은 기본값이 들어가면 위험합니다. `.env.example`의 `DATABASE_URL`에는 `CHANGEME`가 들어 있는데, 이 값을 거부하는 시작 시 검사도 없습니다.
- `DATABASE_URL`은 환경변수에서 읽고, 없으면 import 시점에 `KeyError`로 실패합니다. 이건 안전한 방향이라 괜찮습니다.

## 결함이 아닌 것

- `docker-compose.yml` 7–8행의 `devpassword`는 하드코딩된 값이지만 로컬 개발용입니다. 포트가 `127.0.0.1`에만 바인딩되어 있고 DB 이름도 `shop_dev`이며, README에 따르면 프로덕션 정보는 `DATABASE_URL`로 주입됩니다. 다만 프로덕션에서 같은 비밀번호를 쓰지 않도록 주의해야 합니다.
- `.env.example`에는 자리표시자만 있고 실제 시크릿은 없습니다.

## 보안 외 참고

`routes.py`의 `db`도 정의되지 않았습니다. 보안 결함은 아니고, 이대로면 모든 핸들러가 `NameError`를 냅니다.
