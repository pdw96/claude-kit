<!-- pr-review-toolkit · 못 맞힘 · 떴는가 True · 비용 0.7252792 -->

# 결함 목록 (코드는 수정하지 않음)

`pr-review-toolkit` 의 code-reviewer, silent-failure-hunter, comment-analyzer, pr-test-analyzer 네 에이전트를 돌리고, 제가 직접 읽은 내용과 합쳤습니다. 모든 경로는 저장소 루트 기준입니다. pytest는 실행하지 못했고, 아래는 모두 읽어서 판단한 내용입니다.

## A. 규칙·결정을 어기는 결함

1. **SMS 발송 구현** (확신 높음)
   - 자리: `app/reminder/sms.py` `send_sms`(10–13행), `app/reminder/run.py` `remind` 12행, `pyproject.toml` 의 `httpx`
   - 까닭: `docs/slices/2-dues-reminder/requirements.md` 하지 않을 일 1은 문자 발송을 금지합니다. 근거는 건당 비용과 전화번호 사용 동의를 받지 않았다는 점입니다. 그런데 매달 5일 미납자 전원의 전화번호가 외부 SMS API로 나갑니다.
   - 설계 `design.md`와 `master-plan.md` 범위 변경 표에도 SMS 항목이 없습니다. `sms.py` 11행 주석("이메일을 잘 안 읽는 회원이 있어 문자로도 보낸다")은 결정을 근거 없이 뒤집습니다.
   - `httpx` 의존성은 이 기능에만 쓰입니다.

2. **테스트가 SMS 위반을 가림**
   - 자리: `tests/test_remind.py` 7–8행, `test_unpaid_members_get_one_reminder_each`
   - 까닭: `send_sms`를 아무 일도 안 하는 함수로 바꿔 놓고 호출 여부를 확인하지 않습니다. 금지된 채널이 있어도 테스트가 통과합니다.

3. **PRD.md가 폐기된 결정을 담고 있고 코드와 모순됨**
   - 자리: `PRD.md` 7행(성공 기준 "화면 배너"), 10행(하지 않을 일 "이메일 발송")
   - 까닭: `docs/master-plan.md` 22행에 따르면 2026-08-03에 알림이 배너에서 이메일로 바뀌었습니다. 그런데 PRD는 갱신되지 않았습니다.
   - 그 결과 코드는 PRD의 "하지 않을 일"을 어기고, PRD의 성공 기준(배너)은 어디에도 구현돼 있지 않습니다.
   - `master-plan.md`의 "가리키는 문서" 표와 `CLAUDE.md`에 PRD가 없어 어느 문서가 우선인지 정해져 있지 않습니다.

4. **`master-plan.md` 범위 변경 기록이 실제와 안 맞음**
   - 자리: `docs/master-plan.md` 22행 "`INTENT.md` What 을 고쳤다"
   - 까닭: `INTENT.md` What에는 "미납자 알림"만 있고 채널이 적혀 있지 않습니다. 고친 흔적을 확인할 수 없습니다.

5. **조각 1의 "CSV 내보내기 안 함" 결정을 조각 2가 기록 없이 넘어섬** (경계 사례)
   - 자리: `app/main.py` `download_unpaid`(37–44행), `app/reminder/export.py` `unpaid_csv`, `docs/slices/1-members/requirements.md` 하지 않을 일 1
   - 까닭: 조각 1은 "명부는 화면에서만 본다"고 했습니다. 미납자 CSV는 이름·이메일을 담은 명부의 일부입니다.
   - 조각 2 성공 기준에 CSV가 있으니 기능 자체는 맞습니다. 문제는 `design.md` ④가 "결정 없음 — 대안이 없었다"로 적었고 범위 변경 표에도 기록이 없다는 점입니다.

6. **인증 없는 `/admin/*`로 사실상 자가 가입이 가능함** (확신 중간)
   - 자리: `app/main.py` `register`(16–20행), `roster`, `record_payment`, `download_unpaid`
   - 까닭: 13행 주석은 `INTENT.md` Not 2(회원 자가 가입 화면 금지)를 지킨다고 하지만, 인증이 없어 누구나 `POST /admin/members`로 등록할 수 있습니다.
   - 같은 이유로 이메일이 담긴 미납자 CSV도 누구나 내려받습니다.

## B. 설계의 "보장"을 코드가 못 지키는 결함

7. **같은 달 재실행 시 중복 발송**
   - 자리: `app/reminder/run.py` `remind` 9–13행, `main` 16–18행
   - 까닭: 이미 보냈는지 기록하지 않고 납부 여부로만 대상을 정합니다. `design.md` ②의 "미납자 한 명에 달마다 이메일 한 통"이 지켜지지 않습니다.
   - 크론에 동시 실행 방지(`flock` 등)도 없습니다(`deploy/crontab`).
   - 발송 기록 테이블을 두려면 스키마 변경이라, `CLAUDE.md` 앵커볼트에 따라 먼저 물어봐야 합니다.

8. **한 명이 실패하면 나머지 전원이 알림을 못 받음**
   - 자리: `app/reminder/run.py` 10–12행, `app/reminder/email.py` 12–13행, `app/reminder/sms.py` 13행
   - 까닭: 성공 기준 "미납자 전원에게 이메일이 간다"를 어깁니다.
     - 예외 처리가 없습니다.
     - 크론 환경에서 `SMS_TOKEN`이 없으면 첫 사람 이메일 직후 `KeyError`가 나서 루프가 멈춥니다.
     - `smtplib.SMTP("localhost")`에는 타임아웃이 없습니다.
   - 중간에 멈춘 뒤 재실행하면 앞사람은 중복, 뒷사람은 누락됩니다.
   - 이메일은 갔는데 SMS가 실패한 사람도 재실행 때 다시 받습니다.

9. **`remind` 반환값과 종료 코드가 실제 결과를 반영하지 않음**
   - 자리: `app/reminder/run.py` 13행(`len(targets)`), `main`
   - 까닭: 발송 성공 여부와 무관하게 대상 수를 돌려줍니다. 크론이 성공과 실패를 구분하지 못합니다.

10. **`month` 형식을 검증하지 않음**
    - 자리: `app/main.py` `record_payment`(31–34행), `download_unpaid`(38–44행, 43행 헤더)
    - 까닭: `2026-8`처럼 적으면 크론이 쓰는 `2026-08`과 달라 납부자가 미납자로 분류되어 이메일을 받습니다. 엉뚱한 달의 CSV는 오류 없이 전원 미납으로 나옵니다.
    - `month`는 `Content-Disposition` 헤더에도 그대로 들어갑니다.

11. **납부 중복·없는 회원 입력 처리 없음**
    - 자리: `app/main.py` `record_payment`, `app/db.py`
    - 까닭: 같은 `(member_id, month)`를 두 번 기록하면 기본키 충돌로 500 오류가 납니다. SQLite 외래키 검사는 켜져 있지 않아 없는 `member_id`는 그대로 저장됩니다.

## C. 테스트와 문서의 공백

12. **미납자 CSV 테스트가 없음**
    - 자리: `app/reminder/export.py`, `app/main.py` `download_unpaid`, `app/members.py` `load`
    - 까닭: 성공 기준 2(CSV 내려받기)를 검증하는 테스트가 없습니다. `design.md` ⑤ 검증 계획도 알림 수만 적어 CSV가 빠졌습니다.

13. **이메일 내용과 `main()` 경로 미검증**
    - 자리: `tests/test_remind.py` 7행
    - 까닭: `send_email`을 통째로 모킹해서 수신자, 본문, "계좌 번호 없음"(하지 않을 일 2)을 검증하지 못합니다.
    - 또한 `remind()`만 호출해서 `main()`의 달 계산과 `load()`의 DB 연결은 실행되지 않습니다.

14. **`design.md`가 실제 동작과 다름**
    - 자리: `docs/slices/2-dues-reminder/design.md` ②, ④, ⑤
    - 까닭:
      - "보장하지 않는 것"이 비어 있어 재실행 중복과 실패 시 동작이 정의돼 있지 않습니다.
      - ④의 "결정 없음"이 사실이 아닙니다. 중복 방지 방식, SMS, CSV는 모두 결정이 필요했습니다.

15. **테스트 실행 환경 문제** (확신 낮음)
    - 자리: `app/db.py` 20–21행, `pyproject.toml`, `tests/`
    - 까닭: import만 해도 상대경로 `club.db`가 만들어지고 `create_all`이 실행됩니다. 테스트 DB 격리가 없습니다.
    - 또한 `pyproject.toml`에 pytest 경로 설정이 없고 `conftest.py`도 없어, README의 `pytest`가 `from app...` import에서 실패할 수 있습니다. 실행해서 확인하지는 못했습니다.

16. **`README.md` 누락**
    - 자리: `README.md` 6행
    - 까닭: 알림이 이메일이라는 점과 SMTP가 `localhost` 고정이라는 점, 필요한 환경변수(`SMS_TOKEN`)가 적혀 있지 않습니다. 1번이 정리되면 `SMS_TOKEN` 항목은 사라집니다.

## 지켜지는 것
- `INTENT.md` Not 1(결제 대행 없음)
- 조각 2 하지 않을 일 2(알림에 계좌 번호 없음)와 3(납부 자동 확인 없음)
- 앵커볼트 스키마: 조각 1 설계와 맞고(금액 열 없음, 복합 PK) 변경 이력은 없습니다. 다만 git 커밋이 없어 바뀌었는지는 확인하지 못했습니다.
- "요구사항과 설계를 한 PR로 낸 뒤 구현" 규칙도 커밋이 없어 확인하지 못했습니다.

가장 먼저 볼 것은 1번, 7번, 8번입니다.
