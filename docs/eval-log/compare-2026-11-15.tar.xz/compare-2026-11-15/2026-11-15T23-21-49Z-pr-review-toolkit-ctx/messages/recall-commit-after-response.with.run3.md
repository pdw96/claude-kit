<!-- pr-review-toolkit + 맥락 · 맞힘 · 떴는가 True · 비용 0.48687769999999997 -->

두 리뷰어(`pr-review-toolkit:code-reviewer`, `silent-failure-hunter`)의 결과를 합쳤고, 코드는 고치지 않았습니다. FastAPI를 설치하지 않았고 실제로 띄워 보지도 않았습니다. 그래서 1번은 FastAPI 버전별 동작에 대한 지식에 기댄 판단입니다. 0.141.1에서 실제로 그런지는 직접 확인하지 못했습니다.

`CLAUDE.md`가 읽으라고 한 `INTENT.md`는 저장소에 없고 `.claude/`도 비어 있습니다. 그래서 제외할 「하지 않을 일」 항목 없이 전부 올렸습니다. `settings.py`의 로컬 기본 DB URL은 결함으로 올리지 않았습니다.

## 결함 목록

**1. commit이 응답을 보낸 뒤에 실행될 가능성이 큽니다. commit이 실패해도 클라이언트는 201을 받습니다.**
- 자리: `app/main.py`의 `session_scope` 24줄(`session.commit()`)과 `post_loan` 33줄(`Depends(session_scope)`).
- 까닭: commit이 `yield` 뒤 정리 단계에 있습니다. FastAPI 0.118 이후에는 기본 scope인 request의 `yield` 의존성이 응답을 보낸 뒤에 정리됩니다. 고정 버전은 0.141.1입니다.
- SERIALIZABLE의 직렬화 실패(40001)는 COMMIT 시점에 나는 경우가 많습니다. 그러면 클라이언트는 `loan_id`가 든 201을 받지만 DB에는 대출이 없고 `available_copies`도 줄지 않았습니다.
- 응답 값은 `flush()`만 거친, 커밋되지 않은 값입니다(`app/services/loans.py` 48줄). 앱에는 로깅도 없습니다.
- docs/schema.md 원칙 1이 클라이언트 쪽에서 깨집니다.

**2. 직렬화 실패(40001)를 변환하지도 재시도하지도 않습니다.**
- 자리: `app/services/loans.py`의 `lend` 40줄과 48줄, `app/main.py`의 `post_loan` 40~41줄, `app/db.py` 9줄.
- 까닭: 같은 책을 동시에 빌리면 `UPDATE`나 `flush`에서 직렬화 오류가 납니다. `post_loan`은 `RefusedLoan`만 잡으므로 이 오류는 그냥 500이 됩니다.
- 정상적인 동시성 경합이 서버 오류와 구분되지 않습니다. 재시도 루프도 409/503 같은 응답도 없습니다.
- `IntegrityError`(CHECK 위반)도 같은 경로로 500이 됩니다.
- 재시도하려면 commit이 루프 안에 있어야 합니다. 그래서 1번과 함께 풀어야 합니다.

**3. Alembic 설정이 없어 마이그레이션을 실행할 수 없습니다.**
- 자리: 저장소 최상위와 `migrations/`.
- 까닭: `alembic.ini`, `env.py`, `script.py.mako`가 없습니다. 리비전 파일이 `versions/`가 아니라 `migrations/0001_initial.py`에 바로 있습니다.
- `Base.metadata`를 연결하는 곳도 없어 autogenerate와 모델·DB 불일치 검사를 할 수 없습니다.

**4. 같은 회원이 같은 책을 중복 대출하는 것을 막는 제약이 없습니다.**
- 자리: `app/models.py`의 `Loan`(29~38줄), `migrations/0001_initial.py` 27~36줄, `lend` 31~47줄.
- 까닭: 반납 전 대출 `(book_id, member_id)`의 유일성이 DB에도 코드에도 없습니다. SERIALIZABLE은 직렬 실행에서도 가능한 결과라 이것을 막지 않습니다.
- 이 규칙이 의도된 업무 규칙인지는 docs에 적혀 있지 않아 확실하지 않습니다.

**5. `returned_on`에 정합성 CHECK가 없습니다.**
- 자리: `app/models.py` 31행, `migrations/0001_initial.py` 35행.
- 까닭: `returned_on < loaned_on`인 행이 들어갈 수 있습니다. 반납 경로가 생길 때 DB 쪽 방어선이 없습니다.

**6. `downgrade()`의 안전장치가 `loans`만 봅니다.**
- 자리: `migrations/0001_initial.py` `downgrade` 42줄(검사)과 45~46줄(`drop_table`).
- 까닭: 대출이 0건이면 `books`와 `members`에 데이터가 있어도 그대로 지웁니다. 주석의 "지우면 되살릴 길이 없다"는 이유가 이 두 표에도 똑같이 해당합니다.
- docs는 회원을 지우지 않고 `is_active`로 끈다고 하는데, downgrade가 이 원칙을 우회합니다. 이 검사 범위가 의도였는지는 확인하지 못했습니다.

**7. 검사와 삭제 사이가 원자적이지 않습니다.**
- 자리: `migrations/0001_initial.py` `downgrade` 42~46줄.
- 까닭: `SELECT EXISTS`는 동시 INSERT를 막지 않습니다. 검사 직후 다른 세션이 대출을 넣고 commit하면, `DROP TABLE`이 그 INSERT가 끝나길 기다린 뒤 새 대출까지 지웁니다.
- 앱이 내려가 있다는 보장이 코드에 없습니다. `LOCK TABLE ... ACCESS EXCLUSIVE`를 먼저 걸어야 합니다.
- 두 리뷰어의 위험 평가가 달랐습니다. 한쪽은 중간, 다른 쪽은 `DROP`이 잠금을 기다리므로 낮다고 봤습니다.

**8. 오프라인 모드(`alembic downgrade --sql`)에서 장치가 무력해질 수 있습니다.**
- 자리: `migrations/0001_initial.py` 41~43줄.
- 까닭: 오프라인에서는 `op.get_bind()`가 실제 연결이 아닙니다. 검사 없이 `DROP` SQL만 출력될 수 있습니다.
- 확신이 낮습니다. alembic 1.14에서의 정확한 동작은 확인하지 못했습니다.

**9. `rollback()` 자체가 실패하면 원래 예외가 가려집니다.**
- 자리: `app/main.py` `session_scope` 25~27줄.
- 까닭: 연결이 끊긴 경우 등에는 `rollback()`이 예외를 던져 원래 오류 위에 덮입니다. 로깅도 없습니다.
- 위험은 중간 이하입니다.

## 낮은 확신 (참고)
- 메시지 맥락 부족: `downgrade`의 오류 메시지(43줄)에 몇 건이 막았는지, 무엇을 해야 하는지가 없습니다.
- 트랜잭션 DDL이 꺼져 있으면 `downgrade`가 부분 적용될 수 있습니다. Postgres 기본 설정에서는 해당하지 않습니다.
- 이름 없는 `unique=True` 제약에 `naming_convention`도 없어서, 나중에 제약을 바꾸거나 지울 때 이름 지정이 어렵습니다.
- `loans.book_id`와 `loans.member_id`에 인덱스가 없습니다. Postgres는 FK에 인덱스를 자동으로 만들지 않습니다.
- `books`에 총 소장 권수가 없어서, `available_copies`가 반납 안 된 대출 수와 맞는지 DB에서 검증할 수 없습니다.

## 결함이 아닌 것으로 확인한 것
- 모델과 마이그레이션은 컬럼, 타입, nullable, 기본값, CHECK 이름까지 서로 일치합니다.
- `RefusedLoan`으로 `HTTPException(422)`이 던져지면 `session_scope`의 `except`가 잡아 rollback합니다. 그 전에는 쓰기도 없습니다. 이 동작도 0.141.1에서 직접 실행해 보지는 못했습니다.
- `available_copies`는 SERIALIZABLE과 `CHECK >= 0` 덕분에 음수로 가지 않습니다. 진 쪽의 처리가 2번 문제입니다.

가장 우선할 것은 1번과 2번입니다. 둘은 같은 수정, 즉 응답 전 명시적 commit과 재시도로 함께 풀립니다. 그다음이 3번과 6번입니다.
