<!-- pr-review-toolkit + 맥락 · 맞힘 · 떴는가 True · 비용 0.1118086 -->

저장소는 작아서(파일 4개) 리뷰 에이전트는 띄우지 않고 직접 읽었습니다. `CLAUDE.md`가 읽으라고 한 `INTENT.md`와 닫힌 조각은 저장소에 없습니다. 그래서 제외할 항목 없이 `docs/schema.md`의 원칙만 기준으로 삼았습니다. 코드는 고치지 않았습니다.

## 결함

1. **`migrations/versions/0007_shipping_zone.py` `downgrade()`: 운영자가 만든 그룹 행을 검사 없이 지웁니다.**
   - 끝의 `DELETE FROM code_groups WHERE group_code = 'SHIPPING_ZONE'`가 문제입니다.
   - `upgrade()`는 그룹이 이미 있으면 넘어갑니다("운영자가 먼저 만들어 둔 것이 있으면"). 그러면 그 그룹은 이 리비전이 만든 게 아닙니다.
   - 그런데 downgrade는 그룹의 `name`과 `description`이 심은 값 그대로인지 보지 않습니다. 코드 쪽에만 있는 `changed` 검사가 그룹에는 없습니다.
   - `docs/schema.md` 원칙 1("사람이 만든 데이터는 리비전이 지우지 않는다. 남의 것이면 멈춘다")을 어깁니다.

2. **같은 파일 `downgrade()`: 운영자가 먼저 만든 코드가 시드와 값이 같으면 구분하지 못하고 지웁니다.**
   - `upgrade()`는 같은 키의 코드가 있으면 넘어갑니다(`WHERE NOT EXISTS`). 그래서 운영자가 미리 만든 `METRO`가 시드와 이름, 순서, 활성값까지 같으면 시드로 간주됩니다.
   - 위 검사는 값이 다를 때만 멈춥니다. 값이 같으면 `DELETE FROM common_codes WHERE group_code = ...`가 그 행을 지웁니다.
   - 리비전이 실제로 넣은 행인지 기록한 곳이 없어서 "심은 셋인지는 멈춤 검사가 지킨다"는 주석은 성립하지 않습니다. 이것도 원칙 1 위반입니다.

3. **같은 파일 `downgrade()`: 검사와 삭제가 원자적이지 않습니다.**
   - `orders`, `extra`, `changed`를 `SELECT count(*)`로 확인한 뒤 별도의 `DELETE`와 `drop_column`을 실행합니다. 잠금(`LOCK TABLE` 또는 `SELECT ... FOR UPDATE`)이 없습니다.
   - 기본 READ COMMITTED에서 그 사이에 운영 화면이 코드를 추가하거나 고치거나 주문에 권역을 적으면, 검사를 통과하고도 그 데이터를 지우거나 칸을 떨어뜨립니다.

4. **`app/models.py` `Order.shipping_zone`, 0007 `upgrade()`: 주문의 권역 값에 참조 무결성이 없습니다.**
   - `docs/schema.md`는 이 칸이 `SHIPPING_ZONE` 그룹의 코드를 "가리킨다"고 하지만, 제약이 없는 `String(30)`입니다. 복합 PK `(group_code, code)`라서 FK를 걸 수 없고, CHECK나 트리거도 없습니다.
   - 존재하지 않는 코드를 주문에 적을 수 있습니다.
   - 운영자가 코드를 지우거나 비활성화해도 주문에는 값이 남아 고아가 됩니다. `CommonCode`를 지울 때의 `ondelete` 정책도 없습니다.
   - 제약 대신 `orders.shipping_zone`에 `group_code`를 고정값으로 두는 컬럼이나 전용 FK 구조가 필요합니다.

5. **0006 `downgrade()`: 항상 `RuntimeError`를 던집니다.**
   - 의도된 동작("첫 리비전은 되돌리지 않는다")으로 보입니다. 그래도 `alembic downgrade base`가 중간에 실패하므로 되돌림 경로가 끊깁니다.
   - 사람이 만든 데이터를 보호하려는 것이라면 0007처럼 데이터 유무를 검사하고 멈추는 쪽이 맞습니다. 낮은 우선순위입니다.

6. **0007 전반(참고, 낮음): Postgres 전용 문법과 SQL 문자열 조립.**
   - `VALUES ... AS v(...)`와 행 단위 `IS DISTINCT FROM`을 쓰므로 Postgres에서만 돕니다. 다른 DB에서는 실패합니다.
   - f-string으로 SQL을 만듭니다. 지금은 상수라 안전하지만, `ZONES`에 따옴표가 든 이름이 들어가면 깨집니다.

우선순위는 1, 2번(원칙 위반으로 데이터 손실), 4번(무결성), 3번 순입니다.
