<!-- pr-review-toolkit + 맥락 · 맞힘 · 떴는가 True · 비용 0.1327 -->

저장소가 작아서(파일 9개) 전부 직접 읽었고, 리뷰 에이전트는 따로 띄우지 않았습니다. 코드는 고치지 않았고 테스트도 돌리지 않았습니다. `INTENT.md`는 저장소에 없어서 `CLAUDE.md`가 말하는 「Not」과 「하지 않을 일」은 확인하지 못했습니다. 로컬 DB 주소(`app/main.py`의 `localhost`)는 CLAUDE.md의 "로컬 전용 값" 규칙에 따라 결함으로 올리지 않았습니다.

## 중요도 높음

1. **비활성 공통코드로 새 환불이 만들어집니다.**
   - 자리: `app/services/refunds.py` `_must_be_a_code` (22–24행)
   - 까닭: 코드가 있는지만 보고 `is_active`는 보지 않습니다.
   - `app/models.py`의 `CommonCode` 독스트링은 "새 기록에서는 못 고르고 옛 기록에서는 읽힌다"고 합니다. 그런데 시드의 `POINT`(적립금)와 `PROMO`(행사 보상)는 `is_active=FALSE`이고, 지금은 이 코드로도 환불이 통과합니다.
   - FK도 활성 여부를 막지 못하므로 DB에서도 걸러지지 않습니다.

2. **"되돌리는 환불을 새로 세운다"는 원칙을 구현한 곳이 없습니다.**
   - 자리: `docs/schema.md` 원칙 1, `app/models.py` `Refund`, `migrations/0001_refunds.py` `refunds` 표, `refunds.py` `refund`
   - 까닭:
     - `amount > 0` CHECK(`refunds_amount_positive`) 때문에 음수 환불은 만들 수 없습니다.
     - 되돌림 환불이 원 환불을 가리키는 칸(`reverses_id` 같은 것)이 없습니다.
     - 종류나 상태 칸도 없습니다.
     - `order.refunded`는 늘기만 하고 줄이는 경로가 없습니다.
   - 그래서 되돌리려면 `refunds` 행을 고치거나 지우는 수밖에 없고, 원칙 1과 부딪힙니다.

3. **`orders.refunded`가 중복 저장된 합계인데, DB가 정합성을 막아주지 않습니다.**
   - 자리: `app/models.py` `Order`, `migrations/0001_refunds.py` `orders` 표
   - 까닭:
     - `refunded >= 0`, `refunded <= amount`, `amount >= 0` CHECK가 없습니다.
     - `refunded`와 `SUM(refunds.amount)`가 같다는 보장도 없습니다.
   - `refund()`의 `with_for_update` 락과 앱 쪽 검사만 지켜줍니다. 다른 경로(SQL 직접 수정, 앞으로 생길 되돌림 코드)로 쓰면 어긋나도 알 수 없습니다.

4. **`downgrade()`가 환불이 없으면 주문 데이터를 통째로 지웁니다.**
   - 자리: `migrations/0001_refunds.py` `downgrade` (41–47행)
   - 까닭:
     - 가드는 `refunds`에 행이 있는지만 봅니다.
     - `refunds`가 비어 있으면 `orders`와 `common_codes`를 확인 없이 `drop_table` 합니다.
     - 환불 없는 주문과 공통코드가 함께 사라집니다.
   - 이 마이그레이션이 만든 표라도, 운영에서 되돌리면 "일어난 일은 지우지 않는다"에 어긋납니다.

## 중간

5. **같은 환불 요청을 다시 보내면 중복으로 처리됩니다.**
   - 자리: `app/main.py` `post_refund`, `refunds.py` `refund`
   - 까닭:
     - 멱등 키나 유일 제약이 없습니다.
     - 클라이언트가 타임아웃 뒤 재시도하면, 한도 안에서는 환불이 두 번 세워집니다.
   - 금액이 오가는 쓰기라서 트랜잭션 경계 관점에서 중요합니다.

6. **코드 삭제 금지가 DB에서는 지켜지지 않습니다.**
   - 자리: `app/models.py` `CommonCode`, `migrations/0001_refunds.py` `common_codes`
   - 까닭:
     - "삭제 칸이 없다"는 것은 칸이 없다는 말일 뿐입니다. `DELETE` 자체를 막는 트리거나 권한 제한은 없습니다.
     - FK(기본 RESTRICT)는 이미 참조된 코드만 보호합니다.
     - 아직 쓰이지 않은 코드는 지울 수 있고, 지운 뒤 같은 코드를 다른 뜻으로 다시 만들 수도 있습니다.

7. **공통코드 시드가 마이그레이션에 들어 있지 않습니다.**
   - 자리: `migrations/0001_refunds.py`, `seed/codes.sql`
   - 까닭:
     - 마이그레이션만 적용한 DB에는 코드가 없습니다.
     - 그러면 `_must_be_a_code`가 모든 환불을 거절합니다.
     - 시드를 실행하는 순서를 강제하는 곳이 없습니다.
   - `seed/codes.sql`은 평범한 `INSERT`라서 두 번 돌리면 PK 충돌이 나고, 재실행해도 안전하지 않습니다.

## 낮음

8. **`refunds`에 시각이나 행위자 칸이 없습니다.**
   - 자리: `Refund`, `migrations/0001_refunds.py`
   - 까닭: `created_at`과 처리자가 없어서, "일어난 일"을 보존한다는 원칙에 비해 감사 추적이 약합니다.

9. **금액이 `Integer`(32비트)이고 통화 정보가 없습니다.**
   - 자리: `Order.amount`, `Order.refunded`, `Refund.amount` (모델과 마이그레이션 모두)
   - 까닭: 큰 금액이나 다통화로 넓어지면 넘치거나 모호해집니다. 지금 요구사항이 정해진 게 없으면 참고로만 봐도 됩니다.

10. **Alembic 구성이 저장소에 없습니다.**
    - 자리: 저장소 전체
    - 까닭:
      - `alembic.ini`와 `env.py`가 없어서 `0001`을 실행할 방법이 저장소 안에 없습니다.
      - `docs/schema.md`나 모델과 마이그레이션이 어긋나는지 잡아줄 수단도 없습니다.
      - `Refund`와 `CommonCode`의 제약이 모델과 마이그레이션에 이중으로 적혀 있어서 따로 어긋나기 쉽습니다.

## 문제 없음으로 본 것

- `refund()`는 주문 행을 `with_for_update`로 잠근 뒤에 잔액을 검사하고 갱신합니다. 같은 주문에 동시 환불이 들어와도 한도를 넘지 않습니다.
- `post_refund`는 거절하면 커밋하지 않고, `session()`이 닫을 때 롤백됩니다. 트랜잭션 경계는 일관됩니다.
- `refunds`의 `method_group`/`reason_group` CHECK와 복합 FK 조합은 그룹 혼입을 막습니다.
