<!-- pr-review-toolkit + 맥락 · 맞힘 · 떴는가 True · 비용 0.3594938000000001 -->

두 리뷰 에이전트(`pr-review-toolkit`의 code-reviewer, silent-failure-hunter)가 모두 끝났습니다. 코드는 고치지 않았습니다.

`CLAUDE.md`는 리뷰 전에 `INTENT.md`의 「Not」을 읽으라고 하는데, 저장소에 `INTENT.md`가 없어서 그 기준으로 거르지 못했습니다. 로컬 전용 값이라 `app/main.py:12`의 DSN 하드코딩은 뺐습니다. `INTENT.md`가 다른 곳에 있고 아래 항목이 「Not」에 들어 있다면, 그 항목은 빼 주세요.

## 결함

1. **비활성 코드로도 환불이 만들어집니다.** (확신 높음, 두 에이전트 모두 확인)
   - 자리: `app/services/refunds.py`의 `_must_be_a_code`(22–24줄), 호출은 `refund` 31–32줄
   - 까닭: 코드가 있는지만 보고 `is_active`는 보지 않습니다. `app/models.py`의 `CommonCode` 독스트링과 `docs/schema.md` 원칙 2는 비활성 코드를 새 기록에서 못 고르게 한다고 합니다. `seed/codes.sql`에서 `POINT`와 `PROMO`는 `is_active=FALSE`인데, 이 값으로 요청하면 통과해서 커밋됩니다. 복합 FK로는 이 규칙을 막을 수 없어서, 서비스 검사가 유일한 방어선입니다.

2. **환불을 되돌리는 환불을 만들 수 없습니다.** (확신 높음)
   - 자리: `app/models.py`의 `Refund.__table_args__`(`CHECK amount > 0`), `migrations/0001_refunds.py`의 같은 CHECK, `app/services/refunds.py:33`, `app/main.py:24`의 `Field(gt=0)`
   - 까닭: `docs/schema.md` 원칙 1은 환불을 고치지 않고 되돌리는 환불을 새로 세우라고 합니다. 그런데 DB와 서비스, API가 모두 양수 금액만 받습니다. 되돌리는 대상 환불을 가리키는 열(예: `reverses_refund_id`)도 없고, `orders.refunded`는 늘기만 합니다. 환불을 취소하려면 행을 UPDATE나 DELETE 해야 하는데, 이는 원칙 1이 금지하는 일입니다.

3. **`downgrade`가 비어 있지 않은 `orders`와 `common_codes`를 지웁니다.** (확신 높음)
   - 자리: `migrations/0001_refunds.py`의 `downgrade`(41–47줄)
   - 까닭: `refunds`가 비었는지만 확인하고 세 표를 모두 drop 합니다. 환불이 없으면 실제 주문과 `orders.refunded` 합계가 사라지고, 시드 이후 운영자가 추가한 코드도 사라집니다. 확인 후 drop 전에 잠금이 없어서, 그 사이에 커밋된 환불이 날아갈 수도 있습니다(좁은 경쟁 조건).

4. **`orders`에 DB 수준 제약이 없습니다.** (확신 중간)
   - 자리: `app/models.py`의 `Order`, `migrations/0001_refunds.py`의 `orders` 표
   - 까닭: `refunded <= amount`와 `refunded >= 0`이 파이썬 코드(`refunds.py:33`)에만 있습니다. 스크립트나 수작업, 앞으로 생길 다른 경로에서는 초과 환불이 가능합니다. `orders.refunded`가 `refunds` 합계와 어긋나도 알아챌 장치가 없습니다. 2번의 되돌림이 구현되면 더 중요해집니다.

5. **재시도하면 이중 환불될 수 있습니다.** (확신 중간)
   - 자리: `app/main.py`의 `post_refund`, `Refund` 모델
   - 까닭: 커밋은 됐는데 응답이 유실돼 클라이언트가 재시도하면, 잔액이 남아 있는 한 같은 환불이 한 번 더 만들어집니다. 멱등성 키나 유니크 제약이 없습니다. 클라이언트가 실제로 재시도하는지는 저장소만으로 알 수 없습니다.

6. **행 잠금에 대기 제한이 없습니다.** (확신 낮음~중간)
   - 자리: `app/services/refunds.py:28`의 `with_for_update=True`
   - 까닭: `nowait`, `skip_locked`, `lock_timeout`이 없습니다. 한 주문에서 트랜잭션이 멈추면 그 주문의 환불 요청이 모두 무기한 대기하면서 스레드와 커넥션을 붙잡습니다.

7. **시드가 멱등이 아니고 마이그레이션과도 분리돼 있습니다.** (영향 낮음)
   - 자리: `seed/codes.sql`
   - 까닭: 단순 `INSERT`라 두 번째 실행은 PK 충돌로 실패하고, 이름이나 `is_active` 변경을 재실행으로 반영할 수 없습니다. 마이그레이션이 시드를 보장하지 않으므로, 시드를 빠뜨리면 모든 환불이 "그런 코드가 없다"로 거절됩니다. 조용히 깨지지는 않고 요란하게 실패합니다.

## 범위 밖 참고

`migrations/`에 `env.py`, `alembic.ini`, `versions/`가 없어서 `0001_refunds.py`를 alembic으로 바로 실행할 수 없는 구조로 보입니다. 파일 목록만 보고 판단했고 실제로 돌려 보지는 않았습니다.

## 이상 없음으로 확인한 부분

- 모델과 마이그레이션은 열, 기본값, FK, CHECK가 일치합니다.
- `flush`는 서비스에서, `commit`은 라우트에서 하며, 예외가 나면 `close()`가 롤백하고 잠금도 풉니다. 부분 커밋 경로는 없습니다.
- `orders` 행 잠금(`FOR UPDATE`) 아래에서 읽고 검사하고 갱신하므로, 동시 환불로 한도를 넘는 경로는 찾지 못했습니다.
- 코드 FK는 기본값인 `NO ACTION`이라 사용 중인 코드는 삭제되지 않습니다.
