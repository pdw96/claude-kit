<!-- pr-review-toolkit + 맥락 · 맞힘 · 떴는가 True · 비용 0.4516695 -->

`pr-review-toolkit`의 `code-reviewer`와 `silent-failure-hunter`로 저장소 전체를 읽기 전용으로 검토했습니다. 코드는 고치지 않았고 실행도 하지 않았습니다.

CLAUDE.md는 검토 전에 `INTENT.md`의 Not을 읽으라고 하지만, 저장소에 `INTENT.md`가 없어서 제외할 항목은 확인하지 못했습니다. 아래 결함 중 의도된 제외에 해당하는 것이 있을 수 있습니다. `app/main.py:12`의 하드코딩된 DB URL은 로컬 전용 값이라 결함에서 뺐습니다.

## 높음

1. **꺼진 공통코드로 새 환불이 만들어집니다.**
   - 자리: `app/services/refunds.py:22-24`, `_must_be_a_code`
   - 까닭: 코드가 있는지만 보고 `is_active`는 보지 않습니다. `models.py:12-13`은 꺼진 코드를 "새 기록에서는 못 고른다"고 약속합니다. 시드의 `POINT`와 `PROMO`(둘 다 FALSE)로 보낸 환불도 201로 저장됩니다. FK도 `is_active`를 보지 않아 어느 층에서도 막히지 않습니다.

2. **"되돌리는 환불"을 담을 수 없습니다.**
   - 자리: `app/models.py:40`, `migrations/0001_refunds.py:37`(`CHECK amount > 0`), `app/services/refunds.py:33`, `app/main.py:24`(`gt=0`), `Refund` 모델 전체
   - 까닭: `docs/schema.md:11`은 환불을 고치지 않고 되돌리는 환불을 새로 세운다고 합니다. 그런데 음수 금액은 DB·서비스·API 세 층에서 모두 거절됩니다. 되돌릴 대상 환불을 가리키는 칸(예: `reverses_refund_id`)도 없습니다. 잘못된 환불은 `UPDATE`나 `DELETE`로만 바로잡을 수 있어 원칙 1을 어기게 됩니다. `Order.refunded`도 제자리에서 고치는 누계(`refunds.py:36`)인데 줄이는 정상 경로가 없습니다.

3. **`downgrade`가 주문과 공통코드를 검사 없이 지웁니다.**
   - 자리: `migrations/0001_refunds.py:41-47`, `downgrade()`
   - 까닭: `refunds`가 비었는지만 확인한 뒤 `orders`와 `common_codes`를 `DROP`합니다. 환불이 0건이면 주문과 공통코드가 경고 없이 사라지고, 이는 `docs/schema.md`의 "지우지 않는다"에 어긋납니다. 검사와 `DROP` 사이에 락이 없어서, 그 사이에 커밋된 환불이 함께 지워질 수 있습니다(43~45줄). `LOCK TABLE ... ACCESS EXCLUSIVE`를 먼저 걸어야 합니다.

## 중간

4. **`orders.refunded`의 불변식이 DB에 없습니다.**
   - 자리: `app/models.py:25-30`, `migrations/0001_refunds.py:19-23`
   - 까닭: `refunded <= amount`, `refunded >= 0`, `amount > 0` 같은 CHECK가 없습니다. 이 규칙은 `refunds.py:33`에만 있고, `FOR UPDATE`로 직렬화되는 경로도 `refund()` 하나뿐입니다. 다른 경로(수동 SQL, 배치)가 쓰면 초과 환불을 DB가 막지 못합니다. `refunded`가 `refunds` 합계와 일치한다는 보장도 없습니다.

5. **마이그레이션을 실행할 설정이 저장소에 없습니다.**
   - 자리: `migrations/` 전체
   - 까닭: `env.py`, `script.py.mako`, `alembic.ini`가 없어서 `alembic upgrade`와 `downgrade`가 이 저장소만으로는 돌지 않습니다. PostgreSQL DDL이 트랜잭션 안에서 도는지도 알 수 없습니다. `downgrade`가 중간에 실패하면 일부 테이블만 지워진 상태가 남을 수 있습니다.

6. **시드가 마이그레이션에 묶여 있지 않고 다시 돌릴 수도 없습니다.**
   - 자리: `seed/codes.sql` 전체, `migrations/0001_refunds.py`의 `upgrade()`
   - 까닭: `upgrade()`는 빈 `common_codes`만 만듭니다. 시드를 따로 넣기 전에는 모든 환불이 "그런 코드가 없다"로 거절되는데, 이 순서를 적은 곳이 없습니다. `ON CONFLICT`가 없어서 두 번 돌리면 PK 충돌로 실패합니다. `DO UPDATE`를 붙이면 꺼 둔 `is_active`가 되살아날 수 있어 주의해야 합니다. `BEGIN`/`COMMIT`도 없습니다. `downgrade` 뒤 `upgrade`를 다시 하면 코드가 자동으로 돌아오지 않습니다.

## 낮음

7. **커밋 실패와 롤백이 암묵적입니다.**
   - 자리: `app/main.py:15-20`(`session()`), `app/main.py:31-35`(`post_refund`)
   - 까닭:
     - 명시적 `rollback()`이 없고 `finally: s.close()`의 암묵적 롤백에 기댑니다. 롤백이 응답 뒤 의존성 정리 단계에서 일어나, 그때까지 `FOR UPDATE` 락이 유지됩니다.
     - `s.commit()`(35줄)이 `try` 밖에 있어 커밋 시점의 `IntegrityError`가 그대로 500이 됩니다.
     - 커밋이 서비스가 아니라 엔드포인트에 있어, `refund()`를 다른 곳에서 호출하면 커밋을 빠뜨릴 수 있습니다.

8. **락 대기에 상한이 없습니다.**
   - 자리: `app/services/refunds.py:28`, `with_for_update=True`
   - 까닭: `lock_timeout`, `nowait`, `skip_locked`가 없어, 같은 주문에 요청이 몰리면 DB 커넥션을 쥔 채 무한정 대기합니다. 락 대상이 주문 행 하나라 데드락 위험은 낮습니다.

9. **"지우지 않음"이 DB에서 강제되지 않습니다.** (두 에이전트 모두 확신이 낮았습니다.)
   - 자리: `refunds`, `common_codes` 테이블
   - 까닭: `UPDATE`/`DELETE`를 막는 트리거나 권한이 없습니다. 이미 쓰인 코드의 삭제는 FK가 막아 주지만, 쓰이지 않은 코드와 환불 행 자체는 지울 수 있습니다. 원칙이 관례로만 지켜지고 있습니다.

## 문제 없음으로 확인한 부분
- `refund()`가 `SELECT ... FOR UPDATE`로 주문 행을 잠근 뒤 검사하고 갱신하므로, 같은 주문의 동시 환불에서 초과 환불은 막힙니다.
- `session()`은 `finally`에서 항상 `close()`합니다. `commit`은 성공 경로에서 한 번만 일어납니다.
- `Refund`의 FK와 CHECK 제약은 모델과 마이그레이션 0001이 일치합니다.

두 에이전트가 겹쳐서 지적한 항목은 1번과 3번이고, 2번은 `code-reviewer`만 찾았습니다.
