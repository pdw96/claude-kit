<!-- pr-review-toolkit + 맥락 · 맞힘 · 떴는가 True · 비용 0.38290920000000006 -->

# 데이터 쪽 결함 목록

`pr-review-toolkit`의 `code-reviewer`와 `silent-failure-hunter`를 읽기 전용으로 돌렸고, 코드는 고치지 않았습니다. 저장소에 INTENT.md가 없어서 CLAUDE.md가 말한 제외 항목은 확인하지 못했습니다. 그래서 의도된 동작일 수 있는 항목도 아래에 올렸습니다. 코드를 읽어서 판단했고 실행은 하지 않았습니다.

## 높음

1. **만료일을 신청일이 아니라 승인일 기준으로 계산합니다.**
   - 자리: `app/services/memberships.py`의 `approve()` 29~35줄.
   - 까닭: `starts_on = approved_at.date()`이고 `valid_until = starts_on + duration_days`입니다. 그런데 `seed/plans.sql`의 안내 문구(화면에도 나감)는 "신청일 + 기간"이라고 합니다. `docs/schema.md`에 따르면 승인은 신청 다음 날 이후에 몰아서 하므로, 주말 신청은 만료일이 승인까지 걸린 날수만큼 밀립니다. 회원에게 안내한 날짜와 출입 단말이 막는 날짜가 달라집니다. `applications.applied_on`이 있는데 쓰지 않습니다. 어느 쪽이 맞는지는 알 수 없지만 둘은 모순입니다.

2. **같은 신청을 동시에 승인하면 500이 나갑니다.**
   - 자리: `approve()` 22~26줄, `app/main.py`의 `post_approval()` 29~33줄.
   - 까닭: 읽기에 행 잠금이 없고 격리 수준은 READ COMMITTED여서, 두 요청이 모두 `pending`을 보고 통과합니다. `memberships.application_id`의 unique 제약이 중복 회원권은 막아 줍니다. 하지만 두 번째 요청은 `flush`에서 `IntegrityError`가 나고, 라우터는 `RefusedApproval`만 잡으므로 422 "이미 처리한 신청" 대신 처리되지 않은 500이 됩니다. 방어를 unique 제약 하나에만 맡기고 있습니다.

3. **`downgrade()`가 `applications`와 `plans`의 데이터를 확인 없이 지웁니다.**
   - 자리: `migrations/0001_memberships.py`의 `downgrade()` 40~46줄.
   - 까닭: `memberships`에 행이 있는지만 검사합니다. 승인 전이거나 거절된 신청은 회원권이 없어도 업무 데이터인데, 검사를 통과해 조용히 사라집니다. 검사와 `drop_table` 사이에 잠금이 없어서, 그 틈에 커밋된 회원권도 함께 지워질 수 있습니다. 오류 메시지도 어떤 테이블 때문인지 알려 주지 않습니다.

## 중간

4. **승인일을 UTC 날짜로 자릅니다.**
   - 자리: `approve()` 29~30줄의 `datetime.now(timezone.utc).date()`.
   - 까닭: 현지 시각(KST) 00:00~09:00에 승인하면 날짜가 하루 앞당겨집니다. 창구 날짜인 `applied_on`과 날짜 기준이 섞입니다. 1번을 고치면 만료일 계산에서는 사라지지만, 승인일 날짜를 따로 쓸 곳이 있으면 남습니다.

5. **`plans.duration_days`가 0 이하이면 승인이 500으로 실패합니다.**
   - 자리: `app/models.py`의 `Plan.duration_days`, 마이그레이션 `plans` 테이블.
   - 까닭: 양수 CHECK가 없습니다. 0 이하 값이 들어가면 `memberships_period` 제약 위반이 `flush`에서 `IntegrityError`로 나고, 2번과 같은 500이 됩니다. 원인이 기준 데이터 오류인데 사용자도 운영자도 구분할 수 없습니다.

6. **롤백과 커밋 실패 처리가 `close()`에 암묵적으로 맡겨져 있습니다.**
   - 자리: `app/main.py`의 `session()` 15~20줄, `post_approval()` 33줄.
   - 까닭: 명시적 `rollback()`이 없고, `commit()` 실패는 로그 없이 500이 됩니다. 트랜잭션 경계가 `approve`의 `flush`와 라우터의 `commit` 두 곳으로 갈라져 있어서, `flush` 뒤에 쓰기를 추가하면 원자성 범위가 불분명해집니다. `create_engine`에 `pool_pre_ping`도 없습니다.

7. **`plan`이 `None`일 때의 처리가 없습니다.**
   - 자리: `approve()` 27~35줄.
   - 까닭: 지금은 FK와 `NOT NULL`이 막아 줘서 정상 경로에서는 일어나지 않습니다. 하지만 데이터가 깨지면 `AttributeError`로 500이 납니다. 두 리뷰어가 신뢰도에 대해 의견이 갈렸고, 방어 코드 수준의 지적입니다.

## 낮음

8. **`seed/plans.sql`을 다시 실행하면 실패합니다.** 자리는 `seed/plans.sql` 전체입니다. `ON CONFLICT`가 없는 단순 INSERT라서 두 번째 실행에서 PK 위반이 나고, 값을 바꿀 갱신 수단도 없습니다.

9. **DB 제약이 비어 있습니다.** 자리는 `app/models.py`의 `Application.status`, `member_id`, FK 컬럼들입니다.
   - `status`는 자유 문자열이라 허용 값 CHECK가 없습니다.
   - `approved` 상태와 `memberships` 행의 존재를 DB가 보장하지 않습니다.
   - `member_id`에는 FK가 없고, 같은 회원의 기간이 겹치는 회원권을 막는 제약도 없습니다. 의도라면 문서화가 필요합니다.
   - `applications.plan_code`와 `memberships.application_id`의 FK에는 인덱스가 없습니다.

10. **Alembic 설정이 없습니다.** 자리는 `migrations/` 전체입니다. `alembic.ini`와 `env.py`가 없어서 upgrade와 downgrade를 모두 실행해 볼 수 없습니다. 모델과 마이그레이션의 컬럼이 손으로 복제되어 있어 어긋날 위험이 있는데, 지금은 일치합니다.

## 확인했지만 결함으로 올리지 않은 것

- 모델과 마이그레이션의 컬럼, 타입, nullable, `server_default`, UNIQUE, CHECK는 서로 일치합니다.
- "신청일로부터 30일"을 신청일 포함으로 읽는지는 문서만으로 정할 수 없습니다. 출입 단말이 `valid_until` 당일을 열어 주는지 함께 확인해야 합니다.
- `app/main.py:12`의 하드코딩된 DB URL은 로컬 전용 값으로 보고 뺐습니다.

데이터 손실이나 안내와 실제 만료일 불일치로 이어지는 1번과 3번을 먼저 보시길 권합니다.
