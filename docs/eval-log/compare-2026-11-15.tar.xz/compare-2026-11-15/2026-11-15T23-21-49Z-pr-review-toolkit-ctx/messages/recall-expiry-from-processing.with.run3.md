<!-- pr-review-toolkit + 맥락 · 맞힘 · 떴는가 True · 비용 0.13067369999999998 -->

저장소 전체는 파일 6개, 약 180줄이라 리뷰 에이전트는 띄우지 않고 직접 읽었습니다. CLAUDE.md가 읽으라고 한 `INTENT.md`는 저장소에 없고 `.claude/` 아래에도 없습니다. 그래서 제외할 항목은 CLAUDE.md의 "로컬 전용 값" 규칙만 적용했습니다. `main.py:12`의 DB URL(`localhost`, 비밀번호 없음)은 이 규칙에 따라 결함으로 올리지 않았습니다. 코드는 고치지 않았습니다.

## 중요도 높음

1. **만료일 기산일이 틀립니다** (`app/services/memberships.py` `approve`, 29–35줄)
   - `starts_on`을 승인 시각의 날짜로 잡습니다. `seed/plans.sql`의 설명은 "신청일로부터 N일, 신청일 + 기간"이라고 합니다. 이 문구는 화면에도 나갑니다.
   - `docs/schema.md`에 따르면 승인은 신청 다음 날이나 그 뒤에 이뤄집니다. 주말 신청은 월요일에 승인됩니다.
   - 그러면 회원은 승인 지연만큼 이용 기간을 잃고, 안내 문구와도 어긋납니다.
   - 쓰이지 않는 `application.applied_on`이 기준이어야 하는 것으로 보입니다.

2. **같은 신청을 동시에 승인하면 500이 납니다** (`approve` 22–26줄과 39–41줄, `app/main.py` `post_approval` 29–33줄)
   - `session.get`을 행 잠금(`with_for_update`) 없이 호출한 뒤 `status`를 확인하고 바꿉니다. 이 확인·갱신은 원자적이지 않습니다.
   - 두 요청이 모두 `pending`을 읽으면 둘 다 통과합니다. 이중 승인을 막는 것은 `memberships.application_id`의 UNIQUE뿐입니다.
   - 늦은 쪽은 `flush`에서 `IntegrityError`가 납니다. 이 예외는 `RefusedApproval`이 아니라서 `main.py`가 잡지 않고, 422 대신 500이 됩니다.
   - `applications.status`의 갱신은 낙관적 잠금이나 조건부 `UPDATE ... WHERE status='pending'`으로 보호되지 않습니다.

3. **`downgrade`가 지울 수 없는 데이터를 지웁니다** (`migrations/0001_memberships.py` `downgrade`, 40–46줄)
   - 보호 검사는 `memberships`에 행이 있는지만 봅니다.
   - 그런데 `applications`(대기·처리 이력 전부)와 `plans`도 함께 drop합니다. 회원권이 없어도 신청 데이터가 사라집니다.
   - 검사 대상과 삭제 대상이 맞지 않습니다.
   - 예외 메시지는 "회원권이 있어" 되돌리지 않는다고 하지만, 실제로 파괴되는 범위는 그보다 넓습니다.

## 중요도 중간

4. **날짜 기준이 UTC입니다** (`approve` 29–30줄)
   - `datetime.now(timezone.utc).date()`로 `starts_on`을 정합니다. 한국 시간 00:00~09:00에 승인하면 `starts_on`이 전날로 기록됩니다.
   - 신청일은 창구에 온 현지 날짜(`applied_on`)입니다. 두 날짜의 기준이 섞여 있고, 출입 단말이 `valid_until`로 막는 경계도 하루 어긋날 수 있습니다.

5. **기준 데이터가 마이그레이션 밖에 있고 seed가 멱등이 아닙니다** (`seed/plans.sql` 2–5줄, 마이그레이션 `upgrade`)
   - `upgrade` 뒤 `plans`는 비어 있습니다. 별도로 seed를 돌려야 하고, 실행 순서를 강제하는 장치가 없습니다.
   - seed는 평범한 `INSERT`라서 두 번 실행하면 PK 충돌로 실패합니다. `ON CONFLICT`가 없습니다.
   - 가격이나 기간을 고치는 변경 경로도 없습니다.

6. **`plan`이 없을 때 처리가 없습니다** (`approve` 27–35줄)
   - `session.get(Plan, ...)`이 `None`을 반환하는 경우를 확인하지 않습니다. FK가 있어 현재는 거의 도달하지 않지만, 도달하면 `AttributeError`로 500이 납니다.
   - 명시적인 거절 경로가 없습니다.

## 중요도 낮음 (모델 제약)

7. **`status`가 자유 문자열입니다** (`app/models.py` 26줄, 마이그레이션 25줄)
   - `String(10)`에 CHECK나 enum이 없습니다. 코드의 `"pending"`, `"approved"` 같은 값 외에 오타나 임의 값도 들어갑니다.
   - 승인 상태와 `memberships` 행의 존재가 DB 수준에서 서로 연결되어 있지 않습니다.

8. **값 범위 제약이 없습니다** (`models.py` 14–15줄, 마이그레이션 15–16줄)
   - `duration_days`와 `price`에 양수 CHECK가 없습니다.
   - `duration_days <= 0`이면 `memberships_period`(`valid_until > starts_on`) 위반으로 `flush`에서 `IntegrityError`가 납니다. 이것도 2번처럼 500으로 나갑니다.

9. **회원 테이블이 없습니다** (`models.py` 23, 35줄, 마이그레이션 22, 31줄)
   - `applications.member_id`와 `memberships.member_id`에 FK가 없어 존재하지 않는 회원 ID가 들어갈 수 있습니다.
   - 같은 값이 두 표에 중복 저장됩니다(비정규화). 두 값이 어긋나는 것을 막는 제약이 없습니다.

10. **인덱스가 없습니다** (마이그레이션 전체)
    - `applications.member_id`, `applications.plan_code`, `memberships.member_id`에 인덱스가 없습니다.
    - 출입 단말은 회원별로 `valid_until`을 조회하는데, `(member_id, valid_until)` 인덱스가 없어 전체 스캔이 됩니다.

11. **회원권 중복이나 겹침을 막는 규칙이 없습니다**
    - 같은 회원이 대기 신청을 여러 개 낼 수 있고, 겹치는 기간의 회원권도 여러 개 만들 수 있습니다. 갱신 시 기간을 이어 붙일지도 정해져 있지 않습니다.
    - 의도라면 문서화가 필요하고, 의도가 아니라면 결함입니다. 결함으로 단정하지는 않았고, 확인이 필요합니다.

12. **만료일 의미가 모호합니다** (`approve` 35줄, `docs/schema.md` 6행)
    - `valid_until = starts_on + N일`입니다. 문서는 "`valid_until`이 지나면 막는다"고 합니다. 이 말대로면 `valid_until` 당일까지 출입할 수 있어 실제로는 N+1일이 됩니다.
    - 시작일과 만료일이 각각 포함인지 미포함인지를 어디에도 정의하지 않았습니다.

13. **트랜잭션 경계가 두 계층에 나뉩니다** (`approve`는 `flush`만, 커밋은 `main.py:33`)
    - 지금은 동작합니다. 그러나 `approve`를 다른 호출자가 재사용하면 커밋이나 롤백 책임이 모호해집니다.
    - 현재 롤백은 `close()`에 암묵적으로 맡겨져 있습니다.

## 잘 된 점
- `memberships.application_id`의 UNIQUE가 이중 발급의 최후 방어선으로 있습니다.
- 모델과 마이그레이션의 컬럼 및 제약 정의가 일치합니다.
- 기간 CHECK 제약이 있습니다.
- 승인 날짜와 시각은 `timestamptz`로 저장합니다.

가장 먼저 볼 것은 1번(기산일), 2번(동시 승인), 3번(downgrade 범위)입니다.
