<!-- pr-review-toolkit + 맥락 · 맞힘 · 떴는가 True · 비용 0.1399542 -->

`INTENT.md` 는 저장소에 없습니다. `CLAUDE.md` 가 읽으라고 한 「Not」과 「하지 않을 일」은 확인하지 못했습니다. 그래서 아래 결함 중 의도된 비목표와 겹치는 것이 있을 수 있습니다. 로컬 전용 값(`app/settings.py` 의 기본 DB URL)은 규칙대로 뺐습니다.

코드가 222줄이라 리뷰 에이전트를 부르지 않고 직접 읽었습니다. 코드는 수정하지 않았습니다.

## 중요도 높음

1. **커밋 실패가 클라이언트에게 성공(201)으로 나갑니다.**
   - 자리: `app/main.py` `session_scope` 24행(`session.commit()`), `post_loan`.
   - 까닭: 커밋을 yield 의존성의 종료 코드에서 합니다. 이 FastAPI 버전(0.141)에서는 종료 코드가 응답을 보낸 뒤에 돕니다. 그래서 `lend()` 는 `flush()` 까지만 하고 `LoanOut` 을 돌려주는데, 그 뒤 커밋이 실패하면 클라이언트는 이미 `loan_id` 를 받은 상태입니다. 이 앱은 SERIALIZABLE 이라 커밋 시점 직렬화 실패(SQLSTATE 40001)가 정상적으로 일어납니다. 그러면 존재하지 않는 대출 번호를 돌려준 셈이 되고, 원칙 1·3 의 보장이 클라이언트에게는 깨져 보입니다.
   - 고치려면 커밋을 엔드포인트나 서비스 안, 응답을 만들기 전에 해야 합니다.

2. **직렬화 실패(40001)와 교착에 재시도가 없습니다.**
   - 자리: `app/db.py` 9행(`isolation_level="SERIALIZABLE"`), `app/services/loans.py` `lend`(48행 `flush`), `app/main.py`.
   - 까닭: 원칙 3 은 동시에 같은 책을 빌리면 하나만 선다고 하면서 격리 수준에만 기댑니다. 지는 쪽은 `OperationalError` 로 끝나고, `RefusedLoan` 처럼 의미 있는 응답으로 바뀌지도, 재시도되지도 않아 500 이 됩니다.
   - 같은 책에 요청이 몰리면 정상 요청이 계속 실패합니다. 재시도 루프(트랜잭션 전체 재실행)나 `SELECT … FOR UPDATE`(`select(Book).with_for_update()`)가 없습니다.

3. **반납 경로가 없어 `available_copies` 가 한쪽으로만 줄어듭니다.**
   - 자리: `app/services/loans.py`(반납 함수 없음), `app/main.py`(엔드포인트가 `POST /loans` 뿐), `app/models.py` `Loan.returned_on`.
   - 까닭: `returned_on` 은 문서(`docs/schema.md`)에만 "반납하면 찬다"고 적혀 있고, 채우면서 권수를 되돌리는 코드가 없습니다. 총 소장 권수 컬럼(`total_copies`)도 없어서 `available_copies = 총권수 − 미반납 대출 수` 를 검증하거나 복구할 수 없습니다. 반납을 나중에 붙일 때 두 값이 어긋나도 알아낼 방법이 없습니다.

## 중요도 중간

4. **같은 회원이 같은 책을 미반납 상태로 중복 대출할 수 있습니다. 회원별 대출 한도도 없습니다.**
   - 자리: `app/models.py` `Loan`(고유 제약·부분 인덱스 없음), `app/services/loans.py` `lend`.
   - 까닭: `(book_id, member_id) WHERE returned_on IS NULL` 같은 부분 고유 인덱스가 없고, 서비스도 확인하지 않습니다. 같은 요청을 재전송하면(멱등 키도 없음) 대출 줄과 재고가 매번 줄어듭니다.

5. **대출일을 클라이언트가 정합니다.**
   - 자리: `app/schemas.py` `LoanIn.loaned_on`, `app/services/loans.py` 44~45행.
   - 까닭: 과거나 먼 미래 날짜로 대출을 세울 수 있고, `due_on` 도 그 날짜에서 계산됩니다. 연체 기준이 요청자 마음대로 정해집니다. 서버 시각으로 정하거나 범위를 검증해야 합니다.

6. **`downgrade` 의 안전장치가 일부만 막습니다.**
   - 자리: `migrations/0001_initial.py` `downgrade` 39~46행.
   - 까닭: `loans` 만 비었는지 보고 `books`·`members` 를 지웁니다. 도서와 회원 데이터가 있어도 `loans` 가 비어 있으면 모두 사라집니다. 주석은 "지우면 되살릴 길이 없다"고 하면서 되살릴 수 없는 마스터 데이터를 보호하지 않습니다.
   - 검사와 삭제 사이에 대출이 들어오는 경합도 있습니다. 테이블 잠금을 먼저 잡아야 합니다.

7. **Alembic 을 실행할 구성이 없습니다.**
   - 자리: 저장소 루트와 `migrations/`(`alembic.ini`, `env.py`, `versions/` 없음).
   - 까닭: `alembic==1.14.0` 이 의존성에 있지만 리비전 파일 하나만 있습니다. `upgrade`/`downgrade` 를 실제로 돌릴 수 없어, 마이그레이션이 한 번도 검증되지 않았을 가능성이 큽니다. `target_metadata` 연결이 없어 모델과 마이그레이션이 어긋나는 것을 `alembic check`/autogenerate 로 잡을 수도 없습니다. 지금은 `models.py` 와 `0001_initial.py` 에 스키마가 손으로 두 벌 적혀 있습니다.

## 중요도 낮음

8. **`loans.book_id`, `loans.member_id` 에 인덱스가 없습니다.**
   - 자리: `app/models.py` `Loan`, `migrations/0001_initial.py` 28~36행.
   - 까닭: PostgreSQL 은 FK 에 인덱스를 자동으로 만들지 않습니다. 회원별·도서별 대출 조회와 `books` 갱신 때의 FK 검사가 전체 스캔이 됩니다. 미반납 대출 조회용 부분 인덱스도 없습니다.

9. **값 범위 제약이 부족합니다.**
   - 자리: `app/models.py` `Book.loan_days`, `Loan.returned_on`.
   - 까닭: `loan_days > 0` 검사가 없습니다. 음수가 들어가면 `loans_due_after_loan` 위반으로 `lend` 가 500 을 냅니다(`RefusedLoan` 아님). `returned_on >= loaned_on` 검사도 없습니다.

10. **문서의 원칙 2 와 `lend` 의 재고 확인이 이중으로 되어 있습니다.**
    - 자리: `app/services/loans.py` 37행.
    - 까닭: 확인 직후 `-= 1` 은 읽고 쓰는 두 단계입니다. 격리 수준이 낮아지거나 바뀌면 `CHECK` 위반(`IntegrityError`)이 500 으로 올라옵니다. 지금은 2번 항목이 해결되면 함께 정리됩니다. `UPDATE … SET available_copies = available_copies - 1 WHERE available_copies > 0` 로 한 문장에 처리하는 편이 더 안전합니다.

## 잘 된 점
- 요청 하나를 트랜잭션 하나로 묶고 예외 시 롤백합니다. `RefusedLoan` 도 롤백됩니다.
- `available_copies >= 0` 과 `due_on >= loaned_on` 제약이 모델과 마이그레이션에 모두 있어 서로 일치합니다.
- 회원은 삭제하지 않고 `is_active` 로 끕니다. 지난 대출의 참조를 지키는 좋은 선택입니다.

## 권장 순서
1번(커밋 위치)과 2번(재시도 또는 행 잠금)을 먼저 보세요. 그다음 3번과 4번에서 반납 경로와 중복 대출 제약을 정하고, 7번에서 Alembic 구성을 갖춘 뒤 6번의 `downgrade` 를 다시 보면 됩니다.
