<!-- pr-review-toolkit + 맥락 · 맞힘 · 떴는가 True · 비용 0.129825 -->

저장소가 작아서 에이전트를 띄우지 않고 직접 읽고 검토했습니다. 코드는 고치지 않았습니다.

`CLAUDE.md`는 리뷰 전에 `INTENT.md`의 Not과 닫힌 조각의 「하지 않을 일」을 읽으라고 합니다. 저장소 안에는 `INTENT.md`도 닫힌 조각 문서도 없었습니다. 그래서 제외할 항목이 없는 상태로 검토했습니다. 로컬 전용 값으로 보이는 `app/main.py`의 하드코딩된 DB 접속 문자열은 결함으로 올리지 않았습니다. 저장소 밖 `/home/user/claude-kit/INTENT.md`는 이 저장소의 문서가 아니라서 읽지 않았습니다.

## 중요 결함

1. **만료일 기준일이 문서·안내 문구와 다릅니다.**
   - 자리: `app/services/memberships.py`의 `approve()` (`starts_on = approved_at.date()`, `valid_until = starts_on + duration_days`)
   - 까닭: `docs/schema.md`는 `applied_on`을 회원이 창구에 온 날이라고 하고, 승인은 신청 다음 날이나 그 뒤에 몰아서 한다고 씁니다. `seed/plans.sql`의 description은 화면에도 나가는데, "신청일로부터 N일, 만료일은 신청일 + 기간"이라고 약속합니다.
   - 그런데 코드는 `applied_on`을 전혀 읽지 않고 승인일부터 셉니다. 주말에 신청해 월요일에 승인되면 회원은 2~3일을 잃고, 승인이 늦어질수록 더 잃습니다. 출입 단말은 이 `valid_until`로 막기 때문에 실제 출입에 영향이 갑니다.

2. **승인일을 UTC 기준으로 계산합니다.**
   - 자리: `approve()`의 `datetime.now(timezone.utc).date()`
   - 까닭: 체육관 현지 날짜가 아니라 UTC 날짜가 `starts_on`과 `valid_until`이 됩니다. 현지가 UTC보다 앞선 시간대(예: KST)라면 현지 오전 9시 전 승인은 전날 날짜로 기록되어 만료일이 하루 일찍 잡힙니다. 위 1번과 같은 경계 문제입니다.

3. **동시 승인에 대한 보호가 없고, 졌을 때 오류가 500으로 샙니다.**
   - 자리: `approve()`의 `session.get(Application, ...)` 뒤 `status` 확인, 그리고 `post_approval`
   - 까닭: 신청 행에 `SELECT ... FOR UPDATE`나 상태 조건부 UPDATE가 없어서, 두 요청이 모두 `pending`으로 읽고 통과할 수 있습니다. `memberships.application_id`의 UNIQUE가 이중 발급은 막습니다.
   - 하지만 진 쪽은 `flush()`에서 `IntegrityError`가 나는데, `RefusedApproval`로 바뀌지 않고 처리되지 않은 500이 됩니다. "이미 처리한 신청"이라는 422 계약이 경쟁 상황에서는 지켜지지 않습니다.
   - 직원이 몰아서 승인하는 업무 방식이라 겹칠 가능성이 낮지 않습니다.

4. **다운그레이드가 데이터를 조용히 지웁니다.**
   - 자리: `migrations/0001_memberships.py`의 `downgrade()`
   - 까닭: `memberships`에 행이 있는지만 확인하고 `applications`와 `plans`는 확인하지 않습니다. 대기 중인 신청이나 승인 전 신청이 있어도 `drop_table`로 모두 사라지고, 되돌림 보호가 절반만 걸려 있습니다.
   - 존재 확인과 삭제 사이에 틈도 있습니다. PostgreSQL은 DDL이 트랜잭션 안에 있어서 한 트랜잭션으로 묶이면 문제가 줄어들지만, 다른 세션의 삽입을 막는 락은 잡지 않습니다.

## 보통 결함

5. **기준 데이터가 마이그레이션에 없고 시드가 멱등하지 않습니다.**
   - 자리: `seed/plans.sql`, `migrations/0001_memberships.py`
   - 까닭: `upgrade()` 뒤에는 `plans`가 비어 있고, 시드를 별도로 돌려야 합니다. 안 돌리면 신청이 FK 때문에 들어가지 않습니다.
   - 시드는 단순 `INSERT`라서 두 번 돌리면 PK 충돌로 실패합니다. `ON CONFLICT`가 없어 가격이나 문구를 바꿔 다시 심을 수도 없습니다.
   - 시드 롤백 경로도 없습니다. 다운그레이드가 `plans`를 통째로 지우므로 시드는 되돌림과 짝이 맞지 않습니다.

6. **상태 값과 수치에 DB 제약이 없습니다.**
   - 자리: `app/models.py`와 마이그레이션의 `applications.status`, `plans.duration_days`, `plans.price`
   - 까닭: `status`가 자유 문자열 `String(10)`이라 `pending`, `approved` 외의 값이나 오타가 들어가도 막지 못합니다. 코드는 `"pending"`, `"approved"` 문자열을 흩어 쓰고 있습니다.
   - `duration_days`가 0 이하여도 됩니다. 다만 `memberships_period` 체크가 `valid_until > starts_on`을 요구해서, 그런 플랜은 승인 시점에야 제약 위반으로 터집니다. 값 자체를 입구에서 막지 못한다는 점이 문제입니다.
   - `price`의 음수도 막지 않습니다.

7. **신청과 회원권의 정합성이 DB로 보장되지 않습니다.**
   - 자리: `Membership.member_id`, `Membership.application_id`
   - 까닭: 회원권이 `member_id`를 신청에서 복사해 중복 저장합니다. 두 값이 어긋나는 것을 DB가 막지 못합니다.
   - `status = 'approved'`인 신청에 회원권이 있어야 한다는 관계도 강제되지 않습니다. 같은 회원의 회원권 기간 겹침도 막지 않아서, 중복 신청을 승인하면 기간이 겹치는 회원권이 둘 생깁니다.
   - `member_id`에 FK가 없습니다. 회원 표가 이 저장소에 없는 것으로 보이지만, 그렇다면 참조 무결성이 어디서도 보장되지 않습니다.

8. **트랜잭션 경계가 서비스와 엔드포인트로 갈라져 있습니다.**
   - 자리: `app/main.py`의 `post_approval`, `approve()`
   - 까닭: `approve()`는 `flush()`까지만 하고 커밋은 엔드포인트가 합니다. 의도된 분리일 수 있지만, 실패 경로에서 `rollback()`을 명시하지 않고 `finally: s.close()`에 기댑니다. `close()`가 롤백해 주므로 지금은 동작하지만 암묵적입니다.
   - `IntegrityError`처럼 예상 밖 예외는 그대로 전파됩니다(3번).
   - 서비스를 다른 곳에서 재사용하면 커밋 책임이 모호해집니다.

## 사소한 결함

9. **조회 성능용 인덱스가 없습니다.** 자리: `applications.member_id`, `applications.status`, `applications.plan_code`, `memberships.member_id`, `memberships.valid_until`. 승인 대기 목록 조회, 회원별 조회, 출입 단말의 만료 확인이 이 열들로 이뤄질 것 같은데 인덱스가 없습니다.

10. **`plan`이 `None`일 때의 방어가 없습니다.** 자리: `approve()`의 `session.get(Plan, ...)` 뒤. FK가 있어 정상 경로에서는 `None`이 나오기 어렵지만, 값이 `None`이면 `AttributeError`로 500이 됩니다.

11. **마이그레이션 실행 환경이 저장소에 없습니다.** 자리: 저장소 루트. `alembic.ini`와 `env.py`가 없습니다. `requirements.txt`에는 alembic이 있지만 이 마이그레이션을 실제로 돌릴 설정이 없습니다. 모델과 마이그레이션이 손으로 따로 적혀 있어서 어긋나도 알려 줄 수단이 없습니다.

## 잘 된 점

- `memberships.application_id`의 UNIQUE와 `memberships_period` 체크로 이중 발급과 역전된 기간은 DB 층에서 막힙니다.
- 마이그레이션이 PostgreSQL 트랜잭션 DDL 위에서 돌아가고, `downgrade()`에 데이터 보호 장치를 의도적으로 넣은 점은 방향이 맞습니다.

## 권장 순서

1. 1~2번 (기준일과 시간대)을 먼저 정합니다. 출입 차단에 직결되고, 지금 안내 문구가 틀린 약속을 하고 있습니다.
2. 3번 (동시 승인), 4번 (되돌림 보호)을 다음으로 봅니다.
3. 5~8번은 그 뒤에, 9~11번은 여유가 있을 때 봅니다.
