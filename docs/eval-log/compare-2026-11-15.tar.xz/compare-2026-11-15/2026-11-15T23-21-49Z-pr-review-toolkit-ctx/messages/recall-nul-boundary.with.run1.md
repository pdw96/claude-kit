<!-- pr-review-toolkit + 맥락 · 맞힘 · 떴는가 True · 비용 0.4649316 -->

# 결함 목록 (저장소 전체, 코드 수정 없음)

`pr-review-toolkit`의 code-reviewer와 silent-failure-hunter 결과를 합쳤습니다.

- 저장소에 INTENT.md와 「닫힌 조각」이 없습니다. CLAUDE.md가 말하는 제외 항목이 없어서 걸러낸 것은 없습니다. 하드코딩된 DSN(`app/main.py:14`)은 로컬 전용 값으로 보고 올리지 않았습니다.
- code-reviewer는 pydantic으로 경계 입력을 실제로 돌려 1·2번을 확인했습니다. FastAPI와 psycopg는 환경에 없어서, DB 쪽 동작(500)은 알려진 동작을 근거로 판단한 것이고 실행해서 확인하지는 못했습니다.

## 치명

**1. NUL 문자(`\u0000`)가 검증을 통과해 500이 됩니다.**
- 자리: `app/schemas.py`의 `RegistrationIn` 네 필드와 `_present`. 실패 지점은 `app/main.py`의 `post_registration` `s.commit()`입니다.
- 까닭:
  - NUL을 거르는 검증이 없습니다. `note`는 길이만 보고, 나머지 세 칸의 `_present`도 공백만 봅니다.
  - 실제로 `"a\u0000b"`가 검증을 통과했습니다. PostgreSQL `text`는 NUL을 저장하지 못해서 psycopg가 `DataError`를 내고, 이 예외는 처리되지 않아 500이 됩니다.
  - `docs/api.md`의 "받을 수 없는 요청은 경계에서 422, 경계를 지난 요청은 저장된다"를 어깁니다. `_present` docstring이 막겠다던 "이름 없는 실패"가 바로 이것입니다.

**2. DB 예외 처리가 전혀 없습니다.**
- 자리: `app/main.py` `post_registration`(26~30줄).
- 까닭: `commit()` 주변에 try/except도 전역 핸들러도 없습니다. `DataError`, `OperationalError`, `IntegrityError`가 모두 본문 없는 500이 되고 로그도 남지 않습니다. 호출자는 요청이 잘못된 것인지 서버 문제인지 구분하지 못합니다.

## 중요

**3. 유니코드 공백 상당수가 "비어 있다" 검증을 통과합니다.**
- 자리: `app/schemas.py`의 `_BLANK`(8줄)와 `_present`(13줄 `value.strip(_BLANK)`).
- 까닭: 목록에 있는 문자만 벗겨서 `\x0b`, `\x0c`, `\x1c`–`\x1f`, `\x85`, U+1680, U+2000–U+200A(em space 등), U+2028/2029, U+202F, U+205F가 통과합니다. 제로폭 공백(U+200B)도 같은 부류입니다.
  - code-reviewer가 `event_code="\x0b\x0c"`, `attendee_name="\u2003"`이 통과하는 것을 확인했습니다.
  - 사실상 이름이 빈 신청이 201로 저장됩니다. 필수 칸인 `event_code`와 `attendee_name`이 해당하고, 이는 모듈이 내건 약속과 어긋납니다.

**4. 커밋 뒤 `row.id` 접근이 실패하면 저장됐는데도 500이 되고, 명시적 롤백이 없습니다.**
- 자리: `app/main.py` `post_registration`(30줄)과 `session()`(17~22줄).
- 까닭:
  - `expire_on_commit` 기본값 때문에 커밋 뒤 `row.id`가 SELECT를 한 번 더 냅니다. 이 SELECT가 실패하면 행은 저장됐는데 클라이언트는 500을 받습니다.
  - 클라이언트가 재시도하면 중복 신청이 생깁니다. UNIQUE 제약이나 멱등성 장치가 없습니다.
  - 커밋 실패 시 `rollback()`을 직접 부르지 않고 `close()`의 암묵적 롤백에 기댑니다.

**5. `docs/api.md`의 에러 규약이 실제와 다릅니다.**
- 자리: `docs/api.md` 5~10줄.
- 까닭:
  - 응답표에 201과 422뿐이고 500이 없습니다.
  - "경계를 지난 요청은 저장된다"는 1번 때문에 거짓입니다.
  - "`detail`이 칸과 까닭을 말한다"는 검증 오류에만 해당하고, DB 계열 실패에는 `detail` 구조가 없습니다.

## 낮음

**6. 길이 제한이 스키마에만 있고 DB에는 없습니다.**
- 자리: `app/schemas.py` 22~25줄(20/50/100/500자), `app/models.py`와 `migrations/0001_registrations.py`(전부 `Text`, CHECK 제약 없음).
- 까닭: 스키마를 거치지 않는 경로는 제한 없이 저장합니다. 나중에 `VARCHAR(n)`으로 바꾸면 문자 수와 바이트 수 차이로 500이 생길 수 있습니다.

**7. `organization`의 길이 초과 메시지가 어색합니다.**
- 자리: `app/schemas.py` 24줄, `Present | None`에 `Field(max_length=...)`.
- 까닭: 422는 정상으로 나가지만 메시지가 "at most 100 items after validation"으로 나옵니다. 문자열 길이 오류의 까닭을 `detail`이 정확히 말한다는 약속에 조금 못 미칩니다. code-reviewer는 이 항목을 사소하다고 보고 결함에서 뺐습니다.

## 확인 못 한 것
- JSON의 짝 없는 서로게이트(`"\ud800"`)는 code-reviewer가 pydantic에서 422로 거부되는 것을 확인했습니다. silent-failure-hunter는 DB 단계에서 실패할 수 있다고 봤지만, 이 부분은 실행해서 확인하지 못했고 pydantic 단계에서 막히므로 결함으로 올리지 않았습니다.

관련 파일은 `app/main.py`, `app/schemas.py`, `app/models.py`, `migrations/0001_registrations.py`, `docs/api.md`입니다.
