<!-- pr-review-toolkit + 맥락 · 맞힘 · 떴는가 True · 비용 0.45294890000000004 -->

두 리뷰 에이전트(code-reviewer, silent-failure-hunter)의 결과를 합쳤고, 코드는 고치지 않았습니다. 이 환경에는 fastapi, sqlalchemy, alembic이 설치돼 있지 않아 실행으로 확인한 항목은 없습니다. 아래 판단은 모두 코드를 읽고 내린 것입니다. `CLAUDE.md`가 가리키는 `INTENT.md`와 「하지 않을 일」은 저장소에 없어서, 제외할 항목을 확인하지 못했습니다. 로컬 전용 값인 `settings.py`의 기본 `database_url`만 제외했습니다.

## 중요

1. **응답을 보낸 뒤에 커밋될 수 있습니다.**
   - 자리: `app/main.py`의 `session_scope`(16~29줄)와 `post_loan`의 `Depends(session_scope)`(33줄).
   - 까닭: `commit()`이 yield 뒤에 있습니다. FastAPI 0.118 이후로 알려진 동작대로라면, 기본 scope에서 yield 뒤 코드는 응답을 보낸 다음에 돕니다. 그러면 SERIALIZABLE에서 커밋 시점에 나는 직렬화 실패가 201을 보낸 뒤에 터집니다. 클라이언트는 `loan_id`를 받았는데 대출 줄과 권수 차감은 둘 다 롤백됩니다. 응답 쪽에서 `docs/schema.md` 원칙 1이 깨지는 셈입니다.
   - 확신: 두 에이전트 모두 중간 정도입니다. 고정된 버전(0.141.1)의 동작은 확인하지 못했으니 작은 테스트로 재현해 보세요.

2. **동시 대출에서 진 요청이 500이 되고, 재시도도 없습니다.**
   - 자리: `app/db.py:9`(SERIALIZABLE), `app/services/loans.py`의 `lend`(40~48줄, `flush`), `app/main.py:35~41`.
   - 까닭: 직렬화 실패(40001, `OperationalError`)나 `CHECK` 위반(`IntegrityError`)을 잡거나 재시도하는 코드가 없습니다. `RefusedLoan`만 422로 바뀝니다. 하나만 서는 결과는 지켜지지만, 진 쪽은 권수가 남아 있어도 500을 받습니다. `post_loan` docstring의 "422 로 이름을 말한다"와도 어긋납니다.
   - 재시도는 새 세션과 새 트랜잭션으로 해야 합니다. 소진되면 409나 503으로 응답하는 쪽이 맞습니다.

3. **`downgrade`의 보호가 `loans`에만 걸려 있습니다.**
   - 자리: `migrations/0001_initial.py`의 `downgrade`(39~46줄).
   - 까닭: `loans`가 비어 있으면 `members`와 `books`를 데이터째 DROP합니다. 주석의 "지우면 되살릴 길이 없다"는 논리가 나머지 두 표에도 똑같이 적용됩니다. 회원을 지우지 않는다는 `docs/schema.md`의 원칙과도 어긋납니다.

4. **마이그레이션의 외래키 열에 타입이 없을 수 있습니다.**
   - 자리: `migrations/0001_initial.py:30~31`(`loans.book_id`, `loans.member_id`).
   - 까닭: `op.create_table`은 별도 MetaData를 쓰므로 `ForeignKey("books.id")`만으로는 열 타입을 추론하지 못합니다(`NullType`). 그러면 `upgrade`가 실패할 수 있습니다. 모델(`app/models.py:34~35`)은 같은 MetaData 안이라 문제가 없습니다.
   - 확신: 75% 정도입니다. 실행으로 확인하지 못했습니다.

## 낮음 / 참고

5. **`downgrade`의 확인과 DROP 사이에 락이 없습니다.** `migrations/0001_initial.py:42~44`. 앱이 떠 있으면 그 사이에 들어온 대출 행이 지워질 수 있습니다. 확신은 낮습니다.
6. **`rollback()` 실패 시 원래 예외가 가려지고 로그도 없습니다.** `app/main.py`의 `session_scope` `except` 블록. 저장소 전체에 로깅이 없어서, 500·커밋 실패·롤백 모두 흔적이 남지 않습니다.
7. **중복 대출과 `loaned_on`을 막지 않습니다.** `app/services/loans.py`의 `lend`와 `app/models.py`의 `Loan`. 같은 회원이 같은 책을 연달아 빌려도 거절되지 않고 유일 제약도 없습니다. `loaned_on`은 클라이언트 값을 그대로 쓰므로 과거나 먼 미래 날짜도 저장되고, `due_on`이 그에 따라 정해집니다. 의도된 범위 밖일 수 있습니다.
8. **`alembic.ini`와 `migrations/env.py`가 없습니다.** 지금 상태로는 마이그레이션을 실행할 수 없고, 3·4번도 실행으로 확인할 수 없습니다. 의도적으로 뺀 조각이면 무시하세요.
9. **`loans.book_id`와 `loans.member_id`에 인덱스가 없습니다.** 모델과 마이그레이션 양쪽 모두입니다. PostgreSQL은 외래키에 인덱스를 자동으로 만들지 않아서, 반납이나 회원별 조회가 늘면 성능 문제가 됩니다. 확신은 낮습니다.

## 문제 없다고 본 것

- 원칙 2는 지켜집니다. `CHECK (available_copies >= 0)`이 모델(`app/models.py:20`)과 마이그레이션(`migrations/0001_initial.py:25`)에 같은 이름으로 있습니다.
- 원칙 1은 DB 안에서는 지켜집니다. `lend`가 같은 세션에서 권수 차감과 대출 추가를 하고, 커밋과 롤백은 `session_scope` 한 곳이 맡습니다.
- `RefusedLoan`은 쓰기 전에 나므로, 거절 경로에서 롤백해도 잘못 남는 데이터는 없습니다.
- 모델과 마이그레이션의 표·열·제약 이름은 4번을 빼면 일치합니다.

우선순위는 1번(재현으로 확인), 2번, 3번 순입니다.
