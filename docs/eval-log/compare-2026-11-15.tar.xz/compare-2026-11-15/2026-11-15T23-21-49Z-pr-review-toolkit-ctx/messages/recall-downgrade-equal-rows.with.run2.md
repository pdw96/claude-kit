<!-- pr-review-toolkit + 맥락 · 맞힘 · 떴는가 True · 비용 0.36876069999999994 -->

두 리뷰 에이전트(code-reviewer, silent-failure-hunter)와 제가 직접 읽은 내용을 합쳤습니다. 코드는 고치지 않았고 실행도 하지 않았습니다.

CLAUDE.md는 INTENT.md의 Not과 「하지 않을 일」에 적힌 것을 결함으로 올리지 말라고 합니다. 그런데 INTENT.md가 저장소에 없습니다. 그래서 그 제외 규칙은 적용하지 못했고, 아래 중 의도된 선택이 있을 수 있습니다. 로컬 전용 값으로 보이는 것은 없었습니다.

## 주요 결함

**1. `migrations/versions/0007_shipping_zone.py`, `downgrade()`의 `DELETE FROM common_codes`(62줄): 운영자가 만든 코드 줄을 지울 수 있습니다.**
- `upgrade()`는 같은 키가 이미 있으면 넣지 않고 건너뜁니다. 건너뛴 줄은 운영자 것입니다.
- `downgrade()`의 `changed` 검사는 값(name, sort_order, is_active)이 심은 값과 같은지만 봅니다.
- 운영자가 값까지 똑같이 만든 `METRO`, `REGION`, `ISLAND`는 이 검사를 통과하고 지워집니다.
- 값이 같다고 이 리비전이 심은 줄이라는 근거는 되지 않습니다. 출처를 기록하는 칸이나 표가 없습니다.
- docs/schema.md 원칙 1(남의 것이 섞여 있으면 지우지 않고 멈춘다)을 어깁니다.

**2. 같은 파일, `downgrade()`의 `DELETE FROM code_groups`(63줄): 그룹 줄은 검사 없이 지웁니다.**
- `upgrade()`는 운영자가 먼저 만든 `SHIPPING_ZONE` 그룹이 있으면 넘어갑니다.
- `downgrade()`에는 그룹 줄의 name, description, 출처를 보는 멈춤 검사가 없습니다.
- 운영자가 만들었거나 설명을 고친 그룹도 지워집니다. 원칙 1을 어깁니다.
- 61줄 주석 "위의 멈춤 검사가 지킨다"는 그룹 줄에는 맞지 않습니다.

**3. 같은 파일, `downgrade()` 36~64줄: 검사와 삭제 사이에 잠금이 없습니다.**
- `used`, `extra`, `changed` 검사는 잠금 없는 `SELECT count(*)`입니다.
- 그 틈에 운영자가 코드를 더하거나 고치면, 삭제는 검사한 집합이 아니라 `group_code` 전체를 지웁니다.
- 앱이 그 사이에 `orders.shipping_zone`에 값을 쓰면 `drop_column`이 그 값을 버립니다.
- 검사 통과 뒤에 생긴 운영자 데이터는 "멈춘다"는 보장 밖에 있습니다.
- 삭제 조건을 검사한 키로 좁히고, 관련 표에 잠금을 거는 방법이 있습니다.

## 그 밖의 결함

**4. `upgrade()` 21~30줄: 건너뛴 줄을 알리지 않습니다.**
- `WHERE NOT EXISTS`는 건너뛰어도 로그나 경고가 없습니다.
- 운영자가 먼저 만든 줄의 값이 심으려던 값과 달라도 리비전은 성공으로 끝납니다.
- 어긋남은 나중에 downgrade가 멈출 때에야 드러납니다.

**5. `app/models.py` 31줄 `Order.shipping_zone`, 0007의 `add_column`, docs/schema.md 7줄: 참조 무결성이 어디에도 없습니다.**
- 문서는 이 칸이 `SHIPPING_ZONE` 코드를 가리킨다고 하지만, 실제로는 FK나 CHECK가 없는 `String(30)`입니다.
- 없는 코드나 비활성 코드가 주문에 들어갈 수 있고, 코드를 지워도 그 코드를 쓰는 주문이 남습니다.
- `common_codes`의 키가 복합키 `(group_code, code)`라 FK를 걸기 어려운 설계상 선택일 수 있습니다. 그렇다면 문서의 "가리킨다"를 고치거나 별도 보장이 필요합니다.
- 확신도는 낮습니다(약 60).

**6. 0007 `downgrade()` 전체: 되돌림이 트랜잭션 DDL에 기대는데, 그렇다고 선언하지 않았습니다.**
- 삭제 두 번 뒤에 `drop_column`이 실패하면 코드는 지워지고 칸은 남는 반쪽 상태가 됩니다. 트랜잭션 DDL이 없는 환경에서 그렇습니다.
- env.py가 저장소에 없어서 `transactional_ddl`과 `transaction_per_migration` 설정은 확인하지 못했습니다.
- `VALUES ... AS v(...)`와 `IS DISTINCT FROM` 행 비교는 Postgres 전용인데, 지원 DB가 문서에 없습니다.
- 다른 DB에서는 검사 단계에서 실패합니다. 삭제 전이라 데이터는 안전합니다.

**7. `migrations/versions/0006_orders.py`, `downgrade()`: 항상 `RuntimeError`를 냅니다.**
- 의도된 정지로 읽혀서 결함이라기보다 참고 사항입니다.
- 0006이 만든 `common_codes`는 운영자 데이터가 쌓이는 표입니다. 되돌릴 방법이 없다는 선택이 의도인지 문서에 남기는 편이 안전합니다.

**8. 0007 `downgrade()` 44줄: SQL을 f-string과 `repr()`로 조립합니다.**
- 지금은 모듈 상수라 주입 위험은 없습니다.
- `repr()`은 SQL 인용 규칙이 아니라서, 코드값에 `'`나 `\`가 들어가면 깨질 수 있습니다. 바인드 파라미터가 낫습니다.
- 중요도는 낮습니다.

**9. 0007 `upgrade()` 21~30줄: 존재 검사와 삽입이 동시 실행에 안전하지 않습니다.**
- 운영자가 같은 키를 동시에 넣으면 한쪽이 PK 위반으로 실패합니다. 오류가 나므로 조용한 실패는 아닙니다.
- 중요도는 낮습니다. `ON CONFLICT DO NOTHING`과 함께 4번의 알림을 정하면 됩니다.

## 일치하는 부분

모델(`app/models.py`)과 마이그레이션의 컬럼 정의(`code_groups`, `common_codes`, `orders.id`, `shipping_zone`)는 서로 일치합니다.

1~3번이 가장 중요합니다. 원칙 1을 지키려고 만든 멈춤 검사에 구멍이 있다는 점이 공통입니다.
