#!/usr/bin/env bash
# 값싼 실험 — 함정 둘에서 세 팔: vibe-audit · 플러그인 없음 · 플러그인 없음 + 감사자의 규칙 문장만.
set -u
cd /home/user/claude-kit
S=$(dirname "$0")
./scripts/run-compare.sh vibe-audit --case 'trap-*' -j 3 > "$S/arm-vibe.log" 2>&1; echo "vibe-audit 종료 $?"
./scripts/run-compare.sh none --case 'trap-*' -j 3 > "$S/arm-none.log" 2>&1; echo "none 종료 $?"
cp compare/arms.tsv "$S/arms.tsv.orig"
trap 'cp "$S/arms.tsv.orig" compare/arms.tsv' EXIT
printf 'none\tinternal\t%s\n' '기준 문서를 가릴 때 — 의도 문서는 하나입니다(마스터플랜 「가리키는 문서」의 의도 줄 → `INTENT.md` → `PRD.md` 순). 그 밖에 남은 `PRD.md` 는 기준이 아닙니다. 「하지 않을 일」은 의도 문서와 검토하는 변경이 속한 조각의 요구사항 것만 겁니다 — 다른 조각 것은 그 조각에만 걸립니다.' >> compare/arms.tsv
printf 'none\tsecrets\t%s\n' '자리표시자와 진짜를 가르세요 — 아무것에도 붙지 않는 예시 값이나 로컬 전용 개발 비밀번호(컴포즈 · CI 서비스 컨테이너)는 그 자체로 결함이 아닙니다. 볼 것은 그 값으로 밖에서 닿는 자원에 붙을 수 있는가, 같은 값이 프로덕션 경로에도 쓰이는가입니다.' >> compare/arms.tsv
./scripts/run-compare.sh none --case 'trap-*' -j 3 > "$S/arm-sentences.log" 2>&1; echo "문장 팔 종료 $?"
