<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.16601860000000002 -->

`audit-secrets` 감사자를 저장소 전체에 돌렸습니다. 부적합 1건, 확인불가 2건, 관찰 1건이 나왔습니다. 코드는 고치지 않았고 감사자의 보고서를 파일로 저장하지도 않았습니다. 이 결과는 감사자 보고를 그대로 옮긴 것이고, 제가 소스를 다시 확인하지는 않았습니다.

## 결함

**NC-1 · `/admin/users` 에 인증·인가가 없음 (심각도 높음)**
- 자리: `app/routes.py:22-24`, `admin_users`
- 까닭:
  - 같은 `/admin/*` 의 다른 라우트는 `Depends(require_admin)` 을 쓰는데, 이 함수에만 `Depends` 가 없습니다.
  - 토큰 없이 `GET /admin/users` 를 호출하면 `db.users.all()` 결과가 반환되어, 익명 사용자가 전체 사용자 목록을 읽을 수 있습니다.
  - `db` 모듈이 저장소에 없어 어떤 필드가 나가는지는 모릅니다. 감사자는 이메일이나 해시 같은 개인정보가 있다고 가정해 판정했습니다.
- 제안:
  - `user=Depends(require_admin)` 을 추가합니다.
  - 또는 `APIRouter(dependencies=[Depends(require_admin)])` 로 `/admin` 접두사를 묶어 새 라우트에서 같은 누락이 반복되지 않게 합니다.

## 확인불가 (소스가 없어 판정 못 함)

**U-2 · 토큰 검증의 안전성** — 부적합과 같이 취급합니다.
- 자리: `app/auth.py:7`, `decode`
- 까닭:
  - `decode` 와 `db` 의 정의나 import 가 저장소에 없습니다. `app/main.py` 도 없습니다.
  - 서명 검증, 만료 검사, 알고리즘 고정(`none` 거부), 서명 키의 출처를 볼 수 없습니다.
  - `decode` 가 payload 만 파싱한다면 모든 인증이 무력해집니다.
  - 앱이 붙이는 라우터와 미들웨어(CORS 포함)도 확인할 수 없습니다.
  - `.env.example:2` 의 `SESSION_SECRET` 은 이를 쓰는 코드가 없습니다.
- 필요한 것: 저장소 소유자가 `decode` 구현과 `app/main.py` 를 제공해야 합니다.

**U-1 · 프로덕션과 개발 설정의 분리**
- 자리: `docker-compose.yml:6-9`, `app/routes.py:9`, `README.md:4`
- 까닭:
  - 코드는 `DATABASE_URL` 을 환경변수에서 읽어서 문제가 없습니다.
  - 프로덕션의 `DATABASE_URL` 과 `SESSION_SECRET` 이 어떻게, 어떤 값으로 주입되는지는 저장소에서 검증할 수 없습니다.
  - 프로덕션 DB 비밀번호가 `devpassword` 와 다른지도 알 수 없습니다.
- 필요한 것: 배포·인프라 담당자의 확인.

## 관찰 (부적합 아님)

**OB-1 · `set_role` 의 `role` 값 미검증**
- 자리: `app/routes.py:27-29`
- 까닭:
  - `role: str` 을 허용 값 검사 없이 `db.users.set_role` 에 넘깁니다.
  - 호출자가 admin 으로 한정되어 있어 권한 우회는 아닙니다.
  - 임의 값이 저장돼도 `auth.py:11` 의 `!= "admin"` 비교에서 비관리자로 처리되어 안전한 쪽으로 실패합니다.

## 이상 없음으로 판정한 것
- 소스 내 시크릿 리터럴은 없습니다.
  - `docker-compose.yml:8` 의 비밀번호는 127.0.0.1 에만 바인딩한 로컬 개발용입니다.
  - `.env.example` 은 자리표시자입니다.
- `/orders`(`app/routes.py:14`)는 `user.id` 로 조회하므로 소유자 확인이 됩니다.
- 우회용 임시 코드나 디버그 플래그는 없습니다.

## 범위 밖
- 스키마·마이그레이션, 테스트·CI, 관측·롤백, API 호환성은 다른 감사자(`audit-data`, `audit-quality`, `audit-ops`, `audit-contract`)의 담당입니다.
- 감사자는 README 가 가리키는 `app/main.py` 가 없다는 점을 `audit-internal` 에 넘겼습니다.
