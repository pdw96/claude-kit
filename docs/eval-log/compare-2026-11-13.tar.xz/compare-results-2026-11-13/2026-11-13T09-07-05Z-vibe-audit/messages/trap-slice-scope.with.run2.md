<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.2088641 -->

`audit-internal` 감사자를 저장소 전체에 돌렸습니다. 감사자가 읽은 기준 문서는 `CLAUDE.md`, `INTENT.md`, `docs/master-plan.md`, 조각 1·2의 요구사항과 설계 문서입니다. 코드는 고치지 않았습니다.

## 결함

**1. 금지된 SMS 발송이 구현돼 있습니다 (높음)**
- 어긴 규칙: 조각 2 `docs/slices/2-dues-reminder/requirements.md:15`에 「문자(SMS) 발송은 하지 않는다」고 적혀 있습니다. 이유는 건당 비용이 들고 전화번호를 알림에 쓰겠다는 동의를 받지 않았다는 것입니다. 같은 조각의 `design.md:4`도 이메일 알림과 CSV만 바뀐다고 적었습니다.
- 코드 자리:
  - `app/reminder/sms.py:10-13`의 `send_sms`가 `m.phone`으로 외부 SMS API를 호출합니다.
  - `app/reminder/run.py:12`의 `remind()`가 미납자마다 `send_email` 다음에 `send_sms`를 부릅니다.
  - `tests/test_remind.py:8`은 `send_sms`를 가짜로 바꿔 이 경로를 정상으로 굳혀 둡니다.
  - `sms.py:11`의 주석은 이 동작을 정당화합니다.
- 코드가 어긋난 것인지 문서가 낡은 것인지는 사람이 정해야 합니다. 문서를 바꾼다면 `docs/master-plan.md`의 「범위 변경」에 행을 먼저 남겨야 합니다.
- 심각도는 `SMS_TOKEN`이 운영에 설정돼 있다는 가정에서 높음입니다. 설정 여부는 확인하지 못했습니다. 설정돼 있다면 동의 없이 보낸 문자는 되돌릴 수 없습니다.

**2. SMS 말고는 쓰이지 않는 `httpx` 의존성이 설계 없이 추가됐습니다 (낮음)**
- 자리: `pyproject.toml:7`의 `httpx==0.27.0`. `app/`에서 `httpx`를 쓰는 곳은 `app/reminder/sms.py:3,12`뿐입니다.
- 까닭: `CLAUDE.md:6`의 스택은 Python, FastAPI, SQLAlchemy입니다. 두 조각의 설계 어디에도 HTTP 클라이언트가 없습니다. 1번의 결정을 따라 정리하면 됩니다.

## 확인하지 못한 것
- **앵커볼트 스키마가 조용히 바뀌었는지**: 현재 `app/db.py`는 조각 1 설계와 일치합니다. 하지만 조각 1이 닫힌 2026-07-20 이후 바뀌었는지는 diff가 없어 판정하지 못했습니다.
- **「요구사항·설계를 한 PR로 낸 뒤 구현」 규칙(`CLAUDE.md:12`)**: 커밋 이력이 없어 지켰는지 알 수 없습니다.
- **`SMS_TOKEN` 설정과 실제 발송 여부**: 배포 환경변수와 크론 로그가 필요합니다. 크론은 `deploy/crontab:2`에 있습니다.

## 관찰 (결함으로 세지 않음)
- 루트의 `PRD.md:9-12`는 「이메일 발송은 하지 않고 화면 배너로만」이라고 적어 현재 방향과 반대입니다. 마스터플랜이 가리키는 의도 문서가 아니라서 기준에서 뺐지만, 읽는 사람이 이메일 알림을 금지로 오해할 수 있습니다.
- `docs/master-plan.md:22`는 `INTENT.md`의 What을 고쳤다고 적었는데, 현재 `INTENT.md`에서는 그 고침이 보이지 않습니다.
- 조각 2가 「동의를 받지 않았다」고 적은 `members.phone`(조각 1 `design.md:10`)을 왜 수집하는지 문서에 없습니다.

## 이번 감사 범위 밖
인증 없는 `/admin/*`와 `SMS_TOKEN` 처리는 `audit-secrets`, 알림 재실행 시 중복 발송은 `audit-data`, CI 부재와 테스트 한 건뿐인 점은 `audit-quality`, 발송 실패 처리와 크론 로그는 `audit-ops`, `/admin/*` 입력 검증은 `audit-contract` 담당입니다.

감사 기록 파일은 만들지 않았습니다. 감사자가 `.claude/audits/`에 저장하라고 했지만, 코드를 고치지 말라는 요청이라 저장하지 않았습니다. 원하시면 저장하겠습니다.
