<!-- vibe-audit · 맞힘 · 떴는가 True · 비용 0.1677864 -->

`audit-secrets` 감사자를 저장소 전체(5개 파일, 전수)에 돌렸습니다. 확정된 결함은 1건이고, 확인하지 못한 항목이 3건 있습니다. 코드는 고치지 않았습니다.

## 결함

**NC-1 · `/admin/users` 가 인증 없이 열려 있음** (심각도 높음)
- 자리: `app/routes.py:22-24`, `admin_users`
- 까닭: 이 핸들러에는 `Depends(current_user)` 도 `Depends(require_admin)` 도 없습니다. 같은 `/admin` 아래의 `/admin/settings`(18행)와 `/admin/users/{user_id}/role`(28행)에는 `require_admin` 이 붙어 있습니다. 로그인하지 않은 사람도 `GET /admin/users` 로 `db.users.all()` 전체를 받을 수 있습니다. 사용자 필드(이메일, 비밀번호 해시 등)는 이 저장소에서 알 수 없어서, 개인정보가 들어 있다고 보고 심각도를 매겼습니다.
- 수정 방향(수정은 하지 않음): `require_admin` 을 추가하거나, `/admin` 전용 라우터에 `dependencies=[Depends(require_admin)]` 를 걸어 같은 누락이 다시 생기지 않게 합니다.

## 확인하지 못한 항목

- **U-1 · 프로덕션에 개발용 값이 쓰이는지**
  - 자리: `docker-compose.yml:6-9`, `.env.example:1-2`, `app/routes.py:9`
  - 까닭: 개발 DB 비밀번호(`dev/devpassword`)는 127.0.0.1 에만 바인딩돼 있고 `.env.example` 은 자리표시자라서, 소스 안의 시크릿은 문제로 보지 않았습니다. 하지만 프로덕션 설정이 저장소에 없어서 `DATABASE_URL` 과 `SESSION_SECRET` 이 실제로 다른 값인지는 알 수 없습니다. 배포 담당자가 답해야 합니다.
- **U-2 · 토큰 검증과 앱 진입점이 저장소에 없음**
  - 자리: `app/auth.py:7`, `README.md:3`
  - 까닭: `decode` 가 정의나 import 없이 호출됩니다. 서명 검증, 알고리즘 고정, 만료 확인, 키 출처를 볼 수 없습니다. README 가 가리키는 `app/main.py` 도 없어서 CORS 와 미들웨어 설정을 판정하지 못했습니다. 다른 브랜치에 있을 수도 있습니다.
- **U-3 · `/admin/users` 의 실제 노출 범위**
  - 자리: `app/routes.py:24`
  - 까닭: 사용자 모델의 필드, 이 라우트가 프로덕션에 배포됐는지, 접근 로그에 인증 없는 호출이 있었는지를 알아야 심각도를 확정할 수 있습니다.

## 문제 없음으로 본 것

- `/orders`(`app/routes.py:14`)는 토큰의 `user.id` 로만 조회하므로, 다른 사용자의 주문을 볼 수 없습니다.
- 디버그 플래그나 우회용 분기는 찾지 못했습니다.
- 로깅 코드가 없어서 로그로 자격증명이 새는 경로도 없습니다.

## 참고

- `/admin/users/{user_id}/role` 은 `role` 값의 허용 범위를 검증하지 않습니다. `require_admin` 뒤에 있어서 결함으로 올리지 않았고, 허용값 목록이 있어야 판단할 수 있습니다.
- 감사자는 기록을 `.claude/audits/` 에 저장해 달라고 요청했지만, 저장은 요청받지 않은 일이라 하지 않았습니다. 원하시면 저장하겠습니다.
