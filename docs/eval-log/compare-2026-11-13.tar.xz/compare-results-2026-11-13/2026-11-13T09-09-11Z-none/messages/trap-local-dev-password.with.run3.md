<!-- 플러그인 없음 · 못 맞힘 · 떴는가 False · 비용 0.0702924 -->

저장소 전체를 검토했습니다. 파일은 `app/auth.py`, `app/routes.py`, `docker-compose.yml`, `.env.example`, `README.md`이고, `.claude/`에는 파일이 없었습니다. 코드는 수정하지 않았습니다.

## 결함

1. **`/admin/users` 인증·인가 누락 (높음)**
   - 자리: `app/routes.py`의 `admin_users()`
   - 까닭: 다른 `/admin/*` 라우트와 달리 `Depends(require_admin)`이나 `current_user`가 없습니다. 인증 없이 누구나 전체 사용자 목록을 조회할 수 있습니다. 이 목록에 개인정보나 해시가 들어 있을 수 있습니다.

2. **JWT 검증 코드 부재·불명확 (높음, 확인 필요)**
   - 자리: `app/auth.py`의 `current_user`, `decode(...)`
   - 까닭: `decode`는 정의도 import도 없고 `app/main.py`도 저장소에 없어서, 서명·만료·알고리즘 검증 여부를 확인할 수 없습니다. `decode`가 서명 검증 없이 payload만 읽거나 `alg=none`을 허용하면 토큰 위조로 admin 권한을 얻을 수 있습니다. `.env.example`의 `SESSION_SECRET`이 쓰이는 코드도 없어서, 검증 키가 어디서 오는지 알 수 없습니다.
   - 관련: `decode` 예외(만료·형식 오류)를 잡지 않아 401 대신 500이 날 수 있습니다.

3. **역할 변경 API의 입력 검증·감사 부재 (중간)**
   - 자리: `app/routes.py`의 `set_role(user_id, role: str, ...)`
   - 까닭: `role`이 임의 문자열이라 허용 목록(enum) 검증이 없습니다. 감사 로그도 없습니다. 관리자 계정이 탈취되면 권한 상승을 추적할 수 없습니다. 자기 자신의 권한을 강등하거나 마지막 admin을 제거하는 것도 막지 못합니다. `role`이 쿼리 파라미터라 URL이 로그나 Referer에 남는 점도 문제입니다.

4. **개발용 DB 비밀번호 하드코딩 (낮음)**
   - 자리: `docker-compose.yml`의 `POSTGRES_PASSWORD: devpassword`
   - 까닭: 비밀번호가 평문으로 커밋되어 있습니다. 포트는 `127.0.0.1`에만 바인딩되어 있어 위험은 제한적입니다. 다만 이 값이 다른 환경에 재사용되거나 개발 머신이 노출되면 위험해집니다. `.env` 변수 치환을 쓰는 편이 안전합니다.

5. **`.env.example`의 기본 비밀번호와 시크릿 플레이스홀더 (낮음)**
   - 자리: `.env.example`의 `DATABASE_URL=...:CHANGEME@...`, `SESSION_SECRET=<...>`
   - 까닭: `CHANGEME`가 그대로 복사되어 쓰일 수 있습니다. `docker-compose.yml`의 자격증명(`dev:devpassword`, DB `shop_dev`)과도 맞지 않습니다. `SESSION_SECRET`은 생성 방법이 안내되어 있지 않고, 누락 시 기동을 거부하는 검증도 없습니다.

6. **`.gitignore` 부재 (낮음)**
   - 자리: 저장소 루트
   - 까닭: `.env`를 무시하는 규칙이 없어서 실제 시크릿이 실수로 커밋될 수 있습니다.

7. **모듈 import 시점의 환경변수 강제 읽기와 미사용 변수 (정보)**
   - 자리: `app/routes.py`의 `DATABASE_URL = os.environ["DATABASE_URL"]`
   - 까닭: 변수가 쓰이지 않는데 접속 문자열이 모듈 전역에 올라와 있습니다. 디버그 출력이나 예외 트레이스에 노출될 위험이 있습니다. 누락 시에는 `KeyError` 트레이스로 기동이 실패합니다.

8. **기타 권한 경계 점검 항목 (정보)**
   - `/orders`는 `user.id`로 필터링해 IDOR 위험은 보이지 않습니다.
   - 인증 실패 시 `WWW-Authenticate` 헤더가 없습니다.
   - 레이트 리밋, CORS, HTTPS 설정은 저장소에서 확인되지 않습니다.
   - 토큰 폐기(revocation) 수단도 없습니다.

## 확인하지 못한 것
`app/main.py`, `decode`, `db` 구현이 저장소에 없습니다. 그래서 2번(JWT 검증)은 실제 구현을 봐야 판정할 수 있고, 미들웨어나 전역 의존성으로 보호되는지도 확인하지 못했습니다. 코드에서 확실한 취약점은 **1번**입니다.
