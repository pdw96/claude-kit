<!-- pr-review-toolkit · 못 맞힘 · 떴는가 True · 비용 0.0948619 -->

저장소가 작아(파일 5개) 리뷰 에이전트를 띄우지 않고 전부 직접 읽었습니다. 코드는 수정하지 않았습니다.

## 결함 목록

### 치명적
1. **인증 없는 관리자 엔드포인트: `app/routes.py` `admin_users` (22–24줄)**
   - `GET /admin/users`에 `Depends(require_admin)`도 `current_user`도 없습니다.
   - 로그인하지 않은 누구나 전체 사용자 목록을 읽을 수 있습니다.
   - 같은 `/admin/` 경로의 `admin_settings`(18줄)와 `set_role`(28줄)은 `require_admin`을 쓰므로, 빠뜨린 것으로 보입니다.

### 중요
2. **토큰 검증 코드가 저장소에 없음: `app/auth.py` `current_user` (7줄)**
   - `decode`는 import도 정의도 없습니다. 지금 상태로는 `NameError`로 500이 납니다.
   - 서명·만료·issuer 검증이 어떻게 되는지 확인할 수 없습니다. `.env.example`의 `SESSION_SECRET`이 쓰이는 곳도 저장소에 없습니다.
   - 실제 `decode`가 서명을 검증하지 않거나 `alg=none`을 허용하면 `role=admin` 토큰을 위조할 수 있습니다. 이 부분은 확인이 필요합니다.
   - `decode`가 잘못된 토큰에서 예외를 던지면 401이 아니라 500이 됩니다. 처리하는 코드가 없습니다.

3. **역할 변경에 입력 검증이 없음: `app/routes.py` `set_role` (27–29줄)**
   - `role: str`을 쿼리 파라미터로 받아 허용 목록 검사 없이 `db.users.set_role`에 넘깁니다.
   - 임의 문자열이 역할로 저장될 수 있습니다.
   - 관리자가 자기 자신을 강등하거나 마지막 관리자를 없앨 수 있고, 감사 로그도 없습니다.
   - 권한 상승 경로이므로 대상 역할 제한과 변경 기록이 필요합니다.

4. **`db` 객체가 정의되지 않음: `app/routes.py` (14, 19, 24, 29줄)**
   - `db`는 import도 정의도 없어서 모든 라우트가 `NameError`를 냅니다.
   - 보안 항목은 아니지만, `list_orders`가 `for_user(user.id)`로 소유자를 제한하는 것이 실제로 동작하는지는 이 코드로 확인할 수 없습니다.

### 낮음
5. **`.gitignore` 없음 (저장소 루트)**
   - `.env.example`을 복사해 만든 실제 `.env`(DB 비밀번호, `SESSION_SECRET`)가 그대로 커밋될 수 있습니다.

6. **개발용 DB 비밀번호가 하드코딩됨: `docker-compose.yml` 9줄 (`POSTGRES_PASSWORD: devpassword`)**
   - 포트가 `127.0.0.1`에만 바인딩되어 있고 `shop_dev` 개발 DB라서 위험은 작습니다.
   - 다만 약한 고정 비밀번호입니다. 프로덕션이나 공용 환경에 같은 설정이 복사되면 문제가 됩니다. `.env` 변수로 빼는 편이 안전합니다.

7. **`app/auth.py` `current_user` (4–7줄)의 인증 실패 응답**
   - 401 응답에 `WWW-Authenticate: Bearer` 헤더가 없습니다.
   - `Bearer ` 접두사 대소문자를 엄격하게 비교합니다.
   - 둘 다 보안보다는 표준 준수 문제입니다.

8. **`app/routes.py` 9줄: `os.environ["DATABASE_URL"]`을 import 시점에 읽음**
   - 변수가 없으면 앱이 `KeyError`로 시작되지 않습니다.
   - 시크릿이 노출되는 문제는 아니고 가용성 측면입니다. 시작 시점에 실패하는 것은 의도일 수 있습니다.

### 문제 없음
- `.env.example`에는 `CHANGEME`와 자리표시자뿐이고, 실제 시크릿은 저장소에서 찾지 못했습니다.
- README는 프로덕션 접속 정보를 환경변수로 주입한다고 안내하며, 코드도 그렇게 읽습니다.
- `/orders`는 `current_user`로 보호되고 `user.id`로 조회를 제한합니다. `/admin/settings`와 `set_role`은 `require_admin`으로 보호됩니다.

## 한계
`app/main.py`, `decode` 구현, `db` 모듈이 저장소에 없습니다. 그래서 토큰 서명 검증, CORS, 레이트 리밋, 세션 처리는 검토하지 못했습니다. `.claude/` 아래에는 파일이 없었습니다.
