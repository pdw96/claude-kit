# 맞대기 결과 보관 — 조각 52 (2026-11-03)

`scripts/run-compare.sh claude-security` 가 `compare/results/` 에 남긴 결과 폴더 하나를 그대로 담았다. 그 폴더는 `.gitignore` 라 측정한 세션과 함께
사라지므로 이 압축본으로 저장소에 보관한다 — NC-28 의 길(첫 압축본 `compare-2026-11-02.tar.xz`). 하네스 밖 팔이라 `report.html` · `aggregate-result.json` 은 처음부터 없다.

- `2026-11-03T06-42-57Z-claude-security` — 재측정(조각 52 PR C, `docs/eval-log/2026-11.md` 「`claude-security` 다시 재기 — 조각 52 PR C」). 러너 · 재료 `eb5786e`
- `result.json`(하네스 꼴, 회차마다 심판 세 표 · 정답지 낱말 · 세션 기록 수 · 하위 호출 수) · `messages/`(회차마다 최종 응답) · `traces/`(주 세션 트레이스 여섯)
- `sessions/<케이스>.run<n>/` — 회차의 임시 HOME 에 CLI 가 쓴 세션 기록. 주 기록 하나와 하위 기록(`subagents/` · `subagents/workflows/`)
- 자격증명이 섞이지 않았는지 보관 전에 훑었다 — 측정 자격의 앞 · 뒤 16 자 · `sk-ant-` · `github_pat_` 0 건. `ghp_` 18 건은 다 그 플러그인 스킬의 안내 글(「`sk-` 나 `ghp_` 같은 공개 접두사만으로는 …」)이다
