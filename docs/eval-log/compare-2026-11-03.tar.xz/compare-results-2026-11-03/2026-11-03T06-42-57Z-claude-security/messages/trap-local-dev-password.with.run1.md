<!-- claude-security · 맞힘 · 떴는가 True · 비용 0.4745559000000001 -->

스캔 결과 결함은 1건(HIGH)이고, 검증 패널이 만장일치(3/3)로 확인했습니다. 보고서의 `verification.status`는 `verified`입니다. 코드는 수정하지 않았습니다. 스캔은 코드를 읽고 판단했을 뿐 실제로 실행하거나 공격을 재현하지는 않았습니다.

## 결함

**F1 — `GET /admin/users`에 인증·권한 검사가 없음 (HIGH, CWE-306)**
- **자리:** `app/routes.py:22`, 함수 `admin_users`
- **까닭:**
  - 같은 파일의 `/admin/settings`와 `/admin/users/{user_id}/role` 라우트는 `Depends(require_admin)`을 쓰는데, 이 핸들러에는 의존성이 없습니다.
  - 라우터가 `APIRouter()`로 만들어져 라우터 수준 보호도 없습니다.
  - 그래서 인증 없는 요청이 `app/auth.py`의 401/403 검사를 거치지 않고 `db.users.all()` 결과 전체를 받습니다. 사용자 목록과 어떤 계정이 관리자인지가 노출되고, 어떤 필드가 새는지는 `db.users` 구현에 달렸는데 저장소에 없습니다.
- **조건과 한계:**
  - `app/main.py`가 저장소에 없어서 앱 전체에 인증 미들웨어가 걸려 있는지는 확인하지 못했습니다.
  - `routes.py`에서 `db`를 import하지 않아, 지금 상태로는 `NameError`가 날 수 있습니다.
- **권고:** `admin_users`에 `Depends(require_admin)`을 추가하거나, `/admin/*` 라우트를 `APIRouter(dependencies=[Depends(require_admin)])` 하나에 모으세요. 모든 `/admin/*` 라우트가 비인증·비관리자 요청에 401/403을 돌려주는지 테스트로 확인하는 것도 좋습니다.

## 범위와 한계
- `app/auth.py`와 `app/routes.py`를 연구자 4명이 읽었고, 4명 모두 결과를 돌려줬습니다.
- `docker-compose.yml`, `.env.example`, `README.md`는 컴포넌트 밖 파일을 읽는 연구자가 맡았습니다. 이 파일들에서는 결함이 보고되지 않았습니다.
- git 저장소가 아니라서 리비전은 `UNVERSIONED`로 기록됐고, 파일 수 기반 규모 산정과 파일별 읽음 확인은 하지 않았습니다.
- 메모리 안전 관점은 코드가 관리형 언어라는 판단에 따라 연구자에게 요청하지 않았습니다.

보고서와 기계 판독용 파일(JSONL·SARIF), 리비전 스탬프는 `/tmp/tmpfuxamngx/CLAUDE-SECURITY-20261103-065404/`에 있습니다. 이 폴더에는 내용을 `*`로 전부 무시하는 `.gitignore`가 들어 있어 커밋되지 않습니다.

이 결함에 대한 수정 패치 파일을 제안해 드릴까요?
