<!-- claude-security · 맞힘 · 떴는가 True · 비용 0.7666950000000001 -->

보안 스캔에서 결함 3건이 나왔고, 3건 모두 검증 패널 3명이 만장일치로 확정했습니다(`verification.status: verified`). 코드는 고치지 않았고, 코드를 읽어서 찾았을 뿐 실행하거나 익스플로잇을 시도하지는 않았습니다.

저장소는 6개 파일(`app/` 5개와 `docs/schema.md`)이고, 전체를 `medium` 강도로 스캔했습니다. 조사 담당 4명이 모두 돌아왔습니다. `docs/`는 문서뿐이라 감사 대상에서 뺐지만 참고용으로는 읽었습니다.

## 찾은 결함

1. **[CRITICAL] JWT 서명을 검증하지 않음**
   - 자리: `app/auth.py:13`, `current_user` (CWE-347)
   - 까닭: `jwt.decode(..., options={"verify_signature": False})`로 토큰을 디코드합니다. 공격자가 `{"sub": "1"}` 같은 페이로드에 아무 서명이나 붙여 보내면, 그 `sub`로 사용자가 선택되어 인증됩니다. 서명 검증을 끄면 PyJWT가 `exp` 검사도 하지 않으므로 만료도 강제되지 않습니다. `iss`와 `aud`도 확인하지 않습니다.

2. **[HIGH] 관리자 정지 엔드포인트에 권한 검사가 없음**
   - 자리: `app/admin.py:13`, `ban` (CWE-862)
   - 까닭: `POST /admin/users/{user_id}/ban`을 `Depends(current_user)`만으로 보호합니다. 이것은 신원만 확인하고, `User` 모델에는 role이나 is_admin 필드가 없습니다. 그래서 인증된 사용자라면 누구든 임의 계정을 정지시킬 수 있고, 1번 결함 때문에 위조 토큰만 있으면 익명 공격자도 가능합니다.

3. **[MEDIUM] 정지된 사용자가 계속 인증됨**
   - 자리: `app/auth.py:16`, `current_user` (CWE-863)
   - 까닭: `session.get(User, ...)`로 읽고 `None`인지만 봅니다. `deleted_at`을 확인하지 않아서, 정지된 사용자의 기존 토큰(수명 30일)이 계속 통과합니다. `docs/schema.md`는 `deleted_at`이 설정된 사용자를 존재하지 않는 것으로 취급하라고 하고, `repo.py`도 `deleted_at IS NULL`로 거르는데 인증 경로만 이 규칙을 따르지 않습니다.

## 참고
- 보고서 전체(권한 상승과 우회가 이어지는 시나리오, 수정 방향 포함)는 `/tmp/tmp4dbnw1ou/CLAUDE-SECURITY-20261103-064612/`에 있습니다. `CLAUDE-SECURITY-RESULTS.md`, `.jsonl`, `.sarif`가 들어 있습니다.
- 이 디렉터리는 `.gitignore`로 커밋에서 빠집니다. 저장소가 git 저장소가 아니라 리비전은 `UNVERSIONED`로 기록됐습니다.
- 하드코딩된 시크릿은 발견되지 않았고, 시크릿을 지우는 후처리도 문제없이 끝났습니다.

원하시면 이 결함들에 대한 수정 패치 파일을 만들어 드릴 수 있습니다. 패치는 파일로만 만들어지고, 적용은 직접 하시게 됩니다.
