<!-- claude-security · 맞힘 · 떴는가 True · 비용 0.47893100000000005 -->

저장소 전체 스캔에서 결함 1건이 나왔습니다. 심각도는 HIGH입니다. 코드는 수정하지 않았습니다.

## 결함

**F1 — `GET /admin/users`에 인증·관리자 권한 검사가 없음** (HIGH, 신뢰도 high, CWE-306)
- **자리:** `app/routes.py:22`, 함수 `admin_users`
- **까닭:**
  - 이 핸들러에는 `Depends(current_user)`나 `Depends(require_admin)`이 없습니다. 같은 `/admin` 계열의 다른 라우트(`app/routes.py:18`, `app/routes.py:28`)는 `require_admin`을 씁니다. `require_admin`은 `app/auth.py:10-13`에서 401이나 403을 냅니다.
  - 라우터는 의존성 없이 만들어졌습니다. 저장소 안에 앱 진입점도 없어서 다른 곳에서 막아 주는 장치도 찾지 못했습니다.
  - 인증 없이 `GET /admin/users`를 보내면 `db.users.all()`이 그대로 돌아옵니다. 사용자 전체 목록이 노출되고, `POST /admin/users/{user_id}/role` 같은 라우트를 노릴 때 쓸 사용자 ID도 얻을 수 있습니다.
  - 수정 방향은 `admin_users`에 `Depends(require_admin)`을 추가하거나, `/admin` 라우트를 `dependencies=[Depends(require_admin)]`를 건 라우터로 묶는 것입니다.
- **검증:** 검증 패널 3명이 모두 실제 결함으로 판정했습니다. 렌더러가 찍은 검증 상태는 `verified`입니다.

## 알아 둘 점
- **한계:** 스캔은 코드를 읽기만 했고 실행하거나 공격을 재현하지는 않았습니다. README가 가리키는 `app.main:app`은 저장소에 없습니다. 거기서 미들웨어나 라우터 수준 인증을 추가한다면 F1의 노출 범위가 달라질 수 있습니다.
- **범위:** 대상은 5개 파일(`app/auth.py`, `app/routes.py`, `README.md`, `docker-compose.yml`, `.env.example`)이고 모두 읽었습니다. 연구자 4명이 모두 응답했습니다.
- **다른 파일:** `docker-compose.yml`과 `.env.example`에서는 결함이 나오지 않았습니다.
- **형상 기록:** git 저장소가 아니라서 리비전은 `UNVERSIONED`로 기록됐습니다.
- **시크릿 값:** 자격증명 값을 가리는 단계는 오류 없이 끝났습니다.

보고서는 `/tmp/tmpyy7nfseo/CLAUDE-SECURITY-20261103-065641/`에 있습니다. 사람이 읽는 `CLAUDE-SECURITY-RESULTS.md`, 기계용 `.jsonl`, `.sarif`, 리비전 기록 파일이 들어 있고, 디렉터리의 `.gitignore`가 커밋에서 제외합니다.

이 결함에 대한 수정 패치 파일이 필요하면 말씀해 주세요.
