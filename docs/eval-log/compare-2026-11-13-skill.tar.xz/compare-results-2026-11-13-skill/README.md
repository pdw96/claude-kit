# 맞대기 결과 보관 — 규칙 문장을 스킬에 담은 팔 (2026-11-13)

`docs/eval-log/2026-11.md` 「규칙 문장을 스킬에 담은 팔 — 함정 둘」의 결과다. 같은 날의 앞 측정은 `compare-2026-11-13.tar.xz`. 러너 · 재료 `8b6c81e`.
다시 만들 수 있는 `report.html` · `aggregate-result.json` 은 뺐다.

- `2026-11-13T09-41-00Z-none` — 스킬 팔 여섯 회차. `result.json` · `messages/`. 다 맞혀 `traces/` 가 없다
- `2026-11-13T09-42-31Z-none` — 스킬이 떴는지 보려고 케이스마다 한 회차씩 더 돌린 것. `traces/` 둘이 든다 — 첫 도구 호출이 `Skill`(`scope-rules-test:scope-rules`)
- `skill-plugin/` — 측정에 쓴 플러그인. 스킬 하나(`skills/scope-rules/SKILL.md`)뿐이다. 이름과 설명은 측정용 임시다
- `runner.diff` — 저장소의 `scripts/run-compare.sh` 와 측정에 쓴 복사본의 차. 첫 줄은 `none` 팔의 빈 플러그인 자리에 `SKILL_PLUGIN` 을 끼우고, 둘째 줄은 맞힌 회차의 트레이스도 남긴다(둘째 폴더에만 썼다)
- 폴더 이름과 `messages/` 머리의 팔 이름 「플러그인 없음」 · 「떴는가 False」는 러너가 `none` 팔에 붙이는 것이다 — 러너의 「떴는가」는 팔 이름으로 시작하는 호출만 세어 이 스킬을 세지 못한다
- 러너의 자격 훑기는 두 번 다 접두사 꼴 0 건이다
